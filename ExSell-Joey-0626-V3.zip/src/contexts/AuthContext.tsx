import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';

export interface AdminUser {
  id: number;
  email: string;
  display_name: string;
  role: string;
  avatar_url?: string;
  last_login?: string;
  login_count?: number;
}

interface AuthContextType {
  user: AdminUser | null;
  token: string | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  changePassword: (currentPassword: string, newPassword: string) => Promise<{ success: boolean; error?: string }>;
  isAuthenticated: boolean;
  needsSetup: boolean;
  setup: (email: string, password: string, displayName: string) => Promise<{ success: boolean; error?: string }>;
}

const AuthContext = createContext<AuthContextType>({
  user: null, token: null, loading: true, isAuthenticated: false, needsSetup: false,
  login: async () => ({ success: false }), logout: async () => {},
  changePassword: async () => ({ success: false }), setup: async () => ({ success: false }),
});

export const useAuth = () => useContext(AuthContext);

const TOKEN_KEY = 'exsell_admin_token';

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<AdminUser | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [needsSetup, setNeedsSetup] = useState(false);

  const verifyToken = useCallback(async (t: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('admin-auth', {
        body: { action: 'verify', token: t },
      });
      if (error || !data?.valid) {
        localStorage.removeItem(TOKEN_KEY);
        setUser(null);
        setToken(null);
        return false;
      }
      setUser(data.user);
      setToken(t);
      return true;
    } catch {
      localStorage.removeItem(TOKEN_KEY);
      setUser(null);
      setToken(null);
      return false;
    }
  }, []);

  useEffect(() => {
    const savedToken = localStorage.getItem(TOKEN_KEY);
    if (savedToken) {
      verifyToken(savedToken).finally(() => setLoading(false));
    } else {
      setLoading(false);
    }
  }, [verifyToken]);

  const login = async (email: string, password: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('admin-auth', {
        body: { action: 'login', email, password },
      });
      // Edge function always returns 200, so data should have the response
      const response = data || {};
      
      // Handle actual network/invocation errors
      if (error && !data) {
        let errorMsg = 'Network error';
        try {
          if (error.context && typeof error.context.json === 'function') {
            const errBody = await error.context.json();
            errorMsg = errBody?.error || errorMsg;
          } else if (error.message) {
            errorMsg = error.message;
          }
        } catch {}
        return { success: false, error: errorMsg };
      }
      
      if (response.error) return { success: false, error: response.error };
      if (response.success && response.token) {
        localStorage.setItem(TOKEN_KEY, response.token);
        setToken(response.token);
        setUser(response.user);
        return { success: true };
      }
      return { success: false, error: 'Login failed' };
    } catch (e: any) {
      return { success: false, error: e.message || 'Login failed' };
    }
  };


  const logout = async () => {
    if (token) {
      try {
        await supabase.functions.invoke('admin-auth', {
          body: { action: 'logout', token },
        });
      } catch {}
    }
    localStorage.removeItem(TOKEN_KEY);
    setUser(null);
    setToken(null);
  };

  const changePassword = async (currentPassword: string, newPassword: string) => {
    if (!token) return { success: false, error: 'Not authenticated' };
    try {
      const { data, error } = await supabase.functions.invoke('admin-auth', {
        body: { action: 'change_password', token, current_password: currentPassword, new_password: newPassword },
      });
      const response = data || {};
      if (error && !data) {
        let errorMsg = 'Network error';
        try { if (error.message) errorMsg = error.message; } catch {}
        return { success: false, error: errorMsg };
      }
      if (response.error) return { success: false, error: response.error };
      if (response.success) return { success: true };
      return { success: false, error: 'Failed to change password' };
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  };

  const setup = async (email: string, password: string, displayName: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('admin-auth', {
        body: { action: 'setup', email, password, display_name: displayName },
      });
      const response = data || {};
      if (error && !data) {
        let errorMsg = 'Network error';
        try {
          if (error.context && typeof error.context.json === 'function') {
            const errBody = await error.context.json();
            errorMsg = errBody?.error || errorMsg;
          } else if (error.message) {
            errorMsg = error.message;
          }
        } catch {}
        return { success: false, error: errorMsg };
      }
      if (response.error) return { success: false, error: response.error };
      if (response.success) {
        setNeedsSetup(false);
        return { success: true };
      }
      return { success: false, error: 'Setup failed' };
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  };


  return (
    <AuthContext.Provider value={{
      user, token, loading, login, logout, changePassword,
      isAuthenticated: !!user && !!token, needsSetup, setup,
    }}>
      {children}
    </AuthContext.Provider>
  );
};
