import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import { Vehicle } from '@/data/vehicles';
import { toast } from '@/components/ui/use-toast';

interface CompareContextType {
  compareList: Vehicle[];
  addToCompare: (vehicle: Vehicle) => void;
  removeFromCompare: (vehicleId: number) => void;
  clearCompare: () => void;
  isInCompare: (vehicleId: number) => boolean;
  canAddMore: boolean;
}

const CompareContext = createContext<CompareContextType>({
  compareList: [],
  addToCompare: () => {},
  removeFromCompare: () => {},
  clearCompare: () => {},
  isInCompare: () => false,
  canAddMore: true,
});

export const useCompare = () => useContext(CompareContext);

const MAX_COMPARE = 3;
const STORAGE_KEY = 'exsell-compare';

export const CompareProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [compareList, setCompareList] = useState<Vehicle[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch {}
    return [];
  });

  // Persist to localStorage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(compareList));
  }, [compareList]);

  const addToCompare = useCallback((vehicle: Vehicle) => {
    setCompareList((prev) => {
      if (prev.some((v) => v.id === vehicle.id)) {
        return prev;
      }
      if (prev.length >= MAX_COMPARE) {
        toast({
          title: 'Comparison Full',
          description: `You can compare up to ${MAX_COMPARE} vehicles at a time. Remove one to add another.`,
          variant: 'destructive',
        });
        return prev;
      }
      toast({
        title: 'Added to Compare',
        description: `${vehicle.year} ${vehicle.make} ${vehicle.model} added to comparison.`,
      });
      return [...prev, vehicle];
    });
  }, []);

  const removeFromCompare = useCallback((vehicleId: number) => {
    setCompareList((prev) => {
      const vehicle = prev.find((v) => v.id === vehicleId);
      if (vehicle) {
        toast({
          title: 'Removed from Compare',
          description: `${vehicle.year} ${vehicle.make} ${vehicle.model} removed.`,
        });
      }
      return prev.filter((v) => v.id !== vehicleId);
    });
  }, []);

  const clearCompare = useCallback(() => {
    setCompareList([]);
  }, []);

  const isInCompare = useCallback(
    (vehicleId: number) => compareList.some((v) => v.id === vehicleId),
    [compareList]
  );

  const canAddMore = compareList.length < MAX_COMPARE;

  return (
    <CompareContext.Provider
      value={{
        compareList,
        addToCompare,
        removeFromCompare,
        clearCompare,
        isInCompare,
        canAddMore,
      }}
    >
      {children}
    </CompareContext.Provider>
  );
};
