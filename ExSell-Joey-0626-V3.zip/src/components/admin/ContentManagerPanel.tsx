import React, { useState, useEffect, useCallback } from 'react';
import {
  Save, Loader2, CheckCircle, AlertTriangle, Plus, Trash2, ChevronDown, ChevronUp,
  FileText, Target, Heart, Shield, Award, Handshake, Star, Clock, Building2, TrendingUp,
  Sparkles, Eye, Gem, GripVertical, Users, Milestone, BookOpen, BarChart3, RefreshCw,
  Image, Palette, Layout, Wrench, MessageSquare, Phone, Home, AlignLeft, Globe, Activity,
  MapPin, Zap,
} from 'lucide-react';

import { supabase } from '@/lib/supabase';
import { toast } from '@/components/ui/use-toast';
import { saveSiteContent } from '@/hooks/useSiteContent';


// Homepage CMS imports
import {
  HeroSectionEditor, ServicesSectionEditor, WhyChooseUsEditor,
  TestimonialsEditor, ContactSectionEditor, FooterSectionEditor,
  SEOMetaEditor, AnnouncementBannerEditor,
} from './HomepageCMSEditors';
import { AnalyticsEditor } from './AnalyticsEditor';
import GooglePlaceConfigEditor from './GooglePlaceConfigEditor';
import {
  DEFAULT_HERO_SECTION, DEFAULT_SERVICES_SECTION, DEFAULT_WHY_CHOOSE_US,
  DEFAULT_TESTIMONIALS, DEFAULT_CONTACT, DEFAULT_FOOTER, DEFAULT_SEO, DEFAULT_ANALYTICS,
  DEFAULT_ANNOUNCEMENT_BANNER, HOMEPAGE_SECTIONS,
} from '@/data/homepageDefaults';
import type {
  HeroSectionContent, ServicesSectionContent, WhyChooseUsContent,
  TestimonialsSectionContent, ContactSectionContent, FooterContent, SEOContent, AnalyticsConfig,
  AnnouncementBannerContent,
} from '@/data/homepageDefaults';
import { invalidateSEOCache } from '@/hooks/usePageSEO';
import { invalidateAnalyticsCache } from '@/hooks/useAnalytics';



// ─── About Us Types ───
interface StoryContent { paragraphs: string[]; }
interface MissionContent { mission: string; vision: string; }
interface CoreValue { icon: string; title: string; description: string; color: string; }
interface MilestoneItem { year: string; title: string; description: string; icon: string; color: string; }
interface TeamMember { name: string; role: string; image: string; bio: string; color: string; }
interface HeroStat { value: string; label: string; }
interface HeroContent { subtitle: string; stats: HeroStat[]; }

// ─── About Us Default Content ───
const DEFAULT_STORY: StoryContent = {
  paragraphs: [
    "Ex$ell Car Sales LI was born in 2012 from a simple frustration: buying a used car shouldn't feel like navigating a minefield. Founder Joey Farino III, a lifelong car enthusiast and Long Island native, had seen too many friends and family members burned by shady dealers, hidden fees, and vehicles that weren't what they seemed.",
    "Starting with just eight carefully selected vehicles on a modest lot in Suffolk County, Joey set out to prove that a pre-owned dealership could be built on radical transparency. Every vehicle came with a full history report. Every price was clearly posted with no hidden add-ons. Every customer was treated like family.",
    "Word spread quickly. Neighbors told neighbors. Families came back for their second and third vehicles. What started as one man's mission became a team of passionate automotive professionals who share the same belief: you deserve better than the typical car-buying experience.",
    "Today, Ex$ell Car Sales LI is one of Long Island's most trusted names in pre-owned vehicles, with over 1,500 happy customers and a 5-star reputation that we work hard to earn every single day."
  ]
};

const DEFAULT_MISSION: MissionContent = {
  mission: "To redefine the pre-owned vehicle experience on Long Island by combining exceptional quality, radical transparency, and genuine care for every customer who walks through our doors.",
  vision: "To be the dealership that Long Island families recommend without hesitation — where every vehicle is a source of pride, every transaction is built on trust, and every customer becomes part of the Ex$ell family."
};

const DEFAULT_CORE_VALUES: CoreValue[] = [
  { icon: 'Shield', title: 'Transparency', description: 'No hidden fees, no bait-and-switch tactics. We provide full vehicle history reports, honest condition assessments, and upfront pricing on every vehicle.', color: 'from-neon-cyan to-blue-500' },
  { icon: 'Heart', title: 'Customer First', description: "Your needs drive our business. We listen, we advise, and we never pressure. If a vehicle isn't right for you, we'll be the first to say so.", color: 'from-neon-pink to-rose-500' },
  { icon: 'Award', title: 'Quality Assurance', description: 'Every vehicle undergoes a rigorous multi-point inspection. We only put our name on cars we would confidently recommend to our own families.', color: 'from-neon-orange to-amber-500' },
  { icon: 'Handshake', title: 'Community Roots', description: "We're not a faceless corporation — we're your Long Island neighbors. We sponsor local events, support area charities, and believe in giving back to the community that supports us.", color: 'from-neon-green to-emerald-500' },
  { icon: 'Gem', title: 'Integrity', description: 'We treat every customer the way we would want to be treated. Honest dealings, fair pricing, and standing behind every vehicle we sell.', color: 'from-neon-purple to-violet-500' },
  { icon: 'TrendingUp', title: 'Continuous Improvement', description: 'We constantly invest in our team, our technology, and our processes to deliver an ever-better car-buying experience.', color: 'from-yellow-400 to-orange-500' },
];

const DEFAULT_MILESTONES: MilestoneItem[] = [
  { year: '2012', title: 'The Beginning', description: 'Joey Farino III opens Ex$ell Car Sales LI from a modest lot in Suffolk County with just 8 vehicles and a dream of redefining the pre-owned car experience on Long Island.', icon: 'Building2', color: 'neon-pink' },
  { year: '2014', title: 'First 100 Sales', description: 'Within two years, word-of-mouth referrals and a commitment to honesty propel Ex$ell past its first 100 vehicle sales.', icon: 'Car', color: 'neon-orange' },
  { year: '2016', title: 'Expanded Showroom', description: 'Growing demand leads to a major facility upgrade with a larger showroom, dedicated detailing bay, and a full-service inspection center.', icon: 'TrendingUp', color: 'neon-cyan' },
  { year: '2018', title: 'Lender Partner Network', description: 'Ex$ell establishes relationships with a network of trusted lending partners.', icon: 'Handshake', color: 'neon-green' },
  { year: '2020', title: 'Digital Transformation', description: 'Launching a full online inventory experience with virtual walkarounds and contactless delivery options.', icon: 'Sparkles', color: 'neon-purple' },
  { year: '2022', title: '1,000+ Happy Customers', description: 'A decade of dedication culminates in surpassing 1,000 vehicles sold.', icon: 'Star', color: 'neon-pink' },
  { year: '2024', title: '5-Star Reputation', description: "Ex$ell earns a consistent 5-star rating across Google, Facebook, and DealerRater.", icon: 'Award', color: 'neon-orange' },
  { year: '2026', title: 'The Future', description: 'Investing in AI-powered vehicle matching, expanded delivery radius, and an even larger inventory.', icon: 'Eye', color: 'neon-cyan' },
];

const DEFAULT_TEAM: TeamMember[] = [
  { name: 'Joey Farino III', role: 'Founder & Owner', image: 'https://d64gsuwffb70l.cloudfront.net/69c07f5eedda49fd18b3c790_1774304803267_ffdd50d5.png', bio: 'With over 20 years in the automotive industry, Joey founded Ex$ell Car Sales LI with a simple vision: make buying a quality pre-owned vehicle an honest, stress-free experience.', color: 'neon-pink' },
  { name: 'Sophia Reyes', role: 'Sales Manager', image: 'https://d64gsuwffb70l.cloudfront.net/69c07f5eedda49fd18b3c790_1774304821249_778d451a.jpg', bio: "Sophia's encyclopedic knowledge of every vehicle on the lot and her genuine desire to match customers with the perfect car have made her an invaluable part of the team.", color: 'neon-cyan' },
  { name: 'David Chen', role: 'Buyer Concierge', image: 'https://d64gsuwffb70l.cloudfront.net/69c07f5eedda49fd18b3c790_1774304842393_d378fa18.png', bio: 'David walks buyers through every step of the purchase — vehicle history, paperwork, and pickup logistics — so the transaction is smooth from start to finish.', color: 'neon-green' },

  { name: 'Carlos Rivera', role: 'Lead Technician', image: 'https://d64gsuwffb70l.cloudfront.net/69c07f5eedda49fd18b3c790_1774304858352_d5e5637b.jpg', bio: 'ASE-certified with 12 years of experience, Carlos leads our multi-point inspection process.', color: 'neon-orange' },
  { name: 'Aisha Johnson', role: 'Customer Experience Lead', image: 'https://d64gsuwffb70l.cloudfront.net/69c07f5eedda49fd18b3c790_1774304879648_c14f0906.png', bio: "Aisha ensures every customer interaction is exceptional.", color: 'neon-purple' },
  { name: 'Jake Morrison', role: 'Detailing Specialist', image: 'https://d64gsuwffb70l.cloudfront.net/69c07f5eedda49fd18b3c790_1774304898157_8a2920f4.jpg', bio: "Jake's obsession with perfection means every vehicle that leaves our lot looks showroom-ready.", color: 'neon-cyan' },
];

const DEFAULT_HERO: HeroContent = {
  subtitle: "More than a dealership — we're a Long Island family dedicated to helping you find the perfect vehicle with honesty, transparency, and a personal touch you won't find anywhere else.",
  stats: [
    { value: '14+', label: 'Years in Business' },
    { value: '1,500+', label: 'Vehicles Sold' },
    { value: '5.0', label: 'Star Rating' },
    { value: '98%', label: 'Customer Satisfaction' },
  ]
};

const ICON_OPTIONS = ['Shield', 'Heart', 'Award', 'Handshake', 'Gem', 'TrendingUp', 'Star', 'Building2', 'Clock', 'Sparkles', 'Eye', 'Car', 'Target', 'ThumbsUp', 'Wrench'];
const COLOR_OPTIONS = [
  { label: 'Pink', value: 'neon-pink', gradient: 'from-neon-pink to-rose-500', dot: 'bg-pink-500' },
  { label: 'Cyan', value: 'neon-cyan', gradient: 'from-neon-cyan to-blue-500', dot: 'bg-cyan-400' },
  { label: 'Green', value: 'neon-green', gradient: 'from-neon-green to-emerald-500', dot: 'bg-green-400' },
  { label: 'Orange', value: 'neon-orange', gradient: 'from-neon-orange to-amber-500', dot: 'bg-orange-400' },
  { label: 'Purple', value: 'neon-purple', gradient: 'from-neon-purple to-violet-500', dot: 'bg-purple-500' },
  { label: 'Yellow', value: 'yellow', gradient: 'from-yellow-400 to-orange-500', dot: 'bg-yellow-400' },
];

// ─── Helpers ───
async function loadSection<T>(section: string, fallback: T): Promise<T> {
  try {
    const { data, error } = await supabase.from('site_content').select('content').eq('section', section).single();
    if (error || !data) return fallback;
    return data.content as T;
  } catch { return fallback; }
}

async function saveSection(section: string, content: any): Promise<boolean> {
  // Use the safe select-then-update-or-insert helper to avoid the
  // "no unique or exclusion constraint matching the ON CONFLICT specification"
  // error that can occur when PostgREST's schema cache is stale or when the
  // UNIQUE constraint on site_content.section isn't present in a given
  // environment. This helper works reliably in all cases.
  const result = await saveSiteContent(section, content);
  if (!result.success) {
    toast({ title: 'Save Failed', description: result.error || 'Unknown error', variant: 'destructive' });
    return false;
  }
  toast({
    title: 'Content Saved',
    description: `${section.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase())} has been updated. Changes are live on the website.`,
  });
  return true;
}


// ─── Main Component ───
type CMSTab = 'story' | 'mission' | 'values' | 'milestones' | 'team' | 'hero' | 'hp_announcement' | 'hp_hero' | 'hp_services' | 'hp_whychoose' | 'hp_testimonials' | 'hp_contact' | 'hp_footer' | 'hp_seo' | 'hp_analytics' | 'hp_google_place';




const ContentManagerPanel: React.FC = () => {
  const [activeTab, setActiveTab] = useState<CMSTab>('hp_hero');
  const [loading, setLoading] = useState(true);

  // About Us content state
  const [story, setStory] = useState<StoryContent>(DEFAULT_STORY);
  const [mission, setMission] = useState<MissionContent>(DEFAULT_MISSION);
  const [coreValues, setCoreValues] = useState<CoreValue[]>(DEFAULT_CORE_VALUES);
  const [milestones, setMilestones] = useState<MilestoneItem[]>(DEFAULT_MILESTONES);
  const [team, setTeam] = useState<TeamMember[]>(DEFAULT_TEAM);
  const [hero, setHero] = useState<HeroContent>(DEFAULT_HERO);

  const [hpHero, setHpHero] = useState<HeroSectionContent>(DEFAULT_HERO_SECTION);
  const [hpServices, setHpServices] = useState<ServicesSectionContent>(DEFAULT_SERVICES_SECTION);
  const [hpWhyChoose, setHpWhyChoose] = useState<WhyChooseUsContent>(DEFAULT_WHY_CHOOSE_US);
  const [hpTestimonials, setHpTestimonials] = useState<TestimonialsSectionContent>(DEFAULT_TESTIMONIALS);
  const [hpContact, setHpContact] = useState<ContactSectionContent>(DEFAULT_CONTACT);
  const [hpFooter, setHpFooter] = useState<FooterContent>(DEFAULT_FOOTER);
  const [hpSeo, setHpSeo] = useState<SEOContent>(DEFAULT_SEO);
  const [hpAnalytics, setHpAnalytics] = useState<AnalyticsConfig>(DEFAULT_ANALYTICS);
  const [hpAnnouncement, setHpAnnouncement] = useState<AnnouncementBannerContent>(DEFAULT_ANNOUNCEMENT_BANNER);


  // Save states
  const [saving, setSaving] = useState(false);
  const [lastSaved, setLastSaved] = useState<Record<string, Date>>({});

  // Load all content on mount
  useEffect(() => {
    const loadAll = async () => {
      setLoading(true);
      const [s, m, cv, ms, t, h, hh, hs, hw, ht, hc, hf, seo, analytics, announcement] = await Promise.all([
        loadSection<StoryContent>('about_story', DEFAULT_STORY),
        loadSection<MissionContent>('about_mission', DEFAULT_MISSION),
        loadSection<CoreValue[]>('about_core_values', DEFAULT_CORE_VALUES),
        loadSection<MilestoneItem[]>('about_milestones', DEFAULT_MILESTONES),
        loadSection<TeamMember[]>('about_team', DEFAULT_TEAM),
        loadSection<HeroContent>('about_hero', DEFAULT_HERO),
        loadSection<HeroSectionContent>(HOMEPAGE_SECTIONS.hero, DEFAULT_HERO_SECTION),
        loadSection<ServicesSectionContent>(HOMEPAGE_SECTIONS.services, DEFAULT_SERVICES_SECTION),
        loadSection<WhyChooseUsContent>(HOMEPAGE_SECTIONS.whyChooseUs, DEFAULT_WHY_CHOOSE_US),
        loadSection<TestimonialsSectionContent>(HOMEPAGE_SECTIONS.testimonials, DEFAULT_TESTIMONIALS),
        loadSection<ContactSectionContent>(HOMEPAGE_SECTIONS.contact, DEFAULT_CONTACT),
        loadSection<FooterContent>(HOMEPAGE_SECTIONS.footer, DEFAULT_FOOTER),
        loadSection<SEOContent>(HOMEPAGE_SECTIONS.seo, DEFAULT_SEO),
        loadSection<AnalyticsConfig>(HOMEPAGE_SECTIONS.analytics, DEFAULT_ANALYTICS),
        loadSection<AnnouncementBannerContent>(HOMEPAGE_SECTIONS.announcement, DEFAULT_ANNOUNCEMENT_BANNER),
      ]);
      setStory(s); setMission(m); setCoreValues(cv); setMilestones(ms); setTeam(t); setHero(h);
      setHpHero(hh); setHpServices(hs); setHpWhyChoose(hw); setHpTestimonials(ht); setHpContact(hc); setHpFooter(hf);
      setHpSeo(seo); setHpAnalytics(analytics);
      // Merge with defaults so any legacy/partial stored row still has every field the editor expects.
      setHpAnnouncement({ ...DEFAULT_ANNOUNCEMENT_BANNER, ...(announcement || {}) });
      setLoading(false);


    };
    loadAll();
  }, []);

  const handleSave = async (section: string, content: any) => {
    setSaving(true);
    const ok = await saveSection(section, content);
    if (ok) {
      setLastSaved(prev => ({ ...prev, [section]: new Date() }));
      if (section === HOMEPAGE_SECTIONS.seo) {
        invalidateSEOCache();
      }
      if (section === HOMEPAGE_SECTIONS.analytics) {
        invalidateAnalyticsCache();
      }
    }
    setSaving(false);
  };

  const allDefaults: Record<string, any> = {
    about_story: DEFAULT_STORY, about_mission: DEFAULT_MISSION, about_core_values: DEFAULT_CORE_VALUES,
    about_milestones: DEFAULT_MILESTONES, about_team: DEFAULT_TEAM, about_hero: DEFAULT_HERO,
    [HOMEPAGE_SECTIONS.hero]: DEFAULT_HERO_SECTION, [HOMEPAGE_SECTIONS.services]: DEFAULT_SERVICES_SECTION,
    [HOMEPAGE_SECTIONS.whyChooseUs]: DEFAULT_WHY_CHOOSE_US, [HOMEPAGE_SECTIONS.testimonials]: DEFAULT_TESTIMONIALS,
    [HOMEPAGE_SECTIONS.contact]: DEFAULT_CONTACT, [HOMEPAGE_SECTIONS.footer]: DEFAULT_FOOTER,
    [HOMEPAGE_SECTIONS.seo]: DEFAULT_SEO, [HOMEPAGE_SECTIONS.analytics]: DEFAULT_ANALYTICS,
    [HOMEPAGE_SECTIONS.announcement]: DEFAULT_ANNOUNCEMENT_BANNER,

  };


  const handleResetSection = (section: string) => {
    const def = allDefaults[section];
    if (!def) return;
    switch (section) {
      case 'about_story': setStory(def); break;
      case 'about_mission': setMission(def); break;
      case 'about_core_values': setCoreValues(def); break;
      case 'about_milestones': setMilestones(def); break;
      case 'about_team': setTeam(def); break;
      case 'about_hero': setHero(def); break;
      case HOMEPAGE_SECTIONS.hero: setHpHero(def); break;
      case HOMEPAGE_SECTIONS.services: setHpServices(def); break;
      case HOMEPAGE_SECTIONS.whyChooseUs: setHpWhyChoose(def); break;
      case HOMEPAGE_SECTIONS.testimonials: setHpTestimonials(def); break;
      case HOMEPAGE_SECTIONS.contact: setHpContact(def); break;
      case HOMEPAGE_SECTIONS.footer: setHpFooter(def); break;
      case HOMEPAGE_SECTIONS.seo: setHpSeo(def); break;
      case HOMEPAGE_SECTIONS.announcement: setHpAnnouncement(def); break;
    }

    toast({ title: 'Reset to Default', description: 'Content has been reset. Click Save to apply.' });
  };

  // Tab definitions - grouped by page
  const homepageTabs: { key: CMSTab; label: string; icon: React.ElementType; section: string }[] = [
    { key: 'hp_announcement', label: 'Announcement Bar', icon: Sparkles, section: HOMEPAGE_SECTIONS.announcement },
    { key: 'hp_hero', label: 'Hero', icon: Layout, section: HOMEPAGE_SECTIONS.hero },

    { key: 'hp_services', label: 'Services', icon: Wrench, section: HOMEPAGE_SECTIONS.services },
    { key: 'hp_whychoose', label: 'Why Choose Us', icon: Award, section: HOMEPAGE_SECTIONS.whyChooseUs },
    { key: 'hp_testimonials', label: 'Testimonials', icon: MessageSquare, section: HOMEPAGE_SECTIONS.testimonials },
    { key: 'hp_contact', label: 'Contact', icon: Phone, section: HOMEPAGE_SECTIONS.contact },
    { key: 'hp_footer', label: 'Footer', icon: AlignLeft, section: HOMEPAGE_SECTIONS.footer },
  ];

  const seoTab: { key: CMSTab; label: string; icon: React.ElementType; section: string } = 
    { key: 'hp_seo', label: 'SEO & Meta Tags', icon: Globe, section: HOMEPAGE_SECTIONS.seo };

  const aboutTabs: { key: CMSTab; label: string; icon: React.ElementType; section: string }[] = [
    { key: 'story', label: 'Our Story', icon: BookOpen, section: 'about_story' },
    { key: 'mission', label: 'Mission & Vision', icon: Target, section: 'about_mission' },
    { key: 'values', label: 'Core Values', icon: Heart, section: 'about_core_values' },
    { key: 'milestones', label: 'Milestones', icon: Milestone, section: 'about_milestones' },
    { key: 'team', label: 'Team Members', icon: Users, section: 'about_team' },
    { key: 'hero', label: 'Hero & Stats', icon: BarChart3, section: 'about_hero' },
  ];

  const allTabs = [...homepageTabs, seoTab, ...aboutTabs];
  const currentTab = allTabs.find(t => t.key === activeTab) || homepageTabs[0];

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="text-center">
          <Loader2 className="w-8 h-8 text-neon-cyan animate-spin mx-auto mb-3" />
          <p className="text-gray-400 text-sm">Loading site content...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-white font-bold text-lg flex items-center gap-2">
            <FileText className="w-5 h-5 text-neon-cyan" />
            Website Content Manager
          </h2>
          <p className="text-gray-500 text-sm mt-1">
            Edit homepage, About Us, and SEO content. Changes go live immediately after saving.
          </p>
        </div>
        {activeTab !== 'hp_seo' && activeTab !== 'hp_analytics' && activeTab !== 'hp_google_place' && (
          <button onClick={() => handleResetSection(currentTab.section)}
            className="flex items-center gap-1.5 px-3 py-2 text-gray-500 hover:text-gray-300 text-xs border border-white/5 rounded-lg hover:border-white/10 transition-all">
            <RefreshCw className="w-3.5 h-3.5" /> Reset to Default
          </button>
        )}

      </div>

      {/* Page Section Headers + Tab Navigation */}
      <div className="space-y-3">
        {/* Homepage Section */}
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Home className="w-3.5 h-3.5 text-neon-pink" />
            <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">Homepage</span>
            <div className="flex-1 h-px bg-white/5" />
          </div>
          <div className="flex flex-wrap gap-1 bg-white/[0.02] border border-white/5 rounded-xl p-1">
            {homepageTabs.map(tab => {
              const Icon = tab.icon;
              const saved = lastSaved[tab.section];
              return (
                <button key={tab.key} onClick={() => setActiveTab(tab.key)}
                  className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-semibold transition-all whitespace-nowrap ${
                    activeTab === tab.key
                      ? 'bg-gradient-to-r from-neon-pink/20 to-neon-orange/20 text-white border border-neon-pink/30'
                      : 'text-gray-500 hover:text-gray-300 hover:bg-white/[0.03]'
                  }`}>
                  <Icon className="w-4 h-4" />
                  <span className="hidden md:inline">{tab.label}</span>
                  {saved && <CheckCircle className="w-3 h-3 text-neon-green" />}
                </button>
              );
            })}
          </div>
        </div>

        {/* SEO & Meta Tags Section */}
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Globe className="w-3.5 h-3.5 text-neon-green" />
            <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">SEO & Meta Tags</span>
            <div className="flex-1 h-px bg-white/5" />
          </div>
          <div className="flex flex-wrap gap-1 bg-white/[0.02] border border-white/5 rounded-xl p-1">
            <button onClick={() => setActiveTab('hp_seo')}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-semibold transition-all whitespace-nowrap ${
                activeTab === 'hp_seo'
                  ? 'bg-gradient-to-r from-neon-green/20 to-emerald-500/20 text-white border border-neon-green/30'
                  : 'text-gray-500 hover:text-gray-300 hover:bg-white/[0.03]'
              }`}>
              <Globe className="w-4 h-4" />
              <span className="hidden md:inline">SEO & Meta Tags</span>
              {lastSaved[HOMEPAGE_SECTIONS.seo] && <CheckCircle className="w-3 h-3 text-neon-green" />}
            </button>
          </div>
        </div>


        <div>
          <div className="flex items-center gap-2 mb-2">
            <Activity className="w-3.5 h-3.5 text-neon-orange" />
            <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">Analytics & Tracking</span>
            <div className="flex-1 h-px bg-white/5" />
          </div>
          <div className="flex flex-wrap gap-1 bg-white/[0.02] border border-white/5 rounded-xl p-1">
            <button onClick={() => setActiveTab('hp_analytics')}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-semibold transition-all whitespace-nowrap ${
                activeTab === 'hp_analytics'
                  ? 'bg-gradient-to-r from-neon-orange/20 to-amber-500/20 text-white border border-neon-orange/30'
                  : 'text-gray-500 hover:text-gray-300 hover:bg-white/[0.03]'
              }`}>
              <Activity className="w-4 h-4" />
              <span className="hidden md:inline">Google Analytics / GTM</span>
              {lastSaved[HOMEPAGE_SECTIONS.analytics] && <CheckCircle className="w-3 h-3 text-neon-green" />}
            </button>
          </div>
        </div>

        {/* Integrations Section — Google Place ID, etc. */}
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Zap className="w-3.5 h-3.5 text-neon-purple" />
            <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">Integrations</span>
            <div className="flex-1 h-px bg-white/5" />
          </div>
          <div className="flex flex-wrap gap-1 bg-white/[0.02] border border-white/5 rounded-xl p-1">
            <button onClick={() => setActiveTab('hp_google_place')}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-semibold transition-all whitespace-nowrap ${
                activeTab === 'hp_google_place'
                  ? 'bg-gradient-to-r from-neon-purple/20 to-violet-500/20 text-white border border-neon-purple/30'
                  : 'text-gray-500 hover:text-gray-300 hover:bg-white/[0.03]'
              }`}>
              <MapPin className="w-4 h-4" />
              <span className="hidden md:inline">Google Place ID</span>
            </button>
          </div>
        </div>


        {/* About Us Section */}
        <div>
          <div className="flex items-center gap-2 mb-2">
            <BookOpen className="w-3.5 h-3.5 text-neon-cyan" />
            <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">About Us Page</span>
            <div className="flex-1 h-px bg-white/5" />
          </div>
          <div className="flex flex-wrap gap-1 bg-white/[0.02] border border-white/5 rounded-xl p-1">
            {aboutTabs.map(tab => {
              const Icon = tab.icon;
              const saved = lastSaved[tab.section];
              return (
                <button key={tab.key} onClick={() => setActiveTab(tab.key)}
                  className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-semibold transition-all whitespace-nowrap ${
                    activeTab === tab.key
                      ? 'bg-gradient-to-r from-neon-cyan/20 to-blue-500/20 text-white border border-neon-cyan/30'
                      : 'text-gray-500 hover:text-gray-300 hover:bg-white/[0.03]'
                  }`}>
                  <Icon className="w-4 h-4" />
                  <span className="hidden md:inline">{tab.label}</span>
                  {saved && <CheckCircle className="w-3 h-3 text-neon-green" />}
                </button>
              );
            })}
          </div>
        </div>
      </div>


      {/* Tab Content */}
      <div className="bg-white/[0.02] border border-white/5 rounded-2xl p-6">
        {/* Homepage editors */}
        {activeTab === 'hp_announcement' && (
          <AnnouncementBannerEditor data={hpAnnouncement} onChange={setHpAnnouncement} onSave={() => handleSave(HOMEPAGE_SECTIONS.announcement, hpAnnouncement)} saving={saving} />
        )}
        {activeTab === 'hp_hero' && (

          <HeroSectionEditor data={hpHero} onChange={setHpHero} onSave={() => handleSave(HOMEPAGE_SECTIONS.hero, hpHero)} saving={saving} />
        )}
        {activeTab === 'hp_services' && (
          <ServicesSectionEditor data={hpServices} onChange={setHpServices} onSave={() => handleSave(HOMEPAGE_SECTIONS.services, hpServices)} saving={saving} />
        )}
        {activeTab === 'hp_whychoose' && (
          <WhyChooseUsEditor data={hpWhyChoose} onChange={setHpWhyChoose} onSave={() => handleSave(HOMEPAGE_SECTIONS.whyChooseUs, hpWhyChoose)} saving={saving} />
        )}
        {activeTab === 'hp_testimonials' && (
          <TestimonialsEditor data={hpTestimonials} onChange={setHpTestimonials} onSave={() => handleSave(HOMEPAGE_SECTIONS.testimonials, hpTestimonials)} saving={saving} />
        )}
        {activeTab === 'hp_contact' && (
          <ContactSectionEditor data={hpContact} onChange={setHpContact} onSave={() => handleSave(HOMEPAGE_SECTIONS.contact, hpContact)} saving={saving} />
        )}
        {activeTab === 'hp_footer' && (
          <FooterSectionEditor data={hpFooter} onChange={setHpFooter} onSave={() => handleSave(HOMEPAGE_SECTIONS.footer, hpFooter)} saving={saving} />
        )}

        {/* SEO editor */}
        {activeTab === 'hp_seo' && (
          <SEOMetaEditor data={hpSeo} onChange={setHpSeo} onSave={() => handleSave(HOMEPAGE_SECTIONS.seo, hpSeo)} saving={saving} />
        )}
        {/* Analytics editor */}
        {activeTab === 'hp_analytics' && (
          <AnalyticsEditor data={hpAnalytics} onChange={setHpAnalytics} onSave={() => handleSave(HOMEPAGE_SECTIONS.analytics, hpAnalytics)} saving={saving} />
        )}

        {/* Integrations — Google Place ID */}
        {activeTab === 'hp_google_place' && (
          <GooglePlaceConfigEditor />
        )}


        {/* About Us editors */}

        {/* About Us editors */}
        {activeTab === 'story' && (
          <StoryEditor story={story} onChange={setStory} onSave={() => handleSave('about_story', story)} saving={saving} />
        )}
        {activeTab === 'mission' && (
          <MissionEditor mission={mission} onChange={setMission} onSave={() => handleSave('about_mission', mission)} saving={saving} />
        )}
        {activeTab === 'values' && (
          <CoreValuesEditor values={coreValues} onChange={setCoreValues} onSave={() => handleSave('about_core_values', coreValues)} saving={saving} />
        )}
        {activeTab === 'milestones' && (
          <MilestonesEditor milestones={milestones} onChange={setMilestones} onSave={() => handleSave('about_milestones', milestones)} saving={saving} />
        )}
        {activeTab === 'team' && (
          <TeamEditor team={team} onChange={setTeam} onSave={() => handleSave('about_team', team)} saving={saving} />
        )}
        {activeTab === 'hero' && (
          <HeroEditor hero={hero} onChange={setHero} onSave={() => handleSave('about_hero', hero)} saving={saving} />
        )}
      </div>
    </div>
  );
};


// ─── Save Button ───
const SaveButton: React.FC<{ onSave: () => void; saving: boolean; label?: string }> = ({ onSave, saving, label = 'Save Changes' }) => (
  <button onClick={onSave} disabled={saving}
    className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-neon-cyan to-blue-500 text-white font-bold rounded-xl hover:opacity-90 transition-opacity disabled:opacity-50 shadow-lg shadow-neon-cyan/20">
    {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
    {label}
  </button>
);

// ─── Story Editor ───
const StoryEditor: React.FC<{ story: StoryContent; onChange: (s: StoryContent) => void; onSave: () => void; saving: boolean; }> = ({ story, onChange, onSave, saving }) => {
  const updateParagraph = (index: number, value: string) => { const updated = [...story.paragraphs]; updated[index] = value; onChange({ ...story, paragraphs: updated }); };
  const addParagraph = () => { onChange({ ...story, paragraphs: [...story.paragraphs, ''] }); };
  const removeParagraph = (index: number) => { if (story.paragraphs.length <= 1) return; onChange({ ...story, paragraphs: story.paragraphs.filter((_, i) => i !== index) }); };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-white font-bold text-base mb-1 flex items-center gap-2"><BookOpen className="w-4 h-4 text-neon-pink" /> Our Story — About Us Page</h3>
        <p className="text-gray-500 text-sm">Edit the story paragraphs that appear in the "Built on Trust, Driven by Passion" section.</p>
      </div>
      <div className="space-y-4">
        {story.paragraphs.map((p, i) => (
          <div key={i} className="relative group">
            <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">Paragraph {i + 1}</label>
            <textarea value={p} onChange={(e) => updateParagraph(i, e.target.value)} rows={4}
              className="w-full px-4 py-3 bg-white/[0.03] border border-white/10 rounded-xl text-white text-sm placeholder-gray-600 focus:border-neon-cyan focus:outline-none focus:ring-1 focus:ring-neon-cyan/30 transition-all resize-y"
              placeholder={`Enter paragraph ${i + 1}...`} />
            <div className="flex items-center justify-between mt-1">
              <span className="text-gray-600 text-xs">{p.length} characters</span>
              {story.paragraphs.length > 1 && (
                <button onClick={() => removeParagraph(i)} className="text-gray-600 hover:text-red-400 text-xs flex items-center gap-1 transition-colors opacity-0 group-hover:opacity-100">
                  <Trash2 className="w-3 h-3" /> Remove
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
      <button onClick={addParagraph} className="flex items-center gap-2 px-4 py-2.5 border border-dashed border-white/10 rounded-xl text-gray-500 hover:text-white hover:border-white/20 transition-all text-sm">
        <Plus className="w-4 h-4" /> Add Paragraph
      </button>
      <div className="flex justify-end pt-4 border-t border-white/5"><SaveButton onSave={onSave} saving={saving} /></div>
    </div>
  );
};

// ─── Mission Editor ───
const MissionEditor: React.FC<{ mission: MissionContent; onChange: (m: MissionContent) => void; onSave: () => void; saving: boolean; }> = ({ mission, onChange, onSave, saving }) => (
  <div className="space-y-6">
    <div>
      <h3 className="text-white font-bold text-base mb-1 flex items-center gap-2"><Target className="w-4 h-4 text-neon-cyan" /> Mission Statement & Vision</h3>
      <p className="text-gray-500 text-sm">Edit the mission quote and vision statement displayed on the About Us page.</p>
    </div>
    <div>
      <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">Mission Statement</label>
      <textarea value={mission.mission} onChange={(e) => onChange({ ...mission, mission: e.target.value })} rows={4}
        className="w-full px-4 py-3 bg-white/[0.03] border border-white/10 rounded-xl text-white text-sm placeholder-gray-600 focus:border-neon-cyan focus:outline-none focus:ring-1 focus:ring-neon-cyan/30 transition-all resize-y" />
    </div>
    <div>
      <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">Vision Statement</label>
      <textarea value={mission.vision} onChange={(e) => onChange({ ...mission, vision: e.target.value })} rows={4}
        className="w-full px-4 py-3 bg-white/[0.03] border border-white/10 rounded-xl text-white text-sm placeholder-gray-600 focus:border-neon-cyan focus:outline-none focus:ring-1 focus:ring-neon-cyan/30 transition-all resize-y" />
    </div>
    <div className="flex justify-end pt-4 border-t border-white/5"><SaveButton onSave={onSave} saving={saving} /></div>
  </div>
);

// ─── Core Values Editor ───
const CoreValuesEditor: React.FC<{ values: CoreValue[]; onChange: (v: CoreValue[]) => void; onSave: () => void; saving: boolean; }> = ({ values, onChange, onSave, saving }) => {
  const [expandedIndex, setExpandedIndex] = useState<number | null>(null);
  const updateValue = (index: number, field: keyof CoreValue, val: string) => { const updated = [...values]; updated[index] = { ...updated[index], [field]: val }; onChange(updated); };
  const addValue = () => { onChange([...values, { icon: 'Star', title: '', description: '', color: 'from-neon-cyan to-blue-500' }]); setExpandedIndex(values.length); };
  const removeValue = (index: number) => { onChange(values.filter((_, i) => i !== index)); setExpandedIndex(null); };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-white font-bold text-base mb-1 flex items-center gap-2"><Heart className="w-4 h-4 text-neon-pink" /> Core Values</h3>
        <p className="text-gray-500 text-sm">Edit the values displayed in the "What We Stand For" section. ({values.length} values)</p>
      </div>
      <div className="space-y-3">
        {values.map((value, i) => (
          <div key={i} className="bg-white/[0.02] border border-white/5 rounded-xl overflow-hidden">
            <button onClick={() => setExpandedIndex(expandedIndex === i ? null : i)} className="w-full flex items-center justify-between px-4 py-3 hover:bg-white/[0.02] transition-colors">
              <div className="flex items-center gap-3">
                <GripVertical className="w-4 h-4 text-gray-600" />
                <span className="text-white font-semibold text-sm">{value.title || `Value ${i + 1}`}</span>
              </div>
              {expandedIndex === i ? <ChevronUp className="w-4 h-4 text-gray-500" /> : <ChevronDown className="w-4 h-4 text-gray-500" />}
            </button>
            {expandedIndex === i && (
              <div className="px-4 pb-4 space-y-4 border-t border-white/5 pt-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div><label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1.5">Title</label>
                    <input value={value.title} onChange={(e) => updateValue(i, 'title', e.target.value)} className="w-full px-3 py-2.5 bg-white/[0.03] border border-white/10 rounded-lg text-white text-sm focus:border-neon-cyan focus:outline-none" /></div>
                  <div><label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1.5">Icon</label>
                    <select value={value.icon} onChange={(e) => updateValue(i, 'icon', e.target.value)} className="w-full px-3 py-2.5 bg-white/[0.03] border border-white/10 rounded-lg text-white text-sm focus:border-neon-cyan focus:outline-none">
                      {ICON_OPTIONS.map(icon => <option key={icon} value={icon}>{icon}</option>)}
                    </select></div>
                </div>
                <div><label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1.5">Description</label>
                  <textarea value={value.description} onChange={(e) => updateValue(i, 'description', e.target.value)} rows={3} className="w-full px-3 py-2.5 bg-white/[0.03] border border-white/10 rounded-lg text-white text-sm focus:border-neon-cyan focus:outline-none resize-y" /></div>
                <div><label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1.5">Color Theme</label>
                  <div className="flex flex-wrap gap-2">
                    {COLOR_OPTIONS.map(c => (
                      <button key={c.value} onClick={() => updateValue(i, 'color', c.gradient)}
                        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${value.color === c.gradient ? 'border-white/30 bg-white/10 text-white' : 'border-white/5 text-gray-500 hover:border-white/10'}`}>
                        <span className={`w-2.5 h-2.5 rounded-full ${c.dot}`} />{c.label}
                      </button>
                    ))}
                  </div></div>
                <div className="flex justify-end">
                  <button onClick={() => removeValue(i)} className="flex items-center gap-1.5 px-3 py-1.5 text-red-400 hover:bg-red-500/10 rounded-lg text-xs font-medium transition-colors">
                    <Trash2 className="w-3.5 h-3.5" /> Remove Value
                  </button></div>
              </div>
            )}
          </div>
        ))}
      </div>
      <button onClick={addValue} className="flex items-center gap-2 px-4 py-2.5 border border-dashed border-white/10 rounded-xl text-gray-500 hover:text-white hover:border-white/20 transition-all text-sm w-full justify-center">
        <Plus className="w-4 h-4" /> Add Core Value
      </button>
      <div className="flex justify-end pt-4 border-t border-white/5"><SaveButton onSave={onSave} saving={saving} /></div>
    </div>
  );
};

// ─── Milestones Editor ───
const MilestonesEditor: React.FC<{ milestones: MilestoneItem[]; onChange: (m: MilestoneItem[]) => void; onSave: () => void; saving: boolean; }> = ({ milestones, onChange, onSave, saving }) => {
  const [expandedIndex, setExpandedIndex] = useState<number | null>(null);
  const updateMilestone = (index: number, field: keyof MilestoneItem, val: string) => { const updated = [...milestones]; updated[index] = { ...updated[index], [field]: val }; onChange(updated); };
  const addMilestone = () => { onChange([...milestones, { year: new Date().getFullYear().toString(), title: '', description: '', icon: 'Star', color: 'neon-pink' }]); setExpandedIndex(milestones.length); };
  const removeMilestone = (index: number) => { onChange(milestones.filter((_, i) => i !== index)); setExpandedIndex(null); };
  const moveMilestone = (index: number, direction: 'up' | 'down') => {
    const newIndex = direction === 'up' ? index - 1 : index + 1;
    if (newIndex < 0 || newIndex >= milestones.length) return;
    const updated = [...milestones]; [updated[index], updated[newIndex]] = [updated[newIndex], updated[index]]; onChange(updated); setExpandedIndex(newIndex);
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-white font-bold text-base mb-1 flex items-center gap-2"><Milestone className="w-4 h-4 text-neon-orange" /> Timeline Milestones</h3>
        <p className="text-gray-500 text-sm">Edit the milestones in the "Our Journey" timeline section. ({milestones.length} milestones)</p>
      </div>
      <div className="space-y-3">
        {milestones.map((ms, i) => (
          <div key={i} className="bg-white/[0.02] border border-white/5 rounded-xl overflow-hidden">
            <button onClick={() => setExpandedIndex(expandedIndex === i ? null : i)} className="w-full flex items-center justify-between px-4 py-3 hover:bg-white/[0.02] transition-colors">
              <div className="flex items-center gap-3">
                <span className="text-neon-orange font-bold text-xs bg-neon-orange/10 px-2 py-0.5 rounded">{ms.year}</span>
                <span className="text-white font-semibold text-sm">{ms.title || `Milestone ${i + 1}`}</span>
              </div>
              <div className="flex items-center gap-1">
                <button onClick={(e) => { e.stopPropagation(); moveMilestone(i, 'up'); }} disabled={i === 0} className="p-1 text-gray-600 hover:text-white disabled:opacity-30 transition-colors"><ChevronUp className="w-3.5 h-3.5" /></button>
                <button onClick={(e) => { e.stopPropagation(); moveMilestone(i, 'down'); }} disabled={i === milestones.length - 1} className="p-1 text-gray-600 hover:text-white disabled:opacity-30 transition-colors"><ChevronDown className="w-3.5 h-3.5" /></button>
                {expandedIndex === i ? <ChevronUp className="w-4 h-4 text-gray-500 ml-2" /> : <ChevronDown className="w-4 h-4 text-gray-500 ml-2" />}
              </div>
            </button>
            {expandedIndex === i && (
              <div className="px-4 pb-4 space-y-4 border-t border-white/5 pt-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div><label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1.5">Year</label>
                    <input value={ms.year} onChange={(e) => updateMilestone(i, 'year', e.target.value)} className="w-full px-3 py-2.5 bg-white/[0.03] border border-white/10 rounded-lg text-white text-sm focus:border-neon-cyan focus:outline-none" /></div>
                  <div><label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1.5">Title</label>
                    <input value={ms.title} onChange={(e) => updateMilestone(i, 'title', e.target.value)} className="w-full px-3 py-2.5 bg-white/[0.03] border border-white/10 rounded-lg text-white text-sm focus:border-neon-cyan focus:outline-none" /></div>
                  <div><label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1.5">Icon</label>
                    <select value={ms.icon} onChange={(e) => updateMilestone(i, 'icon', e.target.value)} className="w-full px-3 py-2.5 bg-white/[0.03] border border-white/10 rounded-lg text-white text-sm focus:border-neon-cyan focus:outline-none">
                      {ICON_OPTIONS.map(icon => <option key={icon} value={icon}>{icon}</option>)}
                    </select></div>
                </div>
                <div><label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1.5">Description</label>
                  <textarea value={ms.description} onChange={(e) => updateMilestone(i, 'description', e.target.value)} rows={3} className="w-full px-3 py-2.5 bg-white/[0.03] border border-white/10 rounded-lg text-white text-sm focus:border-neon-cyan focus:outline-none resize-y" /></div>
                <div><label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1.5">Color</label>
                  <div className="flex flex-wrap gap-2">
                    {COLOR_OPTIONS.filter(c => c.value !== 'yellow').map(c => (
                      <button key={c.value} onClick={() => updateMilestone(i, 'color', c.value)}
                        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${ms.color === c.value ? 'border-white/30 bg-white/10 text-white' : 'border-white/5 text-gray-500 hover:border-white/10'}`}>
                        <span className={`w-2.5 h-2.5 rounded-full ${c.dot}`} />{c.label}
                      </button>
                    ))}
                  </div></div>
                <div className="flex justify-end">
                  <button onClick={() => removeMilestone(i)} className="flex items-center gap-1.5 px-3 py-1.5 text-red-400 hover:bg-red-500/10 rounded-lg text-xs font-medium transition-colors">
                    <Trash2 className="w-3.5 h-3.5" /> Remove Milestone
                  </button></div>
              </div>
            )}
          </div>
        ))}
      </div>
      <button onClick={addMilestone} className="flex items-center gap-2 px-4 py-2.5 border border-dashed border-white/10 rounded-xl text-gray-500 hover:text-white hover:border-white/20 transition-all text-sm w-full justify-center">
        <Plus className="w-4 h-4" /> Add Milestone
      </button>
      <div className="flex justify-end pt-4 border-t border-white/5"><SaveButton onSave={onSave} saving={saving} /></div>
    </div>
  );
};

// ─── Team Editor ───
const TeamEditor: React.FC<{ team: TeamMember[]; onChange: (t: TeamMember[]) => void; onSave: () => void; saving: boolean; }> = ({ team, onChange, onSave, saving }) => {
  const [expandedIndex, setExpandedIndex] = useState<number | null>(null);
  const updateMember = (index: number, field: keyof TeamMember, val: string) => { const updated = [...team]; updated[index] = { ...updated[index], [field]: val }; onChange(updated); };
  const addMember = () => { onChange([...team, { name: '', role: '', image: '', bio: '', color: 'neon-pink' }]); setExpandedIndex(team.length); };
  const removeMember = (index: number) => { onChange(team.filter((_, i) => i !== index)); setExpandedIndex(null); };
  const moveMember = (index: number, direction: 'up' | 'down') => {
    const newIndex = direction === 'up' ? index - 1 : index + 1;
    if (newIndex < 0 || newIndex >= team.length) return;
    const updated = [...team]; [updated[index], updated[newIndex]] = [updated[newIndex], updated[index]]; onChange(updated); setExpandedIndex(newIndex);
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-white font-bold text-base mb-1 flex items-center gap-2"><Users className="w-4 h-4 text-neon-green" /> Team Members</h3>
        <p className="text-gray-500 text-sm">Edit the team members displayed on the About Us page. ({team.length} members)</p>
      </div>
      <div className="space-y-3">
        {team.map((member, i) => (
          <div key={i} className="bg-white/[0.02] border border-white/5 rounded-xl overflow-hidden">
            <button onClick={() => setExpandedIndex(expandedIndex === i ? null : i)} className="w-full flex items-center justify-between px-4 py-3 hover:bg-white/[0.02] transition-colors">
              <div className="flex items-center gap-3">
                {member.image ? <img src={member.image} alt={member.name} className="w-8 h-8 rounded-full object-cover" /> : <div className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center"><Users className="w-4 h-4 text-gray-600" /></div>}
                <div className="text-left">
                  <span className="text-white font-semibold text-sm block">{member.name || `Team Member ${i + 1}`}</span>
                  <span className="text-gray-500 text-xs">{member.role || 'No role set'}</span>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <button onClick={(e) => { e.stopPropagation(); moveMember(i, 'up'); }} disabled={i === 0} className="p-1 text-gray-600 hover:text-white disabled:opacity-30 transition-colors"><ChevronUp className="w-3.5 h-3.5" /></button>
                <button onClick={(e) => { e.stopPropagation(); moveMember(i, 'down'); }} disabled={i === team.length - 1} className="p-1 text-gray-600 hover:text-white disabled:opacity-30 transition-colors"><ChevronDown className="w-3.5 h-3.5" /></button>
                {expandedIndex === i ? <ChevronUp className="w-4 h-4 text-gray-500 ml-2" /> : <ChevronDown className="w-4 h-4 text-gray-500 ml-2" />}
              </div>
            </button>
            {expandedIndex === i && (
              <div className="px-4 pb-4 space-y-4 border-t border-white/5 pt-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div><label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1.5">Full Name</label>
                    <input value={member.name} onChange={(e) => updateMember(i, 'name', e.target.value)} className="w-full px-3 py-2.5 bg-white/[0.03] border border-white/10 rounded-lg text-white text-sm focus:border-neon-cyan focus:outline-none" /></div>
                  <div><label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1.5">Role / Title</label>
                    <input value={member.role} onChange={(e) => updateMember(i, 'role', e.target.value)} className="w-full px-3 py-2.5 bg-white/[0.03] border border-white/10 rounded-lg text-white text-sm focus:border-neon-cyan focus:outline-none" /></div>
                </div>
                <div><label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1.5">Photo URL</label>
                  <div className="flex gap-3">
                    <input value={member.image} onChange={(e) => updateMember(i, 'image', e.target.value)} className="flex-1 px-3 py-2.5 bg-white/[0.03] border border-white/10 rounded-lg text-white text-sm focus:border-neon-cyan focus:outline-none" placeholder="https://..." />
                    {member.image && <img src={member.image} alt="Preview" className="w-10 h-10 rounded-lg object-cover border border-white/10" />}
                  </div></div>
                <div><label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1.5">Bio</label>
                  <textarea value={member.bio} onChange={(e) => updateMember(i, 'bio', e.target.value)} rows={3} className="w-full px-3 py-2.5 bg-white/[0.03] border border-white/10 rounded-lg text-white text-sm focus:border-neon-cyan focus:outline-none resize-y" />
                  <span className="text-gray-600 text-xs mt-1 block">{member.bio.length} characters</span></div>
                <div><label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1.5">Accent Color</label>
                  <div className="flex flex-wrap gap-2">
                    {COLOR_OPTIONS.filter(c => c.value !== 'yellow').map(c => (
                      <button key={c.value} onClick={() => updateMember(i, 'color', c.value)}
                        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${member.color === c.value ? 'border-white/30 bg-white/10 text-white' : 'border-white/5 text-gray-500 hover:border-white/10'}`}>
                        <span className={`w-2.5 h-2.5 rounded-full ${c.dot}`} />{c.label}
                      </button>
                    ))}
                  </div></div>
                <div className="flex justify-end">
                  <button onClick={() => removeMember(i)} className="flex items-center gap-1.5 px-3 py-1.5 text-red-400 hover:bg-red-500/10 rounded-lg text-xs font-medium transition-colors">
                    <Trash2 className="w-3.5 h-3.5" /> Remove Member
                  </button></div>
              </div>
            )}
          </div>
        ))}
      </div>
      <button onClick={addMember} className="flex items-center gap-2 px-4 py-2.5 border border-dashed border-white/10 rounded-xl text-gray-500 hover:text-white hover:border-white/20 transition-all text-sm w-full justify-center">
        <Plus className="w-4 h-4" /> Add Team Member
      </button>
      <div className="flex justify-end pt-4 border-t border-white/5"><SaveButton onSave={onSave} saving={saving} /></div>
    </div>
  );
};

// ─── Hero Editor (About Us page) ───
const HeroEditor: React.FC<{ hero: HeroContent; onChange: (h: HeroContent) => void; onSave: () => void; saving: boolean; }> = ({ hero, onChange, onSave, saving }) => {
  const updateStat = (index: number, field: 'value' | 'label', val: string) => { const updated = [...hero.stats]; updated[index] = { ...updated[index], [field]: val }; onChange({ ...hero, stats: updated }); };
  const addStat = () => { onChange({ ...hero, stats: [...hero.stats, { value: '', label: '' }] }); };
  const removeStat = (index: number) => { if (hero.stats.length <= 1) return; onChange({ ...hero, stats: hero.stats.filter((_, i) => i !== index) }); };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-white font-bold text-base mb-1 flex items-center gap-2"><BarChart3 className="w-4 h-4 text-neon-cyan" /> About Us Hero Section & Stats</h3>
        <p className="text-gray-500 text-sm">Edit the hero subtitle and the quick stats shown at the top of the About Us page.</p>
      </div>
      <div>
        <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">Hero Subtitle</label>
        <textarea value={hero.subtitle} onChange={(e) => onChange({ ...hero, subtitle: e.target.value })} rows={3}
          className="w-full px-4 py-3 bg-white/[0.03] border border-white/10 rounded-xl text-white text-sm placeholder-gray-600 focus:border-neon-cyan focus:outline-none focus:ring-1 focus:ring-neon-cyan/30 transition-all resize-y" />
      </div>
      <div>
        <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3">Quick Stats ({hero.stats.length})</label>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {hero.stats.map((stat, i) => (
            <div key={i} className="flex items-center gap-2 bg-white/[0.02] border border-white/5 rounded-xl p-3">
              <div className="flex-1 space-y-2">
                <input value={stat.value} onChange={(e) => updateStat(i, 'value', e.target.value)} className="w-full px-3 py-2 bg-white/[0.03] border border-white/10 rounded-lg text-white text-sm font-bold focus:border-neon-cyan focus:outline-none" placeholder="14+" />
                <input value={stat.label} onChange={(e) => updateStat(i, 'label', e.target.value)} className="w-full px-3 py-2 bg-white/[0.03] border border-white/10 rounded-lg text-gray-300 text-xs focus:border-neon-cyan focus:outline-none" placeholder="Years in Business" />
              </div>
              {hero.stats.length > 1 && <button onClick={() => removeStat(i)} className="p-1.5 text-gray-600 hover:text-red-400 transition-colors"><Trash2 className="w-3.5 h-3.5" /></button>}
            </div>
          ))}
        </div>
        {hero.stats.length < 6 && (
          <button onClick={addStat} className="flex items-center gap-2 px-4 py-2 border border-dashed border-white/10 rounded-xl text-gray-500 hover:text-white hover:border-white/20 transition-all text-sm mt-3">
            <Plus className="w-4 h-4" /> Add Stat
          </button>
        )}
      </div>
      <div className="flex justify-end pt-4 border-t border-white/5"><SaveButton onSave={onSave} saving={saving} /></div>
    </div>
  );
};

export default ContentManagerPanel;
