import React, { useState } from 'react';
import {
  Sparkles, Loader2, TrendingUp, TrendingDown, Minus, Target,
  DollarSign, Clock, BarChart3, ChevronDown, ChevronUp, Zap,
  ArrowRight, CheckCircle, AlertTriangle, RefreshCw, X, Info
} from 'lucide-react';
import { Vehicle } from '@/data/vehicles';
import { supabase } from '@/lib/supabase';

interface PricingData {
  suggestedPrice: number;
  lowPrice: number;
  fairPrice: number;
  highPrice: number;
  confidence: number;
  reasoning: string;
  marketTrend: 'rising' | 'stable' | 'declining';
  demandLevel: 'high' | 'moderate' | 'low';
  daysToSell: number;
  comparables: {
    year: number;
    make: string;
    model: string;
    trim: string;
    mileage: number;
    price: number;
    daysOnMarket: number;
    source: string;
  }[];
  adjustments: {
    factor: string;
    impact: number;
    description: string;
  }[];
}

interface AIPricingPanelProps {
  vehicle: Partial<Vehicle>;
  currentPrice: number;
  onApplyPrice: (price: number) => void;
  compact?: boolean;
}

const AIPricingPanel: React.FC<AIPricingPanelProps> = ({
  vehicle,
  currentPrice,
  onApplyPrice,
  compact = false,
}) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [pricing, setPricing] = useState<PricingData | null>(null);
  const [showComparables, setShowComparables] = useState(false);
  const [showAdjustments, setShowAdjustments] = useState(false);
  const [appliedPrice, setAppliedPrice] = useState<number | null>(null);

  const canAnalyze = vehicle.year && vehicle.make && vehicle.model;

  const fetchPricing = async () => {
    if (!canAnalyze) return;
    setLoading(true);
    setError('');
    setPricing(null);
    setAppliedPrice(null);

    try {
      const { data, error: fnError } = await supabase.functions.invoke('ai-pricing', {
        body: {
          year: vehicle.year,
          make: vehicle.make,
          model: vehicle.model,
          trim: vehicle.trim,
          mileage: vehicle.mileage,
          bodyType: vehicle.bodyType,
          drivetrain: vehicle.drivetrain,
          fuelType: vehicle.fuelType,
          engine: vehicle.engine,
          features: vehicle.features,
          exteriorColor: vehicle.exteriorColor,
          condition: vehicle.status === 'available' ? 'Good' : vehicle.status,
        },
      });

      if (fnError) throw new Error(fnError.message || 'Failed to connect to pricing service');
      if (data?.error) throw new Error(data.error);
      if (!data?.pricing) throw new Error('No pricing data returned');

      setPricing(data.pricing);
    } catch (err: any) {
      setError(err.message || 'Failed to get pricing recommendation');
    } finally {
      setLoading(false);
    }
  };

  const handleApplyPrice = (price: number) => {
    onApplyPrice(price);
    setAppliedPrice(price);
  };

  // Calculate gauge position (0-100%) for a given price within the range
  const getGaugePosition = (price: number): number => {
    if (!pricing) return 50;
    const range = pricing.highPrice - pricing.lowPrice;
    if (range <= 0) return 50;
    const pos = ((price - pricing.lowPrice) / range) * 100;
    return Math.max(0, Math.min(100, pos));
  };

  const formatPrice = (p: number) => `$${p.toLocaleString()}`;

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'rising': return <TrendingUp className="w-3.5 h-3.5" />;
      case 'declining': return <TrendingDown className="w-3.5 h-3.5" />;
      default: return <Minus className="w-3.5 h-3.5" />;
    }
  };

  const getTrendColor = (trend: string) => {
    switch (trend) {
      case 'rising': return 'text-emerald-400';
      case 'declining': return 'text-red-400';
      default: return 'text-yellow-400';
    }
  };

  const getDemandColor = (demand: string) => {
    switch (demand) {
      case 'high': return 'text-emerald-400 bg-emerald-400/10 border-emerald-400/20';
      case 'low': return 'text-red-400 bg-red-400/10 border-red-400/20';
      default: return 'text-yellow-400 bg-yellow-400/10 border-yellow-400/20';
    }
  };

  const getPriceDiff = () => {
    if (!pricing || !currentPrice) return null;
    const diff = currentPrice - pricing.suggestedPrice;
    const pct = ((diff / pricing.suggestedPrice) * 100).toFixed(1);
    return { diff, pct, isOver: diff > 0, isUnder: diff < 0 };
  };

  // ── Not yet analyzed ──
  if (!pricing && !loading && !error) {
    return (
      <div className={`rounded-xl border border-indigo-500/20 bg-gradient-to-br from-indigo-500/[0.06] to-purple-500/[0.04] overflow-hidden ${compact ? '' : ''}`}>
        <div className="p-4">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center flex-shrink-0 shadow-lg shadow-indigo-500/20">
              <Sparkles className="w-4.5 h-4.5 text-white" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                AI Price Advisor
                <span className="px-1.5 py-0.5 bg-indigo-500/20 text-indigo-300 text-[10px] font-bold rounded-full uppercase tracking-wider">AI</span>
              </h3>
              <p className="text-xs text-gray-400 mt-0.5">
                Get market-based pricing recommendations powered by AI
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={fetchPricing}
            disabled={!canAnalyze}
            className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-gradient-to-r from-indigo-500 to-purple-600 text-white font-bold rounded-xl hover:opacity-90 transition-all disabled:opacity-40 disabled:cursor-not-allowed shadow-lg shadow-indigo-500/20 text-sm"
          >
            <Sparkles className="w-4 h-4" />
            Analyze Market Price
          </button>

          {!canAnalyze && (
            <p className="text-xs text-gray-500 mt-2 flex items-center gap-1.5">
              <Info className="w-3 h-3" />
              Enter year, make, and model first to enable AI pricing
            </p>
          )}
        </div>
      </div>
    );
  }

  // ── Loading ──
  if (loading) {
    return (
      <div className="rounded-xl border border-indigo-500/30 bg-gradient-to-br from-indigo-500/[0.08] to-purple-500/[0.05] p-6">
        <div className="flex flex-col items-center justify-center py-4">
          <div className="relative mb-4">
            <div className="absolute -inset-3 bg-indigo-500/20 rounded-full blur-xl animate-pulse" />
            <div className="relative w-14 h-14 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center shadow-xl shadow-indigo-500/30">
              <Sparkles className="w-7 h-7 text-white animate-pulse" />
            </div>
          </div>
          <div className="flex items-center gap-2 mb-2">
            <Loader2 className="w-4 h-4 text-indigo-400 animate-spin" />
            <span className="text-sm font-semibold text-white">Analyzing Market Data...</span>
          </div>
          <p className="text-xs text-gray-400 text-center max-w-xs">
            Comparing {vehicle.year} {vehicle.make} {vehicle.model} against recent sales, market trends, and demand data
          </p>
          <div className="flex gap-1 mt-4">
            {[0, 1, 2, 3, 4].map(i => (
              <div
                key={i}
                className="w-2 h-2 rounded-full bg-indigo-400"
                style={{
                  animation: `pulse 1.4s ease-in-out ${i * 0.2}s infinite`,
                  opacity: 0.3,
                }}
              />
            ))}
          </div>
        </div>
      </div>
    );
  }

  // ── Error ──
  if (error) {
    return (
      <div className="rounded-xl border border-red-500/20 bg-red-500/[0.05] p-4">
        <div className="flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="text-sm font-semibold text-red-300">Pricing Analysis Failed</p>
            <p className="text-xs text-red-400/70 mt-1">{error}</p>
            <div className="flex gap-3 mt-3">
              <button
                type="button"
                onClick={fetchPricing}
                className="text-xs text-indigo-400 hover:text-indigo-300 transition-colors flex items-center gap-1 font-medium"
              >
                <RefreshCw className="w-3 h-3" />
                Try Again
              </button>
              <button
                type="button"
                onClick={() => { setError(''); setPricing(null); }}
                className="text-xs text-gray-500 hover:text-white transition-colors"
              >
                Dismiss
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ── Results ──
  if (!pricing) return null;

  const priceDiff = getPriceDiff();
  const suggestedPos = getGaugePosition(pricing.suggestedPrice);
  const currentPos = currentPrice > 0 ? getGaugePosition(currentPrice) : null;

  return (
    <div className="rounded-xl border border-indigo-500/30 bg-gradient-to-br from-indigo-500/[0.06] to-purple-500/[0.04] overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-white/5">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center shadow-lg shadow-indigo-500/20">
            <Sparkles className="w-4 h-4 text-white" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white">AI Price Recommendation</h3>
            <p className="text-[11px] text-gray-500">
              {vehicle.year} {vehicle.make} {vehicle.model} {vehicle.trim}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={fetchPricing}
            className="p-1.5 text-gray-500 hover:text-indigo-400 transition-colors rounded-lg hover:bg-white/5"
            title="Re-analyze"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={() => { setPricing(null); setError(''); }}
            className="p-1.5 text-gray-500 hover:text-white transition-colors rounded-lg hover:bg-white/5"
            title="Close"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      <div className="p-4 space-y-5">
        {/* ── Suggested Price Hero ── */}
        <div className="text-center">
          <p className="text-xs text-gray-400 uppercase tracking-wider font-medium mb-1">Recommended Listing Price</p>
          <div className="flex items-center justify-center gap-2">
            <span className="text-3xl font-black text-white tracking-tight">
              {formatPrice(pricing.suggestedPrice)}
            </span>
            {appliedPrice === pricing.suggestedPrice ? (
              <span className="flex items-center gap-1 px-2 py-1 bg-emerald-500/10 border border-emerald-500/20 rounded-full text-emerald-400 text-[10px] font-bold">
                <CheckCircle className="w-3 h-3" /> Applied
              </span>
            ) : (
              <button
                type="button"
                onClick={() => handleApplyPrice(pricing.suggestedPrice)}
                className="flex items-center gap-1 px-2.5 py-1 bg-indigo-500/10 border border-indigo-500/30 rounded-full text-indigo-300 text-[10px] font-bold hover:bg-indigo-500/20 transition-colors"
              >
                <Zap className="w-3 h-3" /> Apply
              </button>
            )}
          </div>

          {/* Price comparison with current */}
          {priceDiff && currentPrice > 0 && (
            <div className={`inline-flex items-center gap-1.5 mt-2 px-3 py-1.5 rounded-full text-xs font-medium ${
              priceDiff.isOver
                ? 'bg-amber-500/10 border border-amber-500/20 text-amber-400'
                : priceDiff.isUnder
                ? 'bg-emerald-500/10 border border-emerald-500/20 text-emerald-400'
                : 'bg-gray-500/10 border border-gray-500/20 text-gray-400'
            }`}>
              {priceDiff.isOver ? (
                <>
                  <TrendingDown className="w-3 h-3" />
                  Current price is {formatPrice(Math.abs(priceDiff.diff))} ({Math.abs(Number(priceDiff.pct))}%) above market
                </>
              ) : priceDiff.isUnder ? (
                <>
                  <TrendingUp className="w-3 h-3" />
                  Current price is {formatPrice(Math.abs(priceDiff.diff))} ({Math.abs(Number(priceDiff.pct))}%) below market
                </>
              ) : (
                <>
                  <CheckCircle className="w-3 h-3" />
                  Current price matches market value
                </>
              )}
            </div>
          )}
        </div>

        {/* ── Visual Price Gauge ── */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-[10px] text-gray-500 uppercase tracking-wider font-medium">
            <span>Below Market</span>
            <span>Fair Market</span>
            <span>Premium</span>
          </div>

          {/* Gauge bar */}
          <div className="relative h-10">
            {/* Background gradient bar */}
            <div className="absolute top-3 left-0 right-0 h-4 rounded-full overflow-hidden">
              <div className="w-full h-full bg-gradient-to-r from-blue-500 via-emerald-500 via-50% to-amber-500 opacity-30" />
              {/* Segments */}
              <div className="absolute inset-0 flex">
                <div className="flex-1 border-r border-white/10" />
                <div className="flex-1 border-r border-white/10" />
                <div className="flex-1" />
              </div>
            </div>

            {/* Low price marker */}
            <div
              className="absolute top-3 h-4 flex items-center"
              style={{ left: '0%' }}
            >
              <div className="w-0.5 h-full bg-blue-400/60" />
            </div>

            {/* Fair price marker */}
            <div
              className="absolute top-3 h-4 flex items-center"
              style={{ left: `${getGaugePosition(pricing.fairPrice)}%`, transform: 'translateX(-50%)' }}
            >
              <div className="w-0.5 h-full bg-emerald-400/60" />
            </div>

            {/* High price marker */}
            <div
              className="absolute top-3 h-4 flex items-center"
              style={{ left: '100%', transform: 'translateX(-100%)' }}
            >
              <div className="w-0.5 h-full bg-amber-400/60" />
            </div>

            {/* Current price indicator (if set) */}
            {currentPos !== null && currentPrice > 0 && appliedPrice !== pricing.suggestedPrice && (
              <div
                className="absolute top-1 flex flex-col items-center z-10 transition-all duration-500"
                style={{ left: `${currentPos}%`, transform: 'translateX(-50%)' }}
              >
                <div className="w-3 h-3 rounded-full bg-orange-400 border-2 border-orange-300 shadow-lg shadow-orange-400/30" />
                <div className="w-0.5 h-2 bg-orange-400/60" />
              </div>
            )}

            {/* Suggested price indicator */}
            <div
              className="absolute top-0 flex flex-col items-center z-20 transition-all duration-500"
              style={{ left: `${suggestedPos}%`, transform: 'translateX(-50%)' }}
            >
              <div className="w-4 h-4 rounded-full bg-indigo-400 border-2 border-white shadow-lg shadow-indigo-400/40 flex items-center justify-center">
                <div className="w-1.5 h-1.5 rounded-full bg-white" />
              </div>
              <div className="w-0.5 h-3 bg-indigo-400/60" />
            </div>
          </div>

          {/* Price labels */}
          <div className="flex items-center justify-between text-xs">
            <button
              type="button"
              onClick={() => handleApplyPrice(pricing.lowPrice)}
              className={`flex flex-col items-start group ${appliedPrice === pricing.lowPrice ? 'opacity-100' : 'opacity-70 hover:opacity-100'} transition-opacity`}
            >
              <span className="text-blue-400 font-bold group-hover:underline">{formatPrice(pricing.lowPrice)}</span>
              <span className="text-[10px] text-gray-500">Quick Sale</span>
              {appliedPrice === pricing.lowPrice && (
                <span className="text-[9px] text-emerald-400 flex items-center gap-0.5 mt-0.5"><CheckCircle className="w-2.5 h-2.5" /> Applied</span>
              )}
            </button>
            <button
              type="button"
              onClick={() => handleApplyPrice(pricing.fairPrice)}
              className={`flex flex-col items-center group ${appliedPrice === pricing.fairPrice ? 'opacity-100' : 'opacity-70 hover:opacity-100'} transition-opacity`}
            >
              <span className="text-emerald-400 font-bold group-hover:underline">{formatPrice(pricing.fairPrice)}</span>
              <span className="text-[10px] text-gray-500">Fair Market</span>
              {appliedPrice === pricing.fairPrice && (
                <span className="text-[9px] text-emerald-400 flex items-center gap-0.5 mt-0.5"><CheckCircle className="w-2.5 h-2.5" /> Applied</span>
              )}
            </button>
            <button
              type="button"
              onClick={() => handleApplyPrice(pricing.highPrice)}
              className={`flex flex-col items-end group ${appliedPrice === pricing.highPrice ? 'opacity-100' : 'opacity-70 hover:opacity-100'} transition-opacity`}
            >
              <span className="text-amber-400 font-bold group-hover:underline">{formatPrice(pricing.highPrice)}</span>
              <span className="text-[10px] text-gray-500">Premium</span>
              {appliedPrice === pricing.highPrice && (
                <span className="text-[9px] text-emerald-400 flex items-center gap-0.5 mt-0.5"><CheckCircle className="w-2.5 h-2.5" /> Applied</span>
              )}
            </button>
          </div>

          {/* Legend */}
          {currentPrice > 0 && appliedPrice !== pricing.suggestedPrice && (
            <div className="flex items-center gap-4 justify-center mt-1">
              <div className="flex items-center gap-1.5 text-[10px] text-gray-500">
                <div className="w-2.5 h-2.5 rounded-full bg-indigo-400 border border-white/50" />
                Suggested
              </div>
              <div className="flex items-center gap-1.5 text-[10px] text-gray-500">
                <div className="w-2.5 h-2.5 rounded-full bg-orange-400 border border-orange-300/50" />
                Current ({formatPrice(currentPrice)})
              </div>
            </div>
          )}
        </div>

        {/* ── Market Insights Row ── */}
        <div className="grid grid-cols-3 gap-2">
          <div className="bg-white/[0.03] border border-white/5 rounded-lg p-2.5 text-center">
            <div className={`flex items-center justify-center gap-1 mb-1 ${getTrendColor(pricing.marketTrend)}`}>
              {getTrendIcon(pricing.marketTrend)}
              <span className="text-xs font-bold capitalize">{pricing.marketTrend}</span>
            </div>
            <p className="text-[10px] text-gray-500">Market Trend</p>
          </div>
          <div className="bg-white/[0.03] border border-white/5 rounded-lg p-2.5 text-center">
            <div className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full border text-xs font-bold mb-1 ${getDemandColor(pricing.demandLevel)}`}>
              <BarChart3 className="w-3 h-3" />
              {pricing.demandLevel.charAt(0).toUpperCase() + pricing.demandLevel.slice(1)}
            </div>
            <p className="text-[10px] text-gray-500">Demand</p>
          </div>
          <div className="bg-white/[0.03] border border-white/5 rounded-lg p-2.5 text-center">
            <div className="flex items-center justify-center gap-1 text-white mb-1">
              <Clock className="w-3 h-3 text-gray-400" />
              <span className="text-xs font-bold">~{pricing.daysToSell}d</span>
            </div>
            <p className="text-[10px] text-gray-500">Est. Days to Sell</p>
          </div>
        </div>

        {/* ── Confidence Bar ── */}
        <div className="bg-white/[0.02] border border-white/5 rounded-lg p-3">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-gray-400 font-medium flex items-center gap-1.5">
              <Target className="w-3.5 h-3.5 text-indigo-400" />
              Confidence Score
            </span>
            <span className={`text-xs font-bold ${
              pricing.confidence >= 80 ? 'text-emerald-400' :
              pricing.confidence >= 60 ? 'text-yellow-400' :
              'text-red-400'
            }`}>
              {pricing.confidence}%
            </span>
          </div>
          <div className="h-1.5 bg-black/40 rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-1000 ${
                pricing.confidence >= 80 ? 'bg-gradient-to-r from-emerald-500 to-emerald-400' :
                pricing.confidence >= 60 ? 'bg-gradient-to-r from-yellow-500 to-yellow-400' :
                'bg-gradient-to-r from-red-500 to-red-400'
              }`}
              style={{ width: `${pricing.confidence}%` }}
            />
          </div>
          <p className="text-[11px] text-gray-500 mt-2 leading-relaxed">{pricing.reasoning}</p>
        </div>

        {/* ── Price Adjustments ── */}
        {pricing.adjustments && pricing.adjustments.length > 0 && (
          <div className="border border-white/5 rounded-lg overflow-hidden">
            <button
              type="button"
              onClick={() => setShowAdjustments(!showAdjustments)}
              className="w-full flex items-center justify-between p-3 hover:bg-white/[0.02] transition-colors"
            >
              <span className="text-xs font-semibold text-gray-300 flex items-center gap-2">
                <DollarSign className="w-3.5 h-3.5 text-indigo-400" />
                Price Adjustments ({pricing.adjustments.length})
              </span>
              {showAdjustments ? <ChevronUp className="w-4 h-4 text-gray-500" /> : <ChevronDown className="w-4 h-4 text-gray-500" />}
            </button>
            {showAdjustments && (
              <div className="border-t border-white/5">
                {pricing.adjustments.map((adj, i) => (
                  <div key={i} className="flex items-center justify-between px-3 py-2.5 border-b border-white/[0.03] last:border-0 hover:bg-white/[0.01]">
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium text-gray-300">{adj.factor}</p>
                      <p className="text-[10px] text-gray-500 mt-0.5">{adj.description}</p>
                    </div>
                    <span className={`text-xs font-bold ml-3 flex-shrink-0 ${
                      adj.impact > 0 ? 'text-emerald-400' : adj.impact < 0 ? 'text-red-400' : 'text-gray-400'
                    }`}>
                      {adj.impact > 0 ? '+' : ''}{formatPrice(adj.impact)}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ── Comparable Sales ── */}
        {pricing.comparables && pricing.comparables.length > 0 && (
          <div className="border border-white/5 rounded-lg overflow-hidden">
            <button
              type="button"
              onClick={() => setShowComparables(!showComparables)}
              className="w-full flex items-center justify-between p-3 hover:bg-white/[0.02] transition-colors"
            >
              <span className="text-xs font-semibold text-gray-300 flex items-center gap-2">
                <BarChart3 className="w-3.5 h-3.5 text-indigo-400" />
                Comparable Sales ({pricing.comparables.length})
              </span>
              {showComparables ? <ChevronUp className="w-4 h-4 text-gray-500" /> : <ChevronDown className="w-4 h-4 text-gray-500" />}
            </button>
            {showComparables && (
              <div className="border-t border-white/5">
                {/* Table Header */}
                <div className="grid grid-cols-12 gap-2 px-3 py-2 bg-white/[0.02] text-[10px] text-gray-500 uppercase tracking-wider font-semibold">
                  <div className="col-span-4">Vehicle</div>
                  <div className="col-span-2 text-right">Mileage</div>
                  <div className="col-span-2 text-right">Price</div>
                  <div className="col-span-2 text-right">Days</div>
                  <div className="col-span-2 text-right">Source</div>
                </div>
                {/* Table Rows */}
                {pricing.comparables.map((comp, i) => {
                  const priceDiffFromComp = comp.price - pricing.suggestedPrice;
                  return (
                    <div key={i} className="grid grid-cols-12 gap-2 px-3 py-2.5 border-t border-white/[0.03] hover:bg-white/[0.02] transition-colors items-center">
                      <div className="col-span-4">
                        <p className="text-xs text-gray-300 font-medium truncate">
                          {comp.year} {comp.model}
                        </p>
                        <p className="text-[10px] text-gray-600 truncate">{comp.trim}</p>
                      </div>
                      <div className="col-span-2 text-right">
                        <span className="text-xs text-gray-400">{(comp.mileage / 1000).toFixed(0)}K mi</span>
                      </div>
                      <div className="col-span-2 text-right">
                        <span className="text-xs font-bold text-white">{formatPrice(comp.price)}</span>
                      </div>
                      <div className="col-span-2 text-right">
                        <span className="text-xs text-gray-400">{comp.daysOnMarket}d</span>
                      </div>
                      <div className="col-span-2 text-right">
                        <span className="text-[10px] text-gray-500 truncate block">{comp.source}</span>
                      </div>
                    </div>
                  );
                })}
                {/* Average row */}
                <div className="grid grid-cols-12 gap-2 px-3 py-2.5 border-t border-white/10 bg-white/[0.02]">
                  <div className="col-span-4">
                    <span className="text-xs text-indigo-400 font-bold">Average</span>
                  </div>
                  <div className="col-span-2 text-right">
                    <span className="text-xs text-gray-400">
                      {(pricing.comparables.reduce((s, c) => s + c.mileage, 0) / pricing.comparables.length / 1000).toFixed(0)}K mi
                    </span>
                  </div>
                  <div className="col-span-2 text-right">
                    <span className="text-xs font-bold text-indigo-400">
                      {formatPrice(Math.round(pricing.comparables.reduce((s, c) => s + c.price, 0) / pricing.comparables.length))}
                    </span>
                  </div>
                  <div className="col-span-2 text-right">
                    <span className="text-xs text-gray-400">
                      {Math.round(pricing.comparables.reduce((s, c) => s + c.daysOnMarket, 0) / pricing.comparables.length)}d
                    </span>
                  </div>
                  <div className="col-span-2" />
                </div>
              </div>
            )}
          </div>
        )}

        {/* ── Quick Apply Buttons ── */}
        <div className="grid grid-cols-3 gap-2">
          <button
            type="button"
            onClick={() => handleApplyPrice(pricing.lowPrice)}
            className={`py-2.5 rounded-lg text-xs font-bold transition-all ${
              appliedPrice === pricing.lowPrice
                ? 'bg-blue-500/20 border border-blue-500/40 text-blue-300'
                : 'bg-white/[0.03] border border-white/10 text-gray-400 hover:text-blue-400 hover:border-blue-500/30'
            }`}
          >
            {appliedPrice === pricing.lowPrice ? (
              <span className="flex items-center justify-center gap-1"><CheckCircle className="w-3 h-3" /> Applied</span>
            ) : (
              <span className="flex items-center justify-center gap-1"><ArrowRight className="w-3 h-3" /> Use Low</span>
            )}
          </button>
          <button
            type="button"
            onClick={() => handleApplyPrice(pricing.suggestedPrice)}
            className={`py-2.5 rounded-lg text-xs font-bold transition-all ${
              appliedPrice === pricing.suggestedPrice
                ? 'bg-indigo-500/20 border border-indigo-500/40 text-indigo-300'
                : 'bg-gradient-to-r from-indigo-500/20 to-purple-500/20 border border-indigo-500/30 text-indigo-300 hover:from-indigo-500/30 hover:to-purple-500/30'
            }`}
          >
            {appliedPrice === pricing.suggestedPrice ? (
              <span className="flex items-center justify-center gap-1"><CheckCircle className="w-3 h-3" /> Applied</span>
            ) : (
              <span className="flex items-center justify-center gap-1"><Sparkles className="w-3 h-3" /> Use Suggested</span>
            )}
          </button>
          <button
            type="button"
            onClick={() => handleApplyPrice(pricing.highPrice)}
            className={`py-2.5 rounded-lg text-xs font-bold transition-all ${
              appliedPrice === pricing.highPrice
                ? 'bg-amber-500/20 border border-amber-500/40 text-amber-300'
                : 'bg-white/[0.03] border border-white/10 text-gray-400 hover:text-amber-400 hover:border-amber-500/30'
            }`}
          >
            {appliedPrice === pricing.highPrice ? (
              <span className="flex items-center justify-center gap-1"><CheckCircle className="w-3 h-3" /> Applied</span>
            ) : (
              <span className="flex items-center justify-center gap-1"><ArrowRight className="w-3 h-3" /> Use High</span>
            )}
          </button>
        </div>

        {/* Powered by footer */}
        <div className="flex items-center justify-center gap-1.5 text-[10px] text-gray-600 pt-1">
          <Sparkles className="w-3 h-3" />
          Powered by AI market analysis
        </div>
      </div>
    </div>
  );
};

export default AIPricingPanel;
