import React, { useRef, useState, useEffect } from 'react';
import {
  Save, Loader2, Plus, Trash2, ChevronDown, ChevronUp,
  Zap, Wrench, Star, GripVertical, MessageSquare, Phone,
  MapPin, Clock, Layout, Sparkles, Shield, Award, Handshake,
  Link2, AlignLeft, Globe, Search, Image, FileText, Eye, AlertCircle,
  Upload, Check, Images, X, RefreshCw, AlertTriangle
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';
import { resizeToOgImage, isFarFromOgRatio, dataUrlToFile, OG_IMAGE_WIDTH, OG_IMAGE_HEIGHT, OG_IMAGE_RATIO } from '@/lib/imageCompression';
import ImageCropModal from '@/components/admin/ImageCropModal';

import type {
  HeroSectionContent, ServicesSectionContent, WhyChooseUsContent,
  TestimonialsSectionContent, ContactSectionContent, FooterContent,
  ServiceItem, WhyChooseUsReason, TestimonialItem, FooterQuickLink,
  SEOContent, SEOPageKey, SEOPageMeta, AnnouncementBannerContent,
} from '@/data/homepageDefaults';

import { SEO_PAGE_LABELS, DEFAULT_SEO } from '@/data/homepageDefaults';






const ICON_OPTIONS = [
  'Shield', 'Heart', 'Award', 'Handshake', 'Gem', 'TrendingUp', 'TrendingDown',
  'Star', 'Building2', 'Clock', 'Sparkles', 'Eye', 'Car', 'Target', 'ThumbsUp',
  'Wrench', 'FileCheck', 'Truck', 'ShieldCheck', 'Users', 'CheckCircle', 'Phone',
  'Mail', 'MapPin', 'DollarSign', 'Zap',
];

const COLOR_OPTIONS = [
  { label: 'Pink', value: 'text-neon-pink', bg: 'bg-neon-pink/10', border: 'border-neon-pink/20', dot: 'bg-pink-500' },
  { label: 'Cyan', value: 'text-neon-cyan', bg: 'bg-neon-cyan/10', border: 'border-neon-cyan/20', dot: 'bg-cyan-400' },
  { label: 'Green', value: 'text-neon-green', bg: 'bg-neon-green/10', border: 'border-neon-green/20', dot: 'bg-green-400' },
  { label: 'Orange', value: 'text-neon-orange', bg: 'bg-neon-orange/10', border: 'border-neon-orange/20', dot: 'bg-orange-400' },
  { label: 'Purple', value: 'text-neon-purple', bg: 'bg-neon-purple/10', border: 'border-neon-purple/20', dot: 'bg-purple-500' },
  { label: 'Yellow', value: 'text-neon-yellow', bg: 'bg-neon-yellow/10', border: 'border-neon-yellow/20', dot: 'bg-yellow-400' },
];

// ─── Save Button ───
const SaveBtn: React.FC<{ onSave: () => void; saving: boolean }> = ({ onSave, saving }) => (
  <button
    onClick={onSave}
    disabled={saving}
    className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-neon-cyan to-blue-500 text-white font-bold rounded-xl hover:opacity-90 transition-opacity disabled:opacity-50 shadow-lg shadow-neon-cyan/20"
  >
    {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
    Save Changes
  </button>
);

// ─── Text Input Helper ───
const Field: React.FC<{
  label: string; value: string; onChange: (v: string) => void;
  placeholder?: string; multiline?: boolean; rows?: number; hint?: string;
}> = ({ label, value, onChange, placeholder, multiline, rows = 3, hint }) => (
  <div>
    <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1.5">{label}</label>
    {multiline ? (
      <textarea
        value={value} onChange={(e) => onChange(e.target.value)} rows={rows}
        className="w-full px-4 py-3 bg-white/[0.03] border border-white/10 rounded-xl text-white text-sm placeholder-gray-600 focus:border-neon-cyan focus:outline-none focus:ring-1 focus:ring-neon-cyan/30 transition-all resize-y"
        placeholder={placeholder}
      />
    ) : (
      <input
        value={value} onChange={(e) => onChange(e.target.value)}
        className="w-full px-4 py-3 bg-white/[0.03] border border-white/10 rounded-xl text-white text-sm placeholder-gray-600 focus:border-neon-cyan focus:outline-none focus:ring-1 focus:ring-neon-cyan/30 transition-all"
        placeholder={placeholder}
      />
    )}
    {hint && <p className="text-gray-600 text-xs mt-1">{hint}</p>}
  </div>
);

// ═══════════════════════════════════════
// HERO SECTION EDITOR
// ═══════════════════════════════════════
export const HeroSectionEditor: React.FC<{
  data: HeroSectionContent; onChange: (d: HeroSectionContent) => void; onSave: () => void; saving: boolean;
}> = ({ data, onChange, onSave, saving }) => {
  const updateHeadline = (i: number, val: string) => {
    const lines = [...data.headlineLines];
    lines[i] = val;
    onChange({ ...data, headlineLines: lines });
  };

  const updateStat = (i: number, field: string, val: string) => {
    const stats = [...data.stats];
    stats[i] = { ...stats[i], [field]: val };
    onChange({ ...data, stats });
  };

  const updateBadge = (i: number, field: string, val: string) => {
    const badges = [...data.trustBadges];
    badges[i] = { ...badges[i], [field]: val };
    onChange({ ...data, trustBadges: badges });
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-white font-bold text-base mb-1 flex items-center gap-2">
          <Layout className="w-4 h-4 text-neon-pink" />
          Homepage Hero Section
        </h3>
        <p className="text-gray-500 text-sm">Edit the main hero banner at the top of the homepage.</p>
      </div>

      <Field label="Badge Text" value={data.badgeText} onChange={(v) => onChange({ ...data, badgeText: v })} placeholder="Long Island's Premier..." hint="Green badge shown above the headline" />

      <div>
        <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1.5">Headline (3 lines)</label>
        <div className="space-y-2">
          {data.headlineLines.map((line, i) => (
            <input key={i} value={line} onChange={(e) => updateHeadline(i, e.target.value)}
              className="w-full px-4 py-3 bg-white/[0.03] border border-white/10 rounded-xl text-white text-sm focus:border-neon-cyan focus:outline-none"
              placeholder={`Line ${i + 1}`}
            />
          ))}
        </div>
        <p className="text-gray-600 text-xs mt-1">Line 2 gets the gradient neon color effect.</p>
      </div>

      <Field label="Subtitle" value={data.subtitle} onChange={(v) => onChange({ ...data, subtitle: v })} multiline placeholder="Quality pre-owned vehicles..." />

      <div className="grid grid-cols-2 gap-4">
        <Field label="Primary CTA Button" value={data.ctaPrimary} onChange={(v) => onChange({ ...data, ctaPrimary: v })} placeholder="Browse Inventory" />
        <Field label="Secondary CTA Button" value={data.ctaSecondary} onChange={(v) => onChange({ ...data, ctaSecondary: v })} placeholder="Contact Us" />
      </div>

      {/* Trust Badges */}
      <div>
        <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">Trust Badges ({data.trustBadges.length})</label>
        <div className="space-y-2">
          {data.trustBadges.map((badge, i) => (
            <div key={i} className="flex items-center gap-2">
              <select value={badge.icon} onChange={(e) => updateBadge(i, 'icon', e.target.value)}
                className="w-32 px-2 py-2.5 bg-white/[0.03] border border-white/10 rounded-lg text-white text-xs focus:border-neon-cyan focus:outline-none">
                {ICON_OPTIONS.map(ic => <option key={ic} value={ic}>{ic}</option>)}
              </select>
              <input value={badge.text} onChange={(e) => updateBadge(i, 'text', e.target.value)}
                className="flex-1 px-3 py-2.5 bg-white/[0.03] border border-white/10 rounded-lg text-white text-sm focus:border-neon-cyan focus:outline-none"
                placeholder="Badge text..."
              />
              <button onClick={() => onChange({ ...data, trustBadges: data.trustBadges.filter((_, j) => j !== i) })}
                className="p-2 text-gray-600 hover:text-red-400 transition-colors">
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
        {data.trustBadges.length < 5 && (
          <button onClick={() => onChange({ ...data, trustBadges: [...data.trustBadges, { icon: 'Star', text: '' }] })}
            className="flex items-center gap-2 px-4 py-2 border border-dashed border-white/10 rounded-xl text-gray-500 hover:text-white hover:border-white/20 transition-all text-sm mt-2">
            <Plus className="w-4 h-4" /> Add Badge
          </button>
        )}
      </div>

      {/* Stats Bar */}
      <div>
        <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">Stats Bar ({data.stats.length})</label>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {data.stats.map((stat, i) => (
            <div key={i} className="bg-white/[0.02] border border-white/5 rounded-xl p-3 space-y-2">
              <div className="flex items-center gap-2">
                <input value={stat.value} onChange={(e) => updateStat(i, 'value', e.target.value)}
                  className="w-24 px-3 py-2 bg-white/[0.03] border border-white/10 rounded-lg text-white text-sm font-bold focus:border-neon-cyan focus:outline-none"
                  placeholder="500+"
                />
                <input value={stat.label} onChange={(e) => updateStat(i, 'label', e.target.value)}
                  className="flex-1 px-3 py-2 bg-white/[0.03] border border-white/10 rounded-lg text-gray-300 text-xs focus:border-neon-cyan focus:outline-none"
                  placeholder="Cars Sold"
                />
                {data.stats.length > 2 && (
                  <button onClick={() => onChange({ ...data, stats: data.stats.filter((_, j) => j !== i) })}
                    className="p-1.5 text-gray-600 hover:text-red-400 transition-colors">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
              <div className="flex flex-wrap gap-1">
                {COLOR_OPTIONS.map(c => (
                  <button key={c.value} onClick={() => updateStat(i, 'color', c.value)}
                    className={`w-5 h-5 rounded-full border-2 transition-all ${stat.color === c.value ? 'border-white scale-110' : 'border-transparent opacity-60 hover:opacity-100'} ${c.dot}`}
                    title={c.label}
                  />
                ))}
              </div>
            </div>
          ))}
        </div>
        {data.stats.length < 6 && (
          <button onClick={() => onChange({ ...data, stats: [...data.stats, { value: '', label: '', color: 'text-neon-pink' }] })}
            className="flex items-center gap-2 px-4 py-2 border border-dashed border-white/10 rounded-xl text-gray-500 hover:text-white hover:border-white/20 transition-all text-sm mt-2">
            <Plus className="w-4 h-4" /> Add Stat
          </button>
        )}
      </div>

      <div className="flex justify-end pt-4 border-t border-white/5">
        <SaveBtn onSave={onSave} saving={saving} />
      </div>
    </div>
  );
};

// ═══════════════════════════════════════
// SERVICES SECTION EDITOR
// ═══════════════════════════════════════
export const ServicesSectionEditor: React.FC<{
  data: ServicesSectionContent; onChange: (d: ServicesSectionContent) => void; onSave: () => void; saving: boolean;
}> = ({ data, onChange, onSave, saving }) => {
  const [expandedIndex, setExpandedIndex] = useState<number | null>(null);

  const updateService = (i: number, field: keyof ServiceItem, val: string) => {
    const services = [...data.services];
    services[i] = { ...services[i], [field]: val };
    onChange({ ...data, services });
  };

  const addService = () => {
    onChange({ ...data, services: [...data.services, { icon: 'Star', title: '', description: '', color: 'text-neon-pink', bgColor: 'bg-neon-pink/10', borderColor: 'border-neon-pink/20' }] });
    setExpandedIndex(data.services.length);
  };

  const removeService = (i: number) => {
    onChange({ ...data, services: data.services.filter((_, j) => j !== i) });
    setExpandedIndex(null);
  };

  const setServiceColor = (i: number, colorOpt: typeof COLOR_OPTIONS[number]) => {
    const services = [...data.services];
    services[i] = { ...services[i], color: colorOpt.value, bgColor: colorOpt.bg, borderColor: colorOpt.border };
    onChange({ ...data, services });
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-white font-bold text-base mb-1 flex items-center gap-2">
          <Wrench className="w-4 h-4 text-neon-orange" />
          Services Section
        </h3>
        <p className="text-gray-500 text-sm">Edit the "What We Offer" section on the homepage. ({data.services.length} services)</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Field label="Section Title" value={data.title} onChange={(v) => onChange({ ...data, title: v })} placeholder="What We" />
        <Field label="Highlighted Word" value={data.titleHighlight} onChange={(v) => onChange({ ...data, titleHighlight: v })} placeholder="Offer" hint="Gets gradient color" />
      </div>
      <Field label="Subtitle" value={data.subtitle} onChange={(v) => onChange({ ...data, subtitle: v })} multiline placeholder="From finding your perfect car..." />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Field label="CTA Phone (raw)" value={data.ctaPhone} onChange={(v) => onChange({ ...data, ctaPhone: v })} placeholder="6313884426" />
        <Field label="CTA Phone (display)" value={data.ctaPhoneDisplay} onChange={(v) => onChange({ ...data, ctaPhoneDisplay: v })} placeholder="(631) 388-4426" />
      </div>

      <div className="space-y-3">
        {data.services.map((svc, i) => (
          <div key={i} className="bg-white/[0.02] border border-white/5 rounded-xl overflow-hidden">
            <button onClick={() => setExpandedIndex(expandedIndex === i ? null : i)}
              className="w-full flex items-center justify-between px-4 py-3 hover:bg-white/[0.02] transition-colors">
              <div className="flex items-center gap-3">
                <GripVertical className="w-4 h-4 text-gray-600" />
                <span className="text-white font-semibold text-sm">{svc.title || `Service ${i + 1}`}</span>
                <span className="text-gray-600 text-xs">{svc.icon}</span>
              </div>
              {expandedIndex === i ? <ChevronUp className="w-4 h-4 text-gray-500" /> : <ChevronDown className="w-4 h-4 text-gray-500" />}
            </button>
            {expandedIndex === i && (
              <div className="px-4 pb-4 space-y-4 border-t border-white/5 pt-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Field label="Title" value={svc.title} onChange={(v) => updateService(i, 'title', v)} placeholder="Service title..." />
                  <div>
                    <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1.5">Icon</label>
                    <select value={svc.icon} onChange={(e) => updateService(i, 'icon', e.target.value)}
                      className="w-full px-3 py-2.5 bg-white/[0.03] border border-white/10 rounded-lg text-white text-sm focus:border-neon-cyan focus:outline-none">
                      {ICON_OPTIONS.map(ic => <option key={ic} value={ic}>{ic}</option>)}
                    </select>
                  </div>
                </div>
                <Field label="Description" value={svc.description} onChange={(v) => updateService(i, 'description', v)} multiline rows={2} placeholder="Describe this service..." />
                <div>
                  <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1.5">Color</label>
                  <div className="flex flex-wrap gap-2">
                    {COLOR_OPTIONS.map(c => (
                      <button key={c.value} onClick={() => setServiceColor(i, c)}
                        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${svc.color === c.value ? 'border-white/30 bg-white/10 text-white' : 'border-white/5 text-gray-500 hover:border-white/10'}`}>
                        <span className={`w-2.5 h-2.5 rounded-full ${c.dot}`} />{c.label}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="flex justify-end">
                  <button onClick={() => removeService(i)} className="flex items-center gap-1.5 px-3 py-1.5 text-red-400 hover:bg-red-500/10 rounded-lg text-xs font-medium transition-colors">
                    <Trash2 className="w-3.5 h-3.5" /> Remove
                  </button>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      <button onClick={addService}
        className="flex items-center gap-2 px-4 py-2.5 border border-dashed border-white/10 rounded-xl text-gray-500 hover:text-white hover:border-white/20 transition-all text-sm w-full justify-center">
        <Plus className="w-4 h-4" /> Add Service
      </button>

      <div className="flex justify-end pt-4 border-t border-white/5">
        <SaveBtn onSave={onSave} saving={saving} />
      </div>
    </div>
  );
};

// ═══════════════════════════════════════
// WHY CHOOSE US EDITOR
// ═══════════════════════════════════════
export const WhyChooseUsEditor: React.FC<{
  data: WhyChooseUsContent; onChange: (d: WhyChooseUsContent) => void; onSave: () => void; saving: boolean;
}> = ({ data, onChange, onSave, saving }) => {
  const [expandedIndex, setExpandedIndex] = useState<number | null>(null);

  const updateReason = (i: number, field: keyof WhyChooseUsReason, val: string) => {
    const reasons = [...data.reasons];
    reasons[i] = { ...reasons[i], [field]: val };
    onChange({ ...data, reasons });
  };

  const updateStat = (i: number, field: string, val: string) => {
    const stats = [...data.stats];
    stats[i] = { ...stats[i], [field]: val };
    onChange({ ...data, stats });
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-white font-bold text-base mb-1 flex items-center gap-2">
          <Award className="w-4 h-4 text-neon-green" />
          Why Choose Us Section
        </h3>
        <p className="text-gray-500 text-sm">Edit the "Why Choose Ex$ell?" section. ({data.reasons.length} reasons)</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Field label="Section Title" value={data.title} onChange={(v) => onChange({ ...data, title: v })} placeholder="Why Choose" />
        <Field label="Highlighted Word" value={data.titleHighlight} onChange={(v) => onChange({ ...data, titleHighlight: v })} placeholder="Ex$ell?" />
      </div>
      <Field label="Description" value={data.description} onChange={(v) => onChange({ ...data, description: v })} multiline placeholder="At Ex$ell Car Sales..." />

      {/* Reasons */}
      <div className="space-y-3">
        <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider">Reasons ({data.reasons.length})</label>
        {data.reasons.map((reason, i) => (
          <div key={i} className="bg-white/[0.02] border border-white/5 rounded-xl overflow-hidden">
            <button onClick={() => setExpandedIndex(expandedIndex === i ? null : i)}
              className="w-full flex items-center justify-between px-4 py-3 hover:bg-white/[0.02] transition-colors">
              <div className="flex items-center gap-3">
                <GripVertical className="w-4 h-4 text-gray-600" />
                <span className="text-white font-semibold text-sm">{reason.title || `Reason ${i + 1}`}</span>
              </div>
              {expandedIndex === i ? <ChevronUp className="w-4 h-4 text-gray-500" /> : <ChevronDown className="w-4 h-4 text-gray-500" />}
            </button>
            {expandedIndex === i && (
              <div className="px-4 pb-4 space-y-4 border-t border-white/5 pt-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Field label="Title" value={reason.title} onChange={(v) => updateReason(i, 'title', v)} placeholder="Reason title..." />
                  <div>
                    <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1.5">Icon</label>
                    <select value={reason.icon} onChange={(e) => updateReason(i, 'icon', e.target.value)}
                      className="w-full px-3 py-2.5 bg-white/[0.03] border border-white/10 rounded-lg text-white text-sm focus:border-neon-cyan focus:outline-none">
                      {ICON_OPTIONS.map(ic => <option key={ic} value={ic}>{ic}</option>)}
                    </select>
                  </div>
                </div>
                <Field label="Description" value={reason.description} onChange={(v) => updateReason(i, 'description', v)} multiline rows={2} />
                <div>
                  <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1.5">Color</label>
                  <div className="flex flex-wrap gap-2">
                    {COLOR_OPTIONS.map(c => (
                      <button key={c.value} onClick={() => updateReason(i, 'color', c.value)}
                        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${reason.color === c.value ? 'border-white/30 bg-white/10 text-white' : 'border-white/5 text-gray-500 hover:border-white/10'}`}>
                        <span className={`w-2.5 h-2.5 rounded-full ${c.dot}`} />{c.label}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="flex justify-end">
                  <button onClick={() => { onChange({ ...data, reasons: data.reasons.filter((_, j) => j !== i) }); setExpandedIndex(null); }}
                    className="flex items-center gap-1.5 px-3 py-1.5 text-red-400 hover:bg-red-500/10 rounded-lg text-xs font-medium transition-colors">
                    <Trash2 className="w-3.5 h-3.5" /> Remove
                  </button>
                </div>
              </div>
            )}
          </div>
        ))}
        <button onClick={() => { onChange({ ...data, reasons: [...data.reasons, { icon: 'Star', title: '', description: '', color: 'text-neon-pink' }] }); setExpandedIndex(data.reasons.length); }}
          className="flex items-center gap-2 px-4 py-2.5 border border-dashed border-white/10 rounded-xl text-gray-500 hover:text-white hover:border-white/20 transition-all text-sm w-full justify-center">
          <Plus className="w-4 h-4" /> Add Reason
        </button>
      </div>

      {/* Stats */}
      <div>
        <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">Stats ({data.stats.length})</label>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {data.stats.map((stat, i) => (
            <div key={i} className="bg-white/[0.02] border border-white/5 rounded-xl p-3 space-y-2">
              <input value={stat.value} onChange={(e) => updateStat(i, 'value', e.target.value)}
                className="w-full px-3 py-2 bg-white/[0.03] border border-white/10 rounded-lg text-white text-sm font-bold focus:border-neon-cyan focus:outline-none"
                placeholder="500+"
              />
              <input value={stat.label} onChange={(e) => updateStat(i, 'label', e.target.value)}
                className="w-full px-3 py-2 bg-white/[0.03] border border-white/10 rounded-lg text-gray-300 text-xs focus:border-neon-cyan focus:outline-none"
                placeholder="Happy Customers"
              />
              <div className="flex flex-wrap gap-1">
                {COLOR_OPTIONS.map(c => (
                  <button key={c.value} onClick={() => updateStat(i, 'color', c.value)}
                    className={`w-5 h-5 rounded-full border-2 transition-all ${stat.color === c.value ? 'border-white scale-110' : 'border-transparent opacity-60 hover:opacity-100'} ${c.dot}`}
                    title={c.label}
                  />
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="flex justify-end pt-4 border-t border-white/5">
        <SaveBtn onSave={onSave} saving={saving} />
      </div>
    </div>
  );
};

// ═══════════════════════════════════════
// TESTIMONIALS EDITOR
// ═══════════════════════════════════════
export const TestimonialsEditor: React.FC<{
  data: TestimonialsSectionContent; onChange: (d: TestimonialsSectionContent) => void; onSave: () => void; saving: boolean;
}> = ({ data, onChange, onSave, saving }) => {
  const [expandedIndex, setExpandedIndex] = useState<number | null>(null);

  const updateTestimonial = (i: number, field: keyof TestimonialItem, val: any) => {
    const testimonials = [...data.testimonials];
    testimonials[i] = { ...testimonials[i], [field]: val };
    onChange({ ...data, testimonials });
  };

  const addTestimonial = () => {
    onChange({ ...data, testimonials: [...data.testimonials, { name: '', location: '', rating: 5, text: '', vehicle: '' }] });
    setExpandedIndex(data.testimonials.length);
  };

  const removeTestimonial = (i: number) => {
    onChange({ ...data, testimonials: data.testimonials.filter((_, j) => j !== i) });
    setExpandedIndex(null);
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-white font-bold text-base mb-1 flex items-center gap-2">
          <MessageSquare className="w-4 h-4 text-neon-orange" />
          Testimonials Section
        </h3>
        <p className="text-gray-500 text-sm">Edit the customer reviews carousel on the homepage. ({data.testimonials.length} testimonials)</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Field label="Section Title" value={data.title} onChange={(v) => onChange({ ...data, title: v })} placeholder="What Our" />
        <Field label="Highlighted Word" value={data.titleHighlight} onChange={(v) => onChange({ ...data, titleHighlight: v })} placeholder="Customers" />
      </div>
      <Field label="Subtitle" value={data.subtitle} onChange={(v) => onChange({ ...data, subtitle: v })} multiline />

      <div className="grid grid-cols-2 gap-4">
        <Field label="Overall Rating" value={data.overallRating} onChange={(v) => onChange({ ...data, overallRating: v })} placeholder="4.9" />
        <Field label="Review Count" value={data.reviewCount} onChange={(v) => onChange({ ...data, reviewCount: v })} placeholder="200+" />
      </div>

      {/* Testimonial cards */}
      <div className="space-y-3">
        {data.testimonials.map((t, i) => (
          <div key={i} className="bg-white/[0.02] border border-white/5 rounded-xl overflow-hidden">
            <button onClick={() => setExpandedIndex(expandedIndex === i ? null : i)}
              className="w-full flex items-center justify-between px-4 py-3 hover:bg-white/[0.02] transition-colors">
              <div className="flex items-center gap-3">
                <GripVertical className="w-4 h-4 text-gray-600" />
                <span className="text-white font-semibold text-sm">{t.name || `Review ${i + 1}`}</span>
                <span className="text-gray-600 text-xs">{t.vehicle}</span>
                <div className="flex gap-0.5">
                  {Array.from({ length: t.rating }).map((_, s) => (
                    <Star key={s} className="w-3 h-3 text-neon-orange fill-neon-orange" />
                  ))}
                </div>
              </div>
              {expandedIndex === i ? <ChevronUp className="w-4 h-4 text-gray-500" /> : <ChevronDown className="w-4 h-4 text-gray-500" />}
            </button>
            {expandedIndex === i && (
              <div className="px-4 pb-4 space-y-4 border-t border-white/5 pt-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Field label="Name" value={t.name} onChange={(v) => updateTestimonial(i, 'name', v)} placeholder="John D." />
                  <Field label="Location" value={t.location} onChange={(v) => updateTestimonial(i, 'location', v)} placeholder="Babylon, NY" />
                  <Field label="Vehicle Purchased" value={t.vehicle} onChange={(v) => updateTestimonial(i, 'vehicle', v)} placeholder="2021 BMW 330i" />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1.5">Rating</label>
                  <div className="flex gap-1">
                    {[1, 2, 3, 4, 5].map(r => (
                      <button key={r} onClick={() => updateTestimonial(i, 'rating', r)}
                        className={`p-1 transition-colors ${r <= t.rating ? 'text-neon-orange' : 'text-gray-700 hover:text-gray-500'}`}>
                        <Star className={`w-5 h-5 ${r <= t.rating ? 'fill-neon-orange' : ''}`} />
                      </button>
                    ))}
                  </div>
                </div>
                <Field label="Review Text" value={t.text} onChange={(v) => updateTestimonial(i, 'text', v)} multiline rows={3} placeholder="Write the customer review..." />
                <div className="flex justify-end">
                  <button onClick={() => removeTestimonial(i)}
                    className="flex items-center gap-1.5 px-3 py-1.5 text-red-400 hover:bg-red-500/10 rounded-lg text-xs font-medium transition-colors">
                    <Trash2 className="w-3.5 h-3.5" /> Remove
                  </button>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      <button onClick={addTestimonial}
        className="flex items-center gap-2 px-4 py-2.5 border border-dashed border-white/10 rounded-xl text-gray-500 hover:text-white hover:border-white/20 transition-all text-sm w-full justify-center">
        <Plus className="w-4 h-4" /> Add Testimonial
      </button>

      <div className="flex justify-end pt-4 border-t border-white/5">
        <SaveBtn onSave={onSave} saving={saving} />
      </div>
    </div>
  );
};

// ═══════════════════════════════════════
// CONTACT SECTION EDITOR
// ═══════════════════════════════════════
export const ContactSectionEditor: React.FC<{
  data: ContactSectionContent; onChange: (d: ContactSectionContent) => void; onSave: () => void; saving: boolean;
}> = ({ data, onChange, onSave, saving }) => (
  <div className="space-y-6">
    <div>
      <h3 className="text-white font-bold text-base mb-1 flex items-center gap-2">
        <Phone className="w-4 h-4 text-neon-cyan" />
        Contact Section
      </h3>
      <p className="text-gray-500 text-sm">Edit the contact information and details shown on the homepage.</p>
    </div>

    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <Field label="Section Title" value={data.title} onChange={(v) => onChange({ ...data, title: v })} placeholder="Get In" />
      <Field label="Highlighted Word" value={data.titleHighlight} onChange={(v) => onChange({ ...data, titleHighlight: v })} placeholder="Touch" />
    </div>
    <Field label="Subtitle" value={data.subtitle} onChange={(v) => onChange({ ...data, subtitle: v })} multiline />

    <div className="bg-white/[0.02] border border-white/5 rounded-xl p-4 space-y-4">
      <h4 className="text-white font-semibold text-sm flex items-center gap-2"><Phone className="w-3.5 h-3.5 text-neon-pink" /> Phone</h4>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Field label="Phone (raw)" value={data.phone} onChange={(v) => onChange({ ...data, phone: v })} placeholder="6313884426" />
        <Field label="Phone (display)" value={data.phoneDisplay} onChange={(v) => onChange({ ...data, phoneDisplay: v })} placeholder="(631) 388-4426" />
        <Field label="Phone Label" value={data.phoneLabel} onChange={(v) => onChange({ ...data, phoneLabel: v })} placeholder="Call or text anytime" />
      </div>
    </div>

    <div className="bg-white/[0.02] border border-white/5 rounded-xl p-4 space-y-4">
      <h4 className="text-white font-semibold text-sm flex items-center gap-2"><MapPin className="w-3.5 h-3.5 text-neon-green" /> Email & Address</h4>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Field label="Email" value={data.email} onChange={(v) => onChange({ ...data, email: v })} placeholder="info@exsellsalesli.com" />
        <Field label="Email Label" value={data.emailLabel} onChange={(v) => onChange({ ...data, emailLabel: v })} placeholder="Email us anytime" />
        <Field label="Address" value={data.address} onChange={(v) => onChange({ ...data, address: v })} placeholder="Long Island, NY" />
        <Field label="Address Label" value={data.addressLabel} onChange={(v) => onChange({ ...data, addressLabel: v })} placeholder="Serving all of Long Island" />
      </div>
    </div>

    <div className="bg-white/[0.02] border border-white/5 rounded-xl p-4 space-y-4">
      <h4 className="text-white font-semibold text-sm flex items-center gap-2"><Clock className="w-3.5 h-3.5 text-neon-orange" /> Hours & Social</h4>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Field label="Weekday Hours" value={data.hoursWeekday} onChange={(v) => onChange({ ...data, hoursWeekday: v })} placeholder="Mon-Fri: 7AM - 5PM | Sat: 7AM - 2PM" />
        <Field label="Sunday Hours" value={data.hoursSunday} onChange={(v) => onChange({ ...data, hoursSunday: v })} placeholder="Sun: Closed" />

        <Field label="Facebook URL" value={data.facebookUrl} onChange={(v) => onChange({ ...data, facebookUrl: v })} placeholder="https://facebook.com/..." />
        <Field label="Instagram URL" value={data.instagramUrl} onChange={(v) => onChange({ ...data, instagramUrl: v })} placeholder="https://instagram.com/..." />
      </div>
    </div>

    <div className="flex justify-end pt-4 border-t border-white/5">
      <SaveBtn onSave={onSave} saving={saving} />
    </div>
  </div>
);


// ═══════════════════════════════════════
// FOOTER SECTION EDITOR
// ═══════════════════════════════════════
export const FooterSectionEditor: React.FC<{
  data: FooterContent; onChange: (d: FooterContent) => void; onSave: () => void; saving: boolean;
}> = ({ data, onChange, onSave, saving }) => {
  const [expandedLink, setExpandedLink] = useState<number | null>(null);

  const updateService = (i: number, val: string) => {
    const services = [...data.services];
    services[i] = val;
    onChange({ ...data, services });
  };

  const addService = () => {
    onChange({ ...data, services: [...data.services, ''] });
  };

  const removeService = (i: number) => {
    onChange({ ...data, services: data.services.filter((_, j) => j !== i) });
  };

  const moveService = (i: number, dir: 'up' | 'down') => {
    const ni = dir === 'up' ? i - 1 : i + 1;
    if (ni < 0 || ni >= data.services.length) return;
    const s = [...data.services];
    [s[i], s[ni]] = [s[ni], s[i]];
    onChange({ ...data, services: s });
  };

  const updateLink = (i: number, field: keyof FooterQuickLink, val: string) => {
    const links = [...data.quickLinks];
    links[i] = { ...links[i], [field]: val };
    onChange({ ...data, quickLinks: links });
  };

  const addLink = () => {
    onChange({ ...data, quickLinks: [...data.quickLinks, { label: '', type: 'route', target: '/' }] });
    setExpandedLink(data.quickLinks.length);
  };

  const removeLink = (i: number) => {
    onChange({ ...data, quickLinks: data.quickLinks.filter((_, j) => j !== i) });
    setExpandedLink(null);
  };

  const moveLink = (i: number, dir: 'up' | 'down') => {
    const ni = dir === 'up' ? i - 1 : i + 1;
    if (ni < 0 || ni >= data.quickLinks.length) return;
    const links = [...data.quickLinks];
    [links[i], links[ni]] = [links[ni], links[i]];
    onChange({ ...data, quickLinks: links });
    setExpandedLink(ni);
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-white font-bold text-base mb-1 flex items-center gap-2">
          <AlignLeft className="w-4 h-4 text-neon-purple" />
          Footer Section
        </h3>
        <p className="text-gray-500 text-sm">
          Edit the footer tagline, services list, quick links, and bottom bar text. Contact info is pulled from the Contact section.
        </p>
      </div>

      {/* Tagline */}
      <div>
        <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1.5">Footer Tagline</label>
        <textarea
          value={data.tagline}
          onChange={(e) => onChange({ ...data, tagline: e.target.value })}
          rows={3}
          className="w-full px-4 py-3 bg-white/[0.03] border border-white/10 rounded-xl text-white text-sm placeholder-gray-600 focus:border-neon-cyan focus:outline-none focus:ring-1 focus:ring-neon-cyan/30 transition-all resize-y"
          placeholder="Long Island's trusted source for quality pre-owned vehicles..."
        />
        <p className="text-gray-600 text-xs mt-1">Appears below the logo in the footer. {data.tagline.length} characters</p>
      </div>

      {/* Our Services List */}
      <div className="bg-white/[0.02] border border-white/5 rounded-xl p-4 space-y-4">
        <div className="flex items-center justify-between">
          <h4 className="text-white font-semibold text-sm flex items-center gap-2">
            <Wrench className="w-3.5 h-3.5 text-neon-orange" />
            Our Services List ({data.services.length} items)
          </h4>
        </div>
        <p className="text-gray-500 text-xs">These appear in the "Our Services" column of the footer. Each links to the Services section.</p>
        <div className="space-y-2">
          {data.services.map((svc, i) => (
            <div key={i} className="flex items-center gap-2 group">
              <div className="flex flex-col gap-0.5">
                <button
                  onClick={() => moveService(i, 'up')}
                  disabled={i === 0}
                  className="p-0.5 text-gray-600 hover:text-white disabled:opacity-20 transition-colors"
                >
                  <ChevronUp className="w-3 h-3" />
                </button>
                <button
                  onClick={() => moveService(i, 'down')}
                  disabled={i === data.services.length - 1}
                  className="p-0.5 text-gray-600 hover:text-white disabled:opacity-20 transition-colors"
                >
                  <ChevronDown className="w-3 h-3" />
                </button>
              </div>
              <span className="text-gray-600 text-xs w-5 text-center flex-shrink-0">{i + 1}</span>
              <input
                value={svc}
                onChange={(e) => updateService(i, e.target.value)}
                className="flex-1 px-3 py-2.5 bg-white/[0.03] border border-white/10 rounded-lg text-white text-sm focus:border-neon-cyan focus:outline-none"
                placeholder="Service name..."
              />
              <button
                onClick={() => removeService(i)}
                className="p-2 text-gray-600 hover:text-red-400 transition-colors opacity-0 group-hover:opacity-100"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
        {data.services.length < 12 && (
          <button
            onClick={addService}
            className="flex items-center gap-2 px-4 py-2 border border-dashed border-white/10 rounded-xl text-gray-500 hover:text-white hover:border-white/20 transition-all text-sm w-full justify-center"
          >
            <Plus className="w-4 h-4" /> Add Service
          </button>
        )}
      </div>

      {/* Quick Links */}
      <div className="bg-white/[0.02] border border-white/5 rounded-xl p-4 space-y-4">
        <div className="flex items-center justify-between">
          <h4 className="text-white font-semibold text-sm flex items-center gap-2">
            <Link2 className="w-3.5 h-3.5 text-neon-cyan" />
            Quick Links ({data.quickLinks.length} items)
          </h4>
        </div>
        <p className="text-gray-500 text-xs">
          Links in the "Quick Links" column. "Scroll" links scroll to a section on the homepage. "Route" links navigate to a page.
        </p>
        <div className="space-y-2">
          {data.quickLinks.map((link, i) => (
            <div key={i} className="bg-white/[0.02] border border-white/5 rounded-xl overflow-hidden">
              <button
                onClick={() => setExpandedLink(expandedLink === i ? null : i)}
                className="w-full flex items-center justify-between px-3 py-2.5 hover:bg-white/[0.02] transition-colors"
              >
                <div className="flex items-center gap-2">
                  <GripVertical className="w-3.5 h-3.5 text-gray-600" />
                  <span className="text-white font-medium text-sm">{link.label || `Link ${i + 1}`}</span>
                  <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                    link.type === 'scroll' ? 'bg-neon-cyan/10 text-neon-cyan' : 'bg-neon-orange/10 text-neon-orange'
                  }`}>
                    {link.type === 'scroll' ? 'SCROLL' : 'ROUTE'}
                  </span>
                  <span className="text-gray-600 text-xs">{link.target}</span>
                </div>
                <div className="flex items-center gap-1">
                  <button onClick={(e) => { e.stopPropagation(); moveLink(i, 'up'); }} disabled={i === 0}
                    className="p-1 text-gray-600 hover:text-white disabled:opacity-20 transition-colors">
                    <ChevronUp className="w-3 h-3" />
                  </button>
                  <button onClick={(e) => { e.stopPropagation(); moveLink(i, 'down'); }} disabled={i === data.quickLinks.length - 1}
                    className="p-1 text-gray-600 hover:text-white disabled:opacity-20 transition-colors">
                    <ChevronDown className="w-3 h-3" />
                  </button>
                  {expandedLink === i ? <ChevronUp className="w-3.5 h-3.5 text-gray-500 ml-1" /> : <ChevronDown className="w-3.5 h-3.5 text-gray-500 ml-1" />}
                </div>
              </button>
              {expandedLink === i && (
                <div className="px-3 pb-3 space-y-3 border-t border-white/5 pt-3">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1">Label</label>
                      <input
                        value={link.label}
                        onChange={(e) => updateLink(i, 'label', e.target.value)}
                        className="w-full px-3 py-2 bg-white/[0.03] border border-white/10 rounded-lg text-white text-sm focus:border-neon-cyan focus:outline-none"
                        placeholder="Home"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1">Type</label>
                      <select
                        value={link.type}
                        onChange={(e) => updateLink(i, 'type', e.target.value)}
                        className="w-full px-3 py-2 bg-white/[0.03] border border-white/10 rounded-lg text-white text-sm focus:border-neon-cyan focus:outline-none"
                      >
                        <option value="scroll">Scroll to Section</option>
                        <option value="route">Navigate to Page</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1">
                        {link.type === 'scroll' ? 'Section ID' : 'Route Path'}
                      </label>
                      <input
                        value={link.target}
                        onChange={(e) => updateLink(i, 'target', e.target.value)}
                        className="w-full px-3 py-2 bg-white/[0.03] border border-white/10 rounded-lg text-white text-sm focus:border-neon-cyan focus:outline-none"
                        placeholder={link.type === 'scroll' ? 'hero' : '/about'}
                      />
                      <p className="text-gray-600 text-[10px] mt-0.5">
                        {link.type === 'scroll' ? 'e.g. hero, inventory, services, why-us, contact' : 'e.g. /about, /sold, /reviews, /privacy-policy'}
                      </p>
                    </div>
                  </div>
                  <div className="flex justify-end">
                    <button
                      onClick={() => removeLink(i)}
                      className="flex items-center gap-1.5 px-3 py-1.5 text-red-400 hover:bg-red-500/10 rounded-lg text-xs font-medium transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" /> Remove Link
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
        {data.quickLinks.length < 15 && (
          <button
            onClick={addLink}
            className="flex items-center gap-2 px-4 py-2 border border-dashed border-white/10 rounded-xl text-gray-500 hover:text-white hover:border-white/20 transition-all text-sm w-full justify-center"
          >
            <Plus className="w-4 h-4" /> Add Quick Link
          </button>
        )}
      </div>

      {/* Bottom Bar Text */}
      <div className="bg-white/[0.02] border border-white/5 rounded-xl p-4 space-y-4">
        <h4 className="text-white font-semibold text-sm flex items-center gap-2">
          <Layout className="w-3.5 h-3.5 text-neon-green" />
          Bottom Bar
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1.5">Copyright Name</label>
            <input
              value={data.copyrightName}
              onChange={(e) => onChange({ ...data, copyrightName: e.target.value })}
              className="w-full px-3 py-2.5 bg-white/[0.03] border border-white/10 rounded-lg text-white text-sm focus:border-neon-cyan focus:outline-none"
              placeholder="Ex$ell Car Sales LI"
            />
            <p className="text-gray-600 text-[10px] mt-0.5">Shows as "&copy; 2026 [name]. All rights reserved."</p>
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1.5">Website URL Text</label>
            <input
              value={data.websiteUrl}
              onChange={(e) => onChange({ ...data, websiteUrl: e.target.value })}
              className="w-full px-3 py-2.5 bg-white/[0.03] border border-white/10 rounded-lg text-white text-sm focus:border-neon-cyan focus:outline-none"
              placeholder="exsellsalesli.com"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1.5">Location Text</label>
            <input
              value={data.locationText}
              onChange={(e) => onChange({ ...data, locationText: e.target.value })}
              className="w-full px-3 py-2.5 bg-white/[0.03] border border-white/10 rounded-lg text-white text-sm focus:border-neon-cyan focus:outline-none"
              placeholder="Long Island, New York"
            />
          </div>
        </div>
      </div>

      <div className="flex justify-end pt-4 border-t border-white/5">
        <SaveBtn onSave={onSave} saving={saving} />
      </div>
    </div>
  );
};


// ═══════════════════════════════════════
// SEO & META TAGS EDITOR
// ═══════════════════════════════════════

const SEO_PAGES: SEOPageKey[] = ['homepage', 'about', 'reviews', 'sold', 'privacy', 'terms'];

const PAGE_ICONS: Record<SEOPageKey, React.ElementType> = {
  homepage: Layout,
  about: FileText,
  reviews: MessageSquare,
  sold: Award,
  privacy: Shield,
  terms: FileText,
};

const CharCount: React.FC<{ value: string; ideal: number; max: number }> = ({ value, ideal, max }) => {
  const len = value.length;
  const color = len === 0 ? 'text-gray-600' : len <= ideal ? 'text-neon-green' : len <= max ? 'text-neon-orange' : 'text-red-400';
  return (
    <span className={`text-[10px] font-medium ${color}`}>
      {len}/{ideal} chars {len > max && '(too long!)'}
    </span>
  );
};

// ─── OG Image Library Picker ───
interface OgLibraryFile {
  name: string;
  url: string;
  size?: number;
  updatedAt?: string;
}

const OgImageLibrary: React.FC<{
  open: boolean;
  onClose: () => void;
  onSelect: (url: string) => void;
  currentUrl: string;
}> = ({ open, onClose, onSelect, currentUrl }) => {
  const [files, setFiles] = useState<OgLibraryFile[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  // Measured natural dimensions per file name (for aspect-ratio warnings)
  const [dims, setDims] = useState<Record<string, { w: number; h: number }>>({});
  const { toast } = useToast();


  const loadFiles = async () => {
    setLoading(true);
    setError(null);
    try {
      const { data: list, error: listErr } = await supabase.storage
        .from('og-images')
        .list('', { limit: 200, sortBy: { column: 'updated_at', order: 'desc' } });

      if (listErr) throw listErr;

      const imageFiles = (list || []).filter(
        (f) => f.name && !f.name.startsWith('.') && /\.(png|jpe?g|webp|gif)$/i.test(f.name)
      );

      const mapped: OgLibraryFile[] = imageFiles.map((f) => {
        const { data: urlData } = supabase.storage.from('og-images').getPublicUrl(f.name);
        return {
          name: f.name,
          url: urlData.publicUrl,
          size: (f as any).metadata?.size,
          updatedAt: (f as any).updated_at || (f as any).created_at,
        };
      });

      setFiles(mapped);
    } catch (err: any) {
      console.error('Failed to load OG image library:', err);
      setError(err?.message || 'Could not load images.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (open) loadFiles();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const handleDelete = async (name: string) => {
    try {
      const { error: delErr } = await supabase.storage.from('og-images').remove([name]);
      if (delErr) throw delErr;
      setFiles((prev) => prev.filter((f) => f.name !== name));
      toast({ title: 'Image removed', description: 'Deleted from the library.' });
    } catch (err: any) {
      toast({ title: 'Delete failed', description: err?.message || 'Could not delete the image.', variant: 'destructive' });
    }
  };

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center bg-black/70 backdrop-blur-sm p-4"
      onClick={onClose}
    >
      <div
        className="bg-[#13131f] border border-white/10 rounded-2xl w-full max-w-3xl max-h-[85vh] flex flex-col shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-white/10">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-blue-500/10 rounded-lg">
              <Images className="w-5 h-5 text-blue-400" />
            </div>
            <div>
              <h4 className="text-white font-bold text-sm">OG Image Library</h4>
              <p className="text-gray-500 text-xs">Reuse a previously uploaded social share image</p>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <button
              onClick={loadFiles}
              disabled={loading}
              className="p-2 text-gray-500 hover:text-white transition-colors disabled:opacity-50"
              title="Refresh"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
            <button onClick={onClose} className="p-2 text-gray-500 hover:text-white transition-colors" title="Close">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-5">
          {loading ? (
            <div className="flex flex-col items-center justify-center py-16 text-gray-500">
              <Loader2 className="w-7 h-7 animate-spin mb-3 text-blue-400" />
              <span className="text-sm">Loading images…</span>
            </div>
          ) : error ? (
            <div className="flex flex-col items-center justify-center py-16 text-center">
              <AlertCircle className="w-8 h-8 text-red-400 mb-3" />
              <p className="text-gray-400 text-sm mb-3">{error}</p>
              <button onClick={loadFiles} className="px-4 py-2 bg-white/5 border border-white/10 rounded-lg text-sm text-gray-300 hover:bg-white/10 transition-colors">
                Try again
              </button>
            </div>
          ) : files.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-center">
              <Image className="w-10 h-10 text-gray-600 mb-3" />
              <p className="text-gray-400 text-sm font-medium">No images in the library yet</p>
              <p className="text-gray-600 text-xs mt-1">Upload an og:image and it will appear here for reuse.</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
              {files.map((f) => {
                const isSelected = currentUrl === f.url;
                const dim = dims[f.name];
                const badRatio = dim ? isFarFromOgRatio(dim.w, dim.h) : false;
                return (
                  <div
                    key={f.name}
                    className={`group relative rounded-xl overflow-hidden border transition-all cursor-pointer ${
                      isSelected
                        ? 'border-neon-green ring-2 ring-neon-green/40'
                        : badRatio
                        ? 'border-amber-500/50 hover:border-amber-400'
                        : 'border-white/10 hover:border-blue-400/50'
                    }`}
                    onClick={() => { onSelect(f.url); onClose(); }}
                  >
                    <div className="aspect-[1200/630] bg-gray-800 overflow-hidden">
                      <img
                        src={f.url}
                        alt={f.name}
                        loading="lazy"
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        onLoad={(e) => {
                          const im = e.target as HTMLImageElement;
                          if (im.naturalWidth && im.naturalHeight) {
                            setDims((prev) =>
                              prev[f.name]?.w === im.naturalWidth
                                ? prev
                                : { ...prev, [f.name]: { w: im.naturalWidth, h: im.naturalHeight } }
                            );
                          }
                        }}
                        onError={(e) => { (e.target as HTMLImageElement).style.opacity = '0.2'; }}
                      />
                    </div>
                    {isSelected && (
                      <div className="absolute top-1.5 left-1.5 bg-neon-green text-black rounded-full p-0.5">
                        <Check className="w-3.5 h-3.5" />
                      </div>
                    )}
                    {badRatio && (
                      <div
                        className="absolute top-1.5 left-1.5 flex items-center gap-1 bg-amber-500/90 text-black text-[9px] font-bold px-1.5 py-0.5 rounded-md shadow"
                        style={isSelected ? { left: 'auto', right: '2.25rem' } : undefined}
                        title={`This image is ${dim?.w}×${dim?.h} (ratio ${(dim ? dim.w / dim.h : 0).toFixed(2)}:1), far from the recommended 1.91:1. It may look cropped or letterboxed when shared.`}
                      >
                        <AlertTriangle className="w-3 h-3" />
                        Off-ratio
                      </div>
                    )}
                    <button
                      onClick={(e) => { e.stopPropagation(); handleDelete(f.name); }}
                      className="absolute top-1.5 right-1.5 p-1.5 bg-black/60 text-gray-300 hover:text-red-400 rounded-lg opacity-0 group-hover:opacity-100 transition-all"
                      title="Delete from library"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                    <div className="px-2 py-1.5 bg-black/40">
                      <p className="text-gray-400 text-[10px] truncate" title={f.name}>{f.name}</p>
                      {dim && (
                        <p className={`text-[9px] ${badRatio ? 'text-amber-400' : 'text-gray-600'}`}>
                          {dim.w}×{dim.h}{badRatio ? ' • off-ratio' : ''}
                        </p>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {!loading && !error && files.length > 0 && (
            <div className="mt-4 flex items-center gap-2 text-[11px] text-gray-500">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />
              <span>
                Images flagged <span className="text-amber-400 font-semibold">Off-ratio</span> are far from the recommended
                1.91:1 ({OG_IMAGE_WIDTH}×{OG_IMAGE_HEIGHT}) social-share shape and may appear cropped or letterboxed when shared.
              </span>
            </div>
          )}
        </div>


        {/* Footer */}
        <div className="px-5 py-3 border-t border-white/10 flex items-center justify-between">
          <span className="text-gray-600 text-xs">{files.length} image{files.length === 1 ? '' : 's'} in library</span>
          <button onClick={onClose} className="px-4 py-2 bg-white/5 border border-white/10 rounded-lg text-sm text-gray-300 hover:bg-white/10 transition-colors">
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export const SEOMetaEditor: React.FC<{
  data: SEOContent; onChange: (d: SEOContent) => void; onSave: () => void; saving: boolean;
}> = ({ data, onChange, onSave, saving }) => {
  const [activePage, setActivePage] = useState<SEOPageKey>('homepage');
  const [uploading, setUploading] = useState(false);
  const [justUploaded, setJustUploaded] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [showLibrary, setShowLibrary] = useState(false);
  // Source image (data URL) currently being cropped before upload, or null.
  const [cropSrc, setCropSrc] = useState<string | null>(null);

  const { toast } = useToast();

  const updateField = (page: SEOPageKey, field: keyof SEOPageMeta, value: string) => {
    onChange({
      ...data,
      [page]: { ...data[page], [field]: value },
    });
  };

  // Step 1: user picks a file → validate, read as data URL, open the crop modal.
  const handleOgFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      toast({ title: 'Invalid file', description: 'Please choose an image file (JPG, PNG, or WebP).', variant: 'destructive' });
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      toast({ title: 'Image too large', description: 'Please choose an image under 5MB.', variant: 'destructive' });
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      setCropSrc(reader.result as string);
      // Allow re-selecting the same file later.
      if (fileInputRef.current) fileInputRef.current.value = '';
    };
    reader.onerror = () => {
      toast({ title: 'Could not read file', description: 'Please try a different image.', variant: 'destructive' });
      if (fileInputRef.current) fileInputRef.current.value = '';
    };
    reader.readAsDataURL(file);
  };

  // Step 2: user confirms crop (locked to 1.91:1) → resize to the exact
  // recommended 1200x630 dimensions and upload to the og-images bucket.
  const handleCropConfirm = (croppedDataUrl: string) => {
    setCropSrc(null);
    uploadOgImage(croppedDataUrl);
  };

  // Final image (already 1.91:1) → resize to the exact recommended 1200x630
  // dimensions and upload to the og-images bucket.
  const uploadOgImage = async (finalDataUrl: string) => {
    setUploading(true);
    setJustUploaded(false);
    try {
      const finalFile = dataUrlToFile(finalDataUrl, `og-crop-${Date.now()}.jpg`);
      let toUpload: File = finalFile;
      try {
        toUpload = await resizeToOgImage(finalFile, { quality: 0.85, format: 'image/jpeg' });
      } catch (resizeErr) {
        console.warn('OG resize failed, uploading file as-is instead:', resizeErr);
      }

      const fileName = `og-${activePage}-${Date.now()}-${Math.random().toString(36).slice(2)}.jpg`;

      const { error: uploadError } = await supabase.storage
        .from('og-images')
        .upload(fileName, toUpload, { cacheControl: '3600', upsert: false, contentType: 'image/jpeg' });

      if (uploadError) throw uploadError;

      const { data: urlData } = supabase.storage.from('og-images').getPublicUrl(fileName);
      const publicUrl = urlData.publicUrl;

      updateField(activePage, 'ogImage', publicUrl);
      setJustUploaded(true);
      setTimeout(() => setJustUploaded(false), 3000);
      toast({
        title: 'Image uploaded',
        description: `Cropped and resized to ${OG_IMAGE_WIDTH}×${OG_IMAGE_HEIGHT}. Click "Save Changes" to publish it.`,
      });
    } catch (err: any) {
      console.error('OG image upload failed:', err);
      toast({
        title: 'Upload failed',
        description: err?.message || 'Could not upload the image. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setUploading(false);
    }
  };



  const pageMeta = data[activePage];
  const defaultMeta = DEFAULT_SEO[activePage];
  const PageIcon = PAGE_ICONS[activePage];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h3 className="text-white font-bold text-base mb-1 flex items-center gap-2">
          <Globe className="w-4 h-4 text-neon-green" />
          SEO & Meta Tags
        </h3>
        <p className="text-gray-500 text-sm">
          Edit page titles, meta descriptions, and Open Graph tags for search engines and social media sharing. Changes go live immediately after saving.
        </p>
      </div>

      {/* Page selector pills */}
      <div>
        <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">Select Page</label>
        <div className="flex flex-wrap gap-1.5">
          {SEO_PAGES.map((page) => {
            const Icon = PAGE_ICONS[page];
            return (
              <button
                key={page}
                onClick={() => setActivePage(page)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-semibold transition-all ${
                  activePage === page
                    ? 'bg-gradient-to-r from-neon-green/20 to-emerald-500/20 text-white border border-neon-green/30'
                    : 'text-gray-500 hover:text-gray-300 hover:bg-white/[0.03] border border-transparent'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                {SEO_PAGE_LABELS[page]}
              </button>
            );
          })}
        </div>
      </div>

      {/* Active page editor */}
      <div className="bg-white/[0.02] border border-white/5 rounded-xl p-5 space-y-5">
        <div className="flex items-center gap-3 pb-4 border-b border-white/5">
          <div className="p-2 bg-neon-green/10 rounded-lg">
            <PageIcon className="w-5 h-5 text-neon-green" />
          </div>
          <div>
            <h4 className="text-white font-bold text-sm">{SEO_PAGE_LABELS[activePage]}</h4>
            <p className="text-gray-500 text-xs">Edit SEO meta tags for this page</p>
          </div>
        </div>

        {/* Page Title */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider flex items-center gap-1.5">
              <Search className="w-3 h-3" />
              Page Title
            </label>
            <CharCount value={pageMeta.title} ideal={60} max={70} />
          </div>
          <input
            value={pageMeta.title}
            onChange={(e) => updateField(activePage, 'title', e.target.value)}
            className="w-full px-4 py-3 bg-white/[0.03] border border-white/10 rounded-xl text-white text-sm placeholder-gray-600 focus:border-neon-green focus:outline-none focus:ring-1 focus:ring-neon-green/30 transition-all"
            placeholder={defaultMeta.title}
          />
          <p className="text-gray-600 text-[10px] mt-1">Appears in the browser tab and as the main link in search results. Ideal: 50-60 characters.</p>
        </div>

        {/* Meta Description */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider flex items-center gap-1.5">
              <FileText className="w-3 h-3" />
              Meta Description
            </label>
            <CharCount value={pageMeta.metaDescription} ideal={155} max={160} />
          </div>
          <textarea
            value={pageMeta.metaDescription}
            onChange={(e) => updateField(activePage, 'metaDescription', e.target.value)}
            rows={3}
            className="w-full px-4 py-3 bg-white/[0.03] border border-white/10 rounded-xl text-white text-sm placeholder-gray-600 focus:border-neon-green focus:outline-none focus:ring-1 focus:ring-neon-green/30 transition-all resize-y"
            placeholder={defaultMeta.metaDescription}
          />
          <p className="text-gray-600 text-[10px] mt-1">Shown below the title in search results. Ideal: 120-155 characters.</p>
        </div>

        {/* Open Graph Section */}
        <div className="pt-4 border-t border-white/5">
          <div className="flex items-center gap-2 mb-4">
            <div className="p-1.5 bg-blue-500/10 rounded-lg">
              <Globe className="w-3.5 h-3.5 text-blue-400" />
            </div>
            <div>
              <h5 className="text-white font-semibold text-sm">Open Graph Tags</h5>
              <p className="text-gray-500 text-[10px]">Controls how this page appears when shared on Facebook, Twitter, LinkedIn, etc.</p>
            </div>
          </div>

          {/* OG Title */}
          <div className="mb-4">
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">og:title</label>
              <CharCount value={pageMeta.ogTitle} ideal={60} max={90} />
            </div>
            <input
              value={pageMeta.ogTitle}
              onChange={(e) => updateField(activePage, 'ogTitle', e.target.value)}
              className="w-full px-4 py-3 bg-white/[0.03] border border-white/10 rounded-xl text-white text-sm placeholder-gray-600 focus:border-blue-400 focus:outline-none focus:ring-1 focus:ring-blue-400/30 transition-all"
              placeholder={defaultMeta.ogTitle}
            />
            <p className="text-gray-600 text-[10px] mt-1">Title shown in social media link previews. Can differ from page title for better engagement.</p>
          </div>

          {/* OG Description */}
          <div className="mb-4">
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">og:description</label>
              <CharCount value={pageMeta.ogDescription} ideal={155} max={200} />
            </div>
            <textarea
              value={pageMeta.ogDescription}
              onChange={(e) => updateField(activePage, 'ogDescription', e.target.value)}
              rows={2}
              className="w-full px-4 py-3 bg-white/[0.03] border border-white/10 rounded-xl text-white text-sm placeholder-gray-600 focus:border-blue-400 focus:outline-none focus:ring-1 focus:ring-blue-400/30 transition-all resize-y"
              placeholder={defaultMeta.ogDescription}
            />
            <p className="text-gray-600 text-[10px] mt-1">Description shown in social media link previews.</p>
          </div>

          {/* OG Image */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider flex items-center gap-1.5">
                <Image className="w-3 h-3" />
                og:image
              </label>
              {pageMeta.ogImage && (
                <span className="text-neon-green text-[10px] font-medium flex items-center gap-1">
                  <Eye className="w-3 h-3" /> Preview below
                </span>
              )}
            </div>
            <div className="flex items-stretch gap-2">
              <input
                value={pageMeta.ogImage}
                onChange={(e) => updateField(activePage, 'ogImage', e.target.value)}
                className="flex-1 px-4 py-3 bg-white/[0.03] border border-white/10 rounded-xl text-white text-sm placeholder-gray-600 focus:border-blue-400 focus:outline-none focus:ring-1 focus:ring-blue-400/30 transition-all"
                placeholder="https://yourdomain.com/images/og-image.jpg"
              />
              <input
                ref={fileInputRef}
                type="file"
                accept="image/png,image/jpeg,image/jpg,image/webp"
                onChange={handleOgFileSelect}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={uploading}
                className={`flex items-center gap-2 px-4 rounded-xl text-sm font-semibold whitespace-nowrap transition-all disabled:opacity-60 disabled:cursor-not-allowed ${
                  justUploaded
                    ? 'bg-neon-green/20 text-neon-green border border-neon-green/30'
                    : 'bg-blue-500/15 text-blue-300 border border-blue-400/30 hover:bg-blue-500/25'
                }`}
                title="Upload an image from your computer"
              >
                {uploading ? (
                  <><Loader2 className="w-4 h-4 animate-spin" /> Uploading…</>
                ) : justUploaded ? (
                  <><Check className="w-4 h-4" /> Uploaded</>
                ) : (
                  <><Upload className="w-4 h-4" /> Upload</>
                )}
              </button>
              <button
                type="button"
                onClick={() => setShowLibrary(true)}
                className="flex items-center gap-2 px-4 rounded-xl text-sm font-semibold whitespace-nowrap transition-all bg-white/[0.04] text-gray-300 border border-white/10 hover:bg-white/[0.08] hover:text-white"
                title="Choose from previously uploaded images"
              >
                <Images className="w-4 h-4" /> Library
              </button>
            </div>

            <p className="text-gray-600 text-[10px] mt-1">Paste an image URL or click <strong className="text-gray-400">Upload</strong> to pick a file (JPG, PNG, or WebP, under 5MB). You'll then <strong className="text-gray-400">crop it to the 1.91:1 social shape</strong>, and it's automatically resized to {OG_IMAGE_WIDTH}×{OG_IMAGE_HEIGHT}. Leave empty to use default. Remember to click "Save Changes" to publish.</p>

            {pageMeta.ogImage && (
              <div className="mt-3 relative rounded-lg overflow-hidden border border-white/10 max-w-sm">
                <img
                  src={pageMeta.ogImage}
                  alt="OG Image Preview"
                  className="w-full h-auto object-cover"
                  onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
                />
              </div>
            )}
          </div>
        </div>

        {/* Google Preview */}
        <div className="pt-4 border-t border-white/5">
          <div className="flex items-center gap-2 mb-3">
            <Search className="w-3.5 h-3.5 text-gray-500" />
            <span className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Google Search Preview</span>
          </div>
          <div className="bg-white rounded-xl p-4 max-w-xl">
            <div className="text-blue-700 text-lg font-medium leading-snug truncate hover:underline cursor-pointer">
              {pageMeta.title || defaultMeta.title || 'Page Title'}
            </div>
            <div className="text-green-700 text-sm mt-0.5 truncate">
              exsellsalesli.com{activePage === 'homepage' ? '' : `/${activePage === 'sold' ? 'sold' : activePage === 'privacy' ? 'privacy-policy' : activePage === 'terms' ? 'terms-of-service' : activePage}`}
            </div>
            <div className="text-gray-600 text-sm mt-1 line-clamp-2 leading-relaxed">
              {pageMeta.metaDescription || defaultMeta.metaDescription || 'Meta description will appear here...'}
            </div>
          </div>
        </div>

        {/* Social Preview */}
        <div className="pt-4 border-t border-white/5">
          <div className="flex items-center gap-2 mb-3">
            <Globe className="w-3.5 h-3.5 text-gray-500" />
            <span className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Social Media Share Preview</span>
          </div>
          <div className="bg-[#1a1a2e] rounded-xl overflow-hidden max-w-sm border border-white/10">
            {pageMeta.ogImage ? (
              <div className="aspect-[1200/630] bg-gray-800 overflow-hidden">
                <img
                  src={pageMeta.ogImage}
                  alt="Social preview"
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = '';
                    (e.target as HTMLImageElement).className = 'hidden';
                  }}
                />
              </div>
            ) : (
              <div className="aspect-[1200/630] bg-gradient-to-br from-gray-800 to-gray-900 flex items-center justify-center">
                <div className="text-center">
                  <Image className="w-8 h-8 text-gray-600 mx-auto mb-2" />
                  <span className="text-gray-600 text-xs">No OG image set</span>
                </div>
              </div>
            )}
            <div className="p-3">
              <div className="text-gray-500 text-[10px] uppercase tracking-wider mb-1">exsellsalesli.com</div>
              <div className="text-white font-semibold text-sm leading-snug truncate">
                {pageMeta.ogTitle || defaultMeta.ogTitle || 'OG Title'}
              </div>
              <div className="text-gray-400 text-xs mt-1 line-clamp-2">
                {pageMeta.ogDescription || defaultMeta.ogDescription || 'OG Description will appear here...'}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Info box */}
      <div className="flex items-start gap-3 p-4 bg-blue-500/5 border border-blue-500/10 rounded-xl">
        <AlertCircle className="w-4 h-4 text-blue-400 flex-shrink-0 mt-0.5" />
        <div className="text-xs text-gray-400 leading-relaxed">
          <strong className="text-blue-400">SEO Tips:</strong> Keep page titles under 60 characters and meta descriptions under 155 characters for best results in search engines. Open Graph tags control how your pages look when shared on social media — a compelling og:title and og:image can significantly increase click-through rates.
        </div>
      </div>

      {/* OG Image Library Modal */}
      <OgImageLibrary
        open={showLibrary}
        onClose={() => setShowLibrary(false)}
        onSelect={(url) => updateField(activePage, 'ogImage', url)}
        currentUrl={pageMeta.ogImage}
      />

      {/* Interactive crop step (locked to the 1.91:1 social-share ratio) */}
      {cropSrc && (
        <ImageCropModal
          imageUrl={cropSrc}
          lockedAspectRatio={OG_IMAGE_RATIO}
          title="Crop Social Share Image (1.91:1)"
          saveLabel="Use This Crop"
          onSave={handleCropConfirm}
          onClose={() => setCropSrc(null)}
        />
      )}



      <div className="flex justify-end pt-4 border-t border-white/5">
        <SaveBtn onSave={onSave} saving={saving} />
      </div>
    </div>
  );
};


// ═══════════════════════════════════════
// ANNOUNCEMENT BANNER EDITOR
// ═══════════════════════════════════════



const BANNER_THEMES: { value: AnnouncementBannerContent['theme']; label: string; preview: string; dot: string }[] = [
  { value: 'pink', label: 'Pink / Orange', preview: 'from-neon-pink via-rose-500 to-neon-orange', dot: 'bg-pink-500' },
  { value: 'orange', label: 'Orange / Gold', preview: 'from-neon-orange via-amber-500 to-yellow-500', dot: 'bg-orange-400' },
  { value: 'cyan', label: 'Cyan / Blue', preview: 'from-neon-cyan via-blue-500 to-indigo-500', dot: 'bg-cyan-400' },
  { value: 'green', label: 'Green / Teal', preview: 'from-neon-green via-emerald-500 to-teal-500', dot: 'bg-green-400' },
  { value: 'purple', label: 'Purple / Pink', preview: 'from-neon-purple via-violet-500 to-fuchsia-500', dot: 'bg-purple-500' },
];

const Toggle: React.FC<{ checked: boolean; onChange: (v: boolean) => void; label: string; hint?: string }> = ({ checked, onChange, label, hint }) => (
  <button
    type="button"
    onClick={() => onChange(!checked)}
    className="flex items-center gap-3 w-full text-left"
  >
    <span className={`relative inline-flex h-6 w-11 flex-shrink-0 items-center rounded-full transition-colors ${checked ? 'bg-neon-green' : 'bg-white/10'}`}>
      <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${checked ? 'translate-x-6' : 'translate-x-1'}`} />
    </span>
    <span>
      <span className="block text-white text-sm font-semibold">{label}</span>
      {hint && <span className="block text-gray-500 text-xs">{hint}</span>}
    </span>
  </button>
);

export const AnnouncementBannerEditor: React.FC<{
  data: AnnouncementBannerContent; onChange: (d: AnnouncementBannerContent) => void; onSave: () => void; saving: boolean;
}> = ({ data, onChange, onSave, saving }) => {
  const theme = BANNER_THEMES.find(t => t.value === data.theme) || BANNER_THEMES[0];
  const showCtaFields = data.ctaType !== 'none';

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-white font-bold text-base mb-1 flex items-center gap-2">
          <Layout className="w-4 h-4 text-neon-pink" />
          Announcement Banner
        </h3>
        <p className="text-gray-500 text-sm">
          A site-wide bar that appears across the very top of every page — perfect for news, sales, holiday hours, or special services. It only shows when enabled.
        </p>
      </div>

      {/* Enable toggle */}
      <div className="bg-white/[0.02] border border-white/5 rounded-xl p-4">
        <Toggle
          checked={data.enabled}
          onChange={(v) => onChange({ ...data, enabled: v })}
          label={data.enabled ? 'Banner is LIVE on the website' : 'Banner is hidden'}
          hint="Turn this on to display the banner to all visitors."
        />
      </div>

      {/* Live preview */}
      <div>
        <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">Live Preview</label>
        <div className={`rounded-xl overflow-hidden border border-white/10 bg-gradient-to-r ${theme.preview}`}>
          <div className="flex items-center gap-3 px-4 py-2 text-white text-sm font-semibold">
            <span className="flex-1 truncate">{data.message || 'Your announcement message will appear here…'}</span>
            {showCtaFields && data.ctaLabel && (
              <span className="flex-shrink-0 inline-flex items-center gap-1.5 bg-white/20 px-3 py-1 rounded-full text-xs font-bold">
                {data.ctaLabel}
              </span>
            )}
            {data.dismissible && <X className="w-4 h-4 flex-shrink-0" />}
          </div>
        </div>
      </div>

      <Field
        label="Message"
        value={data.message}
        onChange={(v) => onChange({ ...data, message: v })}
        multiline
        rows={2}
        placeholder="e.g. Holiday Hours: Open until 8PM all December! Or — New financing options now available."
        hint={`${data.message.length} characters. Keep it short and punchy for the best look.`}
      />

      {/* Theme picker */}
      <div>
        <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">Color Theme</label>
        <div className="flex flex-wrap gap-2">
          {BANNER_THEMES.map(t => (
            <button
              key={t.value}
              onClick={() => onChange({ ...data, theme: t.value })}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${data.theme === t.value ? 'border-white/30 bg-white/10 text-white' : 'border-white/5 text-gray-500 hover:border-white/10'}`}
            >
              <span className={`w-2.5 h-2.5 rounded-full ${t.dot}`} />{t.label}
            </button>
          ))}
        </div>
      </div>

      {/* Call to action */}
      <div className="bg-white/[0.02] border border-white/5 rounded-xl p-4 space-y-4">
        <h4 className="text-white font-semibold text-sm">Call-to-Action Button (optional)</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1.5">Action Type</label>
            <select
              value={data.ctaType}
              onChange={(e) => onChange({ ...data, ctaType: e.target.value as AnnouncementBannerContent['ctaType'] })}
              className="w-full px-3 py-2.5 bg-white/[0.03] border border-white/10 rounded-lg text-white text-sm focus:border-neon-cyan focus:outline-none"
            >
              <option value="none">No Button</option>
              <option value="scroll">Scroll to Section</option>
              <option value="route">Go to Page</option>
              <option value="external">Open External Link</option>
              <option value="phone">Call Phone Number</option>
            </select>
          </div>
          {showCtaFields && (
            <Field
              label="Button Label"
              value={data.ctaLabel}
              onChange={(v) => onChange({ ...data, ctaLabel: v })}
              placeholder="Shop the Sale"
            />
          )}
        </div>
        {showCtaFields && (
          <Field
            label={
              data.ctaType === 'scroll' ? 'Section ID'
              : data.ctaType === 'route' ? 'Page Path'
              : data.ctaType === 'phone' ? 'Phone Number'
              : 'Full URL'
            }
            value={data.ctaTarget}
            onChange={(v) => onChange({ ...data, ctaTarget: v })}
            placeholder={
              data.ctaType === 'scroll' ? 'inventory'
              : data.ctaType === 'route' ? '/sold'
              : data.ctaType === 'phone' ? '6313884426'
              : 'https://...'
            }
            hint={
              data.ctaType === 'scroll' ? 'e.g. hero, inventory, services, why-us, contact'
              : data.ctaType === 'route' ? 'e.g. /sold, /reviews, /about'
              : data.ctaType === 'phone' ? 'Digits only — opens the phone dialer.'
              : 'Opens in a new tab.'
            }
          />
        )}
      </div>

      {/* Behavior toggles */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white/[0.02] border border-white/5 rounded-xl p-4">
          <Toggle
            checked={data.dismissible}
            onChange={(v) => onChange({ ...data, dismissible: v })}
            label="Allow visitors to close it"
            hint="Shows an X. Remembered for their session."
          />
        </div>
        <div className="bg-white/[0.02] border border-white/5 rounded-xl p-4">
          <Toggle
            checked={data.marquee}
            onChange={(v) => onChange({ ...data, marquee: v })}
            label="Scrolling ticker"
            hint="Animate the message across the bar."
          />
        </div>
      </div>

      <div className="flex justify-end pt-4 border-t border-white/5">
        <SaveBtn onSave={onSave} saving={saving} />
      </div>
    </div>
  );
};
