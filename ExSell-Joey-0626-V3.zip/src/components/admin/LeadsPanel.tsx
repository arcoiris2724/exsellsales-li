import React, { useState, useEffect, useCallback } from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  Search, Mail, Phone, User, Clock, CheckCircle,
  Loader2, RefreshCw, ChevronDown, ChevronUp, MessageSquare,
  StickyNote, Trash2, Car, HelpCircle, Calendar,
  Tag, Inbox, UserCheck, Archive, ExternalLink, BellRing, Zap,
  Camera, Download, ImageIcon,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { toast } from '@/components/ui/use-toast';
import LeadConversation from '@/components/admin/LeadConversation';

/**
 * Pull a vehicle ID out of a `vehicle_interest` string produced by the
 * inline "Request More Info" form on /inventory/:id.
 */
function parseVehicleRef(raw: string | null | undefined): { label: string; vehicleId: number | null } {
  if (!raw) return { label: '', vehicleId: null };
  const match = raw.match(/^(.*?)\s*\(#(\d+)\)\s*$/);
  if (match) {
    const id = Number(match[2]);
    return {
      label: match[1].trim(),
      vehicleId: Number.isFinite(id) ? id : null,
    };
  }
  return { label: raw.trim(), vehicleId: null };
}

export interface TradeInPhoto {
  label: string;
  slot: string;
  url: string;
  path: string;
  size: number;
  uploaded_at: string;
}

export interface Lead {
  id: number;
  name: string;
  email: string | null;
  phone: string;
  subject: string | null;
  message: string | null;
  vehicle_interest: string | null;
  preferred_date: string | null;
  preferred_time: string | null;
  lead_type: string | null;
  status: string;
  admin_notes: string | null;
  created_at: string;
  updated_at: string;
  notification_sent_at: string | null;
  first_response_at: string | null;
  trade_in_photos?: TradeInPhoto[] | null;
}

const leadStatusConfig = {
  new: {
    label: 'New',
    color: 'text-neon-cyan',
    bg: 'bg-neon-cyan/10',
    border: 'border-neon-cyan/30',
    icon: Inbox,
    description: 'Unread inquiry',
  },
  contacted: {
    label: 'Contacted',
    color: 'text-amber-400',
    bg: 'bg-amber-400/10',
    border: 'border-amber-400/30',
    icon: UserCheck,
    description: 'Follow-up in progress',
  },
  closed: {
    label: 'Closed',
    color: 'text-gray-400',
    bg: 'bg-gray-400/10',
    border: 'border-gray-400/30',
    icon: Archive,
    description: 'Resolved / Closed',
  },
};

const leadTypeConfig: Record<string, { label: string; color: string; bg: string; icon: React.ElementType }> = {
  contact: { label: 'Contact', color: 'text-neon-pink', bg: 'bg-neon-pink/10', icon: MessageSquare },
  'test-drive': { label: 'Test Drive', color: 'text-neon-cyan', bg: 'bg-neon-cyan/10', icon: Car },
  'trade-in': { label: 'Trade-In', color: 'text-neon-orange', bg: 'bg-neon-orange/10', icon: RefreshCw },
};


const subjectLabels: Record<string, string> = {
  general: 'General Inquiry',
  vehicle: 'Vehicle Question',
  'trade-in': 'Trade-In Valuation',
  detailing: 'Detailing Services',
  'test-drive': 'Test Drive',
};

const LeadsPanel: React.FC = () => {
  const location = useLocation();
  const [leads, setLeads] = useState<Lead[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [sortField] = useState<'created_at'>('created_at');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');
  const [expandedLead, setExpandedLead] = useState<number | string | null>(null);
  const [editingNotes, setEditingNotes] = useState<number | string | null>(null);
  const [notesText, setNotesText] = useState('');
  const [actionLoading, setActionLoading] = useState<number | string | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<number | string | null>(null);

  const loadLeads = useCallback(async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('leads')
        .select('*')
        .order('created_at', { ascending: false });
      if (error) throw error;
      setLeads((data || []) as Lead[]);
    } catch (err) {
      console.error('Failed to load leads:', err);
      toast({ title: 'Error', description: 'Failed to load leads.', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadLeads(); }, [loadLeads]);

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const leadId = params.get('lead');
    if (leadId && leads.length > 0) {
      const found = leads.find((l) => String(l.id) === leadId);
      if (found) {
        setExpandedLead(found.id);
        setTimeout(() => {
          document.getElementById(`lead-row-${found.id}`)?.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }, 100);
      }
    }
  }, [location.search, leads]);

  useEffect(() => {
    const interval = setInterval(() => {
      supabase
        .from('leads')
        .select('*')
        .order('created_at', { ascending: false })
        .then(({ data }) => {
          if (data) setLeads(data as Lead[]);
        });
    }, 30000);
    return () => clearInterval(interval);
  }, []);

  const handleStatusChange = async (leadId: number, newStatus: string) => {
    setActionLoading(leadId);
    try {
      const { error } = await supabase
        .from('leads')
        .update({ status: newStatus, updated_at: new Date().toISOString() })
        .eq('id', leadId);
      if (error) throw error;
      setLeads((prev) =>
        prev.map((l) => (l.id === leadId ? { ...l, status: newStatus, updated_at: new Date().toISOString() } : l))
      );
      toast({ title: 'Status Updated', description: `Lead #${leadId} marked as ${newStatus}.` });
    } catch (err) {
      console.error('Failed to update status:', err);
      toast({ title: 'Error', description: 'Failed to update lead status.', variant: 'destructive' });
    } finally {
      setActionLoading(null);
    }
  };

  const handleSaveNotes = async (leadId: number) => {
    setActionLoading(leadId);
    try {
      const { error } = await supabase
        .from('leads')
        .update({ admin_notes: notesText.trim() || null, updated_at: new Date().toISOString() })
        .eq('id', leadId);
      if (error) throw error;
      setLeads((prev) =>
        prev.map((l) => (l.id === leadId ? { ...l, admin_notes: notesText.trim() || null, updated_at: new Date().toISOString() } : l))
      );
      setEditingNotes(null);
      toast({ title: 'Notes Saved', description: 'Admin notes updated successfully.' });
    } catch (err) {
      console.error('Failed to save notes:', err);
      toast({ title: 'Error', description: 'Failed to save notes.', variant: 'destructive' });
    } finally {
      setActionLoading(null);
    }
  };

  const handleDelete = async (leadId: number) => {
    setActionLoading(leadId);
    try {
      const { error } = await supabase.from('leads').delete().eq('id', leadId);
      if (error) throw error;
      setLeads((prev) => prev.filter((l) => l.id !== leadId));
      setDeleteConfirm(null);
      toast({ title: 'Lead Deleted', description: `Lead #${leadId} has been removed.` });
    } catch (err) {
      console.error('Failed to delete lead:', err);
      toast({ title: 'Error', description: 'Failed to delete lead.', variant: 'destructive' });
    } finally {
      setActionLoading(null);
    }
  };

  const filtered = leads
    .filter((l) => {
      if (statusFilter !== 'all' && l.status !== statusFilter) return false;
      if (typeFilter !== 'all' && l.lead_type !== typeFilter) return false;
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        const searchStr = `${l.name} ${l.email || ''} ${l.phone} ${l.subject || ''} ${l.message || ''} ${l.vehicle_interest || ''}`.toLowerCase();
        if (!searchStr.includes(q)) return false;
      }
      return true;
    })
    .sort((a, b) => (sortDir === 'desc' ? b.created_at.localeCompare(a.created_at) : a.created_at.localeCompare(b.created_at)));

  const stats = {
    total: leads.length,
    new: leads.filter((l) => l.status === 'new').length,
    contacted: leads.filter((l) => l.status === 'contacted').length,
    closed: leads.filter((l) => l.status === 'closed').length,
    contact: leads.filter((l) => l.lead_type === 'contact').length,
    testDrive: leads.filter((l) => l.lead_type === 'test-drive').length,
    tradeIn: leads.filter((l) => l.lead_type === 'trade-in').length,
  };


  const formatTimestamp = (ts: string) => {
    try {
      const d = new Date(ts);
      return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) +
        ' at ' + d.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
    } catch { return ts; }
  };

  const getRelativeTime = (ts: string) => {
    try {
      const now = Date.now();
      const then = new Date(ts).getTime();
      const diffMs = now - then;
      const diffMins = Math.floor(diffMs / 60000);
      const diffHours = Math.floor(diffMs / 3600000);
      const diffDays = Math.floor(diffMs / 86400000);
      if (diffMins < 1) return 'Just now';
      if (diffMins < 60) return `${diffMins}m ago`;
      if (diffHours < 24) return `${diffHours}h ago`;
      if (diffDays < 7) return `${diffDays}d ago`;
      return new Date(ts).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    } catch { return ''; }
  };

  return (
    <div className="space-y-6">
      {/* Stats Row */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-7 gap-3">
        <MiniStat label="Total Leads" value={stats.total} color="text-white" bg="bg-white/5" />
        <MiniStat label="New" value={stats.new} color="text-neon-cyan" bg="bg-neon-cyan/5" />
        <MiniStat label="Contacted" value={stats.contacted} color="text-amber-400" bg="bg-amber-400/5" />
        <MiniStat label="Closed" value={stats.closed} color="text-gray-400" bg="bg-gray-400/5" />
        <MiniStat label="Contact Leads" value={stats.contact} color="text-neon-pink" bg="bg-neon-pink/5" />
        <MiniStat label="Test Drives" value={stats.testDrive} color="text-neon-cyan" bg="bg-neon-cyan/5" />
        <MiniStat label="Trade-Ins" value={stats.tradeIn} color="text-neon-orange" bg="bg-neon-orange/5" />
      </div>


      {/* Toolbar */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by name, email, phone, message..."
            className="w-full pl-10 pr-4 py-2.5 bg-white/[0.03] border border-white/10 rounded-lg text-white text-sm placeholder-gray-500 focus:border-neon-cyan focus:outline-none"
          />
        </div>
        <div className="flex gap-2 flex-wrap">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2.5 bg-white/[0.03] border border-white/10 rounded-lg text-white text-sm focus:border-neon-cyan focus:outline-none"
          >
            <option value="all">All Status</option>
            <option value="new">New</option>
            <option value="contacted">Contacted</option>
            <option value="closed">Closed</option>
          </select>
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="px-3 py-2.5 bg-white/[0.03] border border-white/10 rounded-lg text-white text-sm focus:border-neon-cyan focus:outline-none"
          >
            <option value="all">All Types</option>
            <option value="contact">Contact</option>
            <option value="test-drive">Test Drive</option>
            <option value="trade-in">Trade-In</option>
          </select>

          <select
            value={`${sortField}-${sortDir}`}
            onChange={(e) => {
              const [, dir] = e.target.value.split('-');
              setSortDir(dir as 'asc' | 'desc');
            }}
            className="px-3 py-2.5 bg-white/[0.03] border border-white/10 rounded-lg text-white text-sm focus:border-neon-cyan focus:outline-none"
          >
            <option value="created_at-desc">Newest First</option>
            <option value="created_at-asc">Oldest First</option>
          </select>
          <button
            onClick={loadLeads}
            disabled={loading}
            className="p-2.5 bg-white/[0.03] border border-white/10 rounded-lg text-gray-400 hover:text-white transition-colors"
            title="Refresh"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Leads List */}
      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="w-8 h-8 text-neon-pink animate-spin" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-20">
          <Inbox className="w-12 h-12 text-gray-600 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-white mb-2">No leads found</h3>
          <p className="text-gray-400 text-sm">
            {searchQuery || statusFilter !== 'all' || typeFilter !== 'all'
              ? 'Try adjusting your filters'
              : 'Contact form submissions and test drive bookings will appear here.'}
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((lead) => {
            const sc = leadStatusConfig[lead.status as keyof typeof leadStatusConfig] || leadStatusConfig.new;
            const StatusIcon = sc.icon;
            const typeConf = leadTypeConfig[lead.lead_type || 'contact'] || leadTypeConfig.contact;
            const TypeIcon = typeConf.icon;
            const isExpanded = expandedLead === lead.id;
            const isNew = lead.status === 'new';

            return (
              <div
                key={lead.id}
                id={`lead-row-${lead.id}`}
                className={`bg-white/[0.02] border rounded-xl overflow-hidden transition-all ${
                  deleteConfirm === lead.id
                    ? 'border-red-500/40'
                    : isNew
                    ? 'border-neon-cyan/20 hover:border-neon-cyan/40'
                    : 'border-white/5 hover:border-white/10'
                }`}
              >
                <div
                  className="flex flex-col sm:flex-row items-start sm:items-center gap-3 p-4 cursor-pointer"
                  onClick={() => setExpandedLead(isExpanded ? null : lead.id)}
                >
                  <div className={`flex items-center gap-1.5 px-2.5 py-1.5 ${sc.bg} ${sc.border} border rounded-full flex-shrink-0`}>
                    <StatusIcon className={`w-3.5 h-3.5 ${sc.color}`} />
                    <span className={`text-xs font-semibold ${sc.color}`}>{sc.label}</span>
                  </div>

                  <div className={`flex items-center gap-1.5 px-2.5 py-1 ${typeConf.bg} rounded-full flex-shrink-0`}>
                    <TypeIcon className={`w-3 h-3 ${typeConf.color}`} />
                    <span className={`text-[11px] font-semibold ${typeConf.color}`}>{typeConf.label}</span>
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5 flex-wrap">
                      <span className="text-white font-semibold text-sm truncate">{lead.name}</span>
                      {isNew && (
                        <span className="px-1.5 py-0.5 bg-neon-cyan/20 text-neon-cyan text-[10px] font-bold rounded uppercase tracking-wider flex-shrink-0">
                          New
                        </span>
                      )}
                      {lead.notification_sent_at && (
                        <span
                          title={`Dealer emailed ${formatTimestamp(lead.notification_sent_at)}`}
                          className="inline-flex items-center gap-1 px-1.5 py-0.5 bg-neon-green/15 text-neon-green text-[10px] font-bold rounded uppercase tracking-wider flex-shrink-0"
                        >
                          <BellRing className="w-2.5 h-2.5" />
                          Notified
                        </span>
                      )}
                      {lead.first_response_at && (
                        <span
                          title={`First response ${formatTimestamp(lead.first_response_at)}`}
                          className="inline-flex items-center gap-1 px-1.5 py-0.5 bg-neon-pink/15 text-neon-pink text-[10px] font-bold rounded uppercase tracking-wider flex-shrink-0"
                        >
                          <Zap className="w-2.5 h-2.5" />
                          Replied
                        </span>
                      )}
                      {Array.isArray(lead.trade_in_photos) && lead.trade_in_photos.length > 0 && (
                        <span
                          title={`${lead.trade_in_photos.length} trade-in photo${lead.trade_in_photos.length === 1 ? '' : 's'}`}
                          className="inline-flex items-center gap-1 px-1.5 py-0.5 bg-neon-orange/15 text-neon-orange text-[10px] font-bold rounded uppercase tracking-wider flex-shrink-0"
                        >
                          <Camera className="w-2.5 h-2.5" />
                          {lead.trade_in_photos.length} Photo{lead.trade_in_photos.length === 1 ? '' : 's'}
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-3 text-xs text-gray-500">
                      <span className="flex items-center gap-1">
                        <Phone className="w-3 h-3" />
                        {lead.phone}
                      </span>
                      {lead.email && (
                        <span className="flex items-center gap-1 truncate">
                          <Mail className="w-3 h-3" />
                          {lead.email}
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="hidden md:flex items-center gap-1.5 text-xs text-gray-400 flex-shrink-0 max-w-[160px]">
                    <Tag className="w-3 h-3 flex-shrink-0" />
                    <span className="truncate">{subjectLabels[lead.subject || ''] || lead.subject || 'General'}</span>
                  </div>
                  {lead.vehicle_interest && (() => {
                    const ref = parseVehicleRef(lead.vehicle_interest);
                    if (ref.vehicleId) {
                      return (
                        <Link
                          to={`/inventory/${ref.vehicleId}`}
                          onClick={(e) => e.stopPropagation()}
                          title={`Open VDP for ${ref.label}`}
                          className="hidden lg:flex items-center gap-1.5 text-xs text-neon-orange hover:text-white hover:bg-neon-orange/10 px-2 py-1 rounded border border-neon-orange/20 hover:border-neon-orange/40 transition-colors flex-shrink-0 max-w-[220px] group"
                        >
                          <Car className="w-3 h-3 flex-shrink-0" />
                          <span className="truncate font-semibold">{ref.label}</span>
                          <ExternalLink className="w-3 h-3 flex-shrink-0 opacity-60 group-hover:opacity-100" />
                        </Link>
                      );
                    }
                    return (
                      <div className="hidden lg:flex items-center gap-1.5 text-xs text-neon-orange flex-shrink-0 max-w-[180px]">
                        <Car className="w-3 h-3 flex-shrink-0" />
                        <span className="truncate">{ref.label}</span>
                      </div>
                    );
                  })()}

                  <div className="text-right flex-shrink-0">
                    <div className="text-xs text-gray-400">{getRelativeTime(lead.created_at)}</div>
                  </div>

                  <div className="flex-shrink-0">
                    {isExpanded ? <ChevronUp className="w-4 h-4 text-gray-500" /> : <ChevronDown className="w-4 h-4 text-gray-500" />}
                  </div>
                </div>

                {isExpanded && (
                  <div className="border-t border-white/5 p-4 space-y-4 bg-white/[0.01]">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-3">
                        <h4 className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Lead Details</h4>
                        <div className="space-y-2.5">
                          <DetailRow icon={User} label="Name" value={lead.name} />
                          <DetailRow icon={Phone} label="Phone" value={lead.phone} isLink href={`tel:${lead.phone}`} />
                          {lead.email && (
                            <DetailRow icon={Mail} label="Email" value={lead.email} isLink href={`mailto:${lead.email}`} />
                          )}
                          <DetailRow icon={Tag} label="Subject" value={subjectLabels[lead.subject || ''] || lead.subject || 'General'} />
                          <DetailRow icon={HelpCircle} label="Lead Type" value={typeConf.label} valueColor={typeConf.color} />
                          {lead.vehicle_interest && (() => {
                            const ref = parseVehicleRef(lead.vehicle_interest);
                            if (ref.vehicleId) {
                              return (
                                <div className="flex items-center gap-3 text-sm">
                                  <Car className="w-3.5 h-3.5 text-gray-500 flex-shrink-0" />
                                  <span className="text-gray-500 w-20 flex-shrink-0">Vehicle</span>
                                  <Link
                                    to={`/inventory/${ref.vehicleId}`}
                                    onClick={(e) => e.stopPropagation()}
                                    className="text-neon-orange hover:text-white hover:underline truncate inline-flex items-center gap-1.5 font-semibold"
                                  >
                                    <span className="truncate">{ref.label}</span>
                                    <span className="text-[10px] font-mono text-gray-500">#{ref.vehicleId}</span>
                                    <ExternalLink className="w-3 h-3 flex-shrink-0" />
                                  </Link>
                                </div>
                              );
                            }
                            return <DetailRow icon={Car} label="Vehicle" value={ref.label} valueColor="text-neon-orange" />;
                          })()}
                          {lead.preferred_date && <DetailRow icon={Calendar} label="Pref. Date" value={lead.preferred_date} />}
                          {lead.preferred_time && <DetailRow icon={Clock} label="Pref. Time" value={lead.preferred_time} />}
                          <DetailRow icon={Clock} label="Submitted" value={formatTimestamp(lead.created_at)} />
                          {lead.updated_at && lead.updated_at !== lead.created_at && (
                            <DetailRow icon={RefreshCw} label="Updated" value={formatTimestamp(lead.updated_at)} />
                          )}
                        </div>

                        {lead.message && (
                          <div className="pt-2">
                            <div className="flex items-center gap-2 text-xs text-gray-400 mb-1.5">
                              <MessageSquare className="w-3 h-3" />
                              <span>Customer Message</span>
                            </div>
                            <div className="text-sm text-gray-300 bg-white/[0.03] border border-white/5 rounded-lg p-3 whitespace-pre-wrap">
                              {lead.message}
                            </div>
                          </div>
                        )}
                      </div>

                      <div className="space-y-4">
                        <div>
                          <h4 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3">Quick Actions</h4>
                          <div className="flex flex-wrap gap-2">
                            <a
                              href={`tel:${lead.phone}`}
                              onClick={(e) => e.stopPropagation()}
                              className="flex items-center gap-2 px-4 py-2.5 bg-neon-green/10 border border-neon-green/30 text-neon-green text-xs font-semibold rounded-lg hover:bg-neon-green/20 transition-colors"
                            >
                              <Phone className="w-3.5 h-3.5" />
                              Call
                            </a>
                            <a
                              href={`sms:${lead.phone}`}
                              onClick={(e) => e.stopPropagation()}
                              className="flex items-center gap-2 px-4 py-2.5 bg-neon-cyan/10 border border-neon-cyan/30 text-neon-cyan text-xs font-semibold rounded-lg hover:bg-neon-cyan/20 transition-colors"
                            >
                              <MessageSquare className="w-3.5 h-3.5" />
                              Text
                            </a>
                            {lead.email && (
                              <a
                                href={`mailto:${lead.email}`}
                                onClick={(e) => e.stopPropagation()}
                                className="flex items-center gap-2 px-4 py-2.5 bg-neon-pink/10 border border-neon-pink/30 text-neon-pink text-xs font-semibold rounded-lg hover:bg-neon-pink/20 transition-colors"
                              >
                                <Mail className="w-3.5 h-3.5" />
                                Email
                              </a>
                            )}
                          </div>
                        </div>

                        <div>
                          <h4 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3">Update Status</h4>
                          <div className="grid grid-cols-3 gap-2">
                            {(Object.keys(leadStatusConfig) as Array<keyof typeof leadStatusConfig>).map((status) => {
                              const cfg = leadStatusConfig[status];
                              const Icon = cfg.icon;
                              const isActive = lead.status === status;
                              return (
                                <button
                                  key={status}
                                  onClick={() => { if (!isActive) handleStatusChange(lead.id, status); }}
                                  disabled={isActive || actionLoading === lead.id}
                                  className={`flex flex-col items-center gap-1.5 px-3 py-3 rounded-lg text-xs font-medium transition-all ${
                                    isActive
                                      ? `${cfg.bg} ${cfg.border} border ${cfg.color}`
                                      : 'bg-white/[0.03] border border-white/5 text-gray-400 hover:text-white hover:border-white/20'
                                  } disabled:opacity-50`}
                                >
                                  {actionLoading === lead.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <Icon className="w-4 h-4" />}
                                  {cfg.label}
                                </button>
                              );
                            })}
                          </div>
                        </div>

                        <div>
                          <h4 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3 flex items-center gap-2">
                            <StickyNote className="w-3 h-3" />
                            Admin Notes
                          </h4>
                          {editingNotes === lead.id ? (
                            <div className="space-y-2">
                              <textarea
                                value={notesText}
                                onChange={(e) => setNotesText(e.target.value)}
                                rows={3}
                                placeholder="Add internal notes about this lead..."
                                className="w-full px-3 py-2 bg-black border border-white/10 rounded-lg text-white text-sm placeholder-gray-600 focus:border-neon-cyan focus:outline-none resize-none"
                              />
                              <div className="flex gap-2">
                                <button
                                  onClick={() => handleSaveNotes(lead.id)}
                                  disabled={actionLoading === lead.id}
                                  className="px-4 py-2 bg-gradient-to-r from-neon-cyan to-neon-green text-black text-xs font-bold rounded-lg hover:opacity-90 transition-opacity disabled:opacity-50 flex items-center gap-1.5"
                                >
                                  {actionLoading === lead.id ? <Loader2 className="w-3 h-3 animate-spin" /> : <CheckCircle className="w-3 h-3" />}
                                  Save
                                </button>
                                <button
                                  onClick={() => setEditingNotes(null)}
                                  className="px-4 py-2 border border-white/10 text-gray-400 text-xs rounded-lg hover:text-white transition-colors"
                                >
                                  Cancel
                                </button>
                              </div>
                            </div>
                          ) : (
                            <div
                              onClick={() => {
                                setEditingNotes(lead.id);
                                setNotesText(lead.admin_notes || '');
                              }}
                              className="min-h-[60px] px-3 py-2 bg-white/[0.02] border border-white/5 rounded-lg text-sm cursor-pointer hover:border-white/20 transition-colors"
                            >
                              {lead.admin_notes ? (
                                <p className="text-gray-300">{lead.admin_notes}</p>
                              ) : (
                                <p className="text-gray-600 italic">Click to add notes...</p>
                              )}
                            </div>
                          )}
                        </div>

                        <div className="pt-2 border-t border-white/5">
                          {deleteConfirm === lead.id ? (
                            <div className="flex items-center gap-3">
                              <span className="text-red-400 text-xs font-medium">Delete this lead?</span>
                              <button
                                onClick={() => handleDelete(lead.id)}
                                disabled={actionLoading === lead.id}
                                className="px-3 py-1.5 bg-red-500 text-white text-xs font-semibold rounded-lg hover:bg-red-600 transition-colors disabled:opacity-50 flex items-center gap-1"
                              >
                                {actionLoading === lead.id ? <Loader2 className="w-3 h-3 animate-spin" /> : <Trash2 className="w-3 h-3" />}
                                Yes, Delete
                              </button>
                              <button
                                onClick={() => setDeleteConfirm(null)}
                                className="px-3 py-1.5 border border-white/10 text-gray-400 text-xs rounded-lg hover:text-white transition-colors"
                              >
                                Cancel
                              </button>
                            </div>
                          ) : (
                            <button
                              onClick={() => setDeleteConfirm(lead.id)}
                              className="flex items-center gap-2 text-xs text-gray-500 hover:text-red-400 transition-colors"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                              Delete Lead
                            </button>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Trade-In Photos Gallery — only renders when the lead has uploaded photos */}
                    {Array.isArray(lead.trade_in_photos) && lead.trade_in_photos.length > 0 && (
                      <TradeInPhotoGallery photos={lead.trade_in_photos} leadId={lead.id} />
                    )}


                    {(() => {
                      const ref = parseVehicleRef(lead.vehicle_interest);
                      return (
                        <div className="pt-4 mt-2 border-t border-white/5">
                          <LeadConversation
                            leadId={lead.id as unknown as string}
                            leadName={lead.name}
                            leadEmail={lead.email}
                            vehicleTitle={ref.label || null}
                            vehicleId={ref.vehicleId}
                            originalMessage={lead.message}
                            originalSentAt={lead.created_at}
                          />
                        </div>
                      );
                    })()}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      <div className="text-center py-2 text-gray-600 text-xs">
        {filtered.length} of {leads.length} leads shown
      </div>
    </div>
  );
};

const MiniStat: React.FC<{ label: string; value: number; color: string; bg: string }> = ({ label, value, color, bg }) => (
  <div className={`${bg} border border-white/5 rounded-xl p-3`}>
    <span className="text-gray-500 text-xs font-medium">{label}</span>
    <div className={`text-xl font-bold ${color} mt-1`}>{value}</div>
  </div>
);

const DetailRow: React.FC<{
  icon: React.ElementType;
  label: string;
  value: string;
  isLink?: boolean;
  href?: string;
  valueColor?: string;
}> = ({ icon: Icon, label, value, isLink, href, valueColor }) => (
  <div className="flex items-center gap-3 text-sm">
    <Icon className="w-3.5 h-3.5 text-gray-500 flex-shrink-0" />
    <span className="text-gray-500 w-20 flex-shrink-0">{label}</span>
    {isLink && href ? (
      <a href={href} className="text-neon-cyan hover:underline truncate" onClick={(e) => e.stopPropagation()}>
        {value}
      </a>
    ) : (
      <span className={`${valueColor || 'text-white'} truncate`}>{value}</span>
    )}
  </div>
);

/**
 * Trade-In Photo Gallery — renders the customer-submitted photos that were
 * uploaded with their trade-in request. Each photo is clickable (opens the
 * original full-size image in a new tab) and shows the slot label
 * (Front / Back / Left Side / Right Side / Interior / Odometer).
 */
const TradeInPhotoGallery: React.FC<{
  photos: TradeInPhoto[];
  leadId: number;
}> = ({ photos, leadId }) => {
  const [lightboxPhoto, setLightboxPhoto] = useState<TradeInPhoto | null>(null);

  const formatSize = (bytes: number) => {
    if (!bytes) return '';
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <div className="pt-4 mt-2 border-t border-white/5">
      <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
        <h4 className="text-xs font-semibold text-gray-400 uppercase tracking-wider flex items-center gap-2">
          <Camera className="w-3.5 h-3.5 text-neon-orange" />
          Trade-In Photos
          <span className="text-gray-600 normal-case font-normal">
            ({photos.length} submitted by customer)
          </span>
        </h4>
        <a
          href={photos[0]?.url}
          target="_blank"
          rel="noopener noreferrer"
          onClick={(e) => e.stopPropagation()}
          className="text-[11px] text-gray-500 hover:text-neon-cyan inline-flex items-center gap-1 transition-colors"
          title={`Open lead #${leadId}'s photo folder in storage`}
        >
          <ExternalLink className="w-3 h-3" />
          Open in new tab
        </a>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
        {photos.map((photo, idx) => (
          <button
            key={`${photo.path || photo.url}-${idx}`}
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setLightboxPhoto(photo);
            }}
            className="group relative aspect-[4/3] rounded-lg overflow-hidden bg-black border border-white/10 hover:border-neon-orange/50 transition-all"
            title={`${photo.label} — click to enlarge`}
          >
            <img
              src={photo.url}
              alt={photo.label}
              loading="lazy"
              className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              onError={(e) => {
                // Fallback if the image fails to load
                (e.currentTarget as HTMLImageElement).style.display = 'none';
              }}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent pointer-events-none" />
            <div className="absolute bottom-0 left-0 right-0 p-1.5 pointer-events-none">
              <div className="text-[10px] font-bold text-white drop-shadow truncate">{photo.label}</div>
              {photo.size > 0 && (
                <div className="text-[9px] text-gray-300/80">{formatSize(photo.size)}</div>
              )}
            </div>
            <div className="absolute top-1 right-1 w-5 h-5 bg-black/60 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
              <ImageIcon className="w-2.5 h-2.5 text-white" />
            </div>
          </button>
        ))}
      </div>

      {/* Lightbox modal */}
      {lightboxPhoto && (
        <div
          className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setLightboxPhoto(null)}
        >
          <div
            className="relative max-w-5xl max-h-[90vh] w-full"
            onClick={(e) => e.stopPropagation()}
          >
            <img
              src={lightboxPhoto.url}
              alt={lightboxPhoto.label}
              className="w-full h-full object-contain rounded-lg"
            />
            <div className="absolute top-3 left-3 px-3 py-1.5 bg-black/70 backdrop-blur rounded-full text-white text-xs font-semibold border border-white/10 flex items-center gap-2">
              <Camera className="w-3.5 h-3.5 text-neon-orange" />
              {lightboxPhoto.label}
              <span className="text-gray-400">·</span>
              <span className="text-gray-400 font-normal">{formatSize(lightboxPhoto.size)}</span>
            </div>
            <div className="absolute top-3 right-3 flex gap-2">
              <a
                href={lightboxPhoto.url}
                target="_blank"
                rel="noopener noreferrer"
                download
                onClick={(e) => e.stopPropagation()}
                className="px-3 py-1.5 bg-black/70 backdrop-blur hover:bg-neon-cyan/20 border border-white/10 hover:border-neon-cyan/50 rounded-full text-white text-xs font-semibold transition-colors inline-flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                Download
              </a>
              <button
                type="button"
                onClick={() => setLightboxPhoto(null)}
                className="w-8 h-8 bg-black/70 backdrop-blur hover:bg-red-500 border border-white/10 rounded-full text-white transition-colors flex items-center justify-center"
                title="Close"
              >
                <span className="text-lg leading-none">×</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default LeadsPanel;