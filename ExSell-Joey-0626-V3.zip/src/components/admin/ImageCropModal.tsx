import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  X, RotateCw, RotateCcw, FlipHorizontal, FlipVertical,
  Check, Undo2, Crop, ZoomIn, ZoomOut, Maximize2
} from 'lucide-react';

interface ImageCropModalProps {
  imageUrl: string;
  onSave: (editedDataUrl: string) => void;
  onClose: () => void;
  /** When set, locks cropping to this aspect ratio and starts in crop mode. */
  lockedAspectRatio?: number;
  /** Optional custom title shown in the modal header. */
  title?: string;
  /** Optional label for the save button (defaults to "Apply Changes"). */
  saveLabel?: string;
}

interface CropRect {
  x: number;
  y: number;
  width: number;
  height: number;
}

type DragHandle = 'tl' | 'tr' | 'bl' | 'br' | 't' | 'b' | 'l' | 'r' | 'move' | null;

const ASPECT_RATIOS = [
  { label: 'Free', value: 0 },
  { label: '4:3', value: 4 / 3 },
  { label: '16:9', value: 16 / 9 },
  { label: '1:1', value: 1 },
  { label: '3:2', value: 3 / 2 },
];

const ImageCropModal: React.FC<ImageCropModalProps> = ({
  imageUrl, onSave, onClose, lockedAspectRatio, title, saveLabel,
}) => {
  const isLocked = typeof lockedAspectRatio === 'number' && lockedAspectRatio > 0;
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [image, setImage] = useState<HTMLImageElement | null>(null);
  const [rotation, setRotation] = useState(0);
  const [flipH, setFlipH] = useState(false);
  const [flipV, setFlipV] = useState(false);
  const [crop, setCrop] = useState<CropRect>({ x: 0, y: 0, width: 0, height: 0 });
  const [isCropping, setIsCropping] = useState(isLocked);
  const [dragHandle, setDragHandle] = useState<DragHandle>(null);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [cropStart, setCropStart] = useState<CropRect>({ x: 0, y: 0, width: 0, height: 0 });
  const [aspectRatio, setAspectRatio] = useState(isLocked ? (lockedAspectRatio as number) : 0);
  const [displayScale, setDisplayScale] = useState(1);
  const [displayOffset, setDisplayOffset] = useState({ x: 0, y: 0 });

  // Helper: compute a centered "cover" crop region for a given aspect ratio.
  const computeRatioCrop = useCallback((effW: number, effH: number, ratio: number): CropRect => {
    let cw = effW;
    let ch = cw / ratio;
    if (ch > effH) {
      ch = effH;
      cw = ch * ratio;
    }
    return {
      x: Math.max(0, (effW - cw) / 2),
      y: Math.max(0, (effH - ch) / 2),
      width: Math.min(cw, effW),
      height: Math.min(ch, effH),
    };
  }, []);

  // Load the image
  useEffect(() => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      setImage(img);
      // Initialize crop: a centered ratio "cover" region when locked, else full image.
      if (isLocked) {
        setCrop(computeRatioCrop(img.width, img.height, lockedAspectRatio as number));
      } else {
        setCrop({ x: 0, y: 0, width: img.width, height: img.height });
      }
    };
    img.src = imageUrl;
  }, [imageUrl, isLocked, lockedAspectRatio, computeRatioCrop]);

  // Get the effective image dimensions after rotation
  const getEffectiveDimensions = useCallback(() => {
    if (!image) return { width: 0, height: 0 };
    const isVertical = rotation === 90 || rotation === 270;
    return {
      width: isVertical ? image.height : image.width,
      height: isVertical ? image.width : image.height,
    };
  }, [image, rotation]);

  // Draw the canvas
  useEffect(() => {
    if (!image || !canvasRef.current || !containerRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d')!;
    const container = containerRef.current;
    const containerRect = container.getBoundingClientRect();

    const { width: effW, height: effH } = getEffectiveDimensions();

    // Calculate scale to fit container
    const maxW = containerRect.width - 40;
    const maxH = containerRect.height - 40;
    const scale = Math.min(maxW / effW, maxH / effH, 1);
    setDisplayScale(scale);

    canvas.width = Math.round(effW * scale);
    canvas.height = Math.round(effH * scale);

    const offsetX = Math.round((containerRect.width - canvas.width) / 2);
    const offsetY = Math.round((containerRect.height - canvas.height) / 2);
    setDisplayOffset({ x: offsetX, y: offsetY });

    // Clear
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Apply transforms
    ctx.save();
    ctx.translate(canvas.width / 2, canvas.height / 2);
    ctx.rotate((rotation * Math.PI) / 180);
    ctx.scale(flipH ? -1 : 1, flipV ? -1 : 1);
    ctx.drawImage(
      image,
      -image.width * scale / 2,
      -image.height * scale / 2,
      image.width * scale,
      image.height * scale
    );
    ctx.restore();

    // Draw crop overlay if cropping
    if (isCropping) {
      const sx = crop.x * scale;
      const sy = crop.y * scale;
      const sw = crop.width * scale;
      const sh = crop.height * scale;

      // Darken outside crop area
      ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
      // Top
      ctx.fillRect(0, 0, canvas.width, sy);
      // Bottom
      ctx.fillRect(0, sy + sh, canvas.width, canvas.height - sy - sh);
      // Left
      ctx.fillRect(0, sy, sx, sh);
      // Right
      ctx.fillRect(sx + sw, sy, canvas.width - sx - sw, sh);

      // Crop border
      ctx.strokeStyle = '#00e5ff';
      ctx.lineWidth = 2;
      ctx.strokeRect(sx, sy, sw, sh);

      // Rule of thirds grid
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.3)';
      ctx.lineWidth = 0.5;
      for (let i = 1; i <= 2; i++) {
        // Vertical
        ctx.beginPath();
        ctx.moveTo(sx + (sw * i) / 3, sy);
        ctx.lineTo(sx + (sw * i) / 3, sy + sh);
        ctx.stroke();
        // Horizontal
        ctx.beginPath();
        ctx.moveTo(sx, sy + (sh * i) / 3);
        ctx.lineTo(sx + sw, sy + (sh * i) / 3);
        ctx.stroke();
      }

      // Corner handles
      const handleSize = 10;
      ctx.fillStyle = '#00e5ff';
      const corners = [
        { x: sx, y: sy },
        { x: sx + sw - handleSize, y: sy },
        { x: sx, y: sy + sh - handleSize },
        { x: sx + sw - handleSize, y: sy + sh - handleSize },
      ];
      corners.forEach(c => ctx.fillRect(c.x, c.y, handleSize, handleSize));

      // Edge handles
      ctx.fillRect(sx + sw / 2 - handleSize / 2, sy, handleSize, 4);
      ctx.fillRect(sx + sw / 2 - handleSize / 2, sy + sh - 4, handleSize, 4);
      ctx.fillRect(sx, sy + sh / 2 - handleSize / 2, 4, handleSize);
      ctx.fillRect(sx + sw - 4, sy + sh / 2 - handleSize / 2, 4, handleSize);

      // Dimensions label
      ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
      ctx.fillRect(sx + sw / 2 - 40, sy + sh + 8, 80, 20);
      ctx.fillStyle = '#00e5ff';
      ctx.font = '11px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(`${Math.round(crop.width)}×${Math.round(crop.height)}`, sx + sw / 2, sy + sh + 22);
    }
  }, [image, rotation, flipH, flipV, crop, isCropping, getEffectiveDimensions]);

  // Determine which handle is under the mouse
  const getHandleAtPoint = (mx: number, my: number): DragHandle => {
    const s = displayScale;
    const sx = crop.x * s;
    const sy = crop.y * s;
    const sw = crop.width * s;
    const sh = crop.height * s;
    const hs = 14; // hit area

    // Corners
    if (Math.abs(mx - sx) < hs && Math.abs(my - sy) < hs) return 'tl';
    if (Math.abs(mx - (sx + sw)) < hs && Math.abs(my - sy) < hs) return 'tr';
    if (Math.abs(mx - sx) < hs && Math.abs(my - (sy + sh)) < hs) return 'bl';
    if (Math.abs(mx - (sx + sw)) < hs && Math.abs(my - (sy + sh)) < hs) return 'br';

    // Edges
    if (Math.abs(my - sy) < hs && mx > sx + hs && mx < sx + sw - hs) return 't';
    if (Math.abs(my - (sy + sh)) < hs && mx > sx + hs && mx < sx + sw - hs) return 'b';
    if (Math.abs(mx - sx) < hs && my > sy + hs && my < sy + sh - hs) return 'l';
    if (Math.abs(mx - (sx + sw)) < hs && my > sy + hs && my < sy + sh - hs) return 'r';

    // Inside crop = move
    if (mx >= sx && mx <= sx + sw && my >= sy && my <= sy + sh) return 'move';

    return null;
  };

  const handleCanvasMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isCropping || !canvasRef.current) return;
    const rect = canvasRef.current.getBoundingClientRect();
    const mx = e.clientX - rect.left;
    const my = e.clientY - rect.top;
    const handle = getHandleAtPoint(mx, my);
    if (handle) {
      setDragHandle(handle);
      setDragStart({ x: e.clientX, y: e.clientY });
      setCropStart({ ...crop });
    }
  };

  const handleCanvasMouseMove = useCallback((e: MouseEvent) => {
    if (!dragHandle || !image) return;
    const dx = (e.clientX - dragStart.x) / displayScale;
    const dy = (e.clientY - dragStart.y) / displayScale;
    const { width: effW, height: effH } = getEffectiveDimensions();

    let newCrop = { ...cropStart };

    const applyAspectRatio = (c: CropRect, anchor: 'tl' | 'tr' | 'bl' | 'br'): CropRect => {
      if (aspectRatio <= 0) return c;
      const currentRatio = c.width / c.height;
      if (currentRatio > aspectRatio) {
        c.width = c.height * aspectRatio;
      } else {
        c.height = c.width / aspectRatio;
      }
      return c;
    };

    switch (dragHandle) {
      case 'move':
        newCrop.x = Math.max(0, Math.min(effW - cropStart.width, cropStart.x + dx));
        newCrop.y = Math.max(0, Math.min(effH - cropStart.height, cropStart.y + dy));
        break;
      case 'tl':
        newCrop.x = Math.max(0, cropStart.x + dx);
        newCrop.y = Math.max(0, cropStart.y + dy);
        newCrop.width = cropStart.width - (newCrop.x - cropStart.x);
        newCrop.height = cropStart.height - (newCrop.y - cropStart.y);
        newCrop = applyAspectRatio(newCrop, 'br');
        break;
      case 'tr':
        newCrop.y = Math.max(0, cropStart.y + dy);
        newCrop.width = Math.min(effW - cropStart.x, cropStart.width + dx);
        newCrop.height = cropStart.height - (newCrop.y - cropStart.y);
        newCrop = applyAspectRatio(newCrop, 'bl');
        break;
      case 'bl':
        newCrop.x = Math.max(0, cropStart.x + dx);
        newCrop.width = cropStart.width - (newCrop.x - cropStart.x);
        newCrop.height = Math.min(effH - cropStart.y, cropStart.height + dy);
        newCrop = applyAspectRatio(newCrop, 'tr');
        break;
      case 'br':
        newCrop.width = Math.min(effW - cropStart.x, cropStart.width + dx);
        newCrop.height = Math.min(effH - cropStart.y, cropStart.height + dy);
        newCrop = applyAspectRatio(newCrop, 'tl');
        break;
      case 't':
        newCrop.y = Math.max(0, cropStart.y + dy);
        newCrop.height = cropStart.height - (newCrop.y - cropStart.y);
        break;
      case 'b':
        newCrop.height = Math.min(effH - cropStart.y, cropStart.height + dy);
        break;
      case 'l':
        newCrop.x = Math.max(0, cropStart.x + dx);
        newCrop.width = cropStart.width - (newCrop.x - cropStart.x);
        break;
      case 'r':
        newCrop.width = Math.min(effW - cropStart.x, cropStart.width + dx);
        break;
    }

    // Enforce minimum size
    if (newCrop.width < 30) newCrop.width = 30;
    if (newCrop.height < 30) newCrop.height = 30;

    setCrop(newCrop);
  }, [dragHandle, dragStart, cropStart, displayScale, aspectRatio, getEffectiveDimensions, image]);

  const handleCanvasMouseUp = useCallback(() => {
    setDragHandle(null);
  }, []);

  useEffect(() => {
    if (dragHandle) {
      window.addEventListener('mousemove', handleCanvasMouseMove);
      window.addEventListener('mouseup', handleCanvasMouseUp);
      return () => {
        window.removeEventListener('mousemove', handleCanvasMouseMove);
        window.removeEventListener('mouseup', handleCanvasMouseUp);
      };
    }
  }, [dragHandle, handleCanvasMouseMove, handleCanvasMouseUp]);

  const handleRotate = (deg: number) => {
    const newRotation = (rotation + deg + 360) % 360;
    setRotation(newRotation);
    if (image) {
      const isVertical = newRotation === 90 || newRotation === 270;
      const effW = isVertical ? image.height : image.width;
      const effH = isVertical ? image.width : image.height;
      // When locked, re-fit a centered ratio crop; otherwise reset to full image.
      if (isLocked) {
        setCrop(computeRatioCrop(effW, effH, lockedAspectRatio as number));
      } else {
        setCrop({ x: 0, y: 0, width: effW, height: effH });
      }
    }
  };

  const handleFlipH = () => setFlipH(!flipH);
  const handleFlipV = () => setFlipV(!flipV);

  const toggleCrop = () => {
    if (!isCropping && image) {
      const { width, height } = getEffectiveDimensions();
      // Start with a centered crop region (80% of image)
      const cw = width * 0.8;
      const ch = aspectRatio > 0 ? cw / aspectRatio : height * 0.8;
      setCrop({
        x: (width - cw) / 2,
        y: (height - Math.min(ch, height * 0.8)) / 2,
        width: cw,
        height: Math.min(ch, height * 0.8),
      });
    }
    setIsCropping(!isCropping);
  };

  const resetAll = () => {
    setRotation(0);
    setFlipH(false);
    setFlipV(false);
    if (isLocked && image) {
      // Keep the locked ratio crop; just re-center it.
      setIsCropping(true);
      setCrop(computeRatioCrop(image.width, image.height, lockedAspectRatio as number));
    } else {
      setIsCropping(false);
      if (image) {
        setCrop({ x: 0, y: 0, width: image.width, height: image.height });
      }
    }
  };

  const handleSave = () => {
    if (!image) return;

    const outputCanvas = document.createElement('canvas');
    const ctx = outputCanvas.getContext('2d')!;

    if (isCropping) {
      // Output the cropped region
      outputCanvas.width = Math.round(crop.width);
      outputCanvas.height = Math.round(crop.height);

      // First draw the full transformed image to a temp canvas
      const { width: effW, height: effH } = getEffectiveDimensions();
      const tempCanvas = document.createElement('canvas');
      tempCanvas.width = effW;
      tempCanvas.height = effH;
      const tempCtx = tempCanvas.getContext('2d')!;

      tempCtx.translate(effW / 2, effH / 2);
      tempCtx.rotate((rotation * Math.PI) / 180);
      tempCtx.scale(flipH ? -1 : 1, flipV ? -1 : 1);
      tempCtx.drawImage(image, -image.width / 2, -image.height / 2);

      // Then crop from the temp canvas
      ctx.drawImage(
        tempCanvas,
        crop.x, crop.y, crop.width, crop.height,
        0, 0, crop.width, crop.height
      );
    } else {
      // Output the full transformed image
      const { width: effW, height: effH } = getEffectiveDimensions();
      outputCanvas.width = effW;
      outputCanvas.height = effH;

      ctx.translate(effW / 2, effH / 2);
      ctx.rotate((rotation * Math.PI) / 180);
      ctx.scale(flipH ? -1 : 1, flipV ? -1 : 1);
      ctx.drawImage(image, -image.width / 2, -image.height / 2);
    }

    const dataUrl = outputCanvas.toDataURL('image/jpeg', 0.92);
    onSave(dataUrl);
  };

  const getCursorForHandle = (handle: DragHandle): string => {
    switch (handle) {
      case 'tl': case 'br': return 'nwse-resize';
      case 'tr': case 'bl': return 'nesw-resize';
      case 't': case 'b': return 'ns-resize';
      case 'l': case 'r': return 'ew-resize';
      case 'move': return 'move';
      default: return 'crosshair';
    }
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black/90 backdrop-blur-sm">
      <div className="relative w-full max-w-5xl h-[90vh] bg-[#0a0a0a] rounded-2xl border border-white/10 shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3 border-b border-white/10 bg-[#111] flex-shrink-0">
          <h3 className="text-white font-bold text-sm flex items-center gap-2">
            <Crop className="w-4 h-4 text-neon-cyan" />
            {title || 'Edit Image'}
          </h3>
          <div className="flex items-center gap-2">
            <button
              onClick={resetAll}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-gray-400 hover:text-white border border-white/10 rounded-lg hover:bg-white/5 transition-colors"
            >
              <Undo2 className="w-3.5 h-3.5" />
              Reset
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-gray-400 hover:text-white hover:bg-white/5 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Toolbar */}
        <div className="flex items-center gap-1 px-4 py-2.5 border-b border-white/5 bg-[#0d0d0d] flex-shrink-0 overflow-x-auto">
          {/* Rotate */}
          <ToolButton icon={<RotateCcw className="w-4 h-4" />} label="Rotate Left" onClick={() => handleRotate(-90)} />
          <ToolButton icon={<RotateCw className="w-4 h-4" />} label="Rotate Right" onClick={() => handleRotate(90)} />
          <div className="w-px h-6 bg-white/10 mx-1" />
          {/* Flip */}
          <ToolButton icon={<FlipHorizontal className="w-4 h-4" />} label="Flip H" onClick={handleFlipH} active={flipH} />
          <ToolButton icon={<FlipVertical className="w-4 h-4" />} label="Flip V" onClick={handleFlipV} active={flipV} />
          <div className="w-px h-6 bg-white/10 mx-1" />
          {isLocked ? (
            /* Locked aspect ratio: crop is always on, no free toggle/presets. */
            <span className="flex items-center gap-1.5 px-2.5 py-1.5 text-[11px] font-semibold rounded-md bg-neon-cyan/20 text-neon-cyan border border-neon-cyan/30">
              <Crop className="w-3.5 h-3.5" />
              Locked 1.91:1 (Social)
            </span>
          ) : (
            <>
              {/* Crop toggle */}
              <ToolButton
                icon={<Crop className="w-4 h-4" />}
                label="Crop"
                onClick={toggleCrop}
                active={isCropping}
                accent
              />
              {isCropping && (
                <>
                  <div className="w-px h-6 bg-white/10 mx-1" />
                  {/* Aspect ratio presets */}
                  {ASPECT_RATIOS.map((ar) => (
                    <button
                      key={ar.label}
                      onClick={() => {
                        setAspectRatio(ar.value);
                        if (ar.value > 0 && image) {
                          const { width: effW, height: effH } = getEffectiveDimensions();
                          let cw = crop.width;
                          let ch = cw / ar.value;
                          if (ch > effH) {
                            ch = effH * 0.8;
                            cw = ch * ar.value;
                          }
                          setCrop({
                            x: Math.max(0, (effW - cw) / 2),
                            y: Math.max(0, (effH - ch) / 2),
                            width: Math.min(cw, effW),
                            height: Math.min(ch, effH),
                          });
                        }
                      }}
                      className={`px-2.5 py-1 text-[11px] font-semibold rounded-md transition-colors ${
                        aspectRatio === ar.value
                          ? 'bg-neon-cyan/20 text-neon-cyan border border-neon-cyan/30'
                          : 'text-gray-500 hover:text-white hover:bg-white/5 border border-transparent'
                      }`}
                    >
                      {ar.label}
                    </button>
                  ))}
                  <div className="w-px h-6 bg-white/10 mx-1" />
                  <button
                    onClick={() => {
                      if (image) {
                        const { width, height } = getEffectiveDimensions();
                        setCrop({ x: 0, y: 0, width, height });
                      }
                    }}
                    className="flex items-center gap-1 px-2 py-1 text-[11px] text-gray-500 hover:text-white rounded-md hover:bg-white/5 transition-colors"
                  >
                    <Maximize2 className="w-3 h-3" />
                    Full
                  </button>
                </>
              )}
            </>
          )}

          {/* Info */}
          <div className="ml-auto flex items-center gap-3 text-[11px] text-gray-600">
            {rotation !== 0 && <span>{rotation}°</span>}
            {flipH && <span>Flipped H</span>}
            {flipV && <span>Flipped V</span>}
            {image && (
              <span>
                {image.width}×{image.height}
              </span>
            )}
          </div>
        </div>

        {/* Canvas Area */}
        <div
          ref={containerRef}
          className="flex-1 relative overflow-hidden bg-[#080808]"
          style={{
            backgroundImage: 'radial-gradient(circle at 50% 50%, rgba(255,255,255,0.02) 0%, transparent 70%)',
          }}
        >
          {image && (
            <div className="absolute inset-0 flex items-center justify-center">
              <canvas
                ref={canvasRef}
                onMouseDown={handleCanvasMouseDown}
                className="shadow-2xl"
                style={{
                  cursor: isCropping ? (dragHandle ? getCursorForHandle(dragHandle) : 'crosshair') : 'default',
                }}
              />
            </div>
          )}
          {!image && (
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="animate-pulse text-gray-600 text-sm">Loading image...</div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-5 py-3 border-t border-white/10 bg-[#111] flex-shrink-0">
          <div className="text-[11px] text-gray-600">
            {isCropping && (
              <span>
                Crop: {Math.round(crop.width)}×{Math.round(crop.height)} px
                {aspectRatio > 0 && ` (${ASPECT_RATIOS.find(a => a.value === aspectRatio)?.label})`}
              </span>
            )}
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 text-sm text-gray-400 hover:text-white border border-white/10 rounded-lg hover:bg-white/5 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              disabled={!image}
              className="flex items-center gap-2 px-5 py-2 bg-gradient-to-r from-neon-cyan to-neon-green text-black font-bold text-sm rounded-lg hover:opacity-90 transition-opacity disabled:opacity-40"
            >
              <Check className="w-4 h-4" />
              {saveLabel || 'Apply Changes'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// Toolbar button component
const ToolButton: React.FC<{
  icon: React.ReactNode;
  label: string;
  onClick: () => void;
  active?: boolean;
  accent?: boolean;
}> = ({ icon, label, onClick, active, accent }) => (
  <button
    onClick={onClick}
    title={label}
    className={`flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-lg transition-all ${
      active
        ? accent
          ? 'bg-neon-cyan/20 text-neon-cyan border border-neon-cyan/30'
          : 'bg-white/10 text-white border border-white/20'
        : 'text-gray-400 hover:text-white hover:bg-white/5 border border-transparent'
    }`}
  >
    {icon}
    <span className="hidden sm:inline">{label}</span>
  </button>
);

export default ImageCropModal;
