import React, { useState, useCallback } from 'react';
import {
  X, Upload, Loader2, Plus, Trash2, ImagePlus, AlertCircle,
  Globe, Download, CheckCircle, Image, ChevronDown, ChevronUp,
  ExternalLink, Zap, Camera, AlertTriangle, RefreshCw, Layers
} from 'lucide-react';
import { Vehicle, uploadVehicleImage, uploadImageFromUrl } from '@/data/vehicles';
import { supabase } from '@/lib/supabase';
import AIPricingPanel from '@/components/admin/AIPricingPanel';
import AIDescriptionPanel from '@/components/admin/AIDescriptionPanel';
import MarkAsSoldDialog from '@/components/admin/MarkAsSoldDialog';
import TemplatePicker from '@/components/admin/TemplatePicker';
import ImageUploadManager from '@/components/admin/ImageUploadManager';
import { VehicleTemplate } from '@/data/vehicleTemplates';



interface VehicleFormModalProps {
  vehicle?: Vehicle | null;
  initialData?: Partial<Vehicle> | null;
  onSave: (data: Partial<Vehicle>) => Promise<void>;
  onClose: () => void;
}


const BODY_TYPES = ['Sedan', 'SUV', 'Truck', 'Coupe', 'Convertible', 'Van', 'Wagon', 'Hatchback', 'Minivan'];

const TRANSMISSIONS = ['Automatic', 'Manual', 'CVT'];
const DRIVETRAINS = ['FWD', 'RWD', 'AWD', '4WD'];
const FUEL_TYPES = ['Gasoline', 'Diesel', 'Hybrid', 'Electric', 'Plug-in Hybrid'];
const STATUSES = ['available', 'pending', 'sold'] as const;

type ImportPhase = 'idle' | 'fetching' | 'scraping' | 'uploading' | 'done' | 'error';

interface ImportProgress {
  phase: ImportPhase;
  message: string;
  totalImages: number;
  uploadedImages: number;
  errors: string[];
}

const VehicleFormModal: React.FC<VehicleFormModalProps> = ({ vehicle, initialData, onSave, onClose }) => {
  const isEditing = !!vehicle;
  const hasInitialData = !!initialData && !isEditing;
  const source = vehicle || initialData;

  const [form, setForm] = useState({
    year: source?.year || new Date().getFullYear(),
    make: source?.make || '',
    model: source?.model || '',
    trim: source?.trim || '',
    price: source?.price || 0,
    mileage: source?.mileage || 0,
    exteriorColor: source?.exteriorColor || '',
    interiorColor: source?.interiorColor || '',
    transmission: source?.transmission || 'Automatic',
    drivetrain: source?.drivetrain || 'FWD',
    fuelType: source?.fuelType || 'Gasoline',
    engine: source?.engine || '',
    bodyType: source?.bodyType || 'Sedan',
    vin: source?.vin || '',
    image: source?.image || '',
    images: source?.images || [] as string[],
    features: source?.features || [] as string[],
    status: source?.status || 'available' as Vehicle['status'],
    description: source?.description || '',
    videoUrl: source?.videoUrl || '',
    soldDate: source?.soldDate || undefined as string | undefined,
    soldPrice: source?.soldPrice || undefined as number | undefined,
  });



  const [showSoldDialog, setShowSoldDialog] = useState(false);
  const [newFeature, setNewFeature] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  // Template picker state
  const showTemplatePickerInitially = !isEditing && !hasInitialData;
  const [showTemplatePicker, setShowTemplatePicker] = useState(showTemplatePickerInitially);
  const [appliedTemplate, setAppliedTemplate] = useState<VehicleTemplate | null>(null);

  // Handle template selection
  const handleTemplateSelect = (template: VehicleTemplate) => {
    updateMultipleFields({
      make: template.make,
      model: template.model,
      trim: template.trim,
      engine: template.engine,
      transmission: template.transmission,
      drivetrain: template.drivetrain,
      fuelType: template.fuelType,
      bodyType: template.bodyType,
      features: template.features,
    });
    setAppliedTemplate(template);
    setShowTemplatePicker(false);
    setShowImport(false); // Collapse CL import since we used a template
  };

  // Craigslist import state
  const [craigslistUrl, setCraigslistUrl] = useState('');
  const [showImport, setShowImport] = useState(false); // Default collapsed - template picker is primary


  const [importProgress, setImportProgress] = useState<ImportProgress>({
    phase: 'idle',
    message: '',
    totalImages: 0,
    uploadedImages: 0,
    errors: [],
  });

  const [importResult, setImportResult] = useState<{
    images: string[];
    metadata: Record<string, any>;
    fieldsApplied: string[];
  } | null>(null);

  const updateField = (field: string, value: any) => {
    setForm(prev => ({ ...prev, [field]: value }));
    if (error) setError('');
  };

  const updateMultipleFields = (updates: Record<string, any>) => {
    setForm(prev => ({ ...prev, ...updates }));
    if (error) setError('');
  };

  const addFeature = () => {
    if (newFeature.trim() && !form.features.includes(newFeature.trim())) {
      updateField('features', [...form.features, newFeature.trim()]);
      setNewFeature('');
    }
  };

  const removeFeature = (index: number) => {
    updateField('features', form.features.filter((_, i) => i !== index));
  };

  // Image upload manager callback
  const handleImagesChange = useCallback((images: string[], heroImage: string) => {
    setForm(prev => ({ ...prev, images, image: heroImage }));
  }, []);



  // ===== CRAIGSLIST IMPORT (with robust image handling) =====
  const handleCraigslistImport = async () => {
    if (!craigslistUrl.trim()) {
      setError('Please enter a Craigslist listing URL');
      return;
    }

    const urlLower = craigslistUrl.toLowerCase();
    if (!urlLower.includes('craigslist.org')) {
      setError('Please enter a valid Craigslist URL (e.g., https://city.craigslist.org/cto/d/...)');
      return;
    }

    setError('');
    setImportResult(null);
    setImportProgress({
      phase: 'fetching',
      message: 'Connecting to Craigslist...',
      totalImages: 0,
      uploadedImages: 0,
      errors: [],
    });

    try {
      // Phase 1: Fetching
      await new Promise(r => setTimeout(r, 300));
      setImportProgress(prev => ({
        ...prev,
        phase: 'scraping',
        message: 'Scraping listing page for images and vehicle data...',
      }));

      // Call the edge function
      const { data: rawData, error: fnError } = await supabase.functions.invoke('scrape-craigslist', {
        body: { url: craigslistUrl.trim() },
      });

      if (fnError) {
        throw new Error(fnError.message || 'Failed to connect to scraping service');
      }

      // Sanitize response - filter out non-serializable values (Response objects, streams, etc.)
      const data = rawData || {};
      console.log('Scrape response keys:', Object.keys(data));

      if (data?.error && (!data?.images || data.images.length === 0)) {
        throw new Error(typeof data.error === 'string' ? data.error : 'Scraping failed');
      }

      // Extract only valid string URLs from images array
      const rawImages = data?.images || [];
      let images: string[] = Array.isArray(rawImages) 
        ? rawImages.filter((item: any) => typeof item === 'string' && (item.startsWith('http://') || item.startsWith('https://')))
        : [];
      
      const metadata = data?.metadata || {};
      const totalFound = data?.totalFound || 0;
      const totalUploaded = data?.totalUploaded || 0;
      
      // Filter errors to only include actual string messages, not serialization artifacts
      const rawErrors = data?.errors || [];
      const scrapeErrors: string[] = Array.isArray(rawErrors)
        ? rawErrors
            .filter((e: any) => typeof e === 'string')
            .filter((e: string) => !e.includes('decodeText') && !e.includes('could not be cloned'))
        : [];

      // Check for original/source image URLs as fallback (edge function may provide these)
      const originalImages: string[] = (() => {
        const candidates = data?.originalImages || data?.sourceUrls || data?.scrapedUrls || data?.imageUrls || [];
        if (!Array.isArray(candidates)) return [];
        return candidates.filter((item: any) => typeof item === 'string' && (item.startsWith('http://') || item.startsWith('https://')));
      })();

      // Detect if edge function had the "decodeText could not be cloned" error
      const hadCloneError = Array.isArray(rawErrors) && rawErrors.some((e: any) => {
        const str = typeof e === 'string' ? e : '';
        return str.includes('decodeText') || str.includes('could not be cloned');
      });

      // If edge function failed to upload images, try frontend-side re-upload
      if (images.length === 0 && (originalImages.length > 0 || hadCloneError)) {
        const urlsToUpload = originalImages.length > 0 ? originalImages : [];
        
        if (urlsToUpload.length > 0) {
          setImportProgress(prev => ({
            ...prev,
            phase: 'uploading',
            message: `Server upload failed. Re-uploading ${urlsToUpload.length} images from browser...`,
          }));

          const uploaded: string[] = [];
          const failed: string[] = [];

          for (let i = 0; i < urlsToUpload.length; i++) {
            setImportProgress(prev => ({
              ...prev,
              message: `Re-uploading image ${i + 1} of ${urlsToUpload.length}...`,
            }));
            try {
              const storageUrl = await uploadImageFromUrl(urlsToUpload[i]);
              uploaded.push(storageUrl);
            } catch (err: any) {
              console.warn(`Frontend upload failed for image ${i + 1}:`, err.message);
              // Fall back to using the original URL directly
              uploaded.push(urlsToUpload[i]);
              failed.push(`Image ${i + 1}: used original URL (upload failed)`);
            }
          }

          images = uploaded;
          if (failed.length > 0) {
            scrapeErrors.push(...failed);
          }
        } else if (hadCloneError && totalFound > 0) {
          // Edge function found images but couldn't process them AND didn't return originals
          scrapeErrors.push(`${totalFound} images found on listing but server couldn't process them. You can add images manually.`);
        }
      }

      // Phase 2: Processing results
      setImportProgress({
        phase: 'uploading',
        message: `Processing ${images.length} images and vehicle data...`,
        totalImages: totalFound || images.length,
        uploadedImages: images.length,
        errors: scrapeErrors,
      });

      await new Promise(r => setTimeout(r, 500));

      // Apply metadata to form fields
      const fieldsApplied: string[] = [];
      const updates: Record<string, any> = {};

      if (metadata.year && (!form.year || form.year === new Date().getFullYear())) {
        updates.year = metadata.year;
        fieldsApplied.push('Year');
      }

      if (metadata.price && (!form.price || form.price === 0)) {
        updates.price = metadata.price;
        fieldsApplied.push('Price');
      }

      if (metadata.mileage && (!form.mileage || form.mileage === 0)) {
        updates.mileage = metadata.mileage;
        fieldsApplied.push('Mileage');
      }

      if (metadata.description && !form.description) {
        updates.description = typeof metadata.description === 'string' ? metadata.description : '';
        if (updates.description) fieldsApplied.push('Description');
      }

      if (metadata.transmission && form.transmission === 'Automatic') {
        updates.transmission = metadata.transmission;
        fieldsApplied.push('Transmission');
      }

      if (metadata.drivetrain && form.drivetrain === 'FWD') {
        updates.drivetrain = metadata.drivetrain;
        fieldsApplied.push('Drivetrain');
      }

      if (metadata.fuelType && form.fuelType === 'Gasoline') {
        updates.fuelType = metadata.fuelType;
        fieldsApplied.push('Fuel Type');
      }

      if (metadata.engine && !form.engine) {
        updates.engine = metadata.engine;
        fieldsApplied.push('Engine');
      }

      if (metadata.bodyType && form.bodyType === 'Sedan') {
        updates.bodyType = metadata.bodyType;
        fieldsApplied.push('Body Type');
      }

      if (metadata.exteriorColor && !form.exteriorColor) {
        updates.exteriorColor = metadata.exteriorColor;
        fieldsApplied.push('Exterior Color');
      }

      if (metadata.vin && !form.vin) {
        updates.vin = metadata.vin;
        fieldsApplied.push('VIN');
      }

      // Parse title for make/model if available
      if (metadata.title && typeof metadata.title === 'string') {
        const titleParts = parseTitleForMakeModel(metadata.title, metadata.year);
        if (titleParts.make && !form.make) {
          updates.make = titleParts.make;
          fieldsApplied.push('Make');
        }
        if (titleParts.model && !form.model) {
          updates.model = titleParts.model;
          fieldsApplied.push('Model');
        }
        if (titleParts.trim && !form.trim) {
          updates.trim = titleParts.trim;
          fieldsApplied.push('Trim');
        }
      }

      // Add features (only valid strings)
      if (metadata.features && Array.isArray(metadata.features)) {
        const validFeatures = metadata.features.filter((f: any) => typeof f === 'string' && f.trim().length > 0);
        if (validFeatures.length > 0) {
          const existingFeatures = new Set(form.features.map((f: string) => f.toLowerCase()));
          const newFeatures = validFeatures.filter((f: string) => !existingFeatures.has(f.toLowerCase()));
          if (newFeatures.length > 0) {
            updates.features = [...form.features, ...newFeatures];
            fieldsApplied.push(`${newFeatures.length} Features`);
          }
        }
      }

      // Add images
      if (images.length > 0) {
        const allImages = [...form.images, ...images];
        updates.images = allImages;
        if (!form.image) {
          updates.image = images[0];
        }
        fieldsApplied.push(`${images.length} Photos`);
      }

      if (Object.keys(updates).length > 0) {
        updateMultipleFields(updates);
      }

      setImportResult({
        images,
        metadata,
        fieldsApplied,
      });

      setImportProgress({
        phase: 'done',
        message: images.length > 0
          ? `Successfully imported ${images.length} photos${fieldsApplied.length > 1 ? ` and ${fieldsApplied.length - 1} fields` : ''}!`
          : `Vehicle details imported${fieldsApplied.length > 0 ? ` (${fieldsApplied.length} fields)` : ''}! Add photos manually below.`,
        totalImages: totalFound || images.length,
        uploadedImages: images.length,
        errors: scrapeErrors,
      });

    } catch (err: any) {
      console.error('Craigslist import error:', err);
      setImportProgress({
        phase: 'error',
        message: err.message || 'Failed to import from Craigslist',
        totalImages: 0,
        uploadedImages: 0,
        errors: [typeof err.message === 'string' ? err.message : 'Unknown error'],
      });
    }
  };


  const resetImport = () => {
    setImportProgress({
      phase: 'idle',
      message: '',
      totalImages: 0,
      uploadedImages: 0,
      errors: [],
    });
    setImportResult(null);
    setCraigslistUrl('');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!form.make.trim()) { setError('Make is required'); return; }
    if (!form.model.trim()) { setError('Model is required'); return; }
    if (!form.price || form.price <= 0) { setError('Price must be greater than 0'); return; }
    if (!form.year || form.year < 1900) { setError('Valid year is required'); return; }

    setSaving(true);
    try {
      await onSave(form);
    } catch (err: any) {
      setError(err.message || 'Failed to save vehicle. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  const isImporting = ['fetching', 'scraping', 'uploading'].includes(importProgress.phase);

  return (
    <div className="fixed inset-0 z-[100] flex items-start justify-center overflow-y-auto py-4 md:py-8 px-4">
      <div className="fixed inset-0 bg-black/80 backdrop-blur-sm" onClick={onClose} />

      <div className="relative w-full max-w-4xl bg-[#111111] rounded-2xl border border-white/10 shadow-2xl">
        {/* Header */}
        <div className="sticky top-0 z-10 flex items-center justify-between p-6 border-b border-white/10 bg-[#111111] rounded-t-2xl">
          <div>
            <h2 className="text-xl font-bold text-white flex items-center gap-3">
              {isEditing ? 'Edit Vehicle' : 'Add New Vehicle'}
              {hasInitialData && (
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-gradient-to-r from-purple-500/20 to-blue-500/20 border border-purple-500/30 text-purple-300 text-xs font-bold rounded-full">
                  <Globe className="w-3 h-3" />
                  Imported from Craigslist
                </span>
              )}
            </h2>
            {hasInitialData && (
              <p className="text-xs text-gray-400 mt-1">
                Review the auto-filled data below and make any corrections before saving.
              </p>
            )}
          </div>
          <button onClick={onClose} className="p-2 rounded-lg text-gray-400 hover:text-white hover:bg-white/5 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>



        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {error && (
            <div className="flex items-center gap-3 p-3 bg-red-500/10 border border-red-500/20 rounded-xl">
              <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0" />
              <p className="text-red-400 text-sm">{error}</p>
            </div>
          )}

          {/* ===== TEMPLATE PICKER (shown first for new vehicles) ===== */}
          {!isEditing && !hasInitialData && showTemplatePicker && (
            <div className="rounded-xl border border-neon-cyan/30 bg-gradient-to-br from-neon-cyan/[0.04] to-neon-green/[0.02] p-5">
              <TemplatePicker
                onSelect={handleTemplateSelect}
                onSkip={() => setShowTemplatePicker(false)}
              />
            </div>
          )}

          {/* Template Applied Banner */}
          {appliedTemplate && !showTemplatePicker && (
            <div className="p-4 bg-gradient-to-r from-neon-cyan/[0.08] to-neon-green/[0.06] border border-neon-cyan/20 rounded-xl">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-neon-cyan to-neon-green flex items-center justify-center flex-shrink-0">
                    <Layers className="w-5 h-5 text-black" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2 mb-0.5">
                      <CheckCircle className="w-4 h-4 text-neon-green flex-shrink-0" />
                      <span className="text-neon-green text-sm font-semibold">Template Applied</span>
                    </div>
                    <p className="text-white font-bold text-sm">
                      {appliedTemplate.make} {appliedTemplate.model} {appliedTemplate.trim}
                    </p>
                    <div className="flex items-center gap-3 mt-1 text-[11px] text-gray-400">
                      <span>{appliedTemplate.engine}</span>
                      <span className="text-gray-600">/</span>
                      <span>{appliedTemplate.transmission}</span>
                      <span className="text-gray-600">/</span>
                      <span>{appliedTemplate.drivetrain}</span>
                      <span className="text-gray-600">/</span>
                      <span>{appliedTemplate.bodyType}</span>
                      <span className="text-gray-600">|</span>
                      <span>{appliedTemplate.features.length} features</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  <button
                    type="button"
                    onClick={() => {
                      setShowTemplatePicker(true);
                      setAppliedTemplate(null);
                    }}
                    className="px-3 py-1.5 text-xs text-neon-cyan hover:text-white border border-neon-cyan/30 hover:border-neon-cyan/60 rounded-lg transition-colors"
                  >
                    Change
                  </button>
                </div>
              </div>
              <p className="text-[11px] text-gray-500 mt-3 pl-[52px]">
                Specs auto-filled from template. Now add: year, price, mileage, colors, VIN, and photos below.
              </p>
            </div>
          )}

          {/* Re-open template picker button (when no template applied and picker dismissed) */}
          {!isEditing && !hasInitialData && !showTemplatePicker && !appliedTemplate && (
            <button
              type="button"
              onClick={() => setShowTemplatePicker(true)}
              className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl border border-dashed border-neon-cyan/20 text-gray-500 hover:text-neon-cyan hover:border-neon-cyan/40 transition-all text-sm"
            >
              <Layers className="w-4 h-4" />
              Use a Vehicle Template to auto-fill specs
            </button>
          )}

          {/* Craigslist Import Summary Banner */}
          {hasInitialData && initialData && (
            <div className="p-4 bg-gradient-to-r from-purple-500/[0.08] to-blue-500/[0.06] border border-purple-500/20 rounded-xl">
              <div className="flex items-center gap-4">
                {initialData.image ? (
                  <img src={initialData.image} alt="Imported vehicle" className="w-24 h-16 rounded-lg object-cover flex-shrink-0 border border-white/10" />
                ) : (
                  <div className="w-24 h-16 rounded-lg bg-purple-500/10 border border-purple-500/20 flex items-center justify-center flex-shrink-0">
                    <Globe className="w-6 h-6 text-purple-400" />
                  </div>
                )}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <CheckCircle className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                    <span className="text-emerald-300 text-sm font-semibold">Craigslist Data Imported</span>
                  </div>
                  <p className="text-white font-bold text-sm truncate">
                    {initialData.year || ''} {initialData.make || ''} {initialData.model || ''} {initialData.trim || ''}
                  </p>
                  <div className="flex items-center gap-4 mt-1 text-xs text-gray-400">
                    {initialData.price ? <span className="text-neon-orange font-semibold">${initialData.price.toLocaleString()}</span> : null}
                    {initialData.mileage ? <span>{initialData.mileage.toLocaleString()} mi</span> : null}
                    {initialData.images && initialData.images.length > 0 ? (
                      <span className="flex items-center gap-1">
                        <Camera className="w-3 h-3" />
                        {initialData.images.length} photos
                      </span>
                    ) : null}
                    {initialData.features && initialData.features.length > 0 ? (
                      <span>{initialData.features.length} features</span>
                    ) : null}
                  </div>
                </div>
              </div>
            </div>
          )}


          {/* ===== CRAIGSLIST IMPORT SECTION ===== */}
          <div className="rounded-xl border border-purple-500/30 bg-gradient-to-br from-purple-500/[0.06] to-blue-500/[0.04] overflow-hidden">
            <button
              type="button"
              onClick={() => setShowImport(!showImport)}
              className="w-full flex items-center justify-between p-4 hover:bg-white/[0.02] transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center flex-shrink-0">
                  <Globe className="w-5 h-5 text-white" />
                </div>
                <div className="text-left">
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    Import from Craigslist
                    <span className="px-1.5 py-0.5 bg-purple-500/20 text-purple-300 text-[10px] font-bold rounded-full uppercase tracking-wider">Auto</span>
                  </h3>
                  <p className="text-xs text-gray-400 mt-0.5">
                    Paste a Craigslist listing URL to auto-import all photos & vehicle details
                  </p>
                </div>
              </div>
              {showImport ? (
                <ChevronUp className="w-5 h-5 text-gray-400" />
              ) : (
                <ChevronDown className="w-5 h-5 text-gray-400" />
              )}
            </button>

            {showImport && (
              <div className="px-4 pb-4 space-y-4">
                {/* URL Input */}
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <Globe className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                    <input
                      type="text"
                      value={craigslistUrl}
                      onChange={(e) => setCraigslistUrl(e.target.value)}
                      placeholder="https://city.craigslist.org/cto/d/vehicle-title/1234567890.html"
                      disabled={isImporting}
                      className="w-full pl-10 pr-4 py-3 bg-black/60 border border-white/10 rounded-xl text-white text-sm placeholder-gray-600 focus:border-purple-400 focus:outline-none focus:ring-1 focus:ring-purple-400/30 disabled:opacity-50 transition-all"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={handleCraigslistImport}
                    disabled={isImporting || !craigslistUrl.trim()}
                    className="flex items-center gap-2 px-5 py-3 bg-gradient-to-r from-purple-500 to-blue-500 text-white font-bold rounded-xl hover:opacity-90 transition-all disabled:opacity-40 disabled:cursor-not-allowed flex-shrink-0 shadow-lg shadow-purple-500/20"
                  >
                    {isImporting ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span className="hidden sm:inline">Importing...</span>
                      </>
                    ) : (
                      <>
                        <Download className="w-4 h-4" />
                        <span className="hidden sm:inline">Import</span>
                      </>
                    )}
                  </button>
                </div>

                {/* Progress Indicator */}
                {importProgress.phase !== 'idle' && (
                  <div className="space-y-3">
                    {/* Progress Bar */}
                    {isImporting && (
                      <div className="space-y-2">
                        <div className="h-1.5 bg-black/40 rounded-full overflow-hidden">
                          <div
                            className="h-full rounded-full transition-all duration-1000 ease-out"
                            style={{
                              width: importProgress.phase === 'fetching' ? '20%'
                                : importProgress.phase === 'scraping' ? '50%'
                                : importProgress.phase === 'uploading' ? '80%'
                                : '100%',
                              background: 'linear-gradient(90deg, #a855f7, #3b82f6)',
                            }}
                          />
                        </div>
                        <div className="flex items-center gap-2">
                          <Loader2 className="w-3.5 h-3.5 text-purple-400 animate-spin" />
                          <span className="text-xs text-purple-300">{importProgress.message}</span>
                        </div>
                      </div>
                    )}

                    {/* Phase Steps */}
                    {isImporting && (
                      <div className="flex items-center gap-1 text-[11px]">
                        <PhaseStep
                          label="Connect"
                          active={importProgress.phase === 'fetching'}
                          done={['scraping', 'uploading', 'done'].includes(importProgress.phase)}
                        />
                        <div className="w-4 h-px bg-white/10" />
                        <PhaseStep
                          label="Scrape"
                          active={importProgress.phase === 'scraping'}
                          done={['uploading', 'done'].includes(importProgress.phase)}
                        />
                        <div className="w-4 h-px bg-white/10" />
                        <PhaseStep
                          label="Upload"
                          active={importProgress.phase === 'uploading'}
                          done={importProgress.phase === 'done'}
                        />
                      </div>
                    )}

                    {/* Success State */}
                    {importProgress.phase === 'done' && importResult && (
                      <div className="space-y-3">
                        <div className="flex items-start gap-3 p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl">
                          <CheckCircle className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
                          <div className="flex-1 min-w-0">
                            <p className="text-emerald-300 text-sm font-semibold">Import Successful!</p>
                            <p className="text-emerald-400/70 text-xs mt-1">{importProgress.message}</p>
                          </div>
                        </div>

                        {/* Fields Applied Summary */}
                        {importResult.fieldsApplied.length > 0 && (
                          <div className="p-3 bg-white/[0.02] border border-white/5 rounded-xl">
                            <p className="text-xs text-gray-400 mb-2 font-medium">Auto-filled fields:</p>
                            <div className="flex flex-wrap gap-1.5">
                              {importResult.fieldsApplied.map((field, i) => (
                                <span
                                  key={i}
                                  className="px-2 py-1 bg-purple-500/10 border border-purple-500/20 text-purple-300 text-[11px] font-medium rounded-md flex items-center gap-1"
                                >
                                  <CheckCircle className="w-3 h-3" />
                                  {field}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}

                        {/* Imported Images Preview */}
                        {importResult.images.length > 0 && (
                          <div className="p-3 bg-white/[0.02] border border-white/5 rounded-xl">
                            <div className="flex items-center justify-between mb-2">
                              <p className="text-xs text-gray-400 font-medium flex items-center gap-1.5">
                                <Camera className="w-3.5 h-3.5" />
                                {importResult.images.length} photos imported
                              </p>
                            </div>
                            <div className="flex gap-1.5 overflow-x-auto pb-1 thin-scrollbar">
                              {importResult.images.slice(0, 8).map((url, i) => (
                                <div key={i} className="w-16 h-12 rounded-md overflow-hidden flex-shrink-0 border border-white/10">
                                  <img src={url} alt={`Imported ${i + 1}`} className="w-full h-full object-cover" />
                                </div>
                              ))}
                              {importResult.images.length > 8 && (
                                <div className="w-16 h-12 rounded-md bg-white/5 border border-white/10 flex items-center justify-center flex-shrink-0">
                                  <span className="text-[10px] text-gray-400 font-bold">+{importResult.images.length - 8}</span>
                                </div>
                              )}
                            </div>
                          </div>
                        )}

                        {/* Errors if any */}
                        {importProgress.errors.length > 0 && (
                          <div className="p-3 bg-amber-500/5 border border-amber-500/20 rounded-xl">
                            <p className="text-xs text-amber-400 font-medium mb-1">
                              {importProgress.errors.length} image(s) couldn't be imported:
                            </p>
                            <div className="max-h-20 overflow-y-auto thin-scrollbar">
                              {importProgress.errors.map((err, i) => (
                                <p key={i} className="text-[11px] text-amber-400/60">{err}</p>
                              ))}
                            </div>
                          </div>
                        )}

                        <button
                          type="button"
                          onClick={resetImport}
                          className="text-xs text-gray-500 hover:text-white transition-colors flex items-center gap-1"
                        >
                          <ExternalLink className="w-3 h-3" />
                          Import another listing
                        </button>
                      </div>
                    )}

                    {/* Error State */}
                    {importProgress.phase === 'error' && (
                      <div className="space-y-3">
                        <div className="flex items-start gap-3 p-3 bg-red-500/10 border border-red-500/20 rounded-xl">
                          <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
                          <div className="flex-1">
                            <p className="text-red-300 text-sm font-semibold">Import Failed</p>
                            <p className="text-red-400/70 text-xs mt-1">{importProgress.message}</p>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <button
                            type="button"
                            onClick={handleCraigslistImport}
                            className="text-xs text-purple-400 hover:text-purple-300 transition-colors flex items-center gap-1"
                          >
                            <Zap className="w-3 h-3" />
                            Try again
                          </button>
                          <span className="text-gray-700">|</span>
                          <button
                            type="button"
                            onClick={resetImport}
                            className="text-xs text-gray-500 hover:text-white transition-colors"
                          >
                            Clear
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Helper text */}
                {importProgress.phase === 'idle' && (
                  <div className="flex items-start gap-2 text-[11px] text-gray-500">
                    <Zap className="w-3.5 h-3.5 text-purple-400/50 flex-shrink-0 mt-0.5" />
                    <span>
                      Automatically scrapes all 15-30 vehicle photos, price, mileage, specs, and description from any Craigslist vehicle listing. Images are uploaded to your storage and vehicle details auto-fill the form below.
                    </span>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Basic Info */}
          <div>
            <h3 className="text-sm font-semibold text-neon-cyan uppercase tracking-wider mb-4">Basic Information</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <label className="block text-sm text-gray-400 mb-1">Year *</label>
                <input
                  type="number"
                  value={form.year}
                  onChange={(e) => updateField('year', Number(e.target.value))}
                  className="w-full px-3 py-2.5 bg-black border border-white/10 rounded-lg text-white focus:border-neon-cyan focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-1">Make *</label>
                <input
                  type="text"
                  value={form.make}
                  onChange={(e) => updateField('make', e.target.value)}
                  placeholder="e.g. Toyota"
                  className="w-full px-3 py-2.5 bg-black border border-white/10 rounded-lg text-white placeholder-gray-600 focus:border-neon-cyan focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-1">Model *</label>
                <input
                  type="text"
                  value={form.model}
                  onChange={(e) => updateField('model', e.target.value)}
                  placeholder="e.g. Camry"
                  className="w-full px-3 py-2.5 bg-black border border-white/10 rounded-lg text-white placeholder-gray-600 focus:border-neon-cyan focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-1">Trim</label>
                <input
                  type="text"
                  value={form.trim}
                  onChange={(e) => updateField('trim', e.target.value)}
                  placeholder="e.g. SE"
                  className="w-full px-3 py-2.5 bg-black border border-white/10 rounded-lg text-white placeholder-gray-600 focus:border-neon-cyan focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Pricing & Status */}
          <div>

            <h3 className="text-sm font-semibold text-neon-cyan uppercase tracking-wider mb-4">Pricing & Status</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm text-gray-400 mb-1">Price ($) *</label>
                <input
                  type="number"
                  value={form.price}
                  onChange={(e) => updateField('price', Number(e.target.value))}
                  className="w-full px-3 py-2.5 bg-black border border-white/10 rounded-lg text-white focus:border-neon-cyan focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-1">Mileage</label>
                <input
                  type="number"
                  value={form.mileage}
                  onChange={(e) => updateField('mileage', Number(e.target.value))}
                  className="w-full px-3 py-2.5 bg-black border border-white/10 rounded-lg text-white focus:border-neon-cyan focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-1">Status</label>
                <select
                  value={form.status}
                  onChange={(e) => {
                    const newStatus = e.target.value as Vehicle['status'];
                    if (newStatus === 'sold' && form.status !== 'sold') {
                      setShowSoldDialog(true);
                    } else {
                      updateField('status', newStatus);
                      if (newStatus !== 'sold') {
                        updateMultipleFields({ status: newStatus, soldDate: undefined, soldPrice: undefined });
                      }
                    }
                  }}
                  className="w-full px-3 py-2.5 bg-black border border-white/10 rounded-lg text-white focus:border-neon-cyan focus:outline-none"
                >
                  {STATUSES.map(s => (
                    <option key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Sold Status Banner */}
            {form.status === 'sold' && form.soldDate && (
              <div className="mt-4 p-4 bg-gradient-to-r from-red-500/[0.08] to-neon-orange/[0.06] border border-red-500/20 rounded-xl">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-8 h-8 rounded-lg bg-red-500/10 border border-red-500/20 flex items-center justify-center">
                    <svg className="w-4 h-4 text-red-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" /><polyline points="22 4 12 14.01 9 11.01" />
                    </svg>
                  </div>
                  <div>
                    <p className="text-red-400 text-sm font-bold">Marked as Sold</p>
                    <p className="text-gray-500 text-xs">This vehicle will appear on the Sold List page</p>
                  </div>
                </div>
                <div className="flex items-center gap-6 text-xs mt-2 pl-11">
                  <div>
                    <span className="text-gray-500">Sold Date: </span>
                    <span className="text-white font-semibold">
                      {new Date(form.soldDate + 'T00:00:00').toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
                    </span>
                  </div>
                  {form.soldPrice !== undefined && form.soldPrice > 0 && (
                    <div>
                      <span className="text-gray-500">Sale Price: </span>
                      <span className="text-neon-orange font-bold">${form.soldPrice.toLocaleString()}</span>
                      {form.soldPrice !== form.price && (
                        <span className={`ml-1.5 px-1.5 py-0.5 rounded text-[10px] font-bold ${
                          form.soldPrice < form.price ? 'bg-red-500/10 text-red-400' : 'bg-neon-green/10 text-neon-green'
                        }`}>
                          {form.soldPrice < form.price ? '-' : '+'}${Math.abs(form.soldPrice - form.price).toLocaleString()}
                        </span>
                      )}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* ===== AI PRICING ADVISOR ===== */}
          <AIPricingPanel
            vehicle={form}
            currentPrice={form.price}
            onApplyPrice={(price) => updateField('price', price)}
          />


          {/* Specs */}
          <div>
            <h3 className="text-sm font-semibold text-neon-cyan uppercase tracking-wider mb-4">Specifications</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm text-gray-400 mb-1">Body Type</label>
                <select
                  value={form.bodyType}
                  onChange={(e) => updateField('bodyType', e.target.value)}
                  className="w-full px-3 py-2.5 bg-black border border-white/10 rounded-lg text-white focus:border-neon-cyan focus:outline-none"
                >
                  {BODY_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-1">Transmission</label>
                <select
                  value={form.transmission}
                  onChange={(e) => updateField('transmission', e.target.value)}
                  className="w-full px-3 py-2.5 bg-black border border-white/10 rounded-lg text-white focus:border-neon-cyan focus:outline-none"
                >
                  {TRANSMISSIONS.map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-1">Drivetrain</label>
                <select
                  value={form.drivetrain}
                  onChange={(e) => updateField('drivetrain', e.target.value)}
                  className="w-full px-3 py-2.5 bg-black border border-white/10 rounded-lg text-white focus:border-neon-cyan focus:outline-none"
                >
                  {DRIVETRAINS.map(d => <option key={d} value={d}>{d}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-1">Fuel Type</label>
                <select
                  value={form.fuelType}
                  onChange={(e) => updateField('fuelType', e.target.value)}
                  className="w-full px-3 py-2.5 bg-black border border-white/10 rounded-lg text-white focus:border-neon-cyan focus:outline-none"
                >
                  {FUEL_TYPES.map(f => <option key={f} value={f}>{f}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-1">Engine</label>
                <input
                  type="text"
                  value={form.engine}
                  onChange={(e) => updateField('engine', e.target.value)}
                  placeholder="e.g. 2.5L I4"
                  className="w-full px-3 py-2.5 bg-black border border-white/10 rounded-lg text-white placeholder-gray-600 focus:border-neon-cyan focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-1">VIN</label>
                <input
                  type="text"
                  value={form.vin}
                  onChange={(e) => updateField('vin', e.target.value)}
                  placeholder="Vehicle ID Number"
                  className="w-full px-3 py-2.5 bg-black border border-white/10 rounded-lg text-white placeholder-gray-600 focus:border-neon-cyan focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Colors */}
          <div>
            <h3 className="text-sm font-semibold text-neon-cyan uppercase tracking-wider mb-4">Colors</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm text-gray-400 mb-1">Exterior Color</label>
                <input
                  type="text"
                  value={form.exteriorColor}
                  onChange={(e) => updateField('exteriorColor', e.target.value)}
                  placeholder="e.g. Alpine White"
                  className="w-full px-3 py-2.5 bg-black border border-white/10 rounded-lg text-white placeholder-gray-600 focus:border-neon-cyan focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-1">Interior Color</label>
                <input
                  type="text"
                  value={form.interiorColor}
                  onChange={(e) => updateField('interiorColor', e.target.value)}
                  placeholder="e.g. Black Leather"
                  className="w-full px-3 py-2.5 bg-black border border-white/10 rounded-lg text-white placeholder-gray-600 focus:border-neon-cyan focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Description + AI Writer */}
          <div>
            <h3 className="text-sm font-semibold text-neon-cyan uppercase tracking-wider mb-4">Description</h3>
            <textarea
              value={form.description}
              onChange={(e) => updateField('description', e.target.value)}
              rows={form.description ? 6 : 3}
              placeholder="Write a compelling description for this vehicle, or use the AI writer below..."
              className="w-full px-3 py-2.5 bg-black border border-white/10 rounded-lg text-white placeholder-gray-600 focus:border-neon-cyan focus:outline-none resize-y min-h-[80px]"
            />
            {form.description && (
              <div className="flex items-center justify-between mt-1.5">
                <span className="text-[11px] text-gray-600">
                  {form.description.split(/\s+/).filter(Boolean).length} words
                </span>
                <button
                  type="button"
                  onClick={() => updateField('description', '')}
                  className="text-[11px] text-gray-600 hover:text-red-400 transition-colors"
                >
                  Clear
                </button>
              </div>
            )}
          </div>

          {/* ===== AI DESCRIPTION WRITER ===== */}
          <AIDescriptionPanel
            vehicle={form}
            currentDescription={form.description}
            onApplyDescription={(desc) => updateField('description', desc)}
          />


          {/* Features */}
          <div>
            <h3 className="text-sm font-semibold text-neon-cyan uppercase tracking-wider mb-4">Features</h3>
            <div className="flex gap-2 mb-3">
              <input
                type="text"
                value={newFeature}
                onChange={(e) => setNewFeature(e.target.value)}
                onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addFeature(); } }}
                placeholder="Add a feature (e.g. Navigation)"
                className="flex-1 px-3 py-2.5 bg-black border border-white/10 rounded-lg text-white placeholder-gray-600 focus:border-neon-cyan focus:outline-none"
              />
              <button
                type="button"
                onClick={addFeature}
                className="px-4 py-2.5 bg-neon-cyan/10 border border-neon-cyan/30 text-neon-cyan rounded-lg hover:bg-neon-cyan/20 transition-colors"
              >
                <Plus className="w-5 h-5" />
              </button>
            </div>
            {form.features.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {form.features.map((feature, i) => (
                  <span key={i} className="flex items-center gap-1.5 px-3 py-1.5 bg-white/[0.03] border border-white/10 rounded-full text-sm text-gray-300">
                    {feature}
                    <button type="button" onClick={() => removeFeature(i)} className="text-gray-500 hover:text-red-400 transition-colors">
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* ===== ADVANCED IMAGE UPLOAD MANAGER ===== */}
          <ImageUploadManager
            existingImages={form.images}
            heroImage={form.image}
            onImagesChange={handleImagesChange}
          />



          {/* Video Walkthrough */}
          <div>
            <h3 className="text-sm font-semibold text-neon-cyan uppercase tracking-wider mb-4">Video Walkthrough</h3>
            <div>
              <label className="block text-sm text-gray-400 mb-1">Video URL</label>
              <input
                type="text"
                value={form.videoUrl}
                onChange={(e) => updateField('videoUrl', e.target.value)}
                placeholder="YouTube, Vimeo, or direct video URL (e.g. https://youtube.com/watch?v=...)"
                className="w-full px-3 py-2.5 bg-black border border-white/10 rounded-lg text-white placeholder-gray-600 focus:border-neon-cyan focus:outline-none"
              />
              <p className="text-xs text-gray-600 mt-1">Supports YouTube, Vimeo, and direct MP4/WebM video links</p>
              {form.videoUrl && (
                <div className="mt-2 flex items-center gap-2 px-3 py-2 bg-neon-pink/5 border border-neon-pink/20 rounded-lg">
                  <div className="w-2 h-2 bg-neon-pink rounded-full animate-pulse" />
                  <span className="text-neon-pink text-xs font-medium">Video walkthrough will be shown on the vehicle detail page</span>
                </div>
              )}
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-3 pt-4 border-t border-white/10">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-3 border border-white/10 text-gray-400 font-semibold rounded-xl hover:bg-white/5 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving || isImporting}
              className="flex-1 py-3 bg-gradient-to-r from-neon-pink to-neon-orange text-white font-bold rounded-xl hover:opacity-90 transition-opacity disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {saving ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Saving...
                </>
              ) : (
                isEditing ? 'Update Vehicle' : 'Add Vehicle'
              )}
            </button>
          </div>
        </form>
      </div>

      {/* Mark as Sold Confirmation Dialog */}
      {showSoldDialog && (
        <MarkAsSoldDialog
          vehicle={{
            id: vehicle?.id || 0,
            year: form.year,
            make: form.make,
            model: form.model,
            trim: form.trim,
            price: form.price,
            mileage: form.mileage,
            exteriorColor: form.exteriorColor,
            interiorColor: form.interiorColor,
            transmission: form.transmission,
            drivetrain: form.drivetrain,
            fuelType: form.fuelType,
            engine: form.engine,
            bodyType: form.bodyType,
            vin: form.vin,
            image: form.image,
            images: form.images,
            features: form.features,
            status: form.status,
            description: form.description,
            videoUrl: form.videoUrl,
          }}
          onConfirm={async (soldPrice?: number) => {
            // Set status to sold, auto-set sold date, and optionally set sold price
            const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
            updateMultipleFields({
              status: 'sold' as Vehicle['status'],
              soldDate: today,
              soldPrice: soldPrice,
            });
            setShowSoldDialog(false);
          }}
          onCancel={() => {
            // User cancelled — do NOT change the status
            setShowSoldDialog(false);
          }}
        />
      )}
    </div>
  );

};

// Phase Step indicator component
const PhaseStep: React.FC<{ label: string; active: boolean; done: boolean }> = ({ label, active, done }) => (
  <div className={`flex items-center gap-1.5 px-2 py-1 rounded-md transition-colors ${
    active ? 'bg-purple-500/20 text-purple-300' :
    done ? 'bg-emerald-500/10 text-emerald-400' :
    'text-gray-600'
  }`}>
    {done ? (
      <CheckCircle className="w-3 h-3" />
    ) : active ? (
      <Loader2 className="w-3 h-3 animate-spin" />
    ) : (
      <div className="w-3 h-3 rounded-full border border-current opacity-40" />
    )}
    <span className="font-medium">{label}</span>
  </div>
);

// Helper: Parse Craigslist title to extract make/model/trim
function parseTitleForMakeModel(title: string, year?: number): { make: string; model: string; trim: string } {
  const KNOWN_MAKES = [
    'Acura', 'Alfa Romeo', 'Aston Martin', 'Audi', 'Bentley', 'BMW', 'Buick',
    'Cadillac', 'Chevrolet', 'Chevy', 'Chrysler', 'Dodge', 'Ferrari', 'Fiat', 'Ford',
    'Genesis', 'GMC', 'Honda', 'Hyundai', 'Infiniti', 'Jaguar', 'Jeep', 'Kia',
    'Lamborghini', 'Land Rover', 'Lexus', 'Lincoln', 'Lucid', 'Maserati', 'Mazda',
    'McLaren', 'Mercedes-Benz', 'Mercedes', 'Mini', 'Mitsubishi', 'Nissan', 'Polestar',
    'Pontiac', 'Porsche', 'Ram', 'Rivian', 'Rolls-Royce', 'Saab', 'Saturn', 'Scion',
    'Subaru', 'Suzuki', 'Tesla', 'Toyota', 'Volkswagen', 'VW', 'Volvo'
  ];

  let cleanTitle = title;
  // Remove year from title
  if (year) {
    cleanTitle = cleanTitle.replace(new RegExp(`\\b${year}\\b`, 'g'), '');
  }
  // Remove common prefixes/suffixes
  cleanTitle = cleanTitle.replace(/\*+/g, '').replace(/[!@#$%^&*()]+/g, ' ').trim();

  const words = cleanTitle.split(/\s+/).filter(w => w.length > 0);

  let make = '';
  let model = '';
  let trim = '';

  for (let i = 0; i < words.length; i++) {
    const word = words[i];
    const matchedMake = KNOWN_MAKES.find(m => m.toLowerCase() === word.toLowerCase());
    if (matchedMake) {
      make = matchedMake === 'Chevy' ? 'Chevrolet' : matchedMake === 'VW' ? 'Volkswagen' : matchedMake;
      // Next word(s) are likely the model
      const remaining = words.slice(i + 1);
      if (remaining.length >= 2) {
        model = remaining[0];
        trim = remaining.slice(1).join(' ');
      } else if (remaining.length === 1) {
        model = remaining[0];
      }
      break;
    }
  }

  return { make, model, trim };
}

export default VehicleFormModal;
