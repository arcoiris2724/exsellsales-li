import React, { useState, useRef, useCallback, useEffect } from 'react';
import {
  Upload, X, Loader2, Camera, Trash2, ImagePlus, Star,
  GripVertical, Crop, RotateCw, Check, AlertCircle,
  ArrowDown, ArrowUp, Maximize2, ZoomIn, Sparkles
} from 'lucide-react';
import { uploadVehicleImage } from '@/data/vehicles';
import { compressImage, formatFileSize, readFileAsDataUrl, dataUrlToFile, type ProcessedImage } from '@/lib/imageCompression';
import ImageCropModal from './ImageCropModal';

export interface ManagedImage {
  id: string;
  url: string;           // Final URL (storage URL for existing, blob/data URL for new)
  thumbnail: string;     // Thumbnail data URL
  status: 'existing' | 'pending' | 'compressing' | 'uploading' | 'done' | 'error';
  progress: number;      // 0-100
  file?: File;           // Original file (for new uploads)
  compressedFile?: File; // Compressed file
  originalSize?: number;
  compressedSize?: number;
  error?: string;
  isHero: boolean;       // Is this the primary/hero image
}

interface ImageUploadManagerProps {
  existingImages: string[];
  heroImage: string;
  onImagesChange: (images: string[], heroImage: string) => void;
}

const ImageUploadManager: React.FC<ImageUploadManagerProps> = ({
  existingImages,
  heroImage,
  onImagesChange,
}) => {
  const [images, setImages] = useState<ManagedImage[]>([]);
  const [isDraggingFile, setIsDraggingFile] = useState(false);
  const [dragOverIndex, setDragOverIndex] = useState<number | null>(null);
  const [dragSourceIndex, setDragSourceIndex] = useState<number | null>(null);
  const [cropImage, setCropImage] = useState<{ id: string; url: string } | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const dropRef = useRef<HTMLDivElement>(null);
  const initialized = useRef(false);

  // Initialize from existing images
  useEffect(() => {
    if (initialized.current) return;
    initialized.current = true;

    const initial: ManagedImage[] = existingImages.map((url, i) => ({
      id: `existing-${i}-${Date.now()}`,
      url,
      thumbnail: url,
      status: 'existing' as const,
      progress: 100,
      isHero: url === heroImage,
    }));

    // Ensure at least one hero
    if (initial.length > 0 && !initial.some(img => img.isHero)) {
      initial[0].isHero = true;
    }

    setImages(initial);
  }, [existingImages, heroImage]);

  // Sync changes back to parent
  const syncToParent = useCallback((imgs: ManagedImage[]) => {
    const urls = imgs
      .filter(img => img.status === 'existing' || img.status === 'done')
      .map(img => img.url);
    const hero = imgs.find(img => img.isHero)?.url || urls[0] || '';
    onImagesChange(urls, hero);
  }, [onImagesChange]);

  // ===== FILE DROP HANDLERS =====
  const handleDragEnter = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.dataTransfer.types.includes('Files')) {
      setIsDraggingFile(true);
    }
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (dropRef.current && !dropRef.current.contains(e.relatedTarget as Node)) {
      setIsDraggingFile(false);
    }
  }, []);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingFile(false);
    const files = Array.from(e.dataTransfer.files).filter(f => f.type.startsWith('image/'));
    if (files.length > 0) {
      processAndAddFiles(files);
    }
  }, []);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []).filter(f => f.type.startsWith('image/'));
    if (files.length > 0) {
      processAndAddFiles(files);
    }
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  // ===== PROCESS & ADD FILES =====
  const processAndAddFiles = async (files: File[]) => {
    setIsProcessing(true);

    // Create placeholder entries
    const newEntries: ManagedImage[] = files.map((file, i) => ({
      id: `new-${Date.now()}-${i}-${Math.random().toString(36).substring(2)}`,
      url: URL.createObjectURL(file),
      thumbnail: URL.createObjectURL(file),
      status: 'compressing' as const,
      progress: 0,
      file,
      originalSize: file.size,
      isHero: false,
    }));

    setImages(prev => {
      const updated = [...prev, ...newEntries];
      // If no hero set, make first one hero
      if (!updated.some(img => img.isHero) && updated.length > 0) {
        updated[0].isHero = true;
      }
      return updated;
    });

    // Compress each file
    for (const entry of newEntries) {
      try {
        // Compress
        setImages(prev => prev.map(img =>
          img.id === entry.id ? { ...img, status: 'compressing' as const, progress: 20 } : img
        ));

        const processed: ProcessedImage = await compressImage(entry.file!, {
          maxWidth: 1920,
          maxHeight: 1440,
          quality: 0.82,
        });

        setImages(prev => prev.map(img =>
          img.id === entry.id ? {
            ...img,
            thumbnail: processed.thumbnail,
            compressedFile: processed.file,
            compressedSize: processed.compressedSize,
            status: 'uploading' as const,
            progress: 50,
          } : img
        ));

        // Upload
        const storageUrl = await uploadVehicleImage(processed.file);

        setImages(prev => {
          const updated = prev.map(img =>
            img.id === entry.id ? {
              ...img,
              url: storageUrl,
              status: 'done' as const,
              progress: 100,
            } : img
          );
          syncToParent(updated);
          return updated;
        });

      } catch (err: any) {
        console.error('Upload error:', err);
        setImages(prev => prev.map(img =>
          img.id === entry.id ? {
            ...img,
            status: 'error' as const,
            progress: 0,
            error: err.message || 'Upload failed',
          } : img
        ));
      }
    }

    setIsProcessing(false);
  };

  // ===== IMAGE ACTIONS =====
  const removeImage = (id: string) => {
    setImages(prev => {
      const item = prev.find(img => img.id === id);
      if (item && item.url.startsWith('blob:')) {
        URL.revokeObjectURL(item.url);
      }
      const updated = prev.filter(img => img.id !== id);
      // Reassign hero if needed
      if (item?.isHero && updated.length > 0) {
        updated[0].isHero = true;
      }
      syncToParent(updated);
      return updated;
    });
  };

  const setAsHero = (id: string) => {
    setImages(prev => {
      const updated = prev.map(img => ({
        ...img,
        isHero: img.id === id,
      }));
      syncToParent(updated);
      return updated;
    });
  };

  const retryUpload = async (id: string) => {
    const img = images.find(i => i.id === id);
    if (!img?.file) return;

    setImages(prev => prev.map(i =>
      i.id === id ? { ...i, status: 'compressing' as const, progress: 10, error: undefined } : i
    ));

    try {
      const processed = await compressImage(img.file, { maxWidth: 1920, maxHeight: 1440, quality: 0.82 });

      setImages(prev => prev.map(i =>
        i.id === id ? { ...i, status: 'uploading' as const, progress: 50 } : i
      ));

      const storageUrl = await uploadVehicleImage(processed.file);

      setImages(prev => {
        const updated = prev.map(i =>
          i.id === id ? { ...i, url: storageUrl, status: 'done' as const, progress: 100 } : i
        );
        syncToParent(updated);
        return updated;
      });
    } catch (err: any) {
      setImages(prev => prev.map(i =>
        i.id === id ? { ...i, status: 'error' as const, progress: 0, error: err.message } : i
      ));
    }
  };

  // ===== CROP/EDIT =====
  const openCropEditor = (id: string) => {
    const img = images.find(i => i.id === id);
    if (!img) return;
    setCropImage({ id, url: img.url });
  };

  const handleCropSave = async (editedDataUrl: string) => {
    if (!cropImage) return;
    const { id } = cropImage;
    setCropImage(null);

    const img = images.find(i => i.id === id);
    if (!img) return;

    // Convert data URL to file and re-upload
    const file = dataUrlToFile(editedDataUrl, `edited-${Date.now()}.jpg`);

    setImages(prev => prev.map(i =>
      i.id === id ? {
        ...i,
        thumbnail: editedDataUrl,
        status: 'uploading' as const,
        progress: 40,
        file,
      } : i
    ));

    try {
      const storageUrl = await uploadVehicleImage(file);
      setImages(prev => {
        const updated = prev.map(i =>
          i.id === id ? { ...i, url: storageUrl, thumbnail: editedDataUrl, status: 'done' as const, progress: 100 } : i
        );
        syncToParent(updated);
        return updated;
      });
    } catch (err: any) {
      setImages(prev => prev.map(i =>
        i.id === id ? { ...i, status: 'error' as const, error: 'Re-upload failed after edit' } : i
      ));
    }
  };

  // ===== DRAG-AND-DROP REORDERING =====
  const handleReorderDragStart = (e: React.DragEvent, index: number) => {
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', String(index));
    setDragSourceIndex(index);
    // Set a transparent drag image
    const el = e.currentTarget as HTMLElement;
    if (el) {
      e.dataTransfer.setDragImage(el, 60, 45);
    }
  };

  const handleReorderDragOver = (e: React.DragEvent, index: number) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    setDragOverIndex(index);
  };

  const handleReorderDragLeave = () => {
    setDragOverIndex(null);
  };

  const handleReorderDrop = (e: React.DragEvent, targetIndex: number) => {
    e.preventDefault();
    const sourceIndex = parseInt(e.dataTransfer.getData('text/plain'));
    if (isNaN(sourceIndex) || sourceIndex === targetIndex) {
      setDragOverIndex(null);
      setDragSourceIndex(null);
      return;
    }

    setImages(prev => {
      const updated = [...prev];
      const [moved] = updated.splice(sourceIndex, 1);
      updated.splice(targetIndex, 0, moved);
      syncToParent(updated);
      return updated;
    });

    setDragOverIndex(null);
    setDragSourceIndex(null);
  };

  const handleReorderDragEnd = () => {
    setDragOverIndex(null);
    setDragSourceIndex(null);
  };

  // Move image up/down (for accessibility / mobile)
  const moveImage = (index: number, direction: 'up' | 'down') => {
    const newIndex = direction === 'up' ? index - 1 : index + 1;
    if (newIndex < 0 || newIndex >= images.length) return;

    setImages(prev => {
      const updated = [...prev];
      [updated[index], updated[newIndex]] = [updated[newIndex], updated[index]];
      syncToParent(updated);
      return updated;
    });
  };

  const clearAll = () => {
    if (!confirm(`Remove all ${images.length} photos?`)) return;
    images.forEach(img => {
      if (img.url.startsWith('blob:')) URL.revokeObjectURL(img.url);
    });
    setImages([]);
    syncToParent([]);
  };

  const pendingCount = images.filter(i => ['compressing', 'uploading', 'pending'].includes(i.status)).length;
  const errorCount = images.filter(i => i.status === 'error').length;
  const doneCount = images.filter(i => i.status === 'existing' || i.status === 'done').length;

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold text-neon-cyan uppercase tracking-wider flex items-center gap-2">
          <Camera className="w-4 h-4" />
          Photos
          {images.length > 0 && (
            <span className="text-xs text-gray-500 normal-case tracking-normal font-normal">
              ({doneCount} uploaded{pendingCount > 0 ? `, ${pendingCount} processing` : ''}{errorCount > 0 ? `, ${errorCount} failed` : ''})
            </span>
          )}
        </h3>
        {images.length > 0 && (
          <button
            type="button"
            onClick={clearAll}
            className="text-xs text-red-400/60 hover:text-red-400 transition-colors"
          >
            Clear All
          </button>
        )}
      </div>

      {/* Drop Zone */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        multiple
        onChange={handleFileSelect}
        className="hidden"
      />

      <div
        ref={dropRef}
        onDragEnter={handleDragEnter}
        onDragLeave={handleDragLeave}
        onDragOver={handleDragOver}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
        className={`relative border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-all ${
          isDraggingFile
            ? 'border-neon-cyan bg-neon-cyan/5 scale-[1.01]'
            : 'border-white/15 hover:border-neon-pink/40 hover:bg-white/[0.01]'
        }`}
      >
        <div className={`transition-transform ${isDraggingFile ? 'scale-105' : ''}`}>
          <div className={`w-12 h-12 mx-auto rounded-xl flex items-center justify-center mb-3 ${
            isDraggingFile ? 'bg-neon-cyan/10' : 'bg-white/[0.03]'
          }`}>
            <ImagePlus className={`w-6 h-6 ${isDraggingFile ? 'text-neon-cyan' : 'text-gray-600'}`} />
          </div>
          <p className={`font-semibold text-sm mb-1 ${isDraggingFile ? 'text-neon-cyan' : 'text-white'}`}>
            {isDraggingFile ? 'Drop photos here!' : 'Drag & drop photos here'}
          </p>
          <p className="text-gray-500 text-xs">
            or click to browse — JPG, PNG, WebP — auto-compressed before upload
          </p>
          <div className="flex items-center justify-center gap-4 mt-3 text-[11px] text-gray-600">
            <span className="flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-neon-cyan/50" />
              Auto-compress
            </span>
            <span className="flex items-center gap-1">
              <GripVertical className="w-3 h-3 text-neon-pink/50" />
              Drag to reorder
            </span>
            <span className="flex items-center gap-1">
              <Crop className="w-3 h-3 text-neon-green/50" />
              Crop & rotate
            </span>
          </div>
        </div>
      </div>

      {/* Image Grid with Drag-and-Drop Reordering */}
      {images.length > 0 && (
        <div className="space-y-3">
          {/* Reorder hint */}
          <p className="text-[11px] text-gray-600 flex items-center gap-1.5">
            <GripVertical className="w-3 h-3" />
            Drag images to reorder. First image (or starred) is the hero/cover photo.
          </p>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
            {images.map((img, index) => (
              <div
                key={img.id}
                draggable={img.status !== 'compressing' && img.status !== 'uploading'}
                onDragStart={(e) => handleReorderDragStart(e, index)}
                onDragOver={(e) => handleReorderDragOver(e, index)}
                onDragLeave={handleReorderDragLeave}
                onDrop={(e) => handleReorderDrop(e, index)}
                onDragEnd={handleReorderDragEnd}
                className={`relative group rounded-xl overflow-hidden border-2 transition-all ${
                  img.isHero
                    ? 'border-neon-pink ring-1 ring-neon-pink/30'
                    : dragOverIndex === index
                    ? 'border-neon-cyan ring-1 ring-neon-cyan/30 scale-105'
                    : dragSourceIndex === index
                    ? 'border-white/20 opacity-40 scale-95'
                    : 'border-white/10 hover:border-white/20'
                }`}
              >
                {/* Image */}
                <div className="aspect-[4/3] bg-gray-900 relative overflow-hidden">
                  <img
                    src={img.thumbnail || img.url}
                    alt={`Photo ${index + 1}`}
                    className="w-full h-full object-cover"
                    loading="lazy"
                  />

                  {/* Processing Overlay */}
                  {(img.status === 'compressing' || img.status === 'uploading') && (
                    <div className="absolute inset-0 bg-black/70 flex flex-col items-center justify-center gap-2">
                      <Loader2 className="w-6 h-6 text-neon-cyan animate-spin" />
                      <span className="text-[10px] text-neon-cyan font-medium">
                        {img.status === 'compressing' ? 'Compressing...' : 'Uploading...'}
                      </span>
                      {/* Progress bar */}
                      <div className="w-3/4 h-1 bg-white/10 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-neon-cyan to-neon-green rounded-full transition-all duration-500"
                          style={{ width: `${img.progress}%` }}
                        />
                      </div>
                    </div>
                  )}

                  {/* Error Overlay */}
                  {img.status === 'error' && (
                    <div className="absolute inset-0 bg-black/70 flex flex-col items-center justify-center gap-2 p-2">
                      <AlertCircle className="w-5 h-5 text-red-400" />
                      <span className="text-[10px] text-red-400 text-center">{img.error || 'Failed'}</span>
                      <button
                        type="button"
                        onClick={(e) => { e.stopPropagation(); retryUpload(img.id); }}
                        className="px-2 py-1 bg-red-500/20 border border-red-500/30 text-red-300 text-[10px] font-bold rounded hover:bg-red-500/30 transition-colors"
                      >
                        Retry
                      </button>
                    </div>
                  )}

                  {/* Done check */}
                  {img.status === 'done' && (
                    <div className="absolute top-1.5 right-1.5 w-5 h-5 bg-neon-green rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <Check className="w-3 h-3 text-black" />
                    </div>
                  )}

                  {/* Hover Actions */}
                  {(img.status === 'existing' || img.status === 'done') && (
                    <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-1.5">
                      {/* Drag handle */}
                      <div className="absolute top-1 left-1 p-1 bg-black/50 rounded cursor-grab active:cursor-grabbing">
                        <GripVertical className="w-3.5 h-3.5 text-white/70" />
                      </div>

                      {!img.isHero && (
                        <button
                          type="button"
                          onClick={(e) => { e.stopPropagation(); setAsHero(img.id); }}
                          className="flex items-center gap-1 px-2.5 py-1 bg-neon-pink/80 text-white text-[10px] font-bold rounded-md hover:bg-neon-pink transition-colors"
                        >
                          <Star className="w-3 h-3" />
                          Set as Cover
                        </button>
                      )}
                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={(e) => { e.stopPropagation(); openCropEditor(img.id); }}
                          className="p-1.5 bg-white/10 text-white rounded-md hover:bg-white/20 transition-colors"
                          title="Crop & Rotate"
                        >
                          <Crop className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={(e) => { e.stopPropagation(); removeImage(img.id); }}
                          className="p-1.5 bg-red-500/60 text-white rounded-md hover:bg-red-500 transition-colors"
                          title="Remove"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                      {/* Move buttons for mobile */}
                      <div className="flex items-center gap-1 sm:hidden">
                        <button
                          type="button"
                          onClick={(e) => { e.stopPropagation(); moveImage(index, 'up'); }}
                          disabled={index === 0}
                          className="p-1 bg-white/10 text-white rounded disabled:opacity-30"
                        >
                          <ArrowUp className="w-3 h-3" />
                        </button>
                        <button
                          type="button"
                          onClick={(e) => { e.stopPropagation(); moveImage(index, 'down'); }}
                          disabled={index === images.length - 1}
                          className="p-1 bg-white/10 text-white rounded disabled:opacity-30"
                        >
                          <ArrowDown className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  )}
                </div>

                {/* Footer Info */}
                <div className="px-2 py-1.5 bg-black/40 flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    {img.isHero && (
                      <span className="px-1.5 py-0.5 bg-neon-pink text-white text-[9px] font-bold rounded flex items-center gap-0.5">
                        <Star className="w-2.5 h-2.5 fill-current" />
                        COVER
                      </span>
                    )}
                    <span className="text-[10px] text-gray-500">#{index + 1}</span>
                  </div>
                  <div className="text-[9px] text-gray-600">
                    {img.compressedSize ? (
                      <span className="flex items-center gap-1">
                        {formatFileSize(img.compressedSize)}
                        {img.originalSize && img.compressedSize < img.originalSize && (
                          <span className="text-neon-green">
                            -{Math.round((1 - img.compressedSize / img.originalSize) * 100)}%
                          </span>
                        )}
                      </span>
                    ) : img.originalSize ? (
                      formatFileSize(img.originalSize)
                    ) : null}
                  </div>
                </div>

                {/* Drop indicator line */}
                {dragOverIndex === index && dragSourceIndex !== null && dragSourceIndex !== index && (
                  <div className="absolute inset-y-0 -left-1.5 w-1 bg-neon-cyan rounded-full" />
                )}
              </div>
            ))}

            {/* Add More Button */}
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="aspect-[4/3] rounded-xl border-2 border-dashed border-white/10 hover:border-neon-cyan/30 bg-white/[0.01] hover:bg-neon-cyan/[0.03] flex flex-col items-center justify-center gap-2 transition-all group"
            >
              <div className="w-10 h-10 rounded-lg bg-white/[0.03] group-hover:bg-neon-cyan/10 flex items-center justify-center transition-colors">
                <ImagePlus className="w-5 h-5 text-gray-600 group-hover:text-neon-cyan transition-colors" />
              </div>
              <span className="text-[11px] text-gray-600 group-hover:text-neon-cyan transition-colors font-medium">
                Add More
              </span>
            </button>
          </div>

          {/* Compression Stats */}
          {images.some(img => img.originalSize && img.compressedSize && img.compressedSize < img.originalSize) && (
            <div className="flex items-center gap-2 px-3 py-2 bg-neon-green/[0.04] border border-neon-green/10 rounded-lg">
              <Sparkles className="w-3.5 h-3.5 text-neon-green flex-shrink-0" />
              <span className="text-[11px] text-neon-green/80">
                Auto-compressed: saved{' '}
                {formatFileSize(
                  images.reduce((sum, img) => {
                    if (img.originalSize && img.compressedSize && img.compressedSize < img.originalSize) {
                      return sum + (img.originalSize - img.compressedSize);
                    }
                    return sum;
                  }, 0)
                )}{' '}
                total
              </span>
            </div>
          )}
        </div>
      )}

      {/* Image URL input */}
      <div>
        <label className="block text-xs text-gray-500 mb-1">Or paste an image URL</label>
        <div className="flex gap-2">
          <input
            type="text"
            placeholder="https://..."
            id="imageUrlInput"
            className="flex-1 px-3 py-2 bg-black border border-white/10 rounded-lg text-white text-sm placeholder-gray-600 focus:border-neon-cyan focus:outline-none"
          />
          <button
            type="button"
            onClick={() => {
              const input = document.getElementById('imageUrlInput') as HTMLInputElement;
              if (input?.value.trim()) {
                const url = input.value.trim();
                const newImg: ManagedImage = {
                  id: `url-${Date.now()}`,
                  url,
                  thumbnail: url,
                  status: 'existing',
                  progress: 100,
                  isHero: images.length === 0,
                };
                setImages(prev => {
                  const updated = [...prev, newImg];
                  syncToParent(updated);
                  return updated;
                });
                input.value = '';
              }
            }}
            className="px-4 py-2 bg-neon-cyan/10 border border-neon-cyan/30 text-neon-cyan rounded-lg hover:bg-neon-cyan/20 transition-colors text-sm"
          >
            Add
          </button>
        </div>
      </div>

      {/* Crop Modal */}
      {cropImage && (
        <ImageCropModal
          imageUrl={cropImage.url}
          onSave={handleCropSave}
          onClose={() => setCropImage(null)}
        />
      )}
    </div>
  );
};

export default ImageUploadManager;
