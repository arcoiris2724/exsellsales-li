import React, { useState } from 'react';
import {
  FileText, Loader2, Sparkles, RefreshCw, CheckCircle, AlertTriangle,
  X, Info, Copy, ChevronDown, ChevronUp, Search, BookOpen, Zap,
  TrendingUp, Hash, Eye, PenTool, Briefcase, Coffee, Crown
} from 'lucide-react';
import { Vehicle } from '@/data/vehicles';
import { supabase } from '@/lib/supabase';

type Tone = 'professional' | 'casual' | 'luxury';

interface DescriptionResult {
  description: string;
  seoKeywords: string[];
  highlights: string[];
  wordCount: number;
  readabilityScore: number;
  seoScore: number;
  tone: string;
}

interface AIDescriptionPanelProps {
  vehicle: Partial<Vehicle>;
  currentDescription: string;
  onApplyDescription: (description: string) => void;
}

const TONE_CONFIG: Record<Tone, { label: string; icon: React.ReactNode; color: string; bgColor: string; borderColor: string; description: string }> = {
  professional: {
    label: 'Professional',
    icon: <Briefcase className="w-4 h-4" />,
    color: 'text-blue-400',
    bgColor: 'bg-blue-500/10',
    borderColor: 'border-blue-500/30',
    description: 'Polished dealership-quality voice with precise automotive terminology',
  },
  casual: {
    label: 'Casual',
    icon: <Coffee className="w-4 h-4" />,
    color: 'text-emerald-400',
    bgColor: 'bg-emerald-500/10',
    borderColor: 'border-emerald-500/30',
    description: 'Warm, approachable, and conversational — like a friend recommending a car',
  },
  luxury: {
    label: 'Luxury',
    icon: <Crown className="w-4 h-4" />,
    color: 'text-amber-400',
    bgColor: 'bg-amber-500/10',
    borderColor: 'border-amber-500/30',
    description: 'Elegant, aspirational prose that evokes lifestyle and prestige',
  },
};

const AIDescriptionPanel: React.FC<AIDescriptionPanelProps> = ({
  vehicle,
  currentDescription,
  onApplyDescription,
}) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [result, setResult] = useState<DescriptionResult | null>(null);
  const [selectedTone, setSelectedTone] = useState<Tone>('professional');
  const [applied, setApplied] = useState(false);
  const [copied, setCopied] = useState(false);
  const [showSEO, setShowSEO] = useState(false);
  const [showHighlights, setShowHighlights] = useState(false);
  const [previewExpanded, setPreviewExpanded] = useState(true);

  const canGenerate = vehicle.year && vehicle.make && vehicle.model;

  const generateDescription = async () => {
    if (!canGenerate) return;
    setLoading(true);
    setError('');
    setResult(null);
    setApplied(false);
    setCopied(false);

    try {
      const { data, error: fnError } = await supabase.functions.invoke('ai-description', {
        body: {
          year: vehicle.year,
          make: vehicle.make,
          model: vehicle.model,
          trim: vehicle.trim,
          mileage: vehicle.mileage,
          bodyType: vehicle.bodyType,
          drivetrain: vehicle.drivetrain,
          fuelType: vehicle.fuelType,
          engine: vehicle.engine,
          features: vehicle.features,
          exteriorColor: vehicle.exteriorColor,
          interiorColor: vehicle.interiorColor,
          price: vehicle.price,
          transmission: vehicle.transmission,
          images: vehicle.images,
          vin: vehicle.vin,
          condition: vehicle.status === 'available' ? 'Good' : vehicle.status,
          tone: selectedTone,
        },
      });

      if (fnError) throw new Error(fnError.message || 'Failed to connect to description service');
      if (data?.error) throw new Error(data.error);
      if (!data?.result) throw new Error('No description data returned');

      setResult(data.result);
    } catch (err: any) {
      setError(err.message || 'Failed to generate description');
    } finally {
      setLoading(false);
    }
  };

  const handleApply = () => {
    if (!result) return;
    onApplyDescription(result.description);
    setApplied(true);
  };

  const handleCopy = async () => {
    if (!result) return;
    try {
      await navigator.clipboard.writeText(result.description);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback for older browsers
      const textarea = document.createElement('textarea');
      textarea.value = result.description;
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand('copy');
      document.body.removeChild(textarea);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const getScoreColor = (score: number, max: number) => {
    const pct = score / max;
    if (pct >= 0.8) return 'text-emerald-400';
    if (pct >= 0.6) return 'text-yellow-400';
    return 'text-red-400';
  };

  const getScoreBarColor = (score: number, max: number) => {
    const pct = score / max;
    if (pct >= 0.8) return 'bg-gradient-to-r from-emerald-500 to-emerald-400';
    if (pct >= 0.6) return 'bg-gradient-to-r from-yellow-500 to-yellow-400';
    return 'bg-gradient-to-r from-red-500 to-red-400';
  };

  // ── Not yet generated ──
  if (!result && !loading && !error) {
    return (
      <div className="rounded-xl border border-teal-500/20 bg-gradient-to-br from-teal-500/[0.06] to-cyan-500/[0.04] overflow-hidden">
        <div className="p-4">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-teal-500 to-cyan-600 flex items-center justify-center flex-shrink-0 shadow-lg shadow-teal-500/20">
              <PenTool className="w-4.5 h-4.5 text-white" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                AI Description Writer
                <span className="px-1.5 py-0.5 bg-teal-500/20 text-teal-300 text-[10px] font-bold rounded-full uppercase tracking-wider">AI</span>
              </h3>
              <p className="text-xs text-gray-400 mt-0.5">
                Generate SEO-optimized listing descriptions with one click
              </p>
            </div>
          </div>

          {/* Tone Selector */}
          <div className="mb-4">
            <label className="block text-xs text-gray-400 font-medium mb-2">Select Tone</label>
            <div className="grid grid-cols-3 gap-2">
              {(Object.keys(TONE_CONFIG) as Tone[]).map((tone) => {
                const config = TONE_CONFIG[tone];
                const isSelected = selectedTone === tone;
                return (
                  <button
                    key={tone}
                    type="button"
                    onClick={() => setSelectedTone(tone)}
                    className={`relative flex flex-col items-center gap-1.5 p-3 rounded-xl border transition-all duration-200 ${
                      isSelected
                        ? `${config.bgColor} ${config.borderColor} ${config.color} ring-1 ring-current/20`
                        : 'bg-white/[0.02] border-white/10 text-gray-500 hover:text-gray-300 hover:border-white/20'
                    }`}
                  >
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center transition-colors ${
                      isSelected ? `${config.bgColor}` : 'bg-white/5'
                    }`}>
                      {config.icon}
                    </div>
                    <span className="text-xs font-bold">{config.label}</span>
                    {isSelected && (
                      <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-current flex items-center justify-center">
                        <CheckCircle className="w-3 h-3 text-black" />
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
            <p className="text-[11px] text-gray-500 mt-2 flex items-center gap-1.5">
              <Info className="w-3 h-3 flex-shrink-0" />
              {TONE_CONFIG[selectedTone].description}
            </p>
          </div>

          <button
            type="button"
            onClick={generateDescription}
            disabled={!canGenerate}
            className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-gradient-to-r from-teal-500 to-cyan-600 text-white font-bold rounded-xl hover:opacity-90 transition-all disabled:opacity-40 disabled:cursor-not-allowed shadow-lg shadow-teal-500/20 text-sm"
          >
            <PenTool className="w-4 h-4" />
            Generate Description
          </button>

          {!canGenerate && (
            <p className="text-xs text-gray-500 mt-2 flex items-center gap-1.5">
              <Info className="w-3 h-3" />
              Enter year, make, and model first to enable AI descriptions
            </p>
          )}
        </div>
      </div>
    );
  }

  // ── Loading ──
  if (loading) {
    return (
      <div className="rounded-xl border border-teal-500/30 bg-gradient-to-br from-teal-500/[0.08] to-cyan-500/[0.05] p-6">
        <div className="flex flex-col items-center justify-center py-4">
          <div className="relative mb-4">
            <div className="absolute -inset-3 bg-teal-500/20 rounded-full blur-xl animate-pulse" />
            <div className="relative w-14 h-14 rounded-2xl bg-gradient-to-br from-teal-500 to-cyan-600 flex items-center justify-center shadow-xl shadow-teal-500/30">
              <PenTool className="w-7 h-7 text-white animate-pulse" />
            </div>
          </div>
          <div className="flex items-center gap-2 mb-2">
            <Loader2 className="w-4 h-4 text-teal-400 animate-spin" />
            <span className="text-sm font-semibold text-white">Crafting Your Description...</span>
          </div>
          <p className="text-xs text-gray-400 text-center max-w-xs">
            Writing a {TONE_CONFIG[selectedTone].label.toLowerCase()}, SEO-optimized listing for the {vehicle.year} {vehicle.make} {vehicle.model}
          </p>
          <div className="flex gap-1 mt-4">
            {[0, 1, 2, 3, 4].map(i => (
              <div
                key={i}
                className="w-2 h-2 rounded-full bg-teal-400"
                style={{
                  animation: `pulse 1.4s ease-in-out ${i * 0.2}s infinite`,
                  opacity: 0.3,
                }}
              />
            ))}
          </div>
        </div>
      </div>
    );
  }

  // ── Error ──
  if (error) {
    return (
      <div className="rounded-xl border border-red-500/20 bg-red-500/[0.05] p-4">
        <div className="flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="text-sm font-semibold text-red-300">Description Generation Failed</p>
            <p className="text-xs text-red-400/70 mt-1">{error}</p>
            <div className="flex gap-3 mt-3">
              <button
                type="button"
                onClick={generateDescription}
                className="text-xs text-teal-400 hover:text-teal-300 transition-colors flex items-center gap-1 font-medium"
              >
                <RefreshCw className="w-3 h-3" />
                Try Again
              </button>
              <button
                type="button"
                onClick={() => { setError(''); setResult(null); }}
                className="text-xs text-gray-500 hover:text-white transition-colors"
              >
                Dismiss
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ── Results ──
  if (!result) return null;

  const toneConfig = TONE_CONFIG[result.tone as Tone] || TONE_CONFIG.professional;

  return (
    <div className="rounded-xl border border-teal-500/30 bg-gradient-to-br from-teal-500/[0.06] to-cyan-500/[0.04] overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-white/5">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-teal-500 to-cyan-600 flex items-center justify-center shadow-lg shadow-teal-500/20">
            <PenTool className="w-4 h-4 text-white" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              AI-Generated Description
              <span className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[10px] font-bold ${toneConfig.bgColor} ${toneConfig.color} ${toneConfig.borderColor} border`}>
                {toneConfig.icon}
                {toneConfig.label}
              </span>
            </h3>
            <p className="text-[11px] text-gray-500">
              {vehicle.year} {vehicle.make} {vehicle.model} {vehicle.trim}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => { setResult(null); setError(''); setApplied(false); }}
            className="p-1.5 text-gray-500 hover:text-white transition-colors rounded-lg hover:bg-white/5"
            title="New description"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={() => { setResult(null); setError(''); setApplied(false); }}
            className="p-1.5 text-gray-500 hover:text-white transition-colors rounded-lg hover:bg-white/5"
            title="Close"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      <div className="p-4 space-y-4">
        {/* ── Score Cards Row ── */}
        <div className="grid grid-cols-3 gap-2">
          {/* Word Count */}
          <div className="bg-white/[0.03] border border-white/5 rounded-lg p-2.5 text-center">
            <div className="flex items-center justify-center gap-1 mb-1 text-white">
              <Hash className="w-3.5 h-3.5 text-gray-400" />
              <span className="text-xs font-bold">{result.wordCount}</span>
            </div>
            <p className="text-[10px] text-gray-500">Words</p>
          </div>

          {/* Readability */}
          <div className="bg-white/[0.03] border border-white/5 rounded-lg p-2.5 text-center">
            <div className={`flex items-center justify-center gap-1 mb-1 ${getScoreColor(result.readabilityScore, 10)}`}>
              <Eye className="w-3.5 h-3.5" />
              <span className="text-xs font-bold">{result.readabilityScore}/10</span>
            </div>
            <p className="text-[10px] text-gray-500">Readability</p>
          </div>

          {/* SEO Score */}
          <div className="bg-white/[0.03] border border-white/5 rounded-lg p-2.5 text-center">
            <div className={`flex items-center justify-center gap-1 mb-1 ${getScoreColor(result.seoScore, 100)}`}>
              <TrendingUp className="w-3.5 h-3.5" />
              <span className="text-xs font-bold">{result.seoScore}%</span>
            </div>
            <p className="text-[10px] text-gray-500">SEO Score</p>
          </div>
        </div>

        {/* ── SEO Score Bar ── */}
        <div className="bg-white/[0.02] border border-white/5 rounded-lg p-3">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-gray-400 font-medium flex items-center gap-1.5">
              <Search className="w-3.5 h-3.5 text-teal-400" />
              SEO Effectiveness
            </span>
            <span className={`text-xs font-bold ${getScoreColor(result.seoScore, 100)}`}>
              {result.seoScore >= 80 ? 'Excellent' : result.seoScore >= 60 ? 'Good' : 'Needs Work'}
            </span>
          </div>
          <div className="h-1.5 bg-black/40 rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-1000 ${getScoreBarColor(result.seoScore, 100)}`}
              style={{ width: `${result.seoScore}%` }}
            />
          </div>
        </div>

        {/* ── Description Preview ── */}
        <div className="border border-white/10 rounded-xl overflow-hidden">
          <button
            type="button"
            onClick={() => setPreviewExpanded(!previewExpanded)}
            className="w-full flex items-center justify-between p-3 bg-white/[0.02] hover:bg-white/[0.04] transition-colors"
          >
            <span className="text-xs font-semibold text-gray-300 flex items-center gap-2">
              <FileText className="w-3.5 h-3.5 text-teal-400" />
              Description Preview
            </span>
            {previewExpanded ? <ChevronUp className="w-4 h-4 text-gray-500" /> : <ChevronDown className="w-4 h-4 text-gray-500" />}
          </button>
          {previewExpanded && (
            <div className="p-4 border-t border-white/5">
              <div className="text-sm text-gray-300 leading-relaxed whitespace-pre-wrap max-h-64 overflow-y-auto thin-scrollbar">
                {result.description}
              </div>
            </div>
          )}
        </div>

        {/* ── Action Buttons ── */}
        <div className="grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={handleApply}
            disabled={applied}
            className={`flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-bold transition-all ${
              applied
                ? 'bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 cursor-default'
                : 'bg-gradient-to-r from-teal-500 to-cyan-600 text-white hover:opacity-90 shadow-lg shadow-teal-500/20'
            }`}
          >
            {applied ? (
              <>
                <CheckCircle className="w-4 h-4" />
                Applied to Form
              </>
            ) : (
              <>
                <Zap className="w-4 h-4" />
                Use This Description
              </>
            )}
          </button>
          <button
            type="button"
            onClick={handleCopy}
            className={`flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-bold border transition-all ${
              copied
                ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                : 'bg-white/[0.03] border-white/10 text-gray-400 hover:text-white hover:border-white/20'
            }`}
          >
            {copied ? (
              <>
                <CheckCircle className="w-4 h-4" />
                Copied!
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" />
                Copy to Clipboard
              </>
            )}
          </button>
        </div>

        {/* ── Key Selling Points ── */}
        {result.highlights && result.highlights.length > 0 && (
          <div className="border border-white/5 rounded-lg overflow-hidden">
            <button
              type="button"
              onClick={() => setShowHighlights(!showHighlights)}
              className="w-full flex items-center justify-between p-3 hover:bg-white/[0.02] transition-colors"
            >
              <span className="text-xs font-semibold text-gray-300 flex items-center gap-2">
                <Sparkles className="w-3.5 h-3.5 text-teal-400" />
                Key Selling Points ({result.highlights.length})
              </span>
              {showHighlights ? <ChevronUp className="w-4 h-4 text-gray-500" /> : <ChevronDown className="w-4 h-4 text-gray-500" />}
            </button>
            {showHighlights && (
              <div className="border-t border-white/5 p-3 space-y-2">
                {result.highlights.map((highlight, i) => (
                  <div key={i} className="flex items-start gap-2.5">
                    <div className="w-5 h-5 rounded-full bg-teal-500/10 border border-teal-500/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <span className="text-[10px] font-bold text-teal-400">{i + 1}</span>
                    </div>
                    <p className="text-xs text-gray-300 leading-relaxed">{highlight}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ── SEO Keywords ── */}
        {result.seoKeywords && result.seoKeywords.length > 0 && (
          <div className="border border-white/5 rounded-lg overflow-hidden">
            <button
              type="button"
              onClick={() => setShowSEO(!showSEO)}
              className="w-full flex items-center justify-between p-3 hover:bg-white/[0.02] transition-colors"
            >
              <span className="text-xs font-semibold text-gray-300 flex items-center gap-2">
                <Search className="w-3.5 h-3.5 text-teal-400" />
                SEO Keywords ({result.seoKeywords.length})
              </span>
              {showSEO ? <ChevronUp className="w-4 h-4 text-gray-500" /> : <ChevronDown className="w-4 h-4 text-gray-500" />}
            </button>
            {showSEO && (
              <div className="border-t border-white/5 p-3">
                <div className="flex flex-wrap gap-1.5">
                  {result.seoKeywords.map((keyword, i) => (
                    <span
                      key={i}
                      className="px-2.5 py-1 bg-teal-500/10 border border-teal-500/20 text-teal-300 text-[11px] font-medium rounded-full"
                    >
                      {keyword}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ── Regenerate with Different Tone ── */}
        <div className="border border-white/5 rounded-lg p-3">
          <p className="text-xs text-gray-400 font-medium mb-2">Try a different tone:</p>
          <div className="flex gap-2">
            {(Object.keys(TONE_CONFIG) as Tone[]).map((tone) => {
              const config = TONE_CONFIG[tone];
              const isCurrent = result.tone === tone;
              return (
                <button
                  key={tone}
                  type="button"
                  disabled={isCurrent}
                  onClick={() => {
                    setSelectedTone(tone);
                    setTimeout(() => generateDescription(), 50);
                  }}
                  className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-bold transition-all ${
                    isCurrent
                      ? `${config.bgColor} ${config.borderColor} border ${config.color} opacity-50 cursor-default`
                      : `bg-white/[0.03] border border-white/10 text-gray-400 hover:${config.color} hover:${config.borderColor}`
                  }`}
                >
                  {config.icon}
                  {config.label}
                  {isCurrent && <span className="text-[9px] opacity-70">(current)</span>}
                </button>
              );
            })}
          </div>
        </div>

        {/* Powered by footer */}
        <div className="flex items-center justify-center gap-1.5 text-[10px] text-gray-600 pt-1">
          <PenTool className="w-3 h-3" />
          Powered by AI copywriting
        </div>
      </div>
    </div>
  );
};

export default AIDescriptionPanel;
