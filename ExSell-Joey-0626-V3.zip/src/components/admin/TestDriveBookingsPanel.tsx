import React, { useState, useEffect, useCallback } from 'react';
import {
  Calendar, Clock, Phone, Mail, Car, User, Search,
  CheckCircle, XCircle, AlertCircle, Loader2, RefreshCw,
  ChevronDown, ChevronUp, MessageSquare, StickyNote,
  Filter, ArrowUpDown, MapPin, CalendarCheck, CalendarX,
  Eye, Trash2
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { toast } from '@/components/ui/use-toast';

export interface TestDriveBooking {
  id: number;
  customer_name: string;
  email: string | null;
  phone: string;
  preferred_date: string;
  preferred_time: string;
  vehicle_id: number | null;
  vehicle_label: string | null;
  message: string | null;
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled';
  admin_notes: string | null;
  created_at: string;
  updated_at: string;
}

const statusConfig = {
  pending: {
    label: 'Pending',
    color: 'text-amber-400',
    bg: 'bg-amber-400/10',
    border: 'border-amber-400/30',
    icon: Clock,
    description: 'Awaiting confirmation',
  },
  confirmed: {
    label: 'Confirmed',
    color: 'text-neon-cyan',
    bg: 'bg-neon-cyan/10',
    border: 'border-neon-cyan/30',
    icon: CalendarCheck,
    description: 'Appointment confirmed',
  },
  completed: {
    label: 'Completed',
    color: 'text-neon-green',
    bg: 'bg-neon-green/10',
    border: 'border-neon-green/30',
    icon: CheckCircle,
    description: 'Test drive completed',
  },
  cancelled: {
    label: 'Cancelled',
    color: 'text-red-400',
    bg: 'bg-red-400/10',
    border: 'border-red-400/30',
    icon: CalendarX,
    description: 'Appointment cancelled',
  },
};

const TestDriveBookingsPanel: React.FC = () => {
  const [bookings, setBookings] = useState<TestDriveBooking[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [sortField, setSortField] = useState<'created_at' | 'preferred_date'>('created_at');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');
  const [expandedBooking, setExpandedBooking] = useState<number | null>(null);
  const [editingNotes, setEditingNotes] = useState<number | null>(null);
  const [notesText, setNotesText] = useState('');
  const [actionLoading, setActionLoading] = useState<number | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<number | null>(null);

  const loadBookings = useCallback(async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('test_drive_bookings')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setBookings((data || []) as TestDriveBooking[]);
    } catch (err) {
      console.error('Failed to load bookings:', err);
      toast({ title: 'Error', description: 'Failed to load test drive bookings.', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadBookings();
  }, [loadBookings]);

  // Poll every 30 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      supabase
        .from('test_drive_bookings')
        .select('*')
        .order('created_at', { ascending: false })
        .then(({ data }) => {
          if (data) setBookings(data as TestDriveBooking[]);
        });
    }, 30000);
    return () => clearInterval(interval);
  }, []);

  const handleStatusChange = async (bookingId: number, newStatus: TestDriveBooking['status']) => {
    setActionLoading(bookingId);
    try {
      const { error } = await supabase
        .from('test_drive_bookings')
        .update({ status: newStatus, updated_at: new Date().toISOString() })
        .eq('id', bookingId);

      if (error) throw error;

      setBookings((prev) =>
        prev.map((b) =>
          b.id === bookingId ? { ...b, status: newStatus, updated_at: new Date().toISOString() } : b
        )
      );
      toast({
        title: 'Status Updated',
        description: `Booking #${bookingId} marked as ${newStatus}.`,
      });
    } catch (err) {
      console.error('Failed to update status:', err);
      toast({ title: 'Error', description: 'Failed to update booking status.', variant: 'destructive' });
    } finally {
      setActionLoading(null);
    }
  };

  const handleSaveNotes = async (bookingId: number) => {
    setActionLoading(bookingId);
    try {
      const { error } = await supabase
        .from('test_drive_bookings')
        .update({ admin_notes: notesText.trim() || null, updated_at: new Date().toISOString() })
        .eq('id', bookingId);

      if (error) throw error;

      setBookings((prev) =>
        prev.map((b) =>
          b.id === bookingId
            ? { ...b, admin_notes: notesText.trim() || null, updated_at: new Date().toISOString() }
            : b
        )
      );
      setEditingNotes(null);
      toast({ title: 'Notes Saved', description: 'Admin notes updated successfully.' });
    } catch (err) {
      console.error('Failed to save notes:', err);
      toast({ title: 'Error', description: 'Failed to save notes.', variant: 'destructive' });
    } finally {
      setActionLoading(null);
    }
  };

  const handleDelete = async (bookingId: number) => {
    setActionLoading(bookingId);
    try {
      const { error } = await supabase
        .from('test_drive_bookings')
        .delete()
        .eq('id', bookingId);

      if (error) throw error;

      setBookings((prev) => prev.filter((b) => b.id !== bookingId));
      setDeleteConfirm(null);
      toast({ title: 'Booking Deleted', description: `Booking #${bookingId} has been removed.` });
    } catch (err) {
      console.error('Failed to delete booking:', err);
      toast({ title: 'Error', description: 'Failed to delete booking.', variant: 'destructive' });
    } finally {
      setActionLoading(null);
    }
  };

  // Filter and sort
  const filtered = bookings
    .filter((b) => {
      if (statusFilter !== 'all' && b.status !== statusFilter) return false;
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        const searchStr = `${b.customer_name} ${b.email || ''} ${b.phone} ${b.vehicle_label || ''}`.toLowerCase();
        if (!searchStr.includes(q)) return false;
      }
      return true;
    })
    .sort((a, b) => {
      const aVal = sortField === 'preferred_date' ? a.preferred_date : a.created_at;
      const bVal = sortField === 'preferred_date' ? b.preferred_date : b.created_at;
      return sortDir === 'desc' ? bVal.localeCompare(aVal) : aVal.localeCompare(bVal);
    });

  const stats = {
    total: bookings.length,
    pending: bookings.filter((b) => b.status === 'pending').length,
    confirmed: bookings.filter((b) => b.status === 'confirmed').length,
    completed: bookings.filter((b) => b.status === 'completed').length,
    cancelled: bookings.filter((b) => b.status === 'cancelled').length,
    today: bookings.filter((b) => b.preferred_date === new Date().toISOString().split('T')[0]).length,
  };

  const formatDate = (dateStr: string) => {
    try {
      const d = new Date(dateStr + 'T00:00:00');
      return d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' });
    } catch {
      return dateStr;
    }
  };

  const formatTimestamp = (ts: string) => {
    try {
      const d = new Date(ts);
      return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) +
        ' at ' +
        d.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
    } catch {
      return ts;
    }
  };

  const isUpcoming = (dateStr: string) => {
    const today = new Date().toISOString().split('T')[0];
    return dateStr >= today;
  };

  const isPast = (dateStr: string) => {
    const today = new Date().toISOString().split('T')[0];
    return dateStr < today;
  };

  return (
    <div className="space-y-6">
      {/* Stats Row */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        <MiniStat label="Total" value={stats.total} color="text-white" bg="bg-white/5" />
        <MiniStat label="Pending" value={stats.pending} color="text-amber-400" bg="bg-amber-400/5" />
        <MiniStat label="Confirmed" value={stats.confirmed} color="text-neon-cyan" bg="bg-neon-cyan/5" />
        <MiniStat label="Completed" value={stats.completed} color="text-neon-green" bg="bg-neon-green/5" />
        <MiniStat label="Cancelled" value={stats.cancelled} color="text-red-400" bg="bg-red-400/5" />
        <MiniStat label="Today" value={stats.today} color="text-neon-pink" bg="bg-neon-pink/5" />
      </div>

      {/* Toolbar */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by name, email, phone, or vehicle..."
            className="w-full pl-10 pr-4 py-2.5 bg-white/[0.03] border border-white/10 rounded-lg text-white text-sm placeholder-gray-500 focus:border-neon-cyan focus:outline-none"
          />
        </div>
        <div className="flex gap-2">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2.5 bg-white/[0.03] border border-white/10 rounded-lg text-white text-sm focus:border-neon-cyan focus:outline-none"
          >
            <option value="all">All Status</option>
            <option value="pending">Pending</option>
            <option value="confirmed">Confirmed</option>
            <option value="completed">Completed</option>
            <option value="cancelled">Cancelled</option>
          </select>
          <select
            value={`${sortField}-${sortDir}`}
            onChange={(e) => {
              const [field, dir] = e.target.value.split('-');
              setSortField(field as 'created_at' | 'preferred_date');
              setSortDir(dir as 'asc' | 'desc');
            }}
            className="px-3 py-2.5 bg-white/[0.03] border border-white/10 rounded-lg text-white text-sm focus:border-neon-cyan focus:outline-none"
          >
            <option value="created_at-desc">Newest First</option>
            <option value="created_at-asc">Oldest First</option>
            <option value="preferred_date-asc">Date: Soonest</option>
            <option value="preferred_date-desc">Date: Latest</option>
          </select>
          <button
            onClick={loadBookings}
            disabled={loading}
            className="p-2.5 bg-white/[0.03] border border-white/10 rounded-lg text-gray-400 hover:text-white transition-colors"
            title="Refresh"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Bookings List */}
      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="w-8 h-8 text-neon-pink animate-spin" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-20">
          <Calendar className="w-12 h-12 text-gray-600 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-white mb-2">No bookings found</h3>
          <p className="text-gray-400 text-sm">
            {searchQuery || statusFilter !== 'all'
              ? 'Try adjusting your filters'
              : 'Test drive requests will appear here when customers submit them.'}
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((booking) => {
            const sc = statusConfig[booking.status];
            const StatusIcon = sc.icon;
            const isExpanded = expandedBooking === booking.id;
            const past = isPast(booking.preferred_date);
            const upcoming = isUpcoming(booking.preferred_date);

            return (
              <div
                key={booking.id}
                className={`bg-white/[0.02] border rounded-xl overflow-hidden transition-all ${
                  deleteConfirm === booking.id
                    ? 'border-red-500/40'
                    : booking.status === 'pending' && upcoming
                    ? 'border-amber-400/20 hover:border-amber-400/40'
                    : 'border-white/5 hover:border-white/10'
                }`}
              >
                {/* Main Row */}
                <div
                  className="flex flex-col sm:flex-row items-start sm:items-center gap-4 p-4 cursor-pointer"
                  onClick={() => setExpandedBooking(isExpanded ? null : booking.id)}
                >
                  {/* Status Badge */}
                  <div className={`flex items-center gap-2 px-3 py-1.5 ${sc.bg} ${sc.border} border rounded-full flex-shrink-0`}>
                    <StatusIcon className={`w-3.5 h-3.5 ${sc.color}`} />
                    <span className={`text-xs font-semibold ${sc.color}`}>{sc.label}</span>
                  </div>

                  {/* Customer Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <User className="w-3.5 h-3.5 text-gray-500 flex-shrink-0" />
                      <span className="text-white font-semibold text-sm truncate">{booking.customer_name}</span>
                      {booking.status === 'pending' && upcoming && (
                        <span className="px-1.5 py-0.5 bg-amber-400/20 text-amber-400 text-[10px] font-bold rounded uppercase tracking-wider">
                          New
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-4 text-xs text-gray-500">
                      <span className="flex items-center gap-1">
                        <Phone className="w-3 h-3" />
                        {booking.phone}
                      </span>
                      {booking.email && (
                        <span className="flex items-center gap-1 truncate">
                          <Mail className="w-3 h-3" />
                          {booking.email}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Vehicle */}
                  <div className="flex items-center gap-2 text-sm flex-shrink-0">
                    <Car className="w-3.5 h-3.5 text-neon-orange" />
                    <span className="text-gray-300 truncate max-w-[200px]">
                      {booking.vehicle_label || 'No vehicle specified'}
                    </span>
                  </div>

                  {/* Date/Time */}
                  <div className="text-right flex-shrink-0">
                    <div className={`text-sm font-semibold ${past && booking.status === 'pending' ? 'text-red-400' : 'text-white'}`}>
                      {formatDate(booking.preferred_date)}
                    </div>
                    <div className="text-xs text-gray-500">{booking.preferred_time}</div>
                  </div>

                  {/* Expand Arrow */}
                  <div className="flex-shrink-0">
                    {isExpanded ? (
                      <ChevronUp className="w-4 h-4 text-gray-500" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-gray-500" />
                    )}
                  </div>
                </div>

                {/* Expanded Details */}
                {isExpanded && (
                  <div className="border-t border-white/5 p-4 space-y-4 bg-white/[0.01]">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {/* Left: Details */}
                      <div className="space-y-3">
                        <h4 className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Booking Details</h4>
                        <div className="space-y-2">
                          <DetailRow icon={User} label="Customer" value={booking.customer_name} />
                          <DetailRow icon={Phone} label="Phone" value={booking.phone} isLink href={`tel:${booking.phone}`} />
                          {booking.email && (
                            <DetailRow icon={Mail} label="Email" value={booking.email} isLink href={`mailto:${booking.email}`} />
                          )}
                          <DetailRow icon={Car} label="Vehicle" value={booking.vehicle_label || 'Not specified'} />
                          <DetailRow
                            icon={Calendar}
                            label="Date"
                            value={formatDate(booking.preferred_date)}
                            valueColor={past && booking.status === 'pending' ? 'text-red-400' : undefined}
                          />
                          <DetailRow icon={Clock} label="Time" value={booking.preferred_time} />
                          <DetailRow icon={AlertCircle} label="Submitted" value={formatTimestamp(booking.created_at)} />
                          {booking.message && (
                            <div className="pt-2">
                              <div className="flex items-center gap-2 text-xs text-gray-400 mb-1">
                                <MessageSquare className="w-3 h-3" />
                                <span>Customer Message</span>
                              </div>
                              <p className="text-sm text-gray-300 bg-white/[0.03] border border-white/5 rounded-lg p-3 italic">
                                "{booking.message}"
                              </p>
                            </div>
                          )}
                          {past && booking.status === 'pending' && (
                            <div className="flex items-center gap-2 px-3 py-2 bg-red-500/10 border border-red-500/20 rounded-lg mt-2">
                              <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
                              <span className="text-red-400 text-xs">This appointment date has passed and is still pending.</span>
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Right: Actions */}
                      <div className="space-y-4">
                        {/* Status Change */}
                        <div>
                          <h4 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3">Update Status</h4>
                          <div className="grid grid-cols-2 gap-2">
                            {(Object.keys(statusConfig) as TestDriveBooking['status'][]).map((status) => {
                              const cfg = statusConfig[status];
                              const Icon = cfg.icon;
                              const isActive = booking.status === status;
                              return (
                                <button
                                  key={status}
                                  onClick={() => {
                                    if (!isActive) handleStatusChange(booking.id, status);
                                  }}
                                  disabled={isActive || actionLoading === booking.id}
                                  className={`flex items-center gap-2 px-3 py-2.5 rounded-lg text-xs font-medium transition-all ${
                                    isActive
                                      ? `${cfg.bg} ${cfg.border} border ${cfg.color}`
                                      : 'bg-white/[0.03] border border-white/5 text-gray-400 hover:text-white hover:border-white/20'
                                  } disabled:opacity-50`}
                                >
                                  {actionLoading === booking.id ? (
                                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                                  ) : (
                                    <Icon className="w-3.5 h-3.5" />
                                  )}
                                  {cfg.label}
                                </button>
                              );
                            })}
                          </div>
                        </div>

                        {/* Admin Notes */}
                        <div>
                          <h4 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3 flex items-center gap-2">
                            <StickyNote className="w-3 h-3" />
                            Admin Notes
                          </h4>
                          {editingNotes === booking.id ? (
                            <div className="space-y-2">
                              <textarea
                                value={notesText}
                                onChange={(e) => setNotesText(e.target.value)}
                                rows={3}
                                placeholder="Add internal notes about this booking..."
                                className="w-full px-3 py-2 bg-black border border-white/10 rounded-lg text-white text-sm placeholder-gray-600 focus:border-neon-cyan focus:outline-none resize-none"
                              />
                              <div className="flex gap-2">
                                <button
                                  onClick={() => handleSaveNotes(booking.id)}
                                  disabled={actionLoading === booking.id}
                                  className="px-4 py-2 bg-gradient-to-r from-neon-cyan to-neon-green text-black text-xs font-bold rounded-lg hover:opacity-90 transition-opacity disabled:opacity-50 flex items-center gap-1.5"
                                >
                                  {actionLoading === booking.id ? (
                                    <Loader2 className="w-3 h-3 animate-spin" />
                                  ) : (
                                    <CheckCircle className="w-3 h-3" />
                                  )}
                                  Save
                                </button>
                                <button
                                  onClick={() => setEditingNotes(null)}
                                  className="px-4 py-2 border border-white/10 text-gray-400 text-xs rounded-lg hover:text-white transition-colors"
                                >
                                  Cancel
                                </button>
                              </div>
                            </div>
                          ) : (
                            <div
                              onClick={() => {
                                setEditingNotes(booking.id);
                                setNotesText(booking.admin_notes || '');
                              }}
                              className="min-h-[60px] px-3 py-2 bg-white/[0.02] border border-white/5 rounded-lg text-sm cursor-pointer hover:border-white/20 transition-colors"
                            >
                              {booking.admin_notes ? (
                                <p className="text-gray-300">{booking.admin_notes}</p>
                              ) : (
                                <p className="text-gray-600 italic">Click to add notes...</p>
                              )}
                            </div>
                          )}
                        </div>

                        {/* Delete */}
                        <div className="pt-2 border-t border-white/5">
                          {deleteConfirm === booking.id ? (
                            <div className="flex items-center gap-3">
                              <span className="text-red-400 text-xs font-medium">Delete this booking?</span>
                              <button
                                onClick={() => handleDelete(booking.id)}
                                disabled={actionLoading === booking.id}
                                className="px-3 py-1.5 bg-red-500 text-white text-xs font-semibold rounded-lg hover:bg-red-600 transition-colors disabled:opacity-50 flex items-center gap-1"
                              >
                                {actionLoading === booking.id ? (
                                  <Loader2 className="w-3 h-3 animate-spin" />
                                ) : (
                                  <Trash2 className="w-3 h-3" />
                                )}
                                Yes, Delete
                              </button>
                              <button
                                onClick={() => setDeleteConfirm(null)}
                                className="px-3 py-1.5 border border-white/10 text-gray-400 text-xs rounded-lg hover:text-white transition-colors"
                              >
                                Cancel
                              </button>
                            </div>
                          ) : (
                            <button
                              onClick={() => setDeleteConfirm(booking.id)}
                              className="flex items-center gap-2 text-xs text-gray-500 hover:text-red-400 transition-colors"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                              Delete Booking
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Footer count */}
      <div className="text-center py-2 text-gray-600 text-xs">
        {filtered.length} of {bookings.length} bookings shown
      </div>
    </div>
  );
};

// Helper Components
const MiniStat: React.FC<{ label: string; value: number; color: string; bg: string }> = ({
  label,
  value,
  color,
  bg,
}) => (
  <div className={`${bg} border border-white/5 rounded-xl p-3`}>
    <span className="text-gray-500 text-xs font-medium">{label}</span>
    <div className={`text-xl font-bold ${color} mt-1`}>{value}</div>
  </div>
);

const DetailRow: React.FC<{
  icon: React.ElementType;
  label: string;
  value: string;
  isLink?: boolean;
  href?: string;
  valueColor?: string;
}> = ({ icon: Icon, label, value, isLink, href, valueColor }) => (
  <div className="flex items-center gap-3 text-sm">
    <Icon className="w-3.5 h-3.5 text-gray-500 flex-shrink-0" />
    <span className="text-gray-500 w-20 flex-shrink-0">{label}</span>
    {isLink && href ? (
      <a
        href={href}
        className="text-neon-cyan hover:underline truncate"
        onClick={(e) => e.stopPropagation()}
      >
        {value}
      </a>
    ) : (
      <span className={`${valueColor || 'text-white'} truncate`}>{value}</span>
    )}
  </div>
);

export default TestDriveBookingsPanel;
