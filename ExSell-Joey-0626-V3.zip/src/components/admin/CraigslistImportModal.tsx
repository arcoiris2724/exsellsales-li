import React, { useState } from 'react';
import {
  X, Globe, Download, Loader2, CheckCircle, AlertCircle,
  Zap, Camera, Car, DollarSign, Gauge, Calendar, MapPin,
  ArrowRight, ExternalLink, RotateCcw, Info, FileText,
  Upload, AlertTriangle, RefreshCw
} from 'lucide-react';
import { Vehicle, uploadImageFromUrl } from '@/data/vehicles';
import { supabase } from '@/lib/supabase';

type ImportPhase = 'idle' | 'fetching' | 'scraping' | 'uploading' | 'reupload' | 'done' | 'error';

interface ScrapedData {
  year?: number;
  make?: string;
  model?: string;
  trim?: string;
  price?: number;
  mileage?: number;
  description?: string;
  transmission?: string;
  drivetrain?: string;
  fuelType?: string;
  engine?: string;
  bodyType?: string;
  exteriorColor?: string;
  vin?: string;
  features?: string[];
  images?: string[];
  image?: string;
  title?: string;
  imageQuality?: {
    requestedSize?: string;
    avgBytes?: number;
    smallestBytes?: number;
    largestBytes?: number;
    note?: string;
  };
}


interface CraigslistImportModalProps {
  onImportComplete: (data: Partial<Vehicle>) => void;
  onClose: () => void;
  defaultStatus?: 'available' | 'sold' | 'pending';
}


const KNOWN_MAKES = [
  'Acura', 'Alfa Romeo', 'Aston Martin', 'Audi', 'Bentley', 'BMW', 'Buick',
  'Cadillac', 'Chevrolet', 'Chevy', 'Chrysler', 'Dodge', 'Ferrari', 'Fiat', 'Ford',
  'Genesis', 'GMC', 'Honda', 'Hyundai', 'Infiniti', 'Jaguar', 'Jeep', 'Kia',
  'Lamborghini', 'Land Rover', 'Lexus', 'Lincoln', 'Lucid', 'Maserati', 'Mazda',
  'McLaren', 'Mercedes-Benz', 'Mercedes', 'Mini', 'Mitsubishi', 'Nissan', 'Polestar',
  'Pontiac', 'Porsche', 'Ram', 'Rivian', 'Rolls-Royce', 'Saab', 'Saturn', 'Scion',
  'Subaru', 'Suzuki', 'Tesla', 'Toyota', 'Volkswagen', 'VW', 'Volvo'
];

function parseTitleForMakeModel(title: string, year?: number): { make: string; model: string; trim: string } {
  let cleanTitle = title;
  if (year) {
    cleanTitle = cleanTitle.replace(new RegExp(`\\b${year}\\b`, 'g'), '');
  }
  cleanTitle = cleanTitle.replace(/\*+/g, '').replace(/[!@#$%^&*()]+/g, ' ').trim();
  const words = cleanTitle.split(/\s+/).filter(w => w.length > 0);

  let make = '';
  let model = '';
  let trim = '';

  for (let i = 0; i < words.length; i++) {
    const word = words[i];
    const matchedMake = KNOWN_MAKES.find(m => m.toLowerCase() === word.toLowerCase());
    if (matchedMake) {
      make = matchedMake === 'Chevy' ? 'Chevrolet' : matchedMake === 'VW' ? 'Volkswagen' : matchedMake;
      const remaining = words.slice(i + 1);
      if (remaining.length >= 2) {
        model = remaining[0];
        trim = remaining.slice(1).join(' ');
      } else if (remaining.length === 1) {
        model = remaining[0];
      }
      break;
    }
  }

  return { make, model, trim };
}

/**
 * Sanitize edge function response to ensure all values are plain serializable types.
 * The Deno edge function sometimes returns Response/stream objects instead of strings.
 */
function sanitizeResponse(data: any): any {
  if (data === null || data === undefined) return data;
  if (typeof data === 'string' || typeof data === 'number' || typeof data === 'boolean') return data;
  
  if (Array.isArray(data)) {
    return data
      .map(item => sanitizeResponse(item))
      .filter(item => item !== null && item !== undefined && typeof item !== 'function');
  }
  
  if (typeof data === 'object') {
    // Skip non-plain objects (Response, ReadableStream, etc.)
    if (data.constructor && data.constructor.name !== 'Object' && data.constructor.name !== 'Array') {
      // Try to get a string representation
      try {
        if (typeof data.toString === 'function') {
          const str = data.toString();
          if (str !== '[object Object]' && str !== '[object Response]') return str;
        }
      } catch {}
      return null;
    }
    
    const result: Record<string, any> = {};
    for (const [key, value] of Object.entries(data)) {
      if (typeof value !== 'function') {
        result[key] = sanitizeResponse(value);
      }
    }
    return result;
  }
  
  // Skip functions and other non-serializable types
  if (typeof data === 'function') return null;
  
  return data;
}

/**
 * Extract valid string URLs from an array, filtering out non-string values.
 */
function extractValidUrls(arr: any[]): string[] {
  if (!Array.isArray(arr)) return [];
  return arr.filter(item => typeof item === 'string' && (item.startsWith('http://') || item.startsWith('https://')));
}

const CraigslistImportModal: React.FC<CraigslistImportModalProps> = ({ onImportComplete, onClose, defaultStatus = 'available' }) => {

  const [url, setUrl] = useState('');
  const [phase, setPhase] = useState<ImportPhase>('idle');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [scrapedData, setScrapedData] = useState<ScrapedData | null>(null);
  const [totalFound, setTotalFound] = useState(0);
  const [totalUploaded, setTotalUploaded] = useState(0);
  const [scrapeErrors, setScrapeErrors] = useState<string[]>([]);
  const [reuploadProgress, setReuploadProgress] = useState({ current: 0, total: 0 });
  const [usedOriginalUrls, setUsedOriginalUrls] = useState(false);

  const isImporting = ['fetching', 'scraping', 'uploading', 'reupload'].includes(phase);

  /**
   * Attempt to re-upload images from original Craigslist URLs via the browser.
   * Falls back to using original URLs directly if upload fails.
   */
  const reuploadImagesFromBrowser = async (originalUrls: string[]): Promise<{ uploaded: string[]; failed: string[]; usedOriginals: boolean }> => {
    const uploaded: string[] = [];
    const failed: string[] = [];
    let usedOriginals = false;

    setReuploadProgress({ current: 0, total: originalUrls.length });

    // Try uploading each image from the browser
    for (let i = 0; i < originalUrls.length; i++) {
      setReuploadProgress({ current: i + 1, total: originalUrls.length });
      
      try {
        const storageUrl = await uploadImageFromUrl(originalUrls[i]);
        uploaded.push(storageUrl);
      } catch (err: any) {
        console.warn(`Frontend upload failed for image ${i + 1}:`, err.message);
        failed.push(originalUrls[i]);
      }
    }

    // If most uploads failed, fall back to using original URLs directly
    if (uploaded.length === 0 && originalUrls.length > 0) {
      console.log('All frontend uploads failed, using original Craigslist URLs directly');
      usedOriginals = true;
      return { uploaded: originalUrls, failed: [], usedOriginals: true };
    }

    // If some failed, add original URLs for the failed ones
    if (failed.length > 0 && uploaded.length > 0) {
      // Use original URLs for the ones that failed
      return { uploaded: [...uploaded, ...failed], failed: [], usedOriginals: failed.length > 0 };
    }

    return { uploaded, failed, usedOriginals };
  };

  const handleImport = async () => {
    if (!url.trim()) {
      setError('Please enter a Craigslist listing URL');
      return;
    }

    const urlLower = url.toLowerCase();
    if (!urlLower.includes('craigslist.org')) {
      setError('Please enter a valid Craigslist URL (e.g., https://city.craigslist.org/cto/d/...)');
      return;
    }

    setError('');
    setScrapedData(null);
    setPhase('fetching');
    setMessage('Connecting to Craigslist...');
    setUsedOriginalUrls(false);

    try {
      await new Promise(r => setTimeout(r, 400));
      setPhase('scraping');
      setMessage('Scraping listing for vehicle data & images...');

      const { data, error: fnError } = await supabase.functions.invoke('scrape-craigslist', {
        body: { url: url.trim() },
      });

      if (fnError) {
        throw new Error(fnError.message || 'Failed to connect to scraping service');
      }

      // Sanitize the response to handle non-serializable values
      const cleanData = sanitizeResponse(data) || {};
      console.log('Sanitized scrape response:', cleanData);

      if (cleanData?.error && (!cleanData?.images || cleanData.images.length === 0) && 
          (!cleanData?.originalImages || cleanData.originalImages.length === 0) &&
          (!cleanData?.sourceUrls || cleanData.sourceUrls.length === 0)) {
        throw new Error(cleanData.error);
      }

      // Extract images - check multiple possible fields
      let images: string[] = extractValidUrls(cleanData?.images || []);
      const metadata = cleanData?.metadata || {};
      const found = cleanData?.totalFound || 0;
      const uploaded = cleanData?.totalUploaded || 0;
      const errors: string[] = (cleanData?.errors || []).filter((e: any) => typeof e === 'string');
      const imageQuality = cleanData?.imageQuality || null;


      // Check for original/source image URLs as fallback
      const originalImages: string[] = extractValidUrls(
        cleanData?.originalImages || cleanData?.sourceUrls || cleanData?.scrapedUrls || cleanData?.imageUrls || []
      );

      setTotalFound(found || originalImages.length || images.length);
      setTotalUploaded(uploaded);
      setScrapeErrors(errors);

      // If edge function failed to upload images but we have original URLs, try frontend re-upload
      const edgeUploadFailed = (images.length === 0 && errors.length > 0) || 
                                (images.length === 0 && originalImages.length > 0);
      
      if (edgeUploadFailed && originalImages.length > 0) {
        setPhase('reupload');
        setMessage(`Edge function upload failed. Re-uploading ${originalImages.length} images from browser...`);
        
        const result = await reuploadImagesFromBrowser(originalImages);
        images = result.uploaded;
        setUsedOriginalUrls(result.usedOriginals);
        setScrapeErrors([]); // Clear edge function errors since we handled them
        setTotalUploaded(images.length);
      } else if (images.length === 0 && originalImages.length === 0 && found > 0) {
        // Edge function found images but couldn't process them and didn't return original URLs
        // This is the "decodeText could not be cloned" scenario
        setPhase('uploading');
        setMessage(`Edge function had issues with ${found} images. Vehicle data was still extracted.`);
        setScrapeErrors([`${found} images found but could not be processed by the server. You can add images manually after saving.`]);
        await new Promise(r => setTimeout(r, 500));
      } else {
        setPhase('uploading');
        setMessage(`Processing ${found} images...`);
        await new Promise(r => setTimeout(r, 500));
      }

      // Build scraped data object
      const result: ScrapedData = {};

      if (metadata.year) result.year = metadata.year;
      if (metadata.price) result.price = metadata.price;
      if (metadata.mileage) result.mileage = metadata.mileage;
      if (metadata.description) result.description = metadata.description;
      if (metadata.transmission) result.transmission = metadata.transmission;
      if (metadata.drivetrain) result.drivetrain = metadata.drivetrain;
      if (metadata.fuelType) result.fuelType = metadata.fuelType;
      if (metadata.engine) result.engine = metadata.engine;
      if (metadata.bodyType) result.bodyType = metadata.bodyType;
      if (metadata.exteriorColor) result.exteriorColor = metadata.exteriorColor;
      if (metadata.vin) result.vin = metadata.vin;
      if (metadata.features && Array.isArray(metadata.features) && metadata.features.length > 0) {
        result.features = metadata.features.filter((f: any) => typeof f === 'string');
      }
      if (metadata.title && typeof metadata.title === 'string') result.title = metadata.title;

      // Parse title for make/model
      if (metadata.title) {
        const parsed = parseTitleForMakeModel(metadata.title, metadata.year);
        if (parsed.make) result.make = parsed.make;
        if (parsed.model) result.model = parsed.model;
        if (parsed.trim) result.trim = parsed.trim;
      }

      if (images.length > 0) {
        result.images = images;
        result.image = images[0];
      }

      if (imageQuality) {
        result.imageQuality = imageQuality;
      }

      setScrapedData(result);
      setPhase('done');
      
      if (images.length > 0) {
        setMessage(`Successfully scraped ${images.length} photos and vehicle details!`);
      } else {
        setMessage(`Vehicle details scraped successfully! Images can be added manually.`);
      }


    } catch (err: any) {
      console.error('Craigslist import error:', err);
      setPhase('error');
      setMessage(err.message || 'Failed to import from Craigslist');
      setScrapeErrors([err.message]);
    }
  };

  const handleContinue = () => {
    if (!scrapedData) return;

    const today = new Date().toISOString().split('T')[0];
    const vehicleData: Partial<Vehicle> = {
      year: scrapedData.year || new Date().getFullYear(),
      make: scrapedData.make || '',
      model: scrapedData.model || '',
      trim: scrapedData.trim || '',
      price: scrapedData.price || 0,
      mileage: scrapedData.mileage || 0,
      description: scrapedData.description || '',
      transmission: scrapedData.transmission || 'Automatic',
      drivetrain: scrapedData.drivetrain || 'FWD',
      fuelType: scrapedData.fuelType || 'Gasoline',
      engine: scrapedData.engine || '',
      bodyType: scrapedData.bodyType || 'Sedan',
      exteriorColor: scrapedData.exteriorColor || '',
      vin: scrapedData.vin || '',
      features: scrapedData.features || [],
      images: scrapedData.images || [],
      image: scrapedData.image || '',
      status: defaultStatus as Vehicle['status'],
      ...(defaultStatus === 'sold' ? { soldDate: today, soldPrice: scrapedData.price || 0 } : {}),
    };

    onImportComplete(vehicleData);
  };


  const handleReset = () => {
    setPhase('idle');
    setMessage('');
    setError('');
    setScrapedData(null);
    setUrl('');
    setTotalFound(0);
    setTotalUploaded(0);
    setScrapeErrors([]);
    setReuploadProgress({ current: 0, total: 0 });
    setUsedOriginalUrls(false);
  };

  const progressPercent = phase === 'fetching' ? 20 
    : phase === 'scraping' ? 50 
    : phase === 'uploading' ? 80 
    : phase === 'reupload' ? (reuploadProgress.total > 0 ? 50 + Math.round((reuploadProgress.current / reuploadProgress.total) * 50) : 70)
    : phase === 'done' ? 100 
    : 0;

  // Count how many fields were scraped
  const scrapedFieldCount = scrapedData ? Object.entries(scrapedData).filter(([k, v]) => {
    if (k === 'title') return false;
    if (Array.isArray(v)) return v.length > 0;
    return v !== undefined && v !== null && v !== '' && v !== 0;
  }).length : 0;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div className="fixed inset-0 bg-black/80 backdrop-blur-sm" onClick={!isImporting ? onClose : undefined} />

      <div className="relative w-full max-w-2xl bg-[#111111] rounded-2xl border border-white/10 shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-purple-600/20 via-blue-600/10 to-transparent" />
          <div className="relative flex items-center justify-between p-6 pb-5">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center shadow-lg shadow-purple-500/30">
                <Globe className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  Import from Craigslist
                  <span className="px-2 py-0.5 bg-purple-500/20 text-purple-300 text-[10px] font-bold rounded-full uppercase tracking-wider">Auto</span>
                </h2>
                <p className="text-sm text-gray-400 mt-0.5">
                  Scrape vehicle details & photos from any Craigslist listing
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              disabled={isImporting}
              className="p-2 rounded-lg text-gray-400 hover:text-white hover:bg-white/5 transition-colors disabled:opacity-50"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="p-6 pt-2 space-y-5">
          {/* URL Input */}
          {phase === 'idle' || phase === 'error' ? (
            <>
              <div className="space-y-3">
                <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider">
                  Craigslist Listing URL
                </label>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <Globe className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                    <input
                      type="text"
                      value={url}
                      onChange={(e) => { setUrl(e.target.value); setError(''); }}
                      placeholder="https://city.craigslist.org/cto/d/vehicle-title/1234567890.html"
                      autoFocus
                      onKeyDown={(e) => { if (e.key === 'Enter') handleImport(); }}
                      className="w-full pl-11 pr-4 py-3.5 bg-black/60 border border-white/10 rounded-xl text-white text-sm placeholder-gray-600 focus:border-purple-400 focus:outline-none focus:ring-1 focus:ring-purple-400/30 transition-all"
                    />
                  </div>
                  <button
                    onClick={handleImport}
                    disabled={!url.trim()}
                    className="flex items-center gap-2 px-6 py-3.5 bg-gradient-to-r from-purple-500 to-blue-500 text-white font-bold rounded-xl hover:opacity-90 transition-all disabled:opacity-40 disabled:cursor-not-allowed flex-shrink-0 shadow-lg shadow-purple-500/20"
                  >
                    <Download className="w-4 h-4" />
                    Scrape
                  </button>
                </div>

                {error && (
                  <div className="flex items-center gap-2 px-4 py-3 bg-red-500/10 border border-red-500/20 rounded-xl">
                    <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
                    <p className="text-red-400 text-sm">{error}</p>
                  </div>
                )}

                {phase === 'error' && (
                  <div className="space-y-3">
                    <div className="flex items-start gap-3 p-4 bg-red-500/10 border border-red-500/20 rounded-xl">
                      <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
                      <div className="flex-1">
                        <p className="text-red-300 text-sm font-semibold">Import Failed</p>
                        <p className="text-red-400/70 text-xs mt-1">{message}</p>
                      </div>
                    </div>
                    <div className="flex gap-3">
                      <button
                        onClick={handleImport}
                        className="text-sm text-purple-400 hover:text-purple-300 transition-colors flex items-center gap-1.5 font-medium"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        Try Again
                      </button>
                      <button
                        onClick={handleReset}
                        className="text-sm text-gray-500 hover:text-white transition-colors"
                      >
                        Clear
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* How it works */}
              {phase === 'idle' && (
                <div className="p-4 bg-white/[0.02] border border-white/5 rounded-xl space-y-3">
                  <div className="flex items-center gap-2 text-xs font-semibold text-gray-400 uppercase tracking-wider">
                    <Info className="w-3.5 h-3.5" />
                    How it works
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <StepCard
                      number={1}
                      title="Paste URL"
                      desc="Copy any Craigslist vehicle listing URL"
                      icon={Globe}
                    />
                    <StepCard
                      number={2}
                      title="Auto-Scrape"
                      desc="We extract all photos, price, specs & details"
                      icon={Zap}
                    />
                    <StepCard
                      number={3}
                      title="Review & Save"
                      desc="Edit the pre-filled form and add to inventory"
                      icon={Car}
                    />
                  </div>
                  <p className="text-[11px] text-gray-600 flex items-start gap-1.5">
                    <Zap className="w-3 h-3 text-purple-400/40 flex-shrink-0 mt-0.5" />
                    Supports all Craigslist vehicle listings. Photos are automatically uploaded to your storage. Vehicle details like year, make, model, price, mileage, and description are auto-extracted.
                  </p>
                </div>
              )}
            </>
          ) : null}

          {/* Progress State */}
          {isImporting && (
            <div className="space-y-5 py-4">
              {/* Animated icon */}
              <div className="flex justify-center">
                <div className="relative">
                  <div className="absolute -inset-4 bg-gradient-to-br from-purple-500/20 to-blue-500/20 rounded-full blur-xl animate-pulse" />
                  <div className="relative w-20 h-20 rounded-2xl bg-gradient-to-br from-purple-500/20 to-blue-500/20 border border-purple-500/30 flex items-center justify-center">
                    {phase === 'reupload' ? (
                      <Upload className="w-10 h-10 text-purple-400 animate-bounce" />
                    ) : (
                      <Loader2 className="w-10 h-10 text-purple-400 animate-spin" />
                    )}
                  </div>
                </div>
              </div>

              {/* Progress bar */}
              <div className="space-y-3">
                <div className="h-2 bg-black/40 rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-1000 ease-out"
                    style={{
                      width: `${progressPercent}%`,
                      background: phase === 'reupload' 
                        ? 'linear-gradient(90deg, #f59e0b, #ef4444)' 
                        : 'linear-gradient(90deg, #a855f7, #3b82f6)',
                    }}
                  />
                </div>
                <p className="text-center text-sm text-purple-300 font-medium">{message}</p>
                {phase === 'reupload' && reuploadProgress.total > 0 && (
                  <p className="text-center text-xs text-amber-400/70">
                    Uploading image {reuploadProgress.current} of {reuploadProgress.total} from browser...
                  </p>
                )}
              </div>

              {/* Phase steps */}
              <div className="flex items-center justify-center gap-2">
                <PhaseStep label="Connect" active={phase === 'fetching'} done={['scraping', 'uploading', 'reupload'].includes(phase)} />
                <div className="w-6 h-px bg-white/10" />
                <PhaseStep label="Scrape" active={phase === 'scraping'} done={['uploading', 'reupload'].includes(phase)} />
                <div className="w-6 h-px bg-white/10" />
                <PhaseStep label={phase === 'reupload' ? 'Re-upload' : 'Upload'} active={phase === 'uploading' || phase === 'reupload'} done={false} />
              </div>

              {/* Re-upload explanation */}
              {phase === 'reupload' && (
                <div className="flex items-start gap-2 p-3 bg-amber-500/5 border border-amber-500/20 rounded-xl">
                  <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                  <p className="text-xs text-amber-400/80">
                    Server-side image upload encountered an error. Re-uploading images directly from your browser instead...
                  </p>
                </div>
              )}
            </div>
          )}

          {/* Success State */}
          {phase === 'done' && scrapedData && (
            <div className="space-y-4">
              {/* Success banner */}
              <div className="flex items-start gap-3 p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-xl">
                <CheckCircle className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
                <div className="flex-1">
                  <p className="text-emerald-300 text-sm font-bold">Scrape Successful!</p>
                  <p className="text-emerald-400/70 text-xs mt-1">{message}</p>
                </div>
              </div>

              {/* Info about using original URLs */}
              {usedOriginalUrls && (
                <div className="flex items-start gap-2 p-3 bg-amber-500/5 border border-amber-500/20 rounded-xl">
                  <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                  <p className="text-xs text-amber-400/80">
                    Images are linked from Craigslist directly. They may expire when the listing is removed. 
                    You can re-upload them from the vehicle form after saving.
                  </p>
                </div>
              )}

              {/* Scraped data preview */}
              <div className="p-4 bg-white/[0.02] border border-white/5 rounded-xl space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-white">Scraped Vehicle Data</h3>
                  <span className="text-xs text-purple-300 font-medium">{scrapedFieldCount} fields extracted</span>
                </div>

                {/* Vehicle title/summary */}
                {(scrapedData.year || scrapedData.make || scrapedData.model) && (
                  <div className="flex items-center gap-3 p-3 bg-black/40 rounded-lg">
                    {scrapedData.image ? (
                      <img src={scrapedData.image} alt="Vehicle" className="w-20 h-14 rounded-lg object-cover flex-shrink-0" />
                    ) : (
                      <div className="w-20 h-14 rounded-lg bg-gray-800 flex items-center justify-center flex-shrink-0">
                        <Car className="w-6 h-6 text-gray-600" />
                      </div>
                    )}
                    <div>
                      <p className="text-white font-bold text-sm">
                        {scrapedData.year || ''} {scrapedData.make || ''} {scrapedData.model || ''} {scrapedData.trim || ''}
                      </p>
                      <div className="flex items-center gap-3 mt-1">
                        {scrapedData.price ? (
                          <span className="text-neon-orange font-bold text-xs flex items-center gap-1">
                            <DollarSign className="w-3 h-3" />
                            {scrapedData.price.toLocaleString()}
                          </span>
                        ) : null}
                        {scrapedData.mileage ? (
                          <span className="text-gray-400 text-xs flex items-center gap-1">
                            <Gauge className="w-3 h-3" />
                            {scrapedData.mileage.toLocaleString()} mi
                          </span>
                        ) : null}
                        {scrapedData.year ? (
                          <span className="text-gray-400 text-xs flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            {scrapedData.year}
                          </span>
                        ) : null}
                      </div>
                    </div>
                  </div>
                )}

                {/* Extracted fields grid */}
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {scrapedData.make && <DataChip label="Make" value={scrapedData.make} />}
                  {scrapedData.model && <DataChip label="Model" value={scrapedData.model} />}
                  {scrapedData.trim && <DataChip label="Trim" value={scrapedData.trim} />}
                  {scrapedData.year && <DataChip label="Year" value={String(scrapedData.year)} />}
                  {scrapedData.price && <DataChip label="Price" value={`$${scrapedData.price.toLocaleString()}`} />}
                  {scrapedData.mileage && <DataChip label="Mileage" value={`${scrapedData.mileage.toLocaleString()} mi`} />}
                  {scrapedData.transmission && <DataChip label="Transmission" value={scrapedData.transmission} />}
                  {scrapedData.drivetrain && <DataChip label="Drivetrain" value={scrapedData.drivetrain} />}
                  {scrapedData.fuelType && <DataChip label="Fuel Type" value={scrapedData.fuelType} />}
                  {scrapedData.engine && <DataChip label="Engine" value={scrapedData.engine} />}
                  {scrapedData.bodyType && <DataChip label="Body Type" value={scrapedData.bodyType} />}
                  {scrapedData.exteriorColor && <DataChip label="Color" value={scrapedData.exteriorColor} />}
                  {scrapedData.vin && <DataChip label="VIN" value={scrapedData.vin} />}
                </div>

                {/* Description preview */}
                {scrapedData.description && (
                  <div className="p-3 bg-black/30 rounded-lg">
                    <div className="flex items-center gap-1.5 mb-1.5">
                      <FileText className="w-3.5 h-3.5 text-gray-500" />
                      <span className="text-[11px] text-gray-500 font-medium uppercase tracking-wider">Description</span>
                    </div>
                    <p className="text-xs text-gray-300 line-clamp-3 leading-relaxed">{scrapedData.description}</p>
                  </div>
                )}

                {/* Features */}
                {scrapedData.features && scrapedData.features.length > 0 && (
                  <div>
                    <span className="text-[11px] text-gray-500 font-medium uppercase tracking-wider">
                      {scrapedData.features.length} Features
                    </span>
                    <div className="flex flex-wrap gap-1.5 mt-1.5">
                      {scrapedData.features.slice(0, 10).map((f, i) => (
                        <span key={i} className="px-2 py-0.5 bg-white/[0.04] border border-white/10 rounded text-[11px] text-gray-400">
                          {f}
                        </span>
                      ))}
                      {scrapedData.features.length > 10 && (
                        <span className="px-2 py-0.5 text-[11px] text-gray-600">
                          +{scrapedData.features.length - 10} more
                        </span>
                      )}
                    </div>
                  </div>
                )}

                {/* Photos preview */}
                {scrapedData.images && scrapedData.images.length > 0 && (
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-[11px] text-gray-500 font-medium uppercase tracking-wider flex items-center gap-1.5">
                        <Camera className="w-3.5 h-3.5" />
                        {scrapedData.images.length} Photos Imported
                      </span>
                      <div className="flex items-center gap-2">
                        {scrapedData.imageQuality?.requestedSize && (
                          <span className="text-[11px] text-emerald-400/80 flex items-center gap-1 font-medium">
                            <CheckCircle className="w-3 h-3" />
                            {scrapedData.imageQuality.requestedSize}
                            {scrapedData.imageQuality.avgBytes ? (
                              <span className="text-gray-500 ml-1">
                                · avg {Math.round(scrapedData.imageQuality.avgBytes / 1024)} KB
                              </span>
                            ) : null}
                          </span>
                        )}
                        {usedOriginalUrls && (
                          <span className="text-[11px] text-amber-400/60 flex items-center gap-1">
                            <AlertTriangle className="w-3 h-3" />
                            External links
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="flex gap-1.5 overflow-x-auto pb-1">
                      {scrapedData.images.slice(0, 10).map((imgUrl, i) => (
                        <div key={i} className="w-20 h-14 rounded-lg overflow-hidden flex-shrink-0 border border-white/10">
                          <img src={imgUrl} alt={`Photo ${i + 1}`} className="w-full h-full object-cover" />
                        </div>
                      ))}
                      {scrapedData.images.length > 10 && (
                        <div className="w-20 h-14 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center flex-shrink-0">
                          <span className="text-[11px] text-gray-400 font-bold">+{scrapedData.images.length - 10}</span>
                        </div>
                      )}
                    </div>
                    {/* Image quality notice */}
                    <div className="mt-2 flex items-start gap-1.5 text-[10px] text-gray-500 leading-relaxed">
                      <Info className="w-3 h-3 flex-shrink-0 mt-0.5" />
                      <span>
                        Craigslist caps public image resolution at <strong className="text-gray-400">1200×900 px</strong> — this is the highest quality available from their servers. 
                        No further compression is applied on our end. For sharper photos, retake them with a higher-resolution camera and upload directly.
                      </span>
                    </div>
                  </div>
                )}


                {/* No images warning */}
                {(!scrapedData.images || scrapedData.images.length === 0) && (
                  <div className="flex items-start gap-2 p-3 bg-amber-500/5 border border-amber-500/20 rounded-lg">
                    <Camera className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-xs text-amber-400 font-medium">No images imported</p>
                      <p className="text-[11px] text-amber-400/60 mt-0.5">
                        You can upload photos manually after saving the vehicle details.
                      </p>
                    </div>
                  </div>
                )}

                {/* Scrape errors (only show meaningful ones) */}
                {scrapeErrors.length > 0 && !scrapeErrors[0].includes('decodeText') && (
                  <div className="p-3 bg-amber-500/5 border border-amber-500/20 rounded-lg">
                    <p className="text-xs text-amber-400 font-medium">
                      {scrapeErrors.length} note(s):
                    </p>
                    <div className="max-h-16 overflow-y-auto mt-1">
                      {scrapeErrors.slice(0, 3).map((err, i) => (
                        <p key={i} className="text-[11px] text-amber-400/60 truncate">{err}</p>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Action buttons */}
              <div className="flex gap-3">
                <button
                  onClick={handleReset}
                  className="flex-shrink-0 px-4 py-3 border border-white/10 text-gray-400 font-medium rounded-xl hover:bg-white/5 transition-colors text-sm flex items-center gap-2"
                >
                  <RotateCcw className="w-4 h-4" />
                  Import Another
                </button>
                <button
                  onClick={handleContinue}
                  className="flex-1 py-3 bg-gradient-to-r from-purple-500 to-blue-500 text-white font-bold rounded-xl hover:opacity-90 transition-all shadow-lg shadow-purple-500/20 flex items-center justify-center gap-2 text-sm"
                >
                  Continue to Add Vehicle
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer hint for idle state */}
        {phase === 'idle' && (
          <div className="px-6 py-3 border-t border-white/5 bg-white/[0.01]">
            <p className="text-[11px] text-gray-600 text-center flex items-center justify-center gap-1.5">
              <ExternalLink className="w-3 h-3" />
              Tip: Open Craigslist, find a vehicle listing, copy the full URL from your browser's address bar
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

// Sub-components
const StepCard: React.FC<{ number: number; title: string; desc: string; icon: React.ElementType }> = ({ number, title, desc, icon: Icon }) => (
  <div className="p-3 bg-black/30 rounded-lg border border-white/5">
    <div className="flex items-center gap-2 mb-1.5">
      <div className="w-5 h-5 rounded-full bg-purple-500/20 text-purple-300 text-[10px] font-bold flex items-center justify-center">
        {number}
      </div>
      <Icon className="w-3.5 h-3.5 text-purple-400" />
    </div>
    <p className="text-xs font-semibold text-white">{title}</p>
    <p className="text-[11px] text-gray-500 mt-0.5 leading-relaxed">{desc}</p>
  </div>
);

const PhaseStep: React.FC<{ label: string; active: boolean; done: boolean }> = ({ label, active, done }) => (
  <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md transition-colors text-xs ${
    active ? 'bg-purple-500/20 text-purple-300' :
    done ? 'bg-emerald-500/10 text-emerald-400' :
    'text-gray-600'
  }`}>
    {done ? (
      <CheckCircle className="w-3 h-3" />
    ) : active ? (
      <Loader2 className="w-3 h-3 animate-spin" />
    ) : (
      <div className="w-3 h-3 rounded-full border border-current opacity-40" />
    )}
    <span className="font-medium">{label}</span>
  </div>
);

const DataChip: React.FC<{ label: string; value: string }> = ({ label, value }) => (
  <div className="px-3 py-2 bg-black/30 rounded-lg border border-white/5">
    <span className="text-[10px] text-gray-500 uppercase tracking-wider block">{label}</span>
    <span className="text-xs text-white font-medium mt-0.5 block truncate">{value}</span>
  </div>
);

export default CraigslistImportModal;
