import React, { useEffect, useMemo, useState, useCallback } from 'react';
import {
  BarChart, Bar, LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer,
  CartesianGrid, Legend, ComposedChart,
} from 'recharts';
import {
  TrendingUp, Inbox, UserCheck, Archive, Clock, Car as CarIcon,
  Loader2, RefreshCw, Target, Zap, CheckCircle2, Trophy,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Vehicle } from '@/data/vehicles';
import { fetchVehicles } from '@/data/vehicles';

/**
 * LeadFunnelChart — admin analytics card showing the VDP lead funnel.
 *
 * Metrics:
 *   - Total inquiries / week (bar chart, last 8 ISO weeks)
 *   - Conversion rate: new → contacted → closed (with 'sold' vehicles as
 *     the closed-won signal)
 *   - Average response time (first_response_at − created_at), shown
 *     alongside the weekly bars as a line
 *   - Top 5 vehicles driving inquiries (derived from vehicle_interest
 *     "(#id)" tokens produced by the VDP lead form)
 */

interface LeadRow {
  id: string;
  status: string;
  lead_type: string | null;
  vehicle_interest: string | null;
  created_at: string;
  first_response_at: string | null;
}

function parseVehicleId(raw: string | null | undefined): number | null {
  if (!raw) return null;
  const m = raw.match(/\(#(\d+)\)\s*$/);
  if (!m) return null;
  const n = Number(m[1]);
  return Number.isFinite(n) ? n : null;
}

function parseVehicleLabel(raw: string | null | undefined): string {
  if (!raw) return '';
  return raw.replace(/\s*\(#\d+\)\s*$/, '').trim();
}

// ISO-week key "YYYY-Www" (Monday-based); good enough for a dashboard.
function weekKey(d: Date): { key: string; start: Date } {
  const date = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()));
  const dayNum = date.getUTCDay() || 7; // Mon=1..Sun=7
  date.setUTCDate(date.getUTCDate() + 4 - dayNum); // Thursday in current week
  const yearStart = new Date(Date.UTC(date.getUTCFullYear(), 0, 1));
  const weekNo = Math.ceil(((+date - +yearStart) / 86400000 + 1) / 7);
  const key = `${date.getUTCFullYear()}-W${String(weekNo).padStart(2, '0')}`;
  // Compute start-of-week (Monday) for labeling
  const monday = new Date(d);
  const diff = ((d.getDay() || 7) - 1);
  monday.setDate(d.getDate() - diff);
  monday.setHours(0, 0, 0, 0);
  return { key, start: monday };
}

function formatDuration(seconds: number): string {
  if (!Number.isFinite(seconds) || seconds <= 0) return '—';
  if (seconds < 60) return `${Math.round(seconds)}s`;
  const mins = seconds / 60;
  if (mins < 60) return `${Math.round(mins)}m`;
  const hrs = mins / 60;
  if (hrs < 48) return `${hrs.toFixed(1)}h`;
  return `${(hrs / 24).toFixed(1)}d`;
}

const LeadFunnelChart: React.FC = () => {
  const [leads, setLeads] = useState<LeadRow[]>([]);
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [{ data: leadRows }, vehs] = await Promise.all([
        supabase
          .from('leads')
          .select('id, status, lead_type, vehicle_interest, created_at, first_response_at')
          .order('created_at', { ascending: false }),
        fetchVehicles().catch(() => [] as Vehicle[]),
      ]);
      setLeads((leadRows || []) as LeadRow[]);
      setVehicles(vehs);
    } catch (err) {
      console.warn('LeadFunnelChart load failed:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  // ── Weekly bar data (last 8 weeks) ──
  const weeklyData = useMemo(() => {
    const now = new Date();
    const buckets: { key: string; label: string; start: Date; total: number; responseSecs: number[] }[] = [];
    for (let i = 7; i >= 0; i--) {
      const d = new Date(now);
      d.setDate(d.getDate() - i * 7);
      const { key, start } = weekKey(d);
      if (!buckets.find((b) => b.key === key)) {
        buckets.push({
          key,
          label: start.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
          start,
          total: 0,
          responseSecs: [],
        });
      }
    }

    leads.forEach((l) => {
      const created = new Date(l.created_at);
      const { key } = weekKey(created);
      const bucket = buckets.find((b) => b.key === key);
      if (!bucket) return;
      bucket.total += 1;
      if (l.first_response_at) {
        const diff = (new Date(l.first_response_at).getTime() - created.getTime()) / 1000;
        if (Number.isFinite(diff) && diff > 0) bucket.responseSecs.push(diff);
      }
    });

    return buckets.map((b) => ({
      week: b.label,
      inquiries: b.total,
      avgResponseHrs:
        b.responseSecs.length > 0
          ? +(b.responseSecs.reduce((s, v) => s + v, 0) / b.responseSecs.length / 3600).toFixed(2)
          : 0,
    }));
  }, [leads]);

  // ── Funnel counts ──
  const funnel = useMemo(() => {
    const total = leads.length;
    const contacted = leads.filter(
      (l) => l.status === 'contacted' || l.status === 'closed' || l.first_response_at,
    ).length;
    const closed = leads.filter((l) => l.status === 'closed').length;

    // Closed-won signal: leads whose referenced vehicle is now 'sold'.
    const soldIds = new Set(
      vehicles.filter((v) => v.status === 'sold').map((v) => v.id),
    );
    const closedWon = leads.filter((l) => {
      const vid = parseVehicleId(l.vehicle_interest);
      return vid !== null && soldIds.has(vid);
    }).length;

    return { total, contacted, closed, closedWon };
  }, [leads, vehicles]);

  // ── Average response time (global) ──
  const avgResponseSecs = useMemo(() => {
    const secs: number[] = [];
    leads.forEach((l) => {
      if (!l.first_response_at) return;
      const diff = (new Date(l.first_response_at).getTime() - new Date(l.created_at).getTime()) / 1000;
      if (Number.isFinite(diff) && diff > 0) secs.push(diff);
    });
    if (secs.length === 0) return 0;
    return secs.reduce((s, v) => s + v, 0) / secs.length;
  }, [leads]);

  // ── Top 5 vehicles driving inquiries ──
  const topVehicles = useMemo(() => {
    const counts = new Map<number, { id: number; label: string; count: number }>();
    leads.forEach((l) => {
      const vid = parseVehicleId(l.vehicle_interest);
      if (vid === null) return;
      const label = parseVehicleLabel(l.vehicle_interest) || `Vehicle #${vid}`;
      const existing = counts.get(vid);
      if (existing) {
        existing.count += 1;
      } else {
        counts.set(vid, { id: vid, label, count: 1 });
      }
    });
    return Array.from(counts.values())
      .sort((a, b) => b.count - a.count)
      .slice(0, 5)
      .map((row) => {
        const v = vehicles.find((vv) => vv.id === row.id);
        return {
          ...row,
          label: v ? `${v.year} ${v.make} ${v.model}` : row.label,
          status: v?.status ?? null,
          price: v?.price ?? null,
          image: v?.image ?? null,
        };
      });
  }, [leads, vehicles]);

  // Funnel conversion rates
  const pctContacted = funnel.total > 0 ? (funnel.contacted / funnel.total) * 100 : 0;
  const pctClosed = funnel.total > 0 ? (funnel.closed / funnel.total) * 100 : 0;
  const pctWon = funnel.total > 0 ? (funnel.closedWon / funnel.total) * 100 : 0;

  if (loading && leads.length === 0) {
    return (
      <div className="flex items-center justify-center py-16">
        <Loader2 className="w-6 h-6 text-neon-pink animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header + refresh */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-neon-cyan" />
            Lead Funnel Analytics
          </h2>
          <p className="text-xs text-gray-500 mt-0.5">
            VDP inquiry performance over the last 8 weeks
          </p>
        </div>
        <button
          onClick={load}
          disabled={loading}
          className="p-2 bg-white/[0.03] border border-white/10 rounded-lg text-gray-400 hover:text-white transition-colors"
          title="Refresh"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {/* Funnel stage cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <FunnelStage
          icon={Inbox}
          label="Inquiries"
          value={funnel.total}
          pct={100}
          color="text-neon-cyan"
          bg="bg-neon-cyan/5"
          border="border-neon-cyan/20"
          sublabel="Total leads"
        />
        <FunnelStage
          icon={UserCheck}
          label="Contacted"
          value={funnel.contacted}
          pct={pctContacted}
          color="text-amber-400"
          bg="bg-amber-400/5"
          border="border-amber-400/20"
          sublabel={`${pctContacted.toFixed(0)}% response rate`}
        />
        <FunnelStage
          icon={Archive}
          label="Closed"
          value={funnel.closed}
          pct={pctClosed}
          color="text-gray-300"
          bg="bg-white/5"
          border="border-white/10"
          sublabel={`${pctClosed.toFixed(0)}% of inquiries`}
        />
        <FunnelStage
          icon={Trophy}
          label="Closed–Won"
          value={funnel.closedWon}
          pct={pctWon}
          color="text-neon-green"
          bg="bg-neon-green/5"
          border="border-neon-green/20"
          sublabel="Vehicle now sold"
        />
      </div>

      {/* Avg response + conversion rate row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div className="bg-white/[0.02] border border-white/5 rounded-xl p-4">
          <div className="flex items-center gap-2 text-xs text-gray-500 mb-2">
            <Clock className="w-3.5 h-3.5" />
            Avg Response Time
          </div>
          <div className="text-2xl font-bold text-neon-pink">
            {formatDuration(avgResponseSecs)}
          </div>
          <div className="text-[11px] text-gray-600 mt-1">
            Across {leads.filter((l) => l.first_response_at).length} replies
          </div>
        </div>

        <div className="bg-white/[0.02] border border-white/5 rounded-xl p-4">
          <div className="flex items-center gap-2 text-xs text-gray-500 mb-2">
            <Target className="w-3.5 h-3.5" />
            Inquiry → Contacted
          </div>
          <div className="text-2xl font-bold text-amber-400">
            {pctContacted.toFixed(1)}%
          </div>
          <div className="w-full h-1.5 bg-white/5 rounded-full mt-2 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-amber-500 to-amber-300 rounded-full"
              style={{ width: `${Math.min(pctContacted, 100)}%` }}
            />
          </div>
        </div>

        <div className="bg-white/[0.02] border border-white/5 rounded-xl p-4">
          <div className="flex items-center gap-2 text-xs text-gray-500 mb-2">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Inquiry → Closed–Won
          </div>
          <div className="text-2xl font-bold text-neon-green">
            {pctWon.toFixed(1)}%
          </div>
          <div className="w-full h-1.5 bg-white/5 rounded-full mt-2 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-neon-green to-neon-cyan rounded-full"
              style={{ width: `${Math.min(pctWon, 100)}%` }}
            />
          </div>
        </div>
      </div>

      {/* Weekly composed chart */}
      <div className="bg-white/[0.02] border border-white/5 rounded-xl p-4">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold text-white flex items-center gap-2">
            <Zap className="w-4 h-4 text-neon-cyan" />
            Weekly Inquiries & Response Time
          </h3>
          <div className="flex items-center gap-3 text-[10px] text-gray-500">
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 bg-neon-cyan rounded-sm" />
              Inquiries
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2 h-0.5 bg-neon-pink" />
              Avg resp (hrs)
            </span>
          </div>
        </div>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={weeklyData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
              <XAxis
                dataKey="week"
                stroke="rgba(255,255,255,0.4)"
                style={{ fontSize: 11 }}
                tickLine={false}
              />
              <YAxis
                yAxisId="left"
                stroke="rgba(255,255,255,0.4)"
                style={{ fontSize: 11 }}
                tickLine={false}
                allowDecimals={false}
              />
              <YAxis
                yAxisId="right"
                orientation="right"
                stroke="rgba(255,46,99,0.6)"
                style={{ fontSize: 11 }}
                tickLine={false}
              />
              <Tooltip
                contentStyle={{
                  background: '#0a0a0a',
                  border: '1px solid rgba(255,255,255,0.1)',
                  borderRadius: 8,
                  fontSize: 12,
                }}
                labelStyle={{ color: '#fff' }}
              />
              <Bar
                yAxisId="left"
                dataKey="inquiries"
                fill="#00e5ff"
                radius={[6, 6, 0, 0]}
                name="Inquiries"
              />
              <Line
                yAxisId="right"
                type="monotone"
                dataKey="avgResponseHrs"
                stroke="#ff2e63"
                strokeWidth={2}
                dot={{ r: 3, fill: '#ff2e63' }}
                name="Avg response (hrs)"
              />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Top 5 vehicles */}
      <div className="bg-white/[0.02] border border-white/5 rounded-xl p-4">
        <h3 className="text-sm font-semibold text-white flex items-center gap-2 mb-3">
          <CarIcon className="w-4 h-4 text-neon-orange" />
          Top Vehicles Driving Inquiries
        </h3>
        {topVehicles.length === 0 ? (
          <div className="text-center py-8 text-xs text-gray-600 italic">
            No VDP-linked inquiries yet. When buyers submit the "Request More Info" form on a
            vehicle page, their leads will show up here.
          </div>
        ) : (
          <div className="space-y-2">
            {topVehicles.map((v, idx) => {
              const max = topVehicles[0].count || 1;
              const widthPct = (v.count / max) * 100;
              return (
                <a
                  key={v.id}
                  href={`/inventory/${v.id}`}
                  className="flex items-center gap-3 p-2.5 bg-white/[0.02] border border-white/5 rounded-lg hover:border-neon-orange/30 transition-colors group"
                >
                  <div className="flex items-center justify-center w-6 h-6 bg-white/5 rounded-md text-[11px] font-bold text-gray-400 flex-shrink-0">
                    {idx + 1}
                  </div>
                  {v.image ? (
                    <img
                      src={v.image}
                      alt={v.label}
                      className="w-12 h-9 object-cover rounded-md border border-white/10 flex-shrink-0"
                    />
                  ) : (
                    <div className="w-12 h-9 bg-white/5 rounded-md flex items-center justify-center flex-shrink-0">
                      <CarIcon className="w-4 h-4 text-gray-600" />
                    </div>
                  )}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-white truncate group-hover:text-neon-orange transition-colors">
                        {v.label}
                      </span>
                      {v.status === 'sold' && (
                        <span className="px-1.5 py-0.5 bg-neon-green/10 text-neon-green text-[9px] font-bold rounded uppercase tracking-wider flex-shrink-0">
                          Sold
                        </span>
                      )}
                    </div>
                    <div className="w-full h-1 bg-white/5 rounded-full mt-1.5 overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-neon-orange to-neon-pink rounded-full transition-all"
                        style={{ width: `${widthPct}%` }}
                      />
                    </div>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <div className="text-neon-orange font-bold text-sm">{v.count}</div>
                    <div className="text-[10px] text-gray-600">
                      {v.count === 1 ? 'lead' : 'leads'}
                    </div>
                  </div>
                </a>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

const FunnelStage: React.FC<{
  icon: React.ElementType;
  label: string;
  value: number;
  pct: number;
  color: string;
  bg: string;
  border: string;
  sublabel: string;
}> = ({ icon: Icon, label, value, color, bg, border, sublabel }) => (
  <div className={`${bg} ${border} border rounded-xl p-4`}>
    <div className="flex items-center gap-2 mb-1.5">
      <Icon className={`w-3.5 h-3.5 ${color}`} />
      <span className="text-xs text-gray-500 font-medium">{label}</span>
    </div>
    <div className={`text-2xl font-bold ${color}`}>{value}</div>
    <div className="text-[10px] text-gray-600 mt-1">{sublabel}</div>
  </div>
);

export default LeadFunnelChart;
