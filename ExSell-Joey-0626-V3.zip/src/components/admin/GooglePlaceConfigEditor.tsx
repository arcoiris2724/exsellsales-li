import React, { useEffect, useState } from 'react';
import {
  Save, Loader2, CheckCircle, AlertTriangle, ExternalLink, MapPin,
  Search, RefreshCw, Star, Copy, Sparkles,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { toast } from '@/components/ui/use-toast';
import { saveSiteContent, fetchSectionContent } from '@/hooks/useSiteContent';
import {
  GOOGLE_PLACE_SECTION,
  GOOGLE_PLACE_ID as DEFAULT_PLACE_ID,
  BUSINESS_QUERY,
  GOOGLE_BUSINESS_CID,
  isPlaceholderPlaceId,
  buildMapsEmbedUrl,
  buildWriteReviewUrl,
  type GooglePlaceConfig,
} from '@/lib/googlePlace';

/**
 * Admin editor for the live Google Place ID.
 *
 * Persists `{ placeId }` to `site_content` under section `google_place`.
 * Every component using `usePlaceConfig` (homepage badge, /reviews page,
 * JSON-LD structured data, GoogleReviewsLive) reads this value at render
 * time, so saving here goes live across the entire site immediately.
 */
const GooglePlaceConfigEditor: React.FC = () => {
  const [placeId, setPlaceId] = useState<string>('');
  const [savedPlaceId, setSavedPlaceId] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [autoFinding, setAutoFinding] = useState(false);
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<null | {
    ok: boolean;
    rating?: number | null;
    userRatingCount?: number | null;
    message?: string;
  }>(null);

  // Load existing value on mount
  useEffect(() => {
    (async () => {
      setLoading(true);
      const stored = (await fetchSectionContent(GOOGLE_PLACE_SECTION)) as GooglePlaceConfig | null;
      const val = stored?.placeId?.trim() || '';
      setPlaceId(val);
      setSavedPlaceId(val);
      setLoading(false);
    })();
  }, []);

  const trimmed = placeId.trim();
  const effective = trimmed || DEFAULT_PLACE_ID;
  const placeholder = isPlaceholderPlaceId(effective);
  const dirty = trimmed !== savedPlaceId.trim();
  const looksValid = /^ChIJ[A-Za-z0-9_-]{10,}$/.test(trimmed);

  const handleSave = async () => {
    setSaving(true);
    const result = await saveSiteContent(GOOGLE_PLACE_SECTION, {
      placeId: trimmed,
    } as GooglePlaceConfig);
    setSaving(false);
    if (!result.success) {
      toast({
        title: 'Save Failed',
        description: result.error || 'Unknown error',
        variant: 'destructive',
      });
      return;
    }
    setSavedPlaceId(trimmed);
    toast({
      title: 'Place ID Saved',
      description: trimmed
        ? 'Live Google reviews will now load using this Place ID.'
        : 'Cleared. Live reviews disabled until a Place ID is set.',
    });
  };

  const handleClear = () => {
    setPlaceId('');
    setTestResult(null);
  };

  const handleAutoFind = async () => {
    setAutoFinding(true);
    setTestResult(null);
    try {
      const { data, error } = await supabase.functions.invoke('find-place-id', {
        body: { query: BUSINESS_QUERY, cid: GOOGLE_BUSINESS_CID },
      });
      if (error) throw new Error(error.message || 'Lookup failed');
      if (data?.success && data?.place_id) {
        setPlaceId(data.place_id);
        toast({
          title: 'Place ID Found',
          description: `${data.name || 'Business'} → ${data.place_id}. Click Save to apply.`,
        });
      } else {
        toast({
          title: 'Lookup Failed',
          description:
            data?.message ||
            'Could not auto-resolve the Place ID. Use the manual finder link below to copy it.',
          variant: 'destructive',
        });
      }
    } catch (err: any) {
      toast({
        title: 'Lookup Error',
        description: err?.message || 'Unable to call the find-place-id function.',
        variant: 'destructive',
      });
    } finally {
      setAutoFinding(false);
    }
  };

  const handleTest = async () => {
    if (!trimmed || isPlaceholderPlaceId(trimmed)) {
      toast({
        title: 'Enter a Real Place ID',
        description: 'Paste a real Place ID (starts with ChIJ…) before testing.',
        variant: 'destructive',
      });
      return;
    }
    setTesting(true);
    setTestResult(null);
    try {
      const { data, error } = await supabase.functions.invoke('google-reviews-fetch', {
        body: { placeId: trimmed, forceRefresh: true },
      });
      if (error) throw new Error(error.message || 'Fetch failed');
      if (data?.error) {
        setTestResult({ ok: false, message: data.error });
      } else if (data?.rating != null) {
        setTestResult({
          ok: true,
          rating: data.rating,
          userRatingCount: data.userRatingCount,
        });
      } else {
        setTestResult({
          ok: false,
          message:
            data?.warning ||
            'No rating returned. The Place ID may be valid but Google has no public reviews for it yet.',
        });
      }
    } catch (err: any) {
      setTestResult({ ok: false, message: err?.message || 'Unknown error' });
    } finally {
      setTesting(false);
    }
  };

  const copyExample = () => {
    navigator.clipboard?.writeText(BUSINESS_QUERY);
    toast({ title: 'Copied', description: 'Business address copied to clipboard.' });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-16">
        <Loader2 className="w-6 h-6 text-neon-cyan animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h3 className="text-white font-bold text-base mb-1 flex items-center gap-2">
          <MapPin className="w-4 h-4 text-neon-cyan" /> Google Business Profile — Place ID
        </h3>
        <p className="text-gray-500 text-sm">
          The live Google Place ID controls every reviews-related feature on the site (homepage rating
          badge, /reviews page, JSON-LD structured data for SEO, embedded map). Updates go live
          immediately — no redeploy required.
        </p>
      </div>

      {/* Status banner */}
      <div
        className={`flex items-start gap-3 p-4 rounded-xl border ${
          placeholder
            ? 'bg-amber-500/5 border-amber-500/20'
            : 'bg-emerald-500/5 border-emerald-500/20'
        }`}
      >
        {placeholder ? (
          <AlertTriangle className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
        ) : (
          <CheckCircle className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
        )}
        <div className="flex-1">
          <p
            className={`font-bold text-sm ${
              placeholder ? 'text-amber-300' : 'text-emerald-300'
            }`}
          >
            {placeholder ? 'Live reviews disabled — placeholder Place ID' : 'Live reviews enabled'}
          </p>
          <p
            className={`text-xs leading-relaxed mt-1 ${
              placeholder ? 'text-amber-200/80' : 'text-emerald-200/80'
            }`}
          >
            {placeholder
              ? 'The current Place ID is a hard-coded placeholder, so the homepage badge, /reviews live snippets, and JSON-LD rich-results markup are all hidden. Paste the real ExSell Sales LLC Place ID below and save to turn them on.'
              : `Effective Place ID: ${effective}. Every reviews component on the site is using this value.`}
          </p>
        </div>
      </div>

      {/* Quick lookup helpers */}
      <div className="bg-white/[0.02] border border-white/5 rounded-xl p-4 space-y-3">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-neon-pink" />
          <span className="text-white font-semibold text-sm">Find your Place ID</span>
        </div>
        <p className="text-gray-500 text-xs leading-relaxed">
          Three options — try the auto-finder first, then fall back to Google's official finder if
          needed.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          <button
            onClick={handleAutoFind}
            disabled={autoFinding}
            className="flex items-center justify-center gap-2 px-4 py-2.5 bg-gradient-to-r from-neon-pink to-neon-orange text-white font-semibold rounded-lg text-sm hover:opacity-90 transition-opacity disabled:opacity-50"
          >
            {autoFinding ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Search className="w-4 h-4" />
            )}
            Auto-find for ExSell Sales LLC
          </button>
          <a
            href="https://developers.google.com/maps/documentation/places/web-service/place-id"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-2 px-4 py-2.5 border border-white/10 text-gray-300 font-semibold rounded-lg text-sm hover:bg-white/5 hover:text-white transition-colors"
          >
            <ExternalLink className="w-4 h-4" />
            Open Google's Place ID Finder
          </a>
        </div>

        <div className="flex items-center gap-2 px-3 py-2 bg-black/40 border border-white/5 rounded-lg">
          <span className="text-gray-500 text-xs flex-shrink-0">Search address:</span>
          <span className="text-gray-300 text-xs font-mono truncate flex-1">{BUSINESS_QUERY}</span>
          <button
            onClick={copyExample}
            className="p-1 text-gray-500 hover:text-white transition-colors"
            title="Copy address"
          >
            <Copy className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Place ID input */}
      <div>
        <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">
          Google Place ID
        </label>
        <div className="relative">
          <input
            type="text"
            value={placeId}
            onChange={(e) => {
              setPlaceId(e.target.value);
              setTestResult(null);
            }}
            placeholder="ChIJ..."
            spellCheck={false}
            className={`w-full px-4 py-3 pr-32 bg-white/[0.03] border rounded-xl text-white text-sm font-mono placeholder-gray-600 focus:outline-none focus:ring-1 transition-all ${
              trimmed && !looksValid
                ? 'border-amber-500/40 focus:border-amber-400 focus:ring-amber-400/30'
                : 'border-white/10 focus:border-neon-cyan focus:ring-neon-cyan/30'
            }`}
          />
          {trimmed && (
            <button
              onClick={handleClear}
              className="absolute right-3 top-1/2 -translate-y-1/2 px-2.5 py-1 text-gray-500 hover:text-white text-xs font-medium transition-colors"
              title="Clear"
            >
              Clear
            </button>
          )}
        </div>
        <div className="flex items-center justify-between mt-2 flex-wrap gap-2">
          <div className="text-xs">
            {trimmed && !looksValid && (
              <span className="text-amber-400 flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5" />
                Doesn't look like a valid Place ID — they start with "ChIJ".
              </span>
            )}
            {trimmed && looksValid && (
              <span className="text-emerald-400 flex items-center gap-1.5">
                <CheckCircle className="w-3.5 h-3.5" />
                Format looks correct.
              </span>
            )}
            {!trimmed && (
              <span className="text-gray-600">
                Leave empty to disable live reviews entirely.
              </span>
            )}
          </div>
          {dirty && <span className="text-amber-400 text-xs font-medium">Unsaved changes</span>}
        </div>
      </div>

      {/* Test connection */}
      <div className="bg-white/[0.02] border border-white/5 rounded-xl p-4 space-y-3">
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div>
            <p className="text-white font-semibold text-sm">Test connection</p>
            <p className="text-gray-500 text-xs mt-0.5">
              Calls the Google Places API live to confirm the ID returns a real rating.
            </p>
          </div>
          <button
            onClick={handleTest}
            disabled={testing || !trimmed || isPlaceholderPlaceId(trimmed)}
            className="flex items-center gap-2 px-4 py-2 bg-white/[0.03] border border-white/10 text-white text-sm font-semibold rounded-lg hover:bg-white/[0.06] transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
          >
            {testing ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <RefreshCw className="w-4 h-4" />
            )}
            Test Now
          </button>
        </div>
        {testResult && (
          <div
            className={`p-3 rounded-lg border text-sm ${
              testResult.ok
                ? 'bg-emerald-500/5 border-emerald-500/20 text-emerald-200'
                : 'bg-red-500/5 border-red-500/20 text-red-200'
            }`}
          >
            {testResult.ok ? (
              <div className="flex items-center gap-2">
                <Star className="w-4 h-4 fill-current" />
                <span className="font-semibold">{testResult.rating?.toFixed(1)}</span>
                <span className="opacity-70">
                  / 5.0 from {testResult.userRatingCount?.toLocaleString() ?? '?'} reviews — looks
                  good!
                </span>
              </div>
            ) : (
              <div className="flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                <span>{testResult.message}</span>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Preview links */}
      {trimmed && looksValid && !isPlaceholderPlaceId(trimmed) && (
        <div className="bg-white/[0.02] border border-white/5 rounded-xl p-4 space-y-2">
          <p className="text-white font-semibold text-sm mb-2">Preview links</p>
          <div className="flex flex-wrap gap-2">
            <a
              href={buildWriteReviewUrl(trimmed)}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white/[0.03] border border-white/10 rounded-lg text-xs text-gray-300 hover:text-white hover:border-white/20 transition-colors"
            >
              Write Review URL <ExternalLink className="w-3 h-3" />
            </a>
            <a
              href={buildMapsEmbedUrl(trimmed).replace('/embed/v1/place', '/place/')}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white/[0.03] border border-white/10 rounded-lg text-xs text-gray-300 hover:text-white hover:border-white/20 transition-colors"
            >
              Open on Google Maps <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </div>
      )}

      {/* Save button */}
      <div className="flex items-center justify-between pt-4 border-t border-white/5 gap-3 flex-wrap">
        <p className="text-gray-500 text-xs">
          Saved to <code className="text-gray-300">site_content.{GOOGLE_PLACE_SECTION}</code>.
          Picked up by the entire site on the next render.
        </p>
        <button
          onClick={handleSave}
          disabled={saving || !dirty}
          className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-neon-cyan to-blue-500 text-white font-bold rounded-xl hover:opacity-90 transition-opacity disabled:opacity-40 disabled:cursor-not-allowed shadow-lg shadow-neon-cyan/20"
        >
          {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
          Save Place ID
        </button>
      </div>
    </div>
  );
};

export default GooglePlaceConfigEditor;
