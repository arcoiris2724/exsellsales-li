import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  Send, Loader2, ArrowDownLeft, ArrowUpRight, Mail, StickyNote,
  CheckCircle2, AlertCircle, MessageCircle, RefreshCw,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { toast } from '@/components/ui/use-toast';

export interface LeadMessage {
  id: string;
  lead_id: string;
  direction: 'inbound' | 'outbound';
  body: string;
  author: string | null;
  channel: string | null;
  sent_at: string;
}

interface Props {
  leadId: string | number;
  leadName: string;
  leadEmail: string | null;
  /** Optional extra context for the reply email */
  vehicleTitle?: string | null;
  vehicleId?: number | string | null;
  /** The dealer/author name shown in the email signature */
  authorName?: string;
  /** Auto-seed the thread with the original inbound customer message */
  originalMessage?: string | null;
  originalSentAt?: string | null;
}

/**
 * LeadConversation — two-way messaging thread for a single lead.
 *
 * Shows a running thread of inbound (customer) + outbound (dealer) messages
 * from the `lead_messages` table, plus a composer that POSTs to the
 * `lead-reply` edge function. The edge function handles:
 *   - inserting the outbound row
 *   - emailing the customer (via Resend / GATEWAY_API_KEY)
 *   - stamping `first_response_at`
 *   - auto-transitioning lead status from 'new' → 'contacted'
 */
const LeadConversation: React.FC<Props> = ({
  leadId,
  leadName,
  leadEmail,
  vehicleTitle,
  vehicleId,
  authorName = 'Ex$ell Sales Team',
  originalMessage,
  originalSentAt,
}) => {
  const [messages, setMessages] = useState<LeadMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [reply, setReply] = useState('');
  const [sendAsEmail, setSendAsEmail] = useState(true);
  const [lastResult, setLastResult] = useState<{ ok: boolean; msg: string } | null>(null);
  const threadEndRef = useRef<HTMLDivElement>(null);

  const loadThread = useCallback(async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('lead_messages')
        .select('*')
        .eq('lead_id', leadId)
        .order('sent_at', { ascending: true });
      if (error) throw error;
      setMessages((data || []) as LeadMessage[]);
    } catch (err) {
      console.warn('Failed to load lead thread:', err);
    } finally {
      setLoading(false);
    }
  }, [leadId]);

  useEffect(() => {
    loadThread();
  }, [loadThread]);

  // Auto-scroll to bottom when messages change
  useEffect(() => {
    threadEndRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
  }, [messages.length]);

  const handleSend = async () => {
    const trimmed = reply.trim();
    if (!trimmed) return;
    if (sendAsEmail && !leadEmail) {
      toast({
        title: 'No email on file',
        description: "This lead didn't provide an email — save as a note instead.",
        variant: 'destructive',
      });
      return;
    }
    setSending(true);
    setLastResult(null);
    try {
      const { data, error } = await supabase.functions.invoke('lead-reply', {
        body: {
          lead_id: leadId,
          body: trimmed,
          author: authorName,
          email_to: sendAsEmail ? leadEmail : null,
          send_email: sendAsEmail,
          name: leadName,
          vehicle_title: vehicleTitle || null,
          vehicle_url: vehicleId
            ? `${window.location.origin}/inventory/${vehicleId}`
            : null,
        },
      });

      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      setReply('');
      await loadThread();

      if (sendAsEmail && data?.email_sent) {
        setLastResult({ ok: true, msg: `Emailed to ${leadEmail}` });
        toast({ title: 'Reply sent', description: `Emailed ${leadEmail}.` });
      } else if (sendAsEmail && !data?.email_sent) {
        setLastResult({
          ok: false,
          msg: 'Saved to thread, but email delivery failed (GATEWAY_API_KEY may not be a Resend key).',
        });
        toast({
          title: 'Saved as note',
          description: 'Email provider not configured — reply stored in thread.',
        });
      } else {
        setLastResult({ ok: true, msg: 'Saved as internal note' });
        toast({ title: 'Note saved', description: 'Internal note added to the thread.' });
      }

      if (data?.status_transitioned) {
        toast({
          title: 'Lead marked Contacted',
          description: 'First outbound reply — status auto-advanced.',
        });
      }
    } catch (err: unknown) {
      console.error('Reply failed:', err);
      const msg = (err as Error)?.message || 'Failed to send reply';
      setLastResult({ ok: false, msg });
      toast({ title: 'Reply failed', description: msg, variant: 'destructive' });
    } finally {
      setSending(false);
    }
  };

  const formatTimeOnly = (ts: string) => {
    try {
      const d = new Date(ts);
      const today = new Date();
      const isToday = d.toDateString() === today.toDateString();
      if (isToday) {
        return d.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
      }
      return d.toLocaleString('en-US', {
        month: 'short',
        day: 'numeric',
        hour: 'numeric',
        minute: '2-digit',
      });
    } catch {
      return ts;
    }
  };

  // Combine seed (original inquiry) + DB messages as a visual thread
  type ThreadItem = {
    key: string;
    direction: 'inbound' | 'outbound';
    body: string;
    author: string;
    channel: string;
    sent_at: string;
    seed?: boolean;
  };

  const seedItem: ThreadItem | null = originalMessage
    ? {
        key: 'seed',
        direction: 'inbound',
        body: originalMessage,
        author: leadName,
        channel: 'form',
        sent_at: originalSentAt || new Date().toISOString(),
        seed: true,
      }
    : null;

  const thread: ThreadItem[] = [
    ...(seedItem ? [seedItem] : []),
    ...messages.map((m) => ({
      key: m.id,
      direction: m.direction,
      body: m.body,
      author: m.author || (m.direction === 'inbound' ? leadName : authorName),
      channel: m.channel || 'email',
      sent_at: m.sent_at,
    })),
  ];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h4 className="text-xs font-semibold text-gray-400 uppercase tracking-wider flex items-center gap-2">
          <MessageCircle className="w-3 h-3" />
          Conversation
          <span className="text-gray-600 font-normal normal-case tracking-normal">
            ({thread.length} message{thread.length === 1 ? '' : 's'})
          </span>
        </h4>
        <button
          onClick={loadThread}
          disabled={loading}
          className="text-gray-500 hover:text-white transition-colors"
          title="Refresh thread"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {/* Thread */}
      <div className="bg-black/30 border border-white/5 rounded-xl p-3 max-h-80 overflow-y-auto space-y-3">
        {loading && messages.length === 0 ? (
          <div className="flex items-center justify-center py-6">
            <Loader2 className="w-4 h-4 text-gray-500 animate-spin" />
          </div>
        ) : thread.length === 0 ? (
          <div className="text-center py-6 text-xs text-gray-600 italic">
            No messages yet — your reply will start the conversation.
          </div>
        ) : (
          thread.map((m) => {
            const isInbound = m.direction === 'inbound';
            return (
              <div
                key={m.key}
                className={`flex ${isInbound ? 'justify-start' : 'justify-end'}`}
              >
                <div
                  className={`max-w-[88%] rounded-2xl px-3.5 py-2.5 text-sm border ${
                    isInbound
                      ? 'bg-white/[0.04] border-white/10 text-gray-200 rounded-bl-sm'
                      : 'bg-gradient-to-br from-neon-pink/15 to-neon-orange/10 border-neon-pink/25 text-white rounded-br-sm'
                  }`}
                >
                  <div className="flex items-center gap-1.5 mb-1 text-[10px] uppercase tracking-wider">
                    {isInbound ? (
                      <>
                        <ArrowDownLeft className="w-2.5 h-2.5 text-neon-cyan" />
                        <span className="text-neon-cyan font-semibold">{m.author}</span>
                      </>
                    ) : (
                      <>
                        <ArrowUpRight className="w-2.5 h-2.5 text-neon-pink" />
                        <span className="text-neon-pink font-semibold">{m.author}</span>
                      </>
                    )}
                    {m.channel === 'email' ? (
                      <Mail className="w-2.5 h-2.5 text-gray-500 ml-0.5" />
                    ) : m.channel === 'note' ? (
                      <StickyNote className="w-2.5 h-2.5 text-gray-500 ml-0.5" />
                    ) : null}
                    {m.seed && (
                      <span className="text-[9px] text-gray-500 bg-white/5 rounded px-1 ml-1">
                        original inquiry
                      </span>
                    )}
                    <span className="text-gray-600 ml-auto normal-case tracking-normal">
                      {formatTimeOnly(m.sent_at)}
                    </span>
                  </div>
                  <div className="whitespace-pre-wrap leading-relaxed text-[13px]">
                    {m.body}
                  </div>
                </div>
              </div>
            );
          })
        )}
        <div ref={threadEndRef} />
      </div>

      {/* Composer */}
      <div className="space-y-2">
        <textarea
          value={reply}
          onChange={(e) => setReply(e.target.value)}
          rows={3}
          disabled={sending}
          placeholder={
            leadEmail
              ? `Reply to ${leadName} at ${leadEmail}…`
              : `Add an internal note about ${leadName}…`
          }
          className="w-full px-3 py-2.5 bg-black border border-white/10 rounded-lg text-white text-sm placeholder-gray-600 focus:border-neon-cyan focus:outline-none resize-none disabled:opacity-50"
        />

        <div className="flex flex-wrap items-center gap-3">
          {/* Channel toggle */}
          {leadEmail ? (
            <div className="flex items-center gap-1 bg-white/[0.03] border border-white/10 rounded-lg p-1">
              <button
                type="button"
                onClick={() => setSendAsEmail(true)}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-semibold transition-colors ${
                  sendAsEmail
                    ? 'bg-neon-cyan/15 text-neon-cyan'
                    : 'text-gray-500 hover:text-gray-300'
                }`}
              >
                <Mail className="w-3 h-3" />
                Email
              </button>
              <button
                type="button"
                onClick={() => setSendAsEmail(false)}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-semibold transition-colors ${
                  !sendAsEmail
                    ? 'bg-amber-400/15 text-amber-300'
                    : 'text-gray-500 hover:text-gray-300'
                }`}
              >
                <StickyNote className="w-3 h-3" />
                Note only
              </button>
            </div>
          ) : (
            <span className="text-[11px] text-gray-500 italic">
              No email on file — reply will be saved as an internal note.
            </span>
          )}

          <button
            onClick={handleSend}
            disabled={sending || !reply.trim()}
            className="ml-auto inline-flex items-center gap-1.5 px-4 py-2 bg-gradient-to-r from-neon-pink to-neon-orange text-white text-xs font-bold rounded-lg hover:opacity-90 transition-opacity disabled:opacity-40 disabled:cursor-not-allowed"
          >
            {sending ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Send className="w-3.5 h-3.5" />
            )}
            {sendAsEmail && leadEmail ? 'Send Email Reply' : 'Save Note'}
          </button>
        </div>

        {lastResult && (
          <div
            className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs ${
              lastResult.ok
                ? 'bg-neon-green/10 border border-neon-green/20 text-neon-green'
                : 'bg-amber-400/10 border border-amber-400/20 text-amber-300'
            }`}
          >
            {lastResult.ok ? (
              <CheckCircle2 className="w-3.5 h-3.5 flex-shrink-0" />
            ) : (
              <AlertCircle className="w-3.5 h-3.5 flex-shrink-0" />
            )}
            <span>{lastResult.msg}</span>
          </div>
        )}
      </div>
    </div>
  );
};

export default LeadConversation;
