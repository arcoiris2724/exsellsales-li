import React, { useState } from 'react';
import { AlertTriangle, DollarSign, Loader2, X, Trophy, Calendar } from 'lucide-react';
import { Vehicle } from '@/data/vehicles';

interface MarkAsSoldDialogProps {
  vehicle: Vehicle;
  onConfirm: (soldPrice?: number) => Promise<void>;
  onCancel: () => void;
}

const MarkAsSoldDialog: React.FC<MarkAsSoldDialogProps> = ({ vehicle, onConfirm, onCancel }) => {
  const [soldPrice, setSoldPrice] = useState<string>(String(vehicle.price));
  const [useSalePrice, setUseSalePrice] = useState(false);
  const [loading, setLoading] = useState(false);

  const today = new Date().toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  const handleConfirm = async () => {
    setLoading(true);
    try {
      const finalPrice = useSalePrice && soldPrice ? parseFloat(soldPrice) : undefined;
      await onConfirm(finalPrice);
    } catch {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
      <div className="fixed inset-0 bg-black/80 backdrop-blur-sm" onClick={onCancel} />

      <div className="relative w-full max-w-md bg-[#111111] rounded-2xl border border-red-500/30 shadow-2xl shadow-red-500/10 overflow-hidden">
        {/* Header gradient */}
        <div className="h-1.5 bg-gradient-to-r from-red-500 via-neon-orange to-red-500" />

        <div className="p-6 space-y-5">
          {/* Icon + Title */}
          <div className="text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-red-500/10 border border-red-500/20 mb-4">
              <Trophy className="w-8 h-8 text-red-400" />
            </div>
            <h2 className="text-xl font-black text-white">Mark as Sold?</h2>
            <p className="text-gray-400 text-sm mt-1">
              This will move the vehicle to the <span className="text-red-400 font-semibold">Sold List</span>.
            </p>
          </div>

          {/* Vehicle Preview */}
          <div className="flex items-center gap-4 p-4 bg-white/[0.03] border border-white/5 rounded-xl">
            {vehicle.image ? (
              <img
                src={vehicle.image}
                alt={`${vehicle.make} ${vehicle.model}`}
                className="w-20 h-14 rounded-lg object-cover flex-shrink-0 border border-white/10"
              />
            ) : (
              <div className="w-20 h-14 rounded-lg bg-gray-800 flex items-center justify-center flex-shrink-0">
                <Trophy className="w-6 h-6 text-gray-600" />
              </div>
            )}
            <div className="flex-1 min-w-0">
              <h3 className="text-white font-bold text-sm truncate">
                {vehicle.year} {vehicle.make} {vehicle.model}
              </h3>
              <p className="text-gray-500 text-xs">{vehicle.trim}</p>
              <p className="text-neon-orange font-bold text-sm mt-0.5">
                ${vehicle.price.toLocaleString()}
              </p>
            </div>
          </div>

          {/* Sold Date Info */}
          <div className="flex items-center gap-3 p-3 bg-neon-cyan/5 border border-neon-cyan/20 rounded-xl">
            <Calendar className="w-5 h-5 text-neon-cyan flex-shrink-0" />
            <div>
              <p className="text-neon-cyan text-xs font-semibold">Sold Date</p>
              <p className="text-white text-sm font-medium">{today}</p>
            </div>
          </div>

          {/* Optional Sale Price */}
          <div className="space-y-3">
            <label className="flex items-center gap-3 cursor-pointer group">
              <div
                className={`w-5 h-5 rounded-md border-2 flex items-center justify-center transition-all ${
                  useSalePrice
                    ? 'bg-neon-orange border-neon-orange'
                    : 'border-gray-600 group-hover:border-gray-400'
                }`}
                onClick={() => setUseSalePrice(!useSalePrice)}
              >
                {useSalePrice && (
                  <svg className="w-3 h-3 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                    <polyline points="20 6 9 17 4 12" />
                  </svg>
                )}
              </div>
              <span className="text-gray-300 text-sm font-medium" onClick={() => setUseSalePrice(!useSalePrice)}>
                Enter a final sale price (optional)
              </span>
            </label>

            {useSalePrice && (
              <div className="relative">
                <DollarSign className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                <input
                  type="number"
                  value={soldPrice}
                  onChange={(e) => setSoldPrice(e.target.value)}
                  placeholder="Final sale price"
                  autoFocus
                  className="w-full pl-10 pr-4 py-3 bg-black border border-white/10 rounded-xl text-white text-lg font-bold placeholder-gray-600 focus:border-neon-orange focus:outline-none focus:ring-1 focus:ring-neon-orange/30 transition-all"
                />
                {soldPrice && parseFloat(soldPrice) !== vehicle.price && (
                  <div className="mt-2 flex items-center gap-2 text-xs">
                    <span className="text-gray-500">Listed: ${vehicle.price.toLocaleString()}</span>
                    <span className="text-gray-600">→</span>
                    <span className={`font-bold ${parseFloat(soldPrice) < vehicle.price ? 'text-red-400' : 'text-neon-green'}`}>
                      Sale: ${parseFloat(soldPrice).toLocaleString()}
                    </span>
                    <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                      parseFloat(soldPrice) < vehicle.price
                        ? 'bg-red-500/10 text-red-400'
                        : 'bg-neon-green/10 text-neon-green'
                    }`}>
                      {parseFloat(soldPrice) < vehicle.price ? '-' : '+'}
                      ${Math.abs(parseFloat(soldPrice) - vehicle.price).toLocaleString()}
                    </span>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Warning */}
          <div className="flex items-start gap-3 p-3 bg-amber-500/5 border border-amber-500/20 rounded-xl">
            <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
            <p className="text-amber-400/80 text-xs leading-relaxed">
              All vehicle data, images, specs, and description will be preserved. The vehicle will be removed from active inventory and appear on the Sold List page.
            </p>
          </div>

          {/* Actions */}
          <div className="flex gap-3 pt-1">
            <button
              onClick={onCancel}
              disabled={loading}
              className="flex-1 py-3 border border-white/10 text-gray-400 font-semibold rounded-xl hover:bg-white/5 transition-colors disabled:opacity-50"
            >
              Cancel
            </button>
            <button
              onClick={handleConfirm}
              disabled={loading}
              className="flex-1 py-3 bg-gradient-to-r from-red-500 to-neon-orange text-white font-bold rounded-xl hover:opacity-90 transition-opacity disabled:opacity-50 flex items-center justify-center gap-2 shadow-lg shadow-red-500/20"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Marking Sold...
                </>
              ) : (
                <>
                  <Trophy className="w-4 h-4" />
                  Mark as Sold
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MarkAsSoldDialog;
