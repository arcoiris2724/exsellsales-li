import React, { useState, useRef, useCallback } from 'react';
import {
  Upload, X, Loader2, Camera, Check, AlertCircle, Trash2,
  ImagePlus, Star, ChevronDown, Car, Images, ShieldAlert
} from 'lucide-react';
import { Vehicle, uploadVehicleImage, updateVehicle, clearAllStockPhotos } from '@/data/vehicles';
import { toast } from '@/components/ui/use-toast';

interface BulkImageUploadPanelProps {
  vehicles: Vehicle[];
  onVehiclesUpdated: () => void;
}

interface UploadItem {
  id: string;
  file: File;
  preview: string;
  status: 'pending' | 'uploading' | 'done' | 'error';
  url?: string;
  error?: string;
  progress: number;
}

const BulkImageUploadPanel: React.FC<BulkImageUploadPanelProps> = ({ vehicles, onVehiclesUpdated }) => {
  const [selectedVehicleId, setSelectedVehicleId] = useState<number | null>(null);
  const [uploads, setUploads] = useState<UploadItem[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [showVehicleDropdown, setShowVehicleDropdown] = useState(false);
  const [vehicleSearch, setVehicleSearch] = useState('');
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [isClearing, setIsClearing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const dropRef = useRef<HTMLDivElement>(null);

  const selectedVehicle = vehicles.find(v => v.id === selectedVehicleId) || null;

  const filteredVehicles = vehicles.filter(v => {
    if (!vehicleSearch) return true;
    const q = vehicleSearch.toLowerCase();
    return `${v.year} ${v.make} ${v.model} ${v.trim}`.toLowerCase().includes(q);
  });

  // Count stock photos across all vehicles
  const totalStockPhotos = vehicles.reduce(
    (sum, v) => sum + (v.images?.filter(img => img.includes('unsplash.com')).length || 0) + (v.image && v.image.includes('unsplash.com') && !(v.images || []).includes(v.image) ? 1 : 0),
    0
  );
  const vehiclesWithStock = vehicles.filter(
    v => v.image?.includes('unsplash.com') || (v.images || []).some(img => img.includes('unsplash.com'))
  ).length;

  // Handle Clear All Stock Photos
  const handleClearAllStockPhotos = async () => {
    setIsClearing(true);
    try {
      const result = await clearAllStockPhotos();
      toast({
        title: 'Stock Photos Cleared',
        description: `Removed stock photos from ${result.cleared} vehicle${result.cleared !== 1 ? 's' : ''}. Upload real lot photos to replace them.`,
      });
      onVehiclesUpdated();
    } catch (err: any) {
      toast({
        title: 'Error',
        description: err.message || 'Failed to clear stock photos.',
        variant: 'destructive',
      });
    } finally {
      setIsClearing(false);
      setShowClearConfirm(false);
    }
  };

  // Drag and drop handlers
  const handleDragEnter = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (dropRef.current && !dropRef.current.contains(e.relatedTarget as Node)) {
      setIsDragging(false);
    }
  }, []);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    const files = Array.from(e.dataTransfer.files).filter(f => f.type.startsWith('image/'));
    if (files.length > 0) {
      addFiles(files);
    }
  }, []);

  const addFiles = (files: File[]) => {
    const newUploads: UploadItem[] = files.map(file => ({
      id: `${Date.now()}-${Math.random().toString(36).substring(2)}`,
      file,
      preview: URL.createObjectURL(file),
      status: 'pending' as const,
      progress: 0,
    }));
    setUploads(prev => [...prev, ...newUploads]);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []).filter(f => f.type.startsWith('image/'));
    if (files.length > 0) {
      addFiles(files);
    }
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const removeUpload = (id: string) => {
    setUploads(prev => {
      const item = prev.find(u => u.id === id);
      if (item) URL.revokeObjectURL(item.preview);
      return prev.filter(u => u.id !== id);
    });
  };

  const clearAll = () => {
    uploads.forEach(u => URL.revokeObjectURL(u.preview));
    setUploads([]);
  };

  // Upload all pending files
  const handleUploadAll = async () => {
    if (!selectedVehicle) {
      toast({ title: 'Select a Vehicle', description: 'Please select a vehicle to upload photos to.', variant: 'destructive' });
      return;
    }

    const pendingUploads = uploads.filter(u => u.status === 'pending');
    if (pendingUploads.length === 0) {
      toast({ title: 'No Photos', description: 'Add some photos to upload.', variant: 'destructive' });
      return;
    }

    setIsUploading(true);
    const uploadedUrls: string[] = [];

    for (const item of pendingUploads) {
      setUploads(prev => prev.map(u => u.id === item.id ? { ...u, status: 'uploading' as const, progress: 30 } : u));

      try {
        const url = await uploadVehicleImage(item.file);
        uploadedUrls.push(url);
        setUploads(prev => prev.map(u => u.id === item.id ? { ...u, status: 'done' as const, url, progress: 100 } : u));
      } catch (err: any) {
        setUploads(prev => prev.map(u => u.id === item.id ? { ...u, status: 'error' as const, error: err.message || 'Upload failed', progress: 0 } : u));
      }
    }

    if (uploadedUrls.length > 0) {
      try {
        const existingImages = selectedVehicle.images || [];
        const allImages = [...existingImages, ...uploadedUrls];
        const mainImage = selectedVehicle.image || uploadedUrls[0];

        await updateVehicle(selectedVehicle.id, {
          images: allImages,
          image: existingImages.length === 0 ? uploadedUrls[0] : mainImage,
        });

        toast({
          title: 'Photos Uploaded!',
          description: `${uploadedUrls.length} photo${uploadedUrls.length !== 1 ? 's' : ''} added to ${selectedVehicle.year} ${selectedVehicle.make} ${selectedVehicle.model}.`,
        });
        onVehiclesUpdated();
      } catch (err: any) {
        toast({ title: 'Error', description: 'Photos uploaded but failed to link to vehicle.', variant: 'destructive' });
      }
    }

    setIsUploading(false);
  };

  // Remove an existing image from a vehicle
  const handleRemoveExistingImage = async (imageUrl: string) => {
    if (!selectedVehicle) return;
    const newImages = selectedVehicle.images.filter(img => img !== imageUrl);
    const newMainImage = imageUrl === selectedVehicle.image
      ? (newImages[0] || '')
      : selectedVehicle.image;

    try {
      await updateVehicle(selectedVehicle.id, { images: newImages, image: newMainImage });
      toast({ title: 'Photo Removed', description: 'Photo has been removed from this vehicle.' });
      onVehiclesUpdated();
    } catch {
      toast({ title: 'Error', description: 'Failed to remove photo.', variant: 'destructive' });
    }
  };

  // Set an image as the main/cover image
  const handleSetMainImage = async (imageUrl: string) => {
    if (!selectedVehicle) return;
    try {
      await updateVehicle(selectedVehicle.id, { image: imageUrl });
      toast({ title: 'Cover Photo Updated', description: 'Main photo has been updated.' });
      onVehiclesUpdated();
    } catch {
      toast({ title: 'Error', description: 'Failed to update cover photo.', variant: 'destructive' });
    }
  };

  const pendingCount = uploads.filter(u => u.status === 'pending').length;
  const doneCount = uploads.filter(u => u.status === 'done').length;
  const errorCount = uploads.filter(u => u.status === 'error').length;

  return (
    <div className="space-y-6">

      {/* Clear All Stock Photos Confirmation Dialog */}
      {showClearConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm">
          <div className="bg-[#111] border border-red-500/30 rounded-2xl p-6 max-w-md w-full mx-4 shadow-2xl shadow-red-500/10">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-xl bg-red-500/10 flex items-center justify-center">
                <ShieldAlert className="w-6 h-6 text-red-400" />
              </div>
              <div>
                <h3 className="text-white font-bold text-lg">Clear All Stock Photos</h3>
                <p className="text-gray-500 text-xs">This action cannot be undone</p>
              </div>
            </div>

            <div className="bg-red-500/5 border border-red-500/20 rounded-xl p-4 mb-5">
              <p className="text-gray-300 text-sm mb-3">
                This will remove <span className="text-red-400 font-bold">all Unsplash stock photos</span> from every vehicle in the database:
              </p>
              <ul className="space-y-1.5 text-sm">
                <li className="flex items-center gap-2 text-gray-400">
                  <div className="w-1.5 h-1.5 rounded-full bg-red-400" />
                  <span><span className="text-white font-semibold">{vehiclesWithStock}</span> vehicle{vehiclesWithStock !== 1 ? 's' : ''} affected</span>
                </li>
                <li className="flex items-center gap-2 text-gray-400">
                  <div className="w-1.5 h-1.5 rounded-full bg-red-400" />
                  <span><span className="text-white font-semibold">{totalStockPhotos}</span> stock photo{totalStockPhotos !== 1 ? 's' : ''} will be removed</span>
                </li>
                <li className="flex items-center gap-2 text-gray-400">
                  <div className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                  <span>Real uploaded photos will be <span className="text-neon-green font-semibold">kept</span></span>
                </li>
              </ul>
              <p className="text-amber-400/80 text-xs mt-3">
                Vehicles will show "No Photo Available" until you upload real lot photos.
              </p>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={() => setShowClearConfirm(false)}
                disabled={isClearing}
                className="flex-1 py-2.5 px-4 bg-white/5 border border-white/10 text-gray-300 rounded-xl text-sm font-semibold hover:bg-white/10 transition-colors disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                onClick={handleClearAllStockPhotos}
                disabled={isClearing}
                className="flex-1 py-2.5 px-4 bg-red-500 text-white rounded-xl text-sm font-bold hover:bg-red-600 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {isClearing ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Clearing...
                  </>
                ) : (
                  <>
                    <Trash2 className="w-4 h-4" />
                    Clear All Stock Photos
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Stock Photo Alert Banner + Clear Button */}
      {vehiclesWithStock > 0 && (
        <div className="bg-amber-500/5 border border-amber-500/20 rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center gap-4">
          <div className="flex items-start gap-3 flex-1">
            <div className="w-10 h-10 rounded-lg bg-amber-500/10 flex items-center justify-center flex-shrink-0">
              <AlertCircle className="w-5 h-5 text-amber-400" />
            </div>
            <div>
              <p className="text-amber-300 text-sm font-bold">Stock Photos Detected</p>
              <p className="text-amber-400/60 text-xs mt-0.5">
                {vehiclesWithStock} vehicle{vehiclesWithStock !== 1 ? 's' : ''} still {vehiclesWithStock !== 1 ? 'have' : 'has'} Unsplash stock photos ({totalStockPhotos} total).
                Replace them with real photos from your lot.
              </p>
            </div>
          </div>
          <button
            onClick={() => setShowClearConfirm(true)}
            className="px-4 py-2 bg-red-500/10 border border-red-500/30 text-red-400 rounded-lg text-xs font-bold hover:bg-red-500/20 hover:border-red-500/50 transition-all flex items-center gap-2 whitespace-nowrap"
          >
            <Trash2 className="w-3.5 h-3.5" />
            Clear All Stock Photos
          </button>
        </div>
      )}

      {/* Vehicle Selector */}
      <div className="bg-white/[0.02] border border-white/5 rounded-xl p-5">
        <h3 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
          <Car className="w-4 h-4 text-neon-cyan" />
          Select Vehicle
        </h3>
        <div className="relative">
          <button
            onClick={() => setShowVehicleDropdown(!showVehicleDropdown)}
            className="w-full flex items-center justify-between px-4 py-3 bg-black/60 border border-white/10 rounded-xl text-left hover:border-neon-cyan/30 transition-colors"
          >
            {selectedVehicle ? (
              <div className="flex items-center gap-3">
                <div className="w-12 h-8 rounded-md overflow-hidden bg-gray-900 flex-shrink-0">
                  {selectedVehicle.image && !selectedVehicle.image.includes('unsplash.com') ? (
                    <img src={selectedVehicle.image} alt="" className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <Car className="w-4 h-4 text-gray-700" />
                    </div>
                  )}
                </div>
                <div>
                  <span className="text-white font-semibold text-sm">
                    {selectedVehicle.year} {selectedVehicle.make} {selectedVehicle.model}
                  </span>
                  <span className="text-gray-500 text-xs ml-2">{selectedVehicle.trim}</span>
                  <div className="flex items-center gap-2 text-[11px] text-gray-500">
                    <Camera className="w-3 h-3" />
                    {selectedVehicle.images?.filter(img => !img.includes('unsplash.com')).length || 0} real photos
                    {(selectedVehicle.images?.filter(img => img.includes('unsplash.com')).length || 0) > 0 && (
                      <span className="text-amber-400">
                        + {selectedVehicle.images?.filter(img => img.includes('unsplash.com')).length} stock
                      </span>
                    )}
                    <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                      selectedVehicle.status === 'available' ? 'bg-neon-green/10 text-neon-green' :
                      selectedVehicle.status === 'sold' ? 'bg-red-400/10 text-red-400' :
                      'bg-neon-orange/10 text-neon-orange'
                    }`}>
                      {selectedVehicle.status}
                    </span>
                  </div>
                </div>
              </div>
            ) : (
              <span className="text-gray-500 text-sm">Choose a vehicle to manage photos...</span>
            )}
            <ChevronDown className={`w-4 h-4 text-gray-500 transition-transform ${showVehicleDropdown ? 'rotate-180' : ''}`} />
          </button>

          {showVehicleDropdown && (
            <>
              <div className="fixed inset-0 z-10" onClick={() => setShowVehicleDropdown(false)} />
              <div className="absolute top-full left-0 right-0 mt-1 z-20 bg-[#111] border border-white/10 rounded-xl shadow-2xl max-h-80 overflow-hidden">
                <div className="p-2 border-b border-white/5">
                  <input
                    type="text"
                    value={vehicleSearch}
                    onChange={e => setVehicleSearch(e.target.value)}
                    placeholder="Search vehicles..."
                    autoFocus
                    className="w-full px-3 py-2 bg-white/[0.03] border border-white/10 rounded-lg text-white text-sm placeholder-gray-600 focus:border-neon-cyan focus:outline-none"
                  />
                </div>
                <div className="overflow-y-auto max-h-60">
                  {filteredVehicles.map(v => {
                    const hasStock = v.image?.includes('unsplash.com') || (v.images || []).some(img => img.includes('unsplash.com'));
                    const realCount = (v.images || []).filter(img => !img.includes('unsplash.com')).length;
                    return (
                      <button
                        key={v.id}
                        onClick={() => {
                          setSelectedVehicleId(v.id);
                          setShowVehicleDropdown(false);
                          setVehicleSearch('');
                        }}
                        className={`w-full flex items-center gap-3 px-3 py-2.5 text-left hover:bg-white/[0.03] transition-colors ${
                          v.id === selectedVehicleId ? 'bg-neon-cyan/5 border-l-2 border-neon-cyan' : ''
                        }`}
                      >
                        <div className="w-10 h-7 rounded overflow-hidden bg-gray-900 flex-shrink-0">
                          {v.image && !v.image.includes('unsplash.com') ? (
                            <img src={v.image} alt="" className="w-full h-full object-cover" />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center">
                              <Car className="w-3 h-3 text-gray-700" />
                            </div>
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <span className="text-white text-sm font-medium">{v.year} {v.make} {v.model}</span>
                          <span className="text-gray-500 text-xs ml-1">{v.trim}</span>
                        </div>
                        <div className="flex items-center gap-2 flex-shrink-0">
                          <span className={`text-[11px] ${realCount > 0 ? 'text-neon-green' : 'text-gray-600'}`}>
                            <Camera className="w-3 h-3 inline mr-0.5" />
                            {realCount}
                          </span>
                          {hasStock && (
                            <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-500/10 text-amber-400">
                              STOCK
                            </span>
                          )}
                          <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                            v.status === 'available' ? 'bg-neon-green/10 text-neon-green' :
                            v.status === 'sold' ? 'bg-red-400/10 text-red-400' :
                            'bg-neon-orange/10 text-neon-orange'
                          }`}>
                            {v.status}
                          </span>
                        </div>
                      </button>
                    );
                  })}
                  {filteredVehicles.length === 0 && (
                    <div className="px-4 py-6 text-center text-gray-500 text-sm">No vehicles found</div>
                  )}
                </div>
              </div>
            </>
          )}
        </div>
      </div>

      {/* Current Photos for Selected Vehicle */}
      {selectedVehicle && (
        <div className="bg-white/[0.02] border border-white/5 rounded-xl p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Images className="w-4 h-4 text-neon-pink" />
              Current Photos
              <span className="text-xs text-gray-500 font-normal">
                ({selectedVehicle.images?.length || 0} photo{(selectedVehicle.images?.length || 0) !== 1 ? 's' : ''})
              </span>
            </h3>
          </div>

          {selectedVehicle.images && selectedVehicle.images.length > 0 ? (
            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-3">
              {selectedVehicle.images.map((url, i) => {
                const isMain = url === selectedVehicle.image;
                const isUnsplash = url.includes('unsplash.com');
                return (
                  <div
                    key={i}
                    className={`relative group rounded-lg overflow-hidden border-2 aspect-[4/3] ${
                      isMain ? 'border-neon-pink ring-1 ring-neon-pink/30' : 'border-white/10'
                    } ${isUnsplash ? 'opacity-60' : ''}`}
                  >
                    <img src={url} alt={`Photo ${i + 1}`} className="w-full h-full object-cover" />

                    {/* Hover overlay */}
                    <div className="absolute inset-0 bg-black/70 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-1.5">
                      {!isMain && (
                        <button
                          onClick={() => handleSetMainImage(url)}
                          className="px-2 py-1 bg-neon-pink/80 text-white text-[10px] font-bold rounded flex items-center gap-1 hover:bg-neon-pink transition-colors"
                        >
                          <Star className="w-3 h-3" />
                          Set Cover
                        </button>
                      )}
                      <button
                        onClick={() => handleRemoveExistingImage(url)}
                        className="px-2 py-1 bg-red-500/80 text-white text-[10px] font-bold rounded flex items-center gap-1 hover:bg-red-500 transition-colors"
                      >
                        <Trash2 className="w-3 h-3" />
                        Remove
                      </button>
                    </div>

                    {/* Main badge */}
                    {isMain && (
                      <div className="absolute top-1 left-1 px-1.5 py-0.5 bg-neon-pink text-white text-[9px] font-bold rounded flex items-center gap-0.5">
                        <Star className="w-2.5 h-2.5 fill-current" />
                        COVER
                      </div>
                    )}

                    {/* Stock photo badge */}
                    {isUnsplash && (
                      <div className="absolute bottom-1 left-1 px-1.5 py-0.5 bg-amber-500/80 text-black text-[9px] font-bold rounded">
                        STOCK
                      </div>
                    )}

                    {/* Index */}
                    <div className="absolute bottom-1 right-1 px-1 py-0.5 bg-black/70 text-white text-[9px] rounded">
                      {i + 1}
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="py-8 text-center">
              <Camera className="w-8 h-8 text-gray-700 mx-auto mb-2" />
              <p className="text-gray-500 text-sm">No photos yet</p>
              <p className="text-gray-600 text-xs mt-1">Drag and drop photos below to add them</p>
            </div>
          )}

          {/* Stock photo warning for selected vehicle */}
          {selectedVehicle.images?.some(url => url.includes('unsplash.com')) && (
            <div className="mt-3 flex items-start gap-2 p-3 bg-amber-500/5 border border-amber-500/20 rounded-lg">
              <AlertCircle className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-amber-300 text-xs font-semibold">Stock Photos Detected</p>
                <p className="text-amber-400/60 text-[11px] mt-0.5">
                  This vehicle has Unsplash stock photos (marked with "STOCK"). Upload real photos from your lot to replace them.
                </p>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Drag & Drop Upload Zone */}
      <div className="bg-white/[0.02] border border-white/5 rounded-xl p-5">
        <h3 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
          <Upload className="w-4 h-4 text-neon-green" />
          Upload New Photos
          {pendingCount > 0 && (
            <span className="px-2 py-0.5 bg-neon-green/10 text-neon-green text-[10px] font-bold rounded-full">
              {pendingCount} ready
            </span>
          )}
        </h3>

        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          multiple
          onChange={handleFileSelect}
          className="hidden"
        />

        {/* Drop zone */}
        <div
          ref={dropRef}
          onDragEnter={handleDragEnter}
          onDragLeave={handleDragLeave}
          onDragOver={handleDragOver}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className={`relative border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all ${
            isDragging
              ? 'border-neon-cyan bg-neon-cyan/5 scale-[1.02]'
              : 'border-white/15 hover:border-neon-pink/40 hover:bg-white/[0.01]'
          }`}
        >
          <div className={`transition-transform ${isDragging ? 'scale-110' : ''}`}>
            <div className={`w-16 h-16 mx-auto rounded-2xl flex items-center justify-center mb-4 ${
              isDragging ? 'bg-neon-cyan/10' : 'bg-white/[0.03]'
            }`}>
              <ImagePlus className={`w-8 h-8 ${isDragging ? 'text-neon-cyan' : 'text-gray-600'}`} />
            </div>
            <p className={`font-semibold text-sm mb-1 ${isDragging ? 'text-neon-cyan' : 'text-white'}`}>
              {isDragging ? 'Drop photos here!' : 'Drag & drop photos here'}
            </p>
            <p className="text-gray-500 text-xs">
              or click to browse files - supports JPG, PNG, WebP
            </p>
            <p className="text-gray-600 text-[11px] mt-2">
              Upload multiple photos at once - they'll be added to the selected vehicle
            </p>
          </div>
        </div>

        {/* Upload Queue */}
        {uploads.length > 0 && (
          <div className="mt-4 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3 text-xs">
                {pendingCount > 0 && <span className="text-gray-400">{pendingCount} pending</span>}
                {doneCount > 0 && <span className="text-neon-green">{doneCount} uploaded</span>}
                {errorCount > 0 && <span className="text-red-400">{errorCount} failed</span>}
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={clearAll}
                  disabled={isUploading}
                  className="text-xs text-gray-500 hover:text-red-400 transition-colors disabled:opacity-50"
                >
                  Clear All
                </button>
              </div>
            </div>

            {/* Thumbnail grid of queued uploads */}
            <div className="grid grid-cols-4 sm:grid-cols-5 md:grid-cols-6 lg:grid-cols-8 gap-2">
              {uploads.map((item) => (
                <div
                  key={item.id}
                  className={`relative group rounded-lg overflow-hidden aspect-square border-2 ${
                    item.status === 'done' ? 'border-neon-green/40' :
                    item.status === 'error' ? 'border-red-500/40' :
                    item.status === 'uploading' ? 'border-neon-cyan/40' :
                    'border-white/10'
                  }`}
                >
                  <img src={item.preview} alt="" className="w-full h-full object-cover" />

                  {/* Status overlay */}
                  {item.status === 'uploading' && (
                    <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
                      <Loader2 className="w-5 h-5 text-neon-cyan animate-spin" />
                    </div>
                  )}
                  {item.status === 'done' && (
                    <div className="absolute inset-0 bg-neon-green/10 flex items-center justify-center">
                      <div className="w-6 h-6 bg-neon-green rounded-full flex items-center justify-center">
                        <Check className="w-4 h-4 text-black" />
                      </div>
                    </div>
                  )}
                  {item.status === 'error' && (
                    <div className="absolute inset-0 bg-red-500/10 flex items-center justify-center">
                      <div className="w-6 h-6 bg-red-500 rounded-full flex items-center justify-center">
                        <AlertCircle className="w-4 h-4 text-white" />
                      </div>
                    </div>
                  )}

                  {/* Remove button */}
                  {item.status !== 'uploading' && (
                    <button
                      onClick={() => removeUpload(item.id)}
                      className="absolute top-1 right-1 p-0.5 bg-black/70 rounded-full text-gray-400 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  )}

                  {/* File size */}
                  <div className="absolute bottom-0.5 left-0.5 px-1 py-0.5 bg-black/70 rounded text-[8px] text-gray-400">
                    {(item.file.size / 1024).toFixed(0)}KB
                  </div>
                </div>
              ))}
            </div>

            {/* Upload button */}
            {pendingCount > 0 && (
              <button
                onClick={handleUploadAll}
                disabled={isUploading || !selectedVehicle}
                className="w-full py-3 bg-gradient-to-r from-neon-green to-neon-cyan text-black font-bold rounded-xl hover:opacity-90 transition-opacity disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2 text-sm shadow-lg shadow-neon-green/20"
              >
                {isUploading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Uploading {pendingCount} Photos...
                  </>
                ) : (
                  <>
                    <Upload className="w-4 h-4" />
                    Upload {pendingCount} Photo{pendingCount !== 1 ? 's' : ''} to {selectedVehicle ? `${selectedVehicle.year} ${selectedVehicle.make} ${selectedVehicle.model}` : 'Selected Vehicle'}
                  </>
                )}
              </button>
            )}

            {!selectedVehicle && pendingCount > 0 && (
              <p className="text-amber-400 text-xs text-center flex items-center justify-center gap-1">
                <AlertCircle className="w-3 h-3" />
                Select a vehicle above before uploading
              </p>
            )}
          </div>
        )}
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <QuickStat
          label="Vehicles with Real Photos"
          value={vehicles.filter(v => v.images && v.images.length > 0 && !v.images.every(img => img.includes('unsplash.com'))).length}
          total={vehicles.length}
          color="text-neon-green"
        />
        <QuickStat
          label="Total Real Photos"
          value={vehicles.reduce((sum, v) => sum + (v.images?.filter(img => !img.includes('unsplash.com')).length || 0), 0)}
          color="text-neon-cyan"
        />
        <QuickStat
          label="Stock Photos"
          value={totalStockPhotos}
          color="text-amber-400"
          warning={totalStockPhotos > 0}
        />
        <QuickStat
          label="No Photos"
          value={vehicles.filter(v => !v.images || v.images.length === 0).length}
          color="text-red-400"
        />
      </div>
    </div>
  );
};

const QuickStat: React.FC<{ label: string; value: number; total?: number; color: string; warning?: boolean }> = ({ label, value, total, color, warning }) => (
  <div className={`bg-white/[0.02] border rounded-xl p-4 ${warning ? 'border-amber-500/20' : 'border-white/5'}`}>
    <p className="text-gray-500 text-[11px] font-medium mb-1">{label}</p>
    <p className={`text-xl font-bold ${color}`}>
      {value}
      {total !== undefined && <span className="text-gray-600 text-sm font-normal">/{total}</span>}
    </p>
  </div>
);

export default BulkImageUploadPanel;
