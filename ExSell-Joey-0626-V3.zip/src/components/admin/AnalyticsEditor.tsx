import React, { useState } from 'react';
import {
  Save, Loader2, BarChart3, Code, ToggleLeft, ToggleRight,
  AlertCircle, Shield, CheckCircle, ExternalLink, Cookie, Eye, EyeOff,
  Info
} from 'lucide-react';
import type { AnalyticsConfig } from '@/data/homepageDefaults';

// ─── Helpers ───

const GA4_REGEX = /^G-[A-Z0-9]{6,12}$/i;
const GTM_REGEX = /^GTM-[A-Z0-9]{4,10}$/i;

const ValidationBadge: React.FC<{ value: string; pattern: RegExp; label: string }> = ({ value, pattern, label }) => {
  if (!value) return <span className="text-gray-600 text-[10px]">Not set</span>;
  const valid = pattern.test(value);
  return (
    <span className={`text-[10px] font-medium flex items-center gap-1 ${valid ? 'text-neon-green' : 'text-red-400'}`}>
      {valid ? <CheckCircle className="w-3 h-3" /> : <AlertCircle className="w-3 h-3" />}
      {valid ? `Valid ${label}` : `Invalid ${label} format`}
    </span>
  );
};

// ─── Main Editor ───

export const AnalyticsEditor: React.FC<{
  data: AnalyticsConfig;
  onChange: (d: AnalyticsConfig) => void;
  onSave: () => void;
  saving: boolean;
}> = ({ data, onChange, onSave, saving }) => {
  const [showPreview, setShowPreview] = useState(false);

  const ga4Valid = !data.ga4MeasurementId || GA4_REGEX.test(data.ga4MeasurementId);
  const gtmValid = !data.gtmContainerId || GTM_REGEX.test(data.gtmContainerId);
  const hasAnyId = !!data.ga4MeasurementId || !!data.gtmContainerId;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h3 className="text-white font-bold text-base mb-1 flex items-center gap-2">
          <BarChart3 className="w-4 h-4 text-neon-orange" />
          Google Analytics & Tag Manager
        </h3>
        <p className="text-gray-500 text-sm">
          Connect Google Analytics 4 (GA4) and Google Tag Manager (GTM) to track website traffic, user behavior, and conversions. Scripts are dynamically injected into every page.
        </p>
      </div>

      {/* Master Toggle */}
      <div className="bg-white/[0.02] border border-white/5 rounded-xl p-5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`p-2.5 rounded-xl transition-colors ${data.enabled ? 'bg-neon-green/10' : 'bg-white/5'}`}>
              <BarChart3 className={`w-5 h-5 transition-colors ${data.enabled ? 'text-neon-green' : 'text-gray-600'}`} />
            </div>
            <div>
              <h4 className="text-white font-bold text-sm">Analytics Tracking</h4>
              <p className="text-gray-500 text-xs mt-0.5">
                {data.enabled
                  ? 'Tracking is active — scripts will be injected on every page load'
                  : 'Tracking is disabled — no scripts will be loaded'}
              </p>
            </div>
          </div>
          <button
            onClick={() => onChange({ ...data, enabled: !data.enabled })}
            className={`relative flex items-center w-14 h-7 rounded-full transition-all duration-300 ${
              data.enabled
                ? 'bg-gradient-to-r from-neon-green to-emerald-500 shadow-lg shadow-neon-green/20'
                : 'bg-white/10'
            }`}
          >
            <span
              className={`absolute w-5 h-5 bg-white rounded-full shadow-md transition-all duration-300 ${
                data.enabled ? 'left-8' : 'left-1'
              }`}
            />
          </button>
        </div>

        {data.enabled && !hasAnyId && (
          <div className="mt-4 flex items-start gap-2.5 p-3 bg-neon-orange/5 border border-neon-orange/10 rounded-lg">
            <AlertCircle className="w-4 h-4 text-neon-orange flex-shrink-0 mt-0.5" />
            <p className="text-xs text-gray-400">
              <span className="text-neon-orange font-semibold">Tracking enabled but no IDs configured.</span>{' '}
              Enter a GA4 Measurement ID or GTM Container ID below to start collecting data.
            </p>
          </div>
        )}
      </div>

      {/* GA4 Configuration */}
      <div className="bg-white/[0.02] border border-white/5 rounded-xl p-5 space-y-4">
        <div className="flex items-center gap-3 pb-3 border-b border-white/5">
          <div className="p-2 bg-blue-500/10 rounded-lg">
            <BarChart3 className="w-4 h-4 text-blue-400" />
          </div>
          <div className="flex-1">
            <h4 className="text-white font-bold text-sm">Google Analytics 4 (GA4)</h4>
            <p className="text-gray-500 text-[10px]">Track page views, user sessions, events, and conversions</p>
          </div>
          <a
            href="https://analytics.google.com/"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1 text-[10px] text-gray-500 hover:text-blue-400 transition-colors"
          >
            Open GA4 <ExternalLink className="w-3 h-3" />
          </a>
        </div>

        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
              Measurement ID
            </label>
            <ValidationBadge value={data.ga4MeasurementId} pattern={GA4_REGEX} label="GA4 ID" />
          </div>
          <input
            value={data.ga4MeasurementId}
            onChange={(e) => onChange({ ...data, ga4MeasurementId: e.target.value.trim() })}
            className={`w-full px-4 py-3 bg-white/[0.03] border rounded-xl text-white text-sm placeholder-gray-600 focus:outline-none focus:ring-1 transition-all font-mono ${
              data.ga4MeasurementId && !ga4Valid
                ? 'border-red-500/30 focus:border-red-400 focus:ring-red-400/30'
                : 'border-white/10 focus:border-blue-400 focus:ring-blue-400/30'
            }`}
            placeholder="G-XXXXXXXXXX"
          />
          <p className="text-gray-600 text-[10px] mt-1.5">
            Find this in GA4 &rarr; Admin &rarr; Data Streams &rarr; Web &rarr; Measurement ID. Format: <code className="text-gray-500 bg-white/5 px-1 py-0.5 rounded">G-XXXXXXXXXX</code>
          </p>
        </div>
      </div>

      {/* GTM Configuration */}
      <div className="bg-white/[0.02] border border-white/5 rounded-xl p-5 space-y-4">
        <div className="flex items-center gap-3 pb-3 border-b border-white/5">
          <div className="p-2 bg-neon-cyan/10 rounded-lg">
            <Code className="w-4 h-4 text-neon-cyan" />
          </div>
          <div className="flex-1">
            <h4 className="text-white font-bold text-sm">Google Tag Manager (GTM)</h4>
            <p className="text-gray-500 text-[10px]">Manage all your marketing & analytics tags from one place</p>
          </div>
          <a
            href="https://tagmanager.google.com/"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1 text-[10px] text-gray-500 hover:text-neon-cyan transition-colors"
          >
            Open GTM <ExternalLink className="w-3 h-3" />
          </a>
        </div>

        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
              Container ID
            </label>
            <ValidationBadge value={data.gtmContainerId} pattern={GTM_REGEX} label="GTM ID" />
          </div>
          <input
            value={data.gtmContainerId}
            onChange={(e) => onChange({ ...data, gtmContainerId: e.target.value.trim() })}
            className={`w-full px-4 py-3 bg-white/[0.03] border rounded-xl text-white text-sm placeholder-gray-600 focus:outline-none focus:ring-1 transition-all font-mono ${
              data.gtmContainerId && !gtmValid
                ? 'border-red-500/30 focus:border-red-400 focus:ring-red-400/30'
                : 'border-white/10 focus:border-neon-cyan focus:ring-neon-cyan/30'
            }`}
            placeholder="GTM-XXXXXXX"
          />
          <p className="text-gray-600 text-[10px] mt-1.5">
            Find this in GTM &rarr; Admin &rarr; Container Settings &rarr; Container ID. Format: <code className="text-gray-500 bg-white/5 px-1 py-0.5 rounded">GTM-XXXXXXX</code>
          </p>
        </div>

        {data.ga4MeasurementId && data.gtmContainerId && (
          <div className="flex items-start gap-2.5 p-3 bg-blue-500/5 border border-blue-500/10 rounded-lg">
            <Info className="w-4 h-4 text-blue-400 flex-shrink-0 mt-0.5" />
            <p className="text-xs text-gray-400">
              <span className="text-blue-400 font-semibold">Tip:</span>{' '}
              If you're using GTM to manage your GA4 tag, you may not need to enter the GA4 Measurement ID here separately — GTM can handle it. Only enter both if you want GA4 loaded independently of GTM.
            </p>
          </div>
        )}
      </div>

      {/* Cookie Consent Toggle */}
      <div className="bg-white/[0.02] border border-white/5 rounded-xl p-5 space-y-4">
        <div className="flex items-center gap-3 pb-3 border-b border-white/5">
          <div className="p-2 bg-neon-pink/10 rounded-lg">
            <Cookie className="w-4 h-4 text-neon-pink" />
          </div>
          <div>
            <h4 className="text-white font-bold text-sm">Cookie Consent Compliance</h4>
            <p className="text-gray-500 text-[10px]">Control whether tracking respects the cookie consent banner</p>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex-1">
            <p className="text-white text-sm font-medium">Require Cookie Consent</p>
            <p className="text-gray-500 text-xs mt-0.5">
              {data.respectCookieConsent
                ? 'Tracking scripts will only load after the visitor accepts analytics cookies via the cookie consent banner.'
                : 'Tracking scripts will load immediately on every page, regardless of cookie consent status.'}
            </p>
          </div>
          <button
            onClick={() => onChange({ ...data, respectCookieConsent: !data.respectCookieConsent })}
            className={`relative flex items-center w-14 h-7 rounded-full transition-all duration-300 flex-shrink-0 ml-4 ${
              data.respectCookieConsent
                ? 'bg-gradient-to-r from-neon-pink to-rose-500 shadow-lg shadow-neon-pink/20'
                : 'bg-white/10'
            }`}
          >
            <span
              className={`absolute w-5 h-5 bg-white rounded-full shadow-md transition-all duration-300 ${
                data.respectCookieConsent ? 'left-8' : 'left-1'
              }`}
            />
          </button>
        </div>

        {/* Compliance Notice */}
        <div className="flex items-start gap-2.5 p-3 bg-neon-pink/5 border border-neon-pink/10 rounded-lg">
          <Shield className="w-4 h-4 text-neon-pink flex-shrink-0 mt-0.5" />
          <div className="text-xs text-gray-400 leading-relaxed">
            <span className="text-neon-pink font-semibold">GDPR / CCPA Notice:</span>{' '}
            If your website serves visitors in the EU, UK, or California, you are legally required to obtain consent before loading analytics or marketing cookies. We strongly recommend keeping "Require Cookie Consent" enabled. When enabled, GA4 and GTM scripts will only be injected after a visitor clicks "Accept All" or explicitly enables analytics cookies in the cookie settings modal. Disabling this setting may expose your business to regulatory risk.
          </div>
        </div>
      </div>

      {/* Script Preview */}
      <div className="bg-white/[0.02] border border-white/5 rounded-xl p-5 space-y-4">
        <button
          onClick={() => setShowPreview(!showPreview)}
          className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors text-sm font-medium w-full"
        >
          {showPreview ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
          <Code className="w-4 h-4" />
          {showPreview ? 'Hide' : 'Show'} Script Preview
        </button>

        {showPreview && (
          <div className="space-y-4">
            {/* GA4 Preview */}
            {data.ga4MeasurementId && ga4Valid && (
              <div>
                <label className="block text-[10px] font-semibold text-gray-500 uppercase tracking-wider mb-1.5">
                  GA4 Script (injected into &lt;head&gt;)
                </label>
                <pre className="bg-black/40 border border-white/5 rounded-lg p-3 text-[11px] text-gray-400 overflow-x-auto font-mono leading-relaxed">
{`<!-- Google Analytics 4 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=${data.ga4MeasurementId}"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', '${data.ga4MeasurementId}');
</script>`}
                </pre>
              </div>
            )}

            {/* GTM Preview */}
            {data.gtmContainerId && gtmValid && (
              <div>
                <label className="block text-[10px] font-semibold text-gray-500 uppercase tracking-wider mb-1.5">
                  GTM Script (injected into &lt;head&gt; + &lt;body&gt;)
                </label>
                <pre className="bg-black/40 border border-white/5 rounded-lg p-3 text-[11px] text-gray-400 overflow-x-auto font-mono leading-relaxed">
{`<!-- Google Tag Manager (head) -->
<script>
  (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
  new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
  j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
  'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
  })(window,document,'script','dataLayer','${data.gtmContainerId}');
</script>

<!-- Google Tag Manager (body, noscript) -->
<noscript>
  <iframe src="https://www.googletagmanager.com/ns.html?id=${data.gtmContainerId}"
    height="0" width="0" style="display:none;visibility:hidden"></iframe>
</noscript>`}
                </pre>
              </div>
            )}

            {!data.ga4MeasurementId && !data.gtmContainerId && (
              <p className="text-gray-600 text-xs italic">No tracking IDs configured — nothing to preview.</p>
            )}
          </div>
        )}
      </div>

      {/* Status Summary */}
      <div className="bg-white/[0.02] border border-white/5 rounded-xl p-5">
        <h4 className="text-white font-bold text-sm mb-3 flex items-center gap-2">
          <CheckCircle className="w-4 h-4 text-neon-green" />
          Configuration Summary
        </h4>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <div className="bg-white/[0.02] rounded-lg p-3 text-center">
            <div className={`text-lg font-bold ${data.enabled ? 'text-neon-green' : 'text-gray-600'}`}>
              {data.enabled ? 'ON' : 'OFF'}
            </div>
            <div className="text-gray-500 text-[10px] mt-0.5">Tracking</div>
          </div>
          <div className="bg-white/[0.02] rounded-lg p-3 text-center">
            <div className={`text-lg font-bold font-mono ${data.ga4MeasurementId && ga4Valid ? 'text-blue-400' : 'text-gray-600'}`}>
              {data.ga4MeasurementId ? (ga4Valid ? 'SET' : 'ERR') : '---'}
            </div>
            <div className="text-gray-500 text-[10px] mt-0.5">GA4</div>
          </div>
          <div className="bg-white/[0.02] rounded-lg p-3 text-center">
            <div className={`text-lg font-bold font-mono ${data.gtmContainerId && gtmValid ? 'text-neon-cyan' : 'text-gray-600'}`}>
              {data.gtmContainerId ? (gtmValid ? 'SET' : 'ERR') : '---'}
            </div>
            <div className="text-gray-500 text-[10px] mt-0.5">GTM</div>
          </div>
          <div className="bg-white/[0.02] rounded-lg p-3 text-center">
            <div className={`text-lg font-bold ${data.respectCookieConsent ? 'text-neon-pink' : 'text-gray-600'}`}>
              {data.respectCookieConsent ? 'YES' : 'NO'}
            </div>
            <div className="text-gray-500 text-[10px] mt-0.5">Consent</div>
          </div>
        </div>
      </div>

      {/* How It Works */}
      <div className="flex items-start gap-3 p-4 bg-blue-500/5 border border-blue-500/10 rounded-xl">
        <Info className="w-4 h-4 text-blue-400 flex-shrink-0 mt-0.5" />
        <div className="text-xs text-gray-400 leading-relaxed space-y-1.5">
          <p><strong className="text-blue-400">How it works:</strong></p>
          <ul className="list-disc list-inside space-y-1 text-gray-500">
            <li>When tracking is <strong className="text-white">enabled</strong>, the GA4 and/or GTM scripts are dynamically injected into the <code className="text-gray-400 bg-white/5 px-1 py-0.5 rounded">&lt;head&gt;</code> of every page.</li>
            <li>If "Require Cookie Consent" is on, scripts only load after the visitor accepts analytics cookies.</li>
            <li>Page views are automatically tracked on every route change (SPA-compatible).</li>
            <li>When tracking is <strong className="text-white">disabled</strong>, all injected scripts are removed and no data is collected.</li>
            <li>Changes take effect immediately after saving — no code deployment needed.</li>
          </ul>
        </div>
      </div>

      {/* Save */}
      <div className="flex justify-end pt-4 border-t border-white/5">
        <button
          onClick={onSave}
          disabled={saving || (!ga4Valid) || (!gtmValid)}
          className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-neon-cyan to-blue-500 text-white font-bold rounded-xl hover:opacity-90 transition-opacity disabled:opacity-50 shadow-lg shadow-neon-cyan/20"
        >
          {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
          Save Analytics Settings
        </button>
      </div>
    </div>
  );
};

export default AnalyticsEditor;
