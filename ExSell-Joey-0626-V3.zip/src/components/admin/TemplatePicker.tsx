import React, { useState, useMemo } from 'react';
import {
  Search, Car, Truck, Zap, ChevronRight, Star, X,
  Layers, Filter
} from 'lucide-react';
import {
  VehicleTemplate, TemplateCategory, VEHICLE_TEMPLATES,
  getPopularTemplates, getTemplateCategories
} from '@/data/vehicleTemplates';

interface TemplatePickerProps {
  onSelect: (template: VehicleTemplate) => void;
  onSkip: () => void;
}

const CATEGORY_ICONS: Record<TemplateCategory, React.ElementType> = {
  SUV: Car,
  Sedan: Car,
  Truck: Truck,
  Coupe: Car,
  Van: Car,
  Hatchback: Car,
  Convertible: Car,
  Wagon: Car,
  Minivan: Car,
  Sports: Zap,
};

const CATEGORY_COLORS: Record<TemplateCategory, string> = {
  SUV: 'from-blue-500/20 to-cyan-500/20 border-blue-500/30 text-blue-300',
  Sedan: 'from-purple-500/20 to-pink-500/20 border-purple-500/30 text-purple-300',
  Truck: 'from-amber-500/20 to-orange-500/20 border-amber-500/30 text-amber-300',
  Coupe: 'from-red-500/20 to-pink-500/20 border-red-500/30 text-red-300',
  Van: 'from-green-500/20 to-emerald-500/20 border-green-500/30 text-green-300',
  Hatchback: 'from-teal-500/20 to-cyan-500/20 border-teal-500/30 text-teal-300',
  Convertible: 'from-yellow-500/20 to-amber-500/20 border-yellow-500/30 text-yellow-300',
  Wagon: 'from-indigo-500/20 to-blue-500/20 border-indigo-500/30 text-indigo-300',
  Minivan: 'from-emerald-500/20 to-green-500/20 border-emerald-500/30 text-emerald-300',
  Sports: 'from-red-500/20 to-orange-500/20 border-red-500/30 text-red-300',
};

const TemplatePicker: React.FC<TemplatePickerProps> = ({ onSelect, onSkip }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<TemplateCategory | null>(null);
  const [hoveredTemplate, setHoveredTemplate] = useState<string | null>(null);

  const categories = useMemo(() => getTemplateCategories(), []);
  const popularTemplates = useMemo(() => getPopularTemplates(), []);

  const filteredTemplates = useMemo(() => {
    let results = VEHICLE_TEMPLATES;

    if (selectedCategory) {
      results = results.filter(t => t.category === selectedCategory);
    }

    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      results = results.filter(t =>
        `${t.make} ${t.model} ${t.trim} ${t.engine} ${t.bodyType}`.toLowerCase().includes(q)
      );
    }

    return results;
  }, [searchQuery, selectedCategory]);

  // Group templates by make
  const groupedTemplates = useMemo(() => {
    const groups: Record<string, VehicleTemplate[]> = {};
    filteredTemplates.forEach(t => {
      if (!groups[t.make]) groups[t.make] = [];
      groups[t.make].push(t);
    });
    return Object.entries(groups).sort(([a], [b]) => a.localeCompare(b));
  }, [filteredTemplates]);

  const showPopular = !searchQuery && !selectedCategory;

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-neon-cyan to-neon-green flex items-center justify-center flex-shrink-0">
            <Layers className="w-5 h-5 text-black" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              Quick Add from Template
              <span className="px-1.5 py-0.5 bg-neon-green/20 text-neon-green text-[10px] font-bold rounded-full uppercase tracking-wider">Fast</span>
            </h3>
            <p className="text-xs text-gray-400 mt-0.5">
              Pick a vehicle template to auto-fill specs, then just add year, price, mileage & photos
            </p>
          </div>
        </div>
        <button
          onClick={onSkip}
          className="text-xs text-gray-500 hover:text-white transition-colors flex items-center gap-1"
        >
          Skip
          <ChevronRight className="w-3 h-3" />
        </button>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search templates... (e.g. Toyota Camry, Honda CR-V, Jeep)"
          autoFocus
          className="w-full pl-10 pr-4 py-3 bg-black/60 border border-white/10 rounded-xl text-white text-sm placeholder-gray-600 focus:border-neon-cyan focus:outline-none focus:ring-1 focus:ring-neon-cyan/30 transition-all"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Category Filters */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 thin-scrollbar">
        <div className="flex items-center gap-1 text-gray-500 flex-shrink-0">
          <Filter className="w-3.5 h-3.5" />
        </div>
        <button
          onClick={() => setSelectedCategory(null)}
          className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all whitespace-nowrap ${
            !selectedCategory
              ? 'bg-white/10 text-white border border-white/20'
              : 'text-gray-500 hover:text-gray-300 hover:bg-white/[0.03]'
          }`}
        >
          All ({VEHICLE_TEMPLATES.length})
        </button>
        {categories.map(cat => {
          const count = VEHICLE_TEMPLATES.filter(t => t.category === cat).length;
          const Icon = CATEGORY_ICONS[cat] || Car;
          return (
            <button
              key={cat}
              onClick={() => setSelectedCategory(selectedCategory === cat ? null : cat)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all whitespace-nowrap ${
                selectedCategory === cat
                  ? `bg-gradient-to-r ${CATEGORY_COLORS[cat]} border`
                  : 'text-gray-500 hover:text-gray-300 hover:bg-white/[0.03]'
              }`}
            >
              <Icon className="w-3 h-3" />
              {cat}
              <span className="opacity-60">({count})</span>
            </button>
          );
        })}
      </div>

      {/* Popular Templates */}
      {showPopular && (
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Star className="w-3.5 h-3.5 text-neon-orange" />
            <span className="text-[11px] text-gray-400 font-semibold uppercase tracking-wider">Popular Templates</span>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
            {popularTemplates.map(template => (
              <TemplateCard
                key={template.id}
                template={template}
                isHovered={hoveredTemplate === template.id}
                onHover={() => setHoveredTemplate(template.id)}
                onLeave={() => setHoveredTemplate(null)}
                onSelect={() => onSelect(template)}
                compact
              />
            ))}
          </div>
        </div>
      )}

      {/* All Templates (grouped by make) */}
      <div className="space-y-4 max-h-[400px] overflow-y-auto pr-1 thin-scrollbar">
        {groupedTemplates.length === 0 ? (
          <div className="py-8 text-center">
            <Car className="w-8 h-8 text-gray-700 mx-auto mb-2" />
            <p className="text-gray-500 text-sm">No templates match your search</p>
            <p className="text-gray-600 text-xs mt-1">Try a different search term or clear filters</p>
          </div>
        ) : (
          groupedTemplates.map(([make, templates]) => (
            <div key={make}>
              <div className="flex items-center gap-2 mb-2">
                <span className="text-xs text-gray-400 font-bold uppercase tracking-wider">{make}</span>
                <div className="flex-1 h-px bg-white/5" />
                <span className="text-[10px] text-gray-600">{templates.length} template{templates.length !== 1 ? 's' : ''}</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {templates.map(template => (
                  <TemplateCard
                    key={template.id}
                    template={template}
                    isHovered={hoveredTemplate === template.id}
                    onHover={() => setHoveredTemplate(template.id)}
                    onLeave={() => setHoveredTemplate(null)}
                    onSelect={() => onSelect(template)}
                  />
                ))}
              </div>
            </div>
          ))
        )}
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between pt-2 border-t border-white/5">
        <p className="text-[11px] text-gray-600">
          {filteredTemplates.length} template{filteredTemplates.length !== 1 ? 's' : ''} available
        </p>
        <button
          onClick={onSkip}
          className="text-xs text-gray-500 hover:text-neon-cyan transition-colors flex items-center gap-1"
        >
          Or start with a blank form
          <ChevronRight className="w-3 h-3" />
        </button>
      </div>
    </div>
  );
};

// Template Card Component
const TemplateCard: React.FC<{
  template: VehicleTemplate;
  isHovered: boolean;
  onHover: () => void;
  onLeave: () => void;
  onSelect: () => void;
  compact?: boolean;
}> = ({ template, isHovered, onHover, onLeave, onSelect, compact }) => {
  const catColor = CATEGORY_COLORS[template.category] || 'text-gray-300';

  if (compact) {
    return (
      <button
        onClick={onSelect}
        onMouseEnter={onHover}
        onMouseLeave={onLeave}
        className={`text-left p-3 rounded-xl border transition-all ${
          isHovered
            ? 'bg-neon-cyan/5 border-neon-cyan/30 scale-[1.02]'
            : 'bg-white/[0.02] border-white/5 hover:border-white/10'
        }`}
      >
        <div className="flex items-center gap-2 mb-1">
          <span className="text-white text-xs font-bold truncate">{template.make} {template.model}</span>
          {template.popular && (
            <Star className="w-3 h-3 text-neon-orange fill-neon-orange flex-shrink-0" />
          )}
        </div>
        <div className="flex items-center gap-2 text-[10px] text-gray-500">
          <span>{template.trim}</span>
          <span className="text-gray-700">|</span>
          <span>{template.bodyType}</span>
        </div>
      </button>
    );
  }

  return (
    <button
      onClick={onSelect}
      onMouseEnter={onHover}
      onMouseLeave={onLeave}
      className={`text-left p-3.5 rounded-xl border transition-all w-full ${
        isHovered
          ? 'bg-neon-cyan/5 border-neon-cyan/30 scale-[1.01]'
          : 'bg-white/[0.02] border-white/5 hover:border-white/10'
      }`}
    >
      <div className="flex items-start justify-between gap-2">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-white text-sm font-bold">{template.model}</span>
            <span className="text-gray-500 text-xs">{template.trim}</span>
            {template.popular && (
              <Star className="w-3 h-3 text-neon-orange fill-neon-orange flex-shrink-0" />
            )}
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-[10px] text-gray-500">{template.engine}</span>
            <span className="text-gray-700 text-[10px]">/</span>
            <span className="text-[10px] text-gray-500">{template.transmission}</span>
            <span className="text-gray-700 text-[10px]">/</span>
            <span className="text-[10px] text-gray-500">{template.drivetrain}</span>
          </div>
          <div className="flex items-center gap-1.5 mt-1.5 flex-wrap">
            {template.features.slice(0, 3).map((f, i) => (
              <span key={i} className="px-1.5 py-0.5 bg-white/[0.04] border border-white/5 rounded text-[9px] text-gray-500">
                {f}
              </span>
            ))}
            {template.features.length > 3 && (
              <span className="text-[9px] text-gray-600">+{template.features.length - 3}</span>
            )}
          </div>
        </div>
        <div className={`px-2 py-1 rounded-lg text-[10px] font-bold bg-gradient-to-r ${catColor} border flex-shrink-0`}>
          {template.bodyType}
        </div>
      </div>
      {isHovered && (
        <div className="mt-2 pt-2 border-t border-white/5 flex items-center justify-between">
          <span className="text-[10px] text-neon-cyan font-medium">Click to use this template</span>
          <ChevronRight className="w-3 h-3 text-neon-cyan" />
        </div>
      )}
    </button>
  );
};

export default TemplatePicker;
