import React, { useState, useCallback, useEffect, useRef } from 'react';
import { Vehicle, fetchVehicles, isUsingFallbackData } from '@/data/vehicles';
import { usePageSEO } from '@/hooks/usePageSEO';
import { useReviewsJsonLd } from '@/hooks/useReviewsJsonLd';

import Navbar from './dealership/Navbar';
import HeroSection from './dealership/HeroSection';
import InventorySection from './dealership/InventorySection';
import ServicesSection from './dealership/ServicesSection';
import TradeInSection from './dealership/TradeInSection';
import WhyChooseUs from './dealership/WhyChooseUs';
import TestimonialsSection from './dealership/TestimonialsSection';
import ContactSection from './dealership/ContactSection';
import Footer from './dealership/Footer';
import FloatingCTA from './dealership/FloatingCTA';
import MobileCallBar from './dealership/MobileCallBar';
import TestDriveModal from './dealership/TestDriveModal';
import ComparisonTray from './dealership/ComparisonTray';
import CookieConsentBanner from './dealership/CookieConsentBanner';
import JoeyMascot from './dealership/JoeyMascot';
import FallbackBanner from './dealership/FallbackBanner';



const AppLayout: React.FC = () => {
  usePageSEO('homepage');
  useReviewsJsonLd({ pagePath: '/' });
  const [favorites, setFavorites] = useState<Set<number>>(new Set());


  const [testDriveVehicle, setTestDriveVehicle] = useState<Vehicle | null>(null);
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [vehiclesLoading, setVehiclesLoading] = useState(true);
  const [usingFallback, setUsingFallback] = useState(false);
  const [retrying, setRetrying] = useState(false);
  const pollIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Load favorites from localStorage
  useEffect(() => {
    try {
      const saved = JSON.parse(localStorage.getItem('exsell-favorites') || '[]');
      if (Array.isArray(saved)) {
        setFavorites(new Set(saved));
      }
    } catch {}
  }, []);

  // Fetch vehicles from database on mount
  const loadVehicles = useCallback(async () => {
    setVehiclesLoading(true);
    try {
      const data = await fetchVehicles();
      setVehicles(data);
      setUsingFallback(isUsingFallbackData());
    } catch (err) {
      console.error('Failed to load vehicles:', err);
      setUsingFallback(true);
    } finally {
      setVehiclesLoading(false);
    }
  }, []);

  useEffect(() => {
    loadVehicles();
  }, [loadVehicles]);

  // Retry handler
  const handleRetry = useCallback(async () => {
    setRetrying(true);
    try {
      const data = await fetchVehicles();
      setVehicles(data);
      setUsingFallback(isUsingFallbackData());
    } catch {
      setUsingFallback(true);
    } finally {
      setRetrying(false);
    }
  }, []);

  // Poll for vehicle changes every 30 seconds
  useEffect(() => {
    pollIntervalRef.current = setInterval(() => {
      fetchVehicles().then((data) => {
        setVehicles(data);
        setUsingFallback(isUsingFallbackData());
      }).catch(() => {});
    }, 30000);

    return () => {
      if (pollIntervalRef.current) {
        clearInterval(pollIntervalRef.current);
      }
    };
  }, []);


  const toggleFavorite = useCallback((id: number) => {
    setFavorites((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      localStorage.setItem('exsell-favorites', JSON.stringify(Array.from(next)));
      return next;
    });
  }, []);

  const handleScheduleTestDrive = useCallback((vehicle: Vehicle) => {
    setTestDriveVehicle(vehicle);
    document.body.style.overflow = 'hidden';
  }, []);

  const handleCloseTestDrive = useCallback(() => {
    setTestDriveVehicle(null);
    document.body.style.overflow = '';
  }, []);

  // Filter out sold vehicles for the public inventory display
  const availableVehicles = vehicles.filter(v => v.status !== 'sold');

  return (
    <div className="min-h-screen bg-black text-white">
      <Navbar />
      <HeroSection />

      {/* Show fallback banner if database is unavailable */}
      {usingFallback && !vehiclesLoading && (
        <FallbackBanner onRetry={handleRetry} retrying={retrying} context="inventory" />
      )}

      <InventorySection
        vehicles={availableVehicles}
        loading={vehiclesLoading}
        favorites={favorites}
        onToggleFavorite={toggleFavorite}
        onScheduleTestDrive={handleScheduleTestDrive}
      />

      <ServicesSection />
      <TradeInSection />
      <WhyChooseUs />

      <TestimonialsSection />
      <ContactSection />
      <Footer />
      <FloatingCTA />
      <MobileCallBar />
      <ComparisonTray />

      {/* Test Drive Modal */}
      {testDriveVehicle && (
        <TestDriveModal
          vehicle={testDriveVehicle}
          onClose={handleCloseTestDrive}
        />
      )}

      {/* Cookie Consent Banner */}
      <CookieConsentBanner />

      {/* Joey Mascot Guide */}
      <JoeyMascot />
    </div>


  );
};

export default AppLayout;
