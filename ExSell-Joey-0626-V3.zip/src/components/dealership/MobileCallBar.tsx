import React, { useState, useEffect } from 'react';
import { Phone, MessageSquare, PhoneCall } from 'lucide-react';
import { useCompare } from '@/contexts/CompareContext';
import { trackConversion } from '@/hooks/useAnalytics';
import { getOpenStatus, type OpenStatus } from '@/lib/businessHours';
import CallbackModal from './CallbackModal';

const PHONE = '6313884426';

/**
 * Fixed bottom call-to-action bar shown only on mobile (below the lg breakpoint).
 * Gives phone visitors a persistent, one-tap way to call, text, or request a
 * callback from the dealership, plus a live open/closed status indicator.
 */
const MobileCallBar: React.FC = () => {
  const { compareList } = useCompare();
  const [status, setStatus] = useState<OpenStatus>(() => getOpenStatus());
  const [callbackOpen, setCallbackOpen] = useState(false);

  // Re-evaluate open/closed status every minute so it stays accurate.
  useEffect(() => {
    const tick = () => setStatus(getOpenStatus());
    tick();
    const id = setInterval(tick, 60_000);
    return () => clearInterval(id);
  }, []);

  // Slide above the comparison tray when it's visible so nothing overlaps.
  const bottomClass = compareList.length > 0 ? 'bottom-20' : 'bottom-0';

  return (
    <>
      <div
        className={`lg:hidden fixed ${bottomClass} inset-x-0 z-50 transition-all duration-300`}
        style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
      >
        <div className="bg-black/90 backdrop-blur-md border-t border-white/10 shadow-[0_-4px_20px_rgba(0,0,0,0.5)]">
          {/* Open / closed status strip */}
          <div className="flex items-center justify-center gap-2 pt-2 pb-0.5">
            <span
              className={`inline-block w-2 h-2 rounded-full ${
                status.isOpen ? 'bg-neon-green animate-pulse' : 'bg-gray-500'
              }`}
            />
            <span
              className={`text-xs font-semibold ${
                status.isOpen ? 'text-neon-green' : 'text-gray-400'
              }`}
            >
              {status.label}
            </span>
            {status.isOpen && (
              <span className="text-xs text-gray-500">· {status.detail}</span>
            )}
          </div>

          {/* Action buttons */}
          <div className="flex items-stretch gap-2 px-3 py-2.5">
            <a
              href={`tel:${PHONE}`}
              onClick={() => trackConversion('call_click', { source: 'mobile_bar' })}
              className="flex-1 flex items-center justify-center gap-1.5 py-3 rounded-xl bg-gradient-to-r from-neon-green to-emerald-400 text-black font-extrabold text-sm shadow-lg shadow-neon-green/20 active:scale-[0.98] transition-transform"
              aria-label="Call the dealership now"
            >
              <Phone className="w-5 h-5" />
              <span className="whitespace-nowrap">Call</span>
            </a>
            <a
              href={`sms:${PHONE}`}
              onClick={() => trackConversion('text_click', { source: 'mobile_bar' })}
              className="flex-1 flex items-center justify-center gap-1.5 py-3 rounded-xl bg-gradient-to-r from-neon-cyan to-sky-400 text-black font-extrabold text-sm shadow-lg shadow-neon-cyan/20 active:scale-[0.98] transition-transform"
              aria-label="Send a text message to the dealership"
            >
              <MessageSquare className="w-5 h-5" />
              <span className="whitespace-nowrap">Text</span>
            </a>
            <button
              onClick={() => setCallbackOpen(true)}
              className="flex-1 flex items-center justify-center gap-1.5 py-3 rounded-xl bg-gradient-to-r from-neon-orange to-neon-pink text-white font-extrabold text-sm shadow-lg shadow-neon-orange/20 active:scale-[0.98] transition-transform"
              aria-label="Request a callback from the dealership"
            >
              <PhoneCall className="w-5 h-5" />
              <span className="whitespace-nowrap">Callback</span>
            </button>
          </div>
        </div>
      </div>

      <CallbackModal
        open={callbackOpen}
        onClose={() => setCallbackOpen(false)}
        source="mobile_bar"
      />
    </>
  );
};

export default MobileCallBar;
