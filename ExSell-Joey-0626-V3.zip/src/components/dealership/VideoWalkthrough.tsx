import React, { useState, useRef, useCallback } from 'react';
import { Play, Pause, Maximize2, Volume2, VolumeX, RotateCcw, ExternalLink, X, Video } from 'lucide-react';

interface VideoWalkthroughProps {
  videoUrl: string;
  vehicleTitle: string;
  posterImage?: string;
}

// Detect video type from URL
function getVideoType(url: string): 'youtube' | 'vimeo' | 'direct' | 'unknown' {
  if (url.includes('youtube.com') || url.includes('youtu.be')) return 'youtube';
  if (url.includes('vimeo.com')) return 'vimeo';
  if (url.match(/\.(mp4|webm|ogg|mov)(\?|$)/i)) return 'direct';
  return 'unknown';
}

// Extract YouTube video ID
function getYouTubeId(url: string): string | null {
  const match = url.match(/(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/);
  return match ? match[1] : null;
}

// Extract Vimeo video ID
function getVimeoId(url: string): string | null {
  const match = url.match(/vimeo\.com\/(\d+)/);
  return match ? match[1] : null;
}

const VideoWalkthrough: React.FC<VideoWalkthroughProps> = ({ videoUrl, vehicleTitle, posterImage }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [showVideo, setShowVideo] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const videoType = getVideoType(videoUrl);
  const youtubeId = videoType === 'youtube' ? getYouTubeId(videoUrl) : null;
  const vimeoId = videoType === 'vimeo' ? getVimeoId(videoUrl) : null;

  const handlePlayDirect = useCallback(() => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  }, [isPlaying]);

  const handleMuteToggle = useCallback(() => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  }, [isMuted]);

  const handleRestart = useCallback(() => {
    if (videoRef.current) {
      videoRef.current.currentTime = 0;
      videoRef.current.play();
      setIsPlaying(true);
    }
  }, []);

  const handleFullscreen = useCallback(() => {
    if (containerRef.current) {
      if (!document.fullscreenElement) {
        containerRef.current.requestFullscreen().catch(() => {});
        setIsFullscreen(true);
      } else {
        document.exitFullscreen().catch(() => {});
        setIsFullscreen(false);
      }
    }
  }, []);

  // YouTube / Vimeo embed
  if (videoType === 'youtube' && youtubeId) {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-xl font-bold text-white flex items-center gap-2">
            <Video className="w-5 h-5 text-neon-pink" />
            Video Walkthrough
          </h3>
          <a
            href={videoUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 text-sm text-gray-400 hover:text-neon-cyan transition-colors"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            Open in YouTube
          </a>
        </div>

        {!showVideo ? (
          <button
            onClick={() => setShowVideo(true)}
            className="relative w-full aspect-video rounded-2xl overflow-hidden border border-white/10 group cursor-pointer"
          >
            {/* YouTube thumbnail */}
            <img
              src={posterImage || `https://img.youtube.com/vi/${youtubeId}/maxresdefault.jpg`}
              alt={`${vehicleTitle} video walkthrough`}
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-black/40 group-hover:bg-black/30 transition-colors" />
            
            {/* Play button */}
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <div className="w-20 h-20 bg-gradient-to-br from-neon-pink to-neon-orange rounded-full flex items-center justify-center video-pulse group-hover:scale-110 transition-transform">
                <Play className="w-8 h-8 text-white ml-1" fill="white" />
              </div>
              <p className="text-white font-bold text-lg mt-4 drop-shadow-lg">Watch Video Walkthrough</p>
              <p className="text-gray-300 text-sm mt-1 drop-shadow-lg">Full interior & exterior tour</p>
            </div>

            {/* Video badge */}
            <div className="absolute top-4 left-4 flex items-center gap-2 px-3 py-1.5 bg-neon-pink/90 text-white text-xs font-bold rounded-full">
              <Video className="w-3.5 h-3.5" />
              VIDEO
            </div>
          </button>
        ) : (
          <div className="relative w-full aspect-video rounded-2xl overflow-hidden border border-white/10">
            <iframe
              src={`https://www.youtube.com/embed/${youtubeId}?autoplay=1&rel=0&modestbranding=1`}
              title={`${vehicleTitle} video walkthrough`}
              className="w-full h-full"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
            <button
              onClick={() => setShowVideo(false)}
              className="absolute top-3 right-3 p-2 bg-black/60 backdrop-blur-sm rounded-full text-white hover:bg-black/80 transition-colors z-10"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        <p className="text-gray-500 text-sm">
          Take a virtual tour of this {vehicleTitle}. See every angle, interior details, and more.
        </p>
      </div>
    );
  }

  // Vimeo embed
  if (videoType === 'vimeo' && vimeoId) {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-xl font-bold text-white flex items-center gap-2">
            <Video className="w-5 h-5 text-neon-pink" />
            Video Walkthrough
          </h3>
        </div>

        {!showVideo ? (
          <button
            onClick={() => setShowVideo(true)}
            className="relative w-full aspect-video rounded-2xl overflow-hidden border border-white/10 group cursor-pointer bg-[#0a0a0a]"
          >
            {posterImage && (
              <img
                src={posterImage}
                alt={`${vehicleTitle} video`}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
            )}
            <div className="absolute inset-0 bg-black/40 group-hover:bg-black/30 transition-colors" />
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <div className="w-20 h-20 bg-gradient-to-br from-neon-pink to-neon-orange rounded-full flex items-center justify-center video-pulse group-hover:scale-110 transition-transform">
                <Play className="w-8 h-8 text-white ml-1" fill="white" />
              </div>
              <p className="text-white font-bold text-lg mt-4">Watch Video Walkthrough</p>
            </div>
          </button>
        ) : (
          <div className="relative w-full aspect-video rounded-2xl overflow-hidden border border-white/10">
            <iframe
              src={`https://player.vimeo.com/video/${vimeoId}?autoplay=1`}
              title={`${vehicleTitle} video`}
              className="w-full h-full"
              allow="autoplay; fullscreen; picture-in-picture"
              allowFullScreen
            />
            <button
              onClick={() => setShowVideo(false)}
              className="absolute top-3 right-3 p-2 bg-black/60 backdrop-blur-sm rounded-full text-white hover:bg-black/80 transition-colors z-10"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    );
  }

  // Direct video file (mp4, webm, etc.)
  if (videoType === 'direct') {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-xl font-bold text-white flex items-center gap-2">
            <Video className="w-5 h-5 text-neon-pink" />
            Video Walkthrough
          </h3>
        </div>

        <div ref={containerRef} className="relative w-full aspect-video rounded-2xl overflow-hidden border border-white/10 bg-[#0a0a0a] group">
          <video
            ref={videoRef}
            src={videoUrl}
            poster={posterImage}
            className="w-full h-full object-contain"
            playsInline
            onPlay={() => setIsPlaying(true)}
            onPause={() => setIsPlaying(false)}
            onEnded={() => setIsPlaying(false)}
            onClick={handlePlayDirect}
          />

          {/* Play overlay when not playing */}
          {!isPlaying && (
            <button
              onClick={handlePlayDirect}
              className="absolute inset-0 flex flex-col items-center justify-center bg-black/30"
            >
              <div className="w-20 h-20 bg-gradient-to-br from-neon-pink to-neon-orange rounded-full flex items-center justify-center video-pulse hover:scale-110 transition-transform">
                <Play className="w-8 h-8 text-white ml-1" fill="white" />
              </div>
              <p className="text-white font-bold text-lg mt-4">Play Video Walkthrough</p>
            </button>
          )}

          {/* Controls bar */}
          <div className="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <button
                  onClick={handlePlayDirect}
                  className="p-2 text-white hover:text-neon-pink transition-colors"
                >
                  {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
                </button>
                <button
                  onClick={handleRestart}
                  className="p-2 text-white hover:text-neon-cyan transition-colors"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>
                <button
                  onClick={handleMuteToggle}
                  className="p-2 text-white hover:text-neon-green transition-colors"
                >
                  {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                </button>
              </div>
              <button
                onClick={handleFullscreen}
                className="p-2 text-white hover:text-neon-orange transition-colors"
              >
                <Maximize2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        <p className="text-gray-500 text-sm">
          Take a virtual tour of this {vehicleTitle}. See every angle, interior details, and more.
        </p>
      </div>
    );
  }

  // Unknown/generic URL - try to open externally or embed as iframe
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-xl font-bold text-white flex items-center gap-2">
          <Video className="w-5 h-5 text-neon-pink" />
          Video Walkthrough
        </h3>
      </div>

      {!showVideo ? (
        <button
          onClick={() => setShowVideo(true)}
          className="relative w-full aspect-video rounded-2xl overflow-hidden border border-white/10 group cursor-pointer bg-[#0a0a0a]"
        >
          {posterImage && (
            <img
              src={posterImage}
              alt={`${vehicleTitle} video`}
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
            />
          )}
          <div className="absolute inset-0 bg-black/40 group-hover:bg-black/30 transition-colors flex flex-col items-center justify-center">
            <div className="w-20 h-20 bg-gradient-to-br from-neon-pink to-neon-orange rounded-full flex items-center justify-center video-pulse group-hover:scale-110 transition-transform">
              <Play className="w-8 h-8 text-white ml-1" fill="white" />
            </div>
            <p className="text-white font-bold text-lg mt-4">Watch Video Walkthrough</p>
            <p className="text-gray-300 text-sm mt-1">Full interior & exterior tour</p>
          </div>
        </button>
      ) : (
        <div className="relative w-full aspect-video rounded-2xl overflow-hidden border border-white/10">
          <iframe
            src={videoUrl}
            title={`${vehicleTitle} video walkthrough`}
            className="w-full h-full"
            allow="autoplay; fullscreen; picture-in-picture"
            allowFullScreen
          />
          <button
            onClick={() => setShowVideo(false)}
            className="absolute top-3 right-3 p-2 bg-black/60 backdrop-blur-sm rounded-full text-white hover:bg-black/80 transition-colors z-10"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      <div className="flex items-center gap-3">
        <a
          href={videoUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-1.5 text-sm text-neon-cyan hover:text-neon-cyan/80 transition-colors"
        >
          <ExternalLink className="w-3.5 h-3.5" />
          Open video in new tab
        </a>
      </div>
    </div>
  );
};

export default VideoWalkthrough;
