import React from 'react';
import { AlertTriangle, Database, RefreshCw, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

interface FallbackBannerProps {
  onRetry?: () => void;
  retrying?: boolean;
  context?: 'inventory' | 'sold';
}

const FallbackBanner: React.FC<FallbackBannerProps> = ({ onRetry, retrying = false, context = 'inventory' }) => {
  return (
    <div className="max-w-7xl mx-auto px-4 mb-6">
      <div className="relative overflow-hidden rounded-xl bg-gradient-to-r from-amber-500/10 via-orange-500/10 to-amber-500/10 border border-amber-500/20 p-4 md:p-5">
        <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/5 rounded-full blur-2xl -translate-y-1/2 translate-x-1/2" />
        <div className="relative flex flex-col md:flex-row items-start md:items-center gap-3 md:gap-4">
          <div className="flex items-center gap-3 flex-1">
            <div className="p-2.5 bg-amber-500/10 rounded-lg flex-shrink-0">
              <AlertTriangle className="w-5 h-5 text-amber-400" />
            </div>
            <div>
              <h3 className="text-amber-300 font-bold text-sm">Showing Sample Data</h3>
              <p className="text-amber-400/70 text-xs mt-0.5 leading-relaxed">
                {context === 'sold'
                  ? 'Could not connect to the database. The sold list below is sample data. Your actual sold vehicles are stored in the database.'
                  : 'Could not connect to the database. The inventory below is sample data. Your actual vehicles are managed in the Admin panel.'
                }
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-shrink-0 ml-11 md:ml-0">
            {onRetry && (
              <button
                onClick={onRetry}
                disabled={retrying}
                className="flex items-center gap-1.5 px-3.5 py-2 bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-semibold rounded-lg hover:bg-amber-500/20 transition-colors disabled:opacity-50"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${retrying ? 'animate-spin' : ''}`} />
                {retrying ? 'Retrying...' : 'Retry Connection'}
              </button>
            )}
            <Link
              to="/admin"
              className="flex items-center gap-1.5 px-3.5 py-2 bg-amber-500/20 border border-amber-500/30 text-amber-200 text-xs font-bold rounded-lg hover:bg-amber-500/30 transition-colors"
            >
              <Database className="w-3.5 h-3.5" />
              Admin Panel
              <ArrowRight className="w-3 h-3" />
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FallbackBanner;
