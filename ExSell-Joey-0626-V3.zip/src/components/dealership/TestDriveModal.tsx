import React, { useState } from 'react';
import { X, Calendar, CheckCircle, Car, Loader2, AlertCircle } from 'lucide-react';
import { Vehicle } from '@/data/vehicles';
import { supabase } from '@/lib/supabase';

interface TestDriveModalProps {
  vehicle: Vehicle | null;
  onClose: () => void;
}

const TestDriveModal: React.FC<TestDriveModalProps> = ({ vehicle, onClose }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    preferredDate: '',
    preferredTime: '',
    message: '',
  });
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.name.trim()) newErrors.name = 'Name is required';
    if (!formData.phone.trim()) newErrors.phone = 'Phone is required';
    if (!formData.preferredDate) newErrors.preferredDate = 'Please select a date';
    if (!formData.preferredTime) newErrors.preferredTime = 'Please select a time';
    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Invalid email format';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitError('');

    if (!validate()) return;

    setSubmitting(true);

    const vehicleLabel = vehicle
      ? `${vehicle.year} ${vehicle.make} ${vehicle.model} ${vehicle.trim}`
      : null;

    try {
      // 1. Insert into test_drive_bookings table
      const bookingData = {
        customer_name: formData.name.trim(),
        email: formData.email.trim() || null,
        phone: formData.phone.trim(),
        preferred_date: formData.preferredDate,
        preferred_time: formData.preferredTime,
        vehicle_id: vehicle?.id || null,
        vehicle_label: vehicleLabel,
        message: formData.message.trim() || null,
        status: 'pending',
      };

      const { data: insertedBooking, error: bookingError } = await supabase
        .from('test_drive_bookings')
        .insert(bookingData)
        .select()
        .single();

      if (bookingError) throw bookingError;

      // 2. Also insert into leads table for backward compatibility
      try {
        await supabase.from('leads').insert({
          name: formData.name.trim(),
          phone: formData.phone.trim(),
          email: formData.email.trim() || null,
          subject: 'test-drive',
          message: formData.message.trim() || null,
          vehicle_interest: vehicleLabel,
          preferred_date: formData.preferredDate,
          preferred_time: formData.preferredTime,
          lead_type: 'test-drive',
        });
      } catch {
        // Leads table insert is non-critical, don't fail the booking
      }

      // 3. Fire-and-forget notification via edge function
      supabase.functions.invoke('test-drive-notify', {
        body: {
          booking: {
            ...bookingData,
            id: insertedBooking?.id,
          },
        },
      }).catch((err) => {
        console.warn('Notification dispatch failed (non-critical):', err);
      });

      setSubmitted(true);
    } catch (err: any) {
      console.error('Failed to submit test drive request:', err);
      setSubmitError('Something went wrong. Please try again or call us at (631) 388-4426.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) setErrors((prev) => ({ ...prev, [field]: '' }));
    if (submitError) setSubmitError('');
  };

  if (!vehicle) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div className="fixed inset-0 bg-black/80 backdrop-blur-sm" onClick={onClose} />

      <div className="relative w-full max-w-lg bg-[#0a0a0a] rounded-2xl border border-white/10 shadow-2xl animate-slide-in overflow-hidden">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-2 bg-black/60 rounded-full text-gray-400 hover:text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {submitted ? (
          <div className="p-8 text-center space-y-4">
            <div className="w-16 h-16 mx-auto bg-neon-green/10 rounded-full flex items-center justify-center">
              <CheckCircle className="w-8 h-8 text-neon-green" />
            </div>
            <h3 className="text-2xl font-bold text-white">Test Drive Scheduled!</h3>
            <p className="text-gray-400">
              We'll confirm your test drive for the{' '}
              <span className="text-neon-cyan font-semibold">
                {vehicle.year} {vehicle.make} {vehicle.model}
              </span>{' '}
              on <span className="text-white font-semibold">{formData.preferredDate}</span> at{' '}
              <span className="text-white font-semibold">{formData.preferredTime}</span>.
              Check your phone for a confirmation text.
            </p>
            <button
              onClick={onClose}
              className="px-8 py-3 bg-gradient-to-r from-neon-pink to-neon-orange text-white font-bold rounded-xl hover:opacity-90 transition-opacity"
            >
              Done
            </button>
          </div>
        ) : (
          <>
            {/* Header */}
            <div className="p-6 pb-4 border-b border-white/5">
              <div className="flex items-center gap-3 mb-2">
                <div className="p-2 bg-neon-cyan/10 rounded-lg">
                  <Calendar className="w-5 h-5 text-neon-cyan" />
                </div>
                <h3 className="text-xl font-bold text-white">Schedule a Test Drive</h3>
              </div>
              <div className="flex items-center gap-2 text-gray-400 text-sm">
                <Car className="w-4 h-4 text-neon-orange" />
                <span>
                  {vehicle.year} {vehicle.make} {vehicle.model} {vehicle.trim}
                </span>
              </div>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              {submitError && (
                <div className="flex items-center gap-3 p-3 bg-red-500/10 border border-red-500/20 rounded-xl">
                  <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0" />
                  <p className="text-red-400 text-sm">{submitError}</p>
                </div>
              )}

              <div>
                <label className="block text-sm text-gray-400 mb-1">Full Name *</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => handleChange('name', e.target.value)}
                  placeholder="John Smith"
                  disabled={submitting}
                  className={`w-full px-4 py-2.5 bg-black border rounded-lg text-white placeholder-gray-600 focus:outline-none transition-colors disabled:opacity-50 ${
                    errors.name ? 'border-red-500' : 'border-white/10 focus:border-neon-cyan'
                  }`}
                />
                {errors.name && <p className="text-red-400 text-xs mt-1">{errors.name}</p>}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Phone *</label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => handleChange('phone', e.target.value)}
                    placeholder="(555) 123-4567"
                    disabled={submitting}
                    className={`w-full px-4 py-2.5 bg-black border rounded-lg text-white placeholder-gray-600 focus:outline-none transition-colors disabled:opacity-50 ${
                      errors.phone ? 'border-red-500' : 'border-white/10 focus:border-neon-cyan'
                    }`}
                  />
                  {errors.phone && <p className="text-red-400 text-xs mt-1">{errors.phone}</p>}
                </div>
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Email</label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => handleChange('email', e.target.value)}
                    placeholder="john@email.com"
                    disabled={submitting}
                    className={`w-full px-4 py-2.5 bg-black border rounded-lg text-white placeholder-gray-600 focus:outline-none transition-colors disabled:opacity-50 ${
                      errors.email ? 'border-red-500' : 'border-white/10 focus:border-neon-cyan'
                    }`}
                  />
                  {errors.email && <p className="text-red-400 text-xs mt-1">{errors.email}</p>}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Preferred Date *</label>
                  <input
                    type="date"
                    value={formData.preferredDate}
                    onChange={(e) => handleChange('preferredDate', e.target.value)}
                    min={new Date().toISOString().split('T')[0]}
                    disabled={submitting}
                    className={`w-full px-4 py-2.5 bg-black border rounded-lg text-white focus:outline-none transition-colors [color-scheme:dark] disabled:opacity-50 ${
                      errors.preferredDate ? 'border-red-500' : 'border-white/10 focus:border-neon-cyan'
                    }`}
                  />
                  {errors.preferredDate && <p className="text-red-400 text-xs mt-1">{errors.preferredDate}</p>}
                </div>
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Preferred Time *</label>
                  <select
                    value={formData.preferredTime}
                    onChange={(e) => handleChange('preferredTime', e.target.value)}
                    disabled={submitting}
                    className={`w-full px-4 py-2.5 bg-black border rounded-lg text-white focus:outline-none transition-colors disabled:opacity-50 ${
                      errors.preferredTime ? 'border-red-500' : 'border-white/10 focus:border-neon-cyan'
                    }`}
                  >
                    <option value="">Select time</option>
                    <option value="9:00 AM">9:00 AM</option>
                    <option value="10:00 AM">10:00 AM</option>
                    <option value="11:00 AM">11:00 AM</option>
                    <option value="12:00 PM">12:00 PM</option>
                    <option value="1:00 PM">1:00 PM</option>
                    <option value="2:00 PM">2:00 PM</option>
                    <option value="3:00 PM">3:00 PM</option>
                    <option value="4:00 PM">4:00 PM</option>
                    <option value="5:00 PM">5:00 PM</option>
                    <option value="6:00 PM">6:00 PM</option>
                  </select>
                  {errors.preferredTime && <p className="text-red-400 text-xs mt-1">{errors.preferredTime}</p>}
                </div>
              </div>

              <div>
                <label className="block text-sm text-gray-400 mb-1">Message (Optional)</label>
                <textarea
                  value={formData.message}
                  onChange={(e) => handleChange('message', e.target.value)}
                  rows={3}
                  placeholder="Any questions or special requests?"
                  disabled={submitting}
                  className="w-full px-4 py-2.5 bg-black border border-white/10 rounded-lg text-white placeholder-gray-600 focus:border-neon-cyan focus:outline-none transition-colors resize-none disabled:opacity-50"
                />
              </div>

              <button
                type="submit"
                disabled={submitting}
                className="w-full py-3.5 bg-gradient-to-r from-neon-pink to-neon-orange text-white font-bold rounded-xl hover:opacity-90 transition-opacity neon-pulse disabled:opacity-50 disabled:cursor-not-allowed disabled:animate-none flex items-center justify-center gap-2"
              >
                {submitting ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Scheduling...
                  </>
                ) : (
                  'Confirm Test Drive'
                )}
              </button>

              <p className="text-xs text-gray-500 text-center">
                By submitting, you agree to be contacted about this vehicle. We'll call or text to confirm.
              </p>
            </form>
          </>
        )}
      </div>
    </div>
  );
};

export default TestDriveModal;
