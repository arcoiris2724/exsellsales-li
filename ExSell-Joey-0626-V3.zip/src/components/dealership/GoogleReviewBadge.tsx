import React from 'react';
import { Link } from 'react-router-dom';
import { Star } from 'lucide-react';
import { useGoogleReviews } from '@/hooks/useGoogleReviews';

interface GoogleReviewBadgeProps {
  /** Visual style variant. */
  variant?: 'compact' | 'inline' | 'pill';
  /** If true, renders a subtle skeleton while loading; otherwise renders nothing. */
  showSkeleton?: boolean;
  /** Optional className to extend the outer wrapper. */
  className?: string;
}

const renderStars = (rating: number, size = 'w-3.5 h-3.5') => {
  const full = Math.floor(rating);
  const hasHalf = rating - full >= 0.5;
  return (
    <div className="flex items-center gap-0.5">
      {[0, 1, 2, 3, 4].map((i) => {
        const filled = i < full;
        const half = !filled && i === full && hasHalf;
        return (
          <Star
            key={i}
            className={`${size} ${
              filled || half ? 'fill-neon-orange text-neon-orange' : 'text-gray-600'
            }`}
            strokeWidth={1.5}
          />
        );
      })}
    </div>
  );
};

const GoogleLogo: React.FC<{ className?: string }> = ({ className = 'w-4 h-4' }) => (
  <svg className={className} viewBox="0 0 24 24" aria-hidden="true">
    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" />
    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
  </svg>
);

/**
 * Compact live Google review badge showing the current rating + review count,
 * linking to the full /reviews page. Gracefully hides when the live feed
 * isn't configured or hasn't loaded yet.
 */
const GoogleReviewBadge: React.FC<GoogleReviewBadgeProps> = ({
  variant = 'compact',
  showSkeleton = false,
  className = '',
}) => {
  const { data, isLoading, isError, placeholder, rating, userRatingCount } = useGoogleReviews();

  // Not configured OR errored → render nothing (non-blocking).
  if (placeholder || isError) return null;

  if (isLoading) {
    if (!showSkeleton) return null;
    return (
      <div
        className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5 border border-white/10 animate-pulse ${className}`}
        aria-label="Loading Google reviews"
      >
        <GoogleLogo />
        <div className="h-3 w-20 bg-white/10 rounded" />
      </div>
    );
  }

  if (!data || rating == null) return null;

  const ratingLabel = rating.toFixed(1);
  const countLabel =
    userRatingCount != null ? `${userRatingCount.toLocaleString()} reviews` : 'Google reviews';
  const a11y = `Google rating ${ratingLabel} out of 5 from ${countLabel}`;

  // ── Pill (biggest) ──
  if (variant === 'pill') {
    return (
      <Link
        to="/reviews"
        aria-label={a11y}
        className={`group inline-flex items-center gap-3 px-4 py-2 rounded-full bg-white/5 backdrop-blur border border-white/10 hover:border-neon-orange/40 hover:bg-white/10 transition-all ${className}`}
      >
        <GoogleLogo className="w-4 h-4" />
        <span className="text-white font-bold text-sm leading-none">{ratingLabel}</span>
        {renderStars(rating, 'w-3.5 h-3.5')}
        <span className="text-gray-400 text-xs leading-none border-l border-white/10 pl-3">
          {userRatingCount != null ? userRatingCount.toLocaleString() : ''} Google reviews
        </span>
      </Link>
    );
  }

  // ── Inline (text-first, for headers/testimonials) ──
  if (variant === 'inline') {
    return (
      <Link
        to="/reviews"
        aria-label={a11y}
        className={`inline-flex items-center gap-2 text-sm hover:opacity-90 transition-opacity ${className}`}
      >
        {renderStars(rating, 'w-4 h-4')}
        <span className="text-white font-bold">{ratingLabel}</span>
        {userRatingCount != null && (
          <span className="text-gray-500">
            based on {userRatingCount.toLocaleString()} Google reviews
          </span>
        )}
      </Link>
    );
  }

  // ── Compact (default) ──
  return (
    <Link
      to="/reviews"
      aria-label={a11y}
      className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/[0.04] border border-white/10 hover:border-neon-orange/40 hover:bg-white/[0.08] transition-all ${className}`}
    >
      <GoogleLogo className="w-3.5 h-3.5" />
      {renderStars(rating, 'w-3 h-3')}
      <span className="text-white text-xs font-bold">{ratingLabel}</span>
      {userRatingCount != null && (
        <span className="text-gray-400 text-xs">
          ({userRatingCount.toLocaleString()})
        </span>
      )}
    </Link>
  );
};

export default GoogleReviewBadge;
