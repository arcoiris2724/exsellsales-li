import React, { useMemo } from 'react';
import { Link } from 'react-router-dom';
import { Vehicle } from '@/data/vehicles';

interface CarCloudProps {
  vehicles: Vehicle[];
}

interface CloudItem {
  text: string;
  size: number;
  color: string;
  x: number;
  y: number;
  rotation: number;
  delay: number;
  duration: number;
  vehicleId: number;
  price: string;
}

const NEON_COLORS = [
  'text-neon-pink',
  'text-neon-cyan',
  'text-neon-green',
  'text-neon-orange',
  'text-neon-purple',
  'text-neon-yellow',
];

const GLOW_CLASSES = [
  'neon-text-pink',
  'neon-text-cyan',
  'neon-text-green',
  'neon-text-orange',
];

const CarCloud: React.FC<CarCloudProps> = ({ vehicles }) => {
  const featured = vehicles
    .filter((v) => v.status === 'available')
    .slice(0, 5);

  const cloudItems = useMemo<CloudItem[]>(() => {
    if (featured.length === 0) return [];

    // Predefined positions for a nice word cloud layout (percentages)
    const positions = [
      { x: 50, y: 18, size: 2.2, rotation: -3 },
      { x: 25, y: 42, size: 1.6, rotation: 5 },
      { x: 72, y: 38, size: 1.8, rotation: -6 },
      { x: 38, y: 68, size: 1.4, rotation: 3 },
      { x: 68, y: 72, size: 1.5, rotation: -4 },
    ];

    return featured.map((v, i) => {
      const pos = positions[i % positions.length];
      return {
        text: `${v.year} ${v.make} ${v.model}`,
        size: pos.size,
        color: NEON_COLORS[i % NEON_COLORS.length],
        x: pos.x,
        y: pos.y,
        rotation: pos.rotation,
        delay: i * 0.4,
        duration: 3 + (i % 3),
        vehicleId: v.id,
        price: `$${v.price.toLocaleString()}`,
      };
    });
  }, [featured]);

  if (cloudItems.length === 0) return null;

  return (
    <div className="relative w-full h-full min-h-[300px]">
      {/* Background glow effects */}
      <div className="absolute inset-0">
        <div className="absolute top-1/4 left-1/3 w-32 h-32 bg-neon-pink/10 rounded-full blur-[60px] animate-pulse" />
        <div className="absolute bottom-1/3 right-1/4 w-28 h-28 bg-neon-cyan/10 rounded-full blur-[50px] animate-pulse" style={{ animationDelay: '1s' }} />
        <div className="absolute top-1/2 left-1/2 w-24 h-24 bg-neon-orange/8 rounded-full blur-[40px] animate-pulse" style={{ animationDelay: '2s' }} />
      </div>

      {/* Cloud items */}
      {cloudItems.map((item, i) => (
        <Link
          key={item.vehicleId}
          to={`/inventory/${item.vehicleId}`}
          className="absolute group cursor-pointer"
          style={{
            left: `${item.x}%`,
            top: `${item.y}%`,
            transform: `translate(-50%, -50%) rotate(${item.rotation}deg)`,
            animation: `cloudFloat ${item.duration}s ease-in-out infinite`,
            animationDelay: `${item.delay}s`,
          }}
        >
          <div className="relative transition-all duration-300 group-hover:scale-110">
            {/* Vehicle name */}
            <div
              className={`font-display font-bold whitespace-nowrap ${item.color} ${GLOW_CLASSES[i % GLOW_CLASSES.length]} transition-all duration-300 group-hover:scale-105`}
              style={{ fontSize: `${item.size}rem` }}
            >
              {item.text}
            </div>

            {/* Price tag that appears on hover */}
            <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-all duration-300 group-hover:-bottom-7">
              <div className="px-3 py-1 bg-black/80 backdrop-blur-sm rounded-full border border-white/10 whitespace-nowrap">
                <span className="text-neon-orange font-bold text-sm">{item.price}</span>
                <span className="text-gray-500 text-xs ml-2">View Details</span>
              </div>
            </div>
          </div>
        </Link>
      ))}

      {/* Decorative connecting lines */}
      <svg className="absolute inset-0 w-full h-full pointer-events-none opacity-[0.06]" xmlns="http://www.w3.org/2000/svg">
        {cloudItems.length >= 2 && cloudItems.map((item, i) => {
          if (i === cloudItems.length - 1) return null;
          const next = cloudItems[i + 1];
          return (
            <line
              key={i}
              x1={`${item.x}%`}
              y1={`${item.y}%`}
              x2={`${next.x}%`}
              y2={`${next.y}%`}
              stroke="url(#cloudGradient)"
              strokeWidth="1"
              strokeDasharray="4 4"
            />
          );
        })}
        <defs>
          <linearGradient id="cloudGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FF0080" />
            <stop offset="50%" stopColor="#FF8C00" />
            <stop offset="100%" stopColor="#00F0FF" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
};

export default CarCloud;
