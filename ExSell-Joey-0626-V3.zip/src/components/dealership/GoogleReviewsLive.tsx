import React from 'react';
import { Star, ExternalLink, Loader2, Quote } from 'lucide-react';
import { useGoogleReviews } from '@/hooks/useGoogleReviews';

interface GoogleReviewsLiveProps {
  placeId: string;
  businessUrl: string;
  /** If true, we won't attempt a fetch (used when the Place ID is still a placeholder). */
  disabled?: boolean;
}

const renderStars = (rating: number, size = 'w-4 h-4') => {
  const full = Math.floor(rating);
  const hasHalf = rating - full >= 0.5;
  return (
    <div className="flex items-center gap-0.5">
      {[0, 1, 2, 3, 4].map((i) => {
        const filled = i < full;
        const half = !filled && i === full && hasHalf;
        return (
          <Star
            key={i}
            className={`${size} ${
              filled || half ? 'fill-neon-orange text-neon-orange' : 'text-gray-600'
            }`}
            strokeWidth={1.5}
          />
        );
      })}
    </div>
  );
};

const GoogleReviewsLive: React.FC<GoogleReviewsLiveProps> = ({
  placeId,
  businessUrl,
  disabled = false,
}) => {
  const { data, isLoading, isError, rating, userRatingCount, reviews } = useGoogleReviews({
    placeId,
    enabled: !disabled,
  });

  // ─── Loading state ───
  if (isLoading && !disabled) {
    return (
      <div className="relative overflow-hidden bg-gradient-to-br from-white/[0.04] to-white/[0.02] border border-white/10 rounded-2xl p-8 mb-8">
        <div className="flex items-center justify-center gap-3 py-8">
          <Loader2 className="w-5 h-5 text-neon-orange animate-spin" />
          <span className="text-gray-400 text-sm">Loading live Google reviews...</span>
        </div>
      </div>
    );
  }

  // ─── Error / not-configured state (friendly, non-blocking) ───
  if (isError || disabled || !data || rating == null) {
    return null;
  }

  const safeReviews = Array.isArray(reviews) ? reviews.slice(0, 5) : [];
  const stale = data.stale;

  return (
    <div className="relative overflow-hidden bg-gradient-to-br from-white/[0.04] to-white/[0.02] border border-white/10 rounded-2xl p-6 md:p-8 mb-8">
      <div className="absolute top-0 right-0 w-80 h-80 bg-neon-orange/5 rounded-full blur-[100px]" />

      <div className="relative">
        {/* Header — aggregate rating */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-5 mb-7 pb-6 border-b border-white/10">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 bg-white rounded-xl flex items-center justify-center flex-shrink-0">
              <svg className="w-8 h-8" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" />
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
              </svg>
            </div>
            <div>
              <div className="flex items-baseline gap-2 flex-wrap">
                <span className="text-4xl md:text-5xl font-black gradient-text-neon leading-none">
                  {rating.toFixed(1)}
                </span>
                <span className="text-gray-500 text-sm">/ 5.0</span>
              </div>
              <div className="flex items-center gap-3 mt-2">
                {renderStars(rating, 'w-5 h-5')}
                {userRatingCount != null && (
                  <span className="text-gray-400 text-sm">
                    <span className="text-white font-semibold">{userRatingCount.toLocaleString()}</span>{' '}
                    Google reviews
                  </span>
                )}
              </div>
            </div>
          </div>

          <a
            href={businessUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-2 px-5 py-3 bg-gradient-to-r from-neon-pink to-neon-orange text-white font-bold rounded-lg shadow-lg shadow-neon-orange/20 hover:opacity-90 transition-opacity text-sm whitespace-nowrap"
          >
            View all on Google
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>

        {/* Recent review snippets */}
        {safeReviews.length > 0 ? (
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-white font-bold text-lg">Recent reviews</h3>
              {stale && (
                <span className="text-xs text-gray-500">Cached preview</span>
              )}
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {safeReviews.map((r, idx) => (
                <div
                  key={idx}
                  className="relative bg-black/40 border border-white/10 rounded-xl p-5 hover:border-white/20 transition-colors"
                >
                  <Quote
                    className="absolute top-3 right-3 w-5 h-5 text-neon-orange/20"
                    strokeWidth={2.5}
                  />

                  <div className="flex items-center gap-3 mb-3">
                    {r.authorPhotoUri ? (
                      <img
                        src={r.authorPhotoUri}
                        alt={r.authorName}
                        className="w-9 h-9 rounded-full object-cover border border-white/10"
                        referrerPolicy="no-referrer"
                        onError={(e) => {
                          (e.target as HTMLImageElement).style.display = 'none';
                        }}
                      />
                    ) : (
                      <div className="w-9 h-9 rounded-full bg-gradient-to-br from-neon-orange/30 to-neon-pink/30 border border-white/10 flex items-center justify-center text-white text-xs font-bold">
                        {r.authorName.charAt(0).toUpperCase()}
                      </div>
                    )}
                    <div className="min-w-0 flex-1">
                      <div className="text-white text-sm font-semibold truncate">
                        {r.authorName}
                      </div>
                      {r.relativeTime && (
                        <div className="text-gray-500 text-xs">{r.relativeTime}</div>
                      )}
                    </div>
                  </div>

                  {r.rating != null && <div className="mb-2">{renderStars(r.rating)}</div>}

                  {r.text && (
                    <p className="text-gray-300 text-sm leading-relaxed line-clamp-4">
                      {r.text}
                    </p>
                  )}
                </div>
              ))}
            </div>
          </div>
        ) : (
          <p className="text-gray-500 text-sm">
            No recent review snippets to display — check the full list on Google.
          </p>
        )}
      </div>
    </div>
  );
};

export default GoogleReviewsLive;
