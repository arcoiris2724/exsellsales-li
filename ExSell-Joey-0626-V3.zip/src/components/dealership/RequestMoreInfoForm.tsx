import React, { useState } from 'react';
import { Send, User, Mail, Phone, MessageSquare, CheckCircle2, Loader2, AlertCircle, MessageCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Vehicle } from '@/data/vehicles';

interface Props {
  vehicle: Vehicle;
}

/**
 * Inline "Request More Info" lead-capture form shown on each Vehicle Detail
 * Page (/inventory/:id). Inserts into the `leads` table with lead_type='contact'
 * and fires the `lead-notify` edge function so the dealer is notified without
 * the buyer having to pick up the phone.
 *
 * The vehicle_id is encoded into the `vehicle_interest` text column using the
 * format `"<year> <make> <model> (#<id>)"` — the LeadsPanel parses this pattern
 * to render a link back to /inventory/<id>.
 */
const RequestMoreInfoForm: React.FC<Props> = ({ vehicle }) => {
  const vehicleTitle = `${vehicle.year} ${vehicle.make} ${vehicle.model}${vehicle.trim ? ' ' + vehicle.trim : ''}`;
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [message, setMessage] = useState(`I'm interested in the ${vehicleTitle}. Please send me more info.`);

  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const validate = (): string | null => {
    if (!name.trim()) return 'Please enter your name.';
    if (!phone.trim() || phone.replace(/\D/g, '').length < 10) return 'Please enter a valid phone number.';
    if (email.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) return 'Please enter a valid email address.';
    return null;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const err = validate();
    if (err) {
      setError(err);
      return;
    }
    setError(null);
    setSubmitting(true);

    // Encode vehicle_id in vehicle_interest so LeadsPanel can link back.
    const vehicleInterestTag = `${vehicleTitle} (#${vehicle.id})`;

    try {
      const { data: insertData, error: insertError } = await supabase
        .from('leads')
        .insert({
          name: name.trim(),
          email: email.trim() || null,
          phone: phone.trim(),
          subject: 'vehicle',
          message: message.trim() || null,
          vehicle_interest: vehicleInterestTag,
          lead_type: 'contact',
          status: 'new',
        })
        .select()
        .single();

      if (insertError) throw insertError;

      // Fire notification — non-blocking for UX; we still mark as submitted
      // even if the notifier fails, because the lead is safely in the DB.
      try {
        await supabase.functions.invoke('lead-notify', {
          body: {
            lead_id: insertData?.id,
            name: name.trim(),
            email: email.trim() || null,
            phone: phone.trim(),
            message: message.trim() || null,
            vehicle_id: vehicle.id,
            vehicle_title: vehicleTitle,
            vehicle_price: vehicle.price || null,
            vehicle_url: `${window.location.origin}/inventory/${vehicle.id}`,
            source: 'vehicle_detail_page',
          },
        });
      } catch (notifyErr) {
        console.warn('lead-notify invoke failed (lead still saved):', notifyErr);
      }

      setSubmitted(true);
    } catch (dbErr: any) {
      console.error('Failed to submit lead:', dbErr);
      setError(dbErr?.message || 'Something went wrong. Please call (631) 388-4426 instead.');
    } finally {
      setSubmitting(false);
    }
  };

  if (submitted) {
    return (
      <div className="mt-10 p-6 md:p-8 bg-gradient-to-br from-neon-green/10 via-neon-cyan/5 to-transparent rounded-2xl border border-neon-green/30">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 bg-neon-green/20 rounded-full flex items-center justify-center flex-shrink-0">
            <CheckCircle2 className="w-6 h-6 text-neon-green" />
          </div>
          <div className="flex-1">
            <h3 className="text-xl font-bold text-white mb-1">Message Received</h3>
            <p className="text-gray-300 text-sm leading-relaxed">
              Thanks <span className="text-neon-green font-semibold">{name.split(' ')[0] || 'there'}</span>!
              We got your inquiry about the <span className="text-neon-orange font-semibold">{vehicleTitle}</span>.
              A member of the Ex$ell Sales team will reach out to you at{' '}
              <span className="text-white font-mono">{phone}</span> shortly — usually within the same business day.
            </p>
            <div className="mt-4 flex flex-wrap gap-2">
              <a
                href="tel:6313884426"
                className="inline-flex items-center gap-2 px-4 py-2 bg-neon-green/10 border border-neon-green/30 text-neon-green text-sm font-semibold rounded-lg hover:bg-neon-green/20 transition-colors"
              >
                <Phone className="w-4 h-4" />
                Call (631) 388-4426
              </a>
              <button
                onClick={() => {
                  setSubmitted(false);
                  setMessage(`I'm interested in the ${vehicleTitle}. Please send me more info.`);
                }}
                className="inline-flex items-center gap-2 px-4 py-2 border border-white/10 text-gray-400 text-sm rounded-lg hover:text-white hover:border-white/30 transition-colors"
              >
                Send another message
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="mt-10 p-6 md:p-8 bg-gradient-to-br from-neon-cyan/5 via-neon-pink/5 to-transparent rounded-2xl border border-neon-cyan/20">
      <div className="flex items-center gap-3 mb-1">
        <div className="w-10 h-10 bg-gradient-to-br from-neon-cyan to-neon-pink rounded-lg flex items-center justify-center">
          <MessageCircle className="w-5 h-5 text-white" />
        </div>
        <div>
          <h3 className="text-xl font-bold text-white">Request More Info</h3>
          <p className="text-sm text-gray-500">
            Fast response about the {vehicle.year} {vehicle.make} {vehicle.model}
            {vehicle.trim ? ` ${vehicle.trim}` : ''} — no pushy sales calls.
          </p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Name */}
        <div>
          <label className="block text-xs font-semibold text-gray-400 mb-1.5 uppercase tracking-wider">
            Full Name <span className="text-neon-pink">*</span>
          </label>
          <div className="relative">
            <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
              placeholder="Jane Smith"
              className="w-full pl-10 pr-3 py-2.5 bg-black/40 border border-white/10 rounded-lg text-white text-sm placeholder-gray-600 focus:border-neon-cyan focus:outline-none"
            />
          </div>
        </div>

        {/* Phone */}
        <div>
          <label className="block text-xs font-semibold text-gray-400 mb-1.5 uppercase tracking-wider">
            Phone <span className="text-neon-pink">*</span>
          </label>
          <div className="relative">
            <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
            <input
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              required
              placeholder="(631) 555-0123"
              className="w-full pl-10 pr-3 py-2.5 bg-black/40 border border-white/10 rounded-lg text-white text-sm placeholder-gray-600 focus:border-neon-cyan focus:outline-none"
            />
          </div>
        </div>

        {/* Email */}
        <div className="md:col-span-2">
          <label className="block text-xs font-semibold text-gray-400 mb-1.5 uppercase tracking-wider">
            Email <span className="text-gray-600 normal-case font-normal">(optional)</span>
          </label>
          <div className="relative">
            <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="jane@example.com"
              className="w-full pl-10 pr-3 py-2.5 bg-black/40 border border-white/10 rounded-lg text-white text-sm placeholder-gray-600 focus:border-neon-cyan focus:outline-none"
            />
          </div>
        </div>

        {/* Message */}
        <div className="md:col-span-2">
          <label className="block text-xs font-semibold text-gray-400 mb-1.5 uppercase tracking-wider">
            Message
          </label>
          <div className="relative">
            <MessageSquare className="absolute left-3 top-3 w-4 h-4 text-gray-500" />
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              rows={4}
              className="w-full pl-10 pr-3 py-2.5 bg-black/40 border border-white/10 rounded-lg text-white text-sm placeholder-gray-600 focus:border-neon-cyan focus:outline-none resize-none"
              placeholder="Any questions about the vehicle — mileage, condition, availability…"

            />
          </div>
        </div>

        {/* Hidden vehicle context — displayed for transparency */}
        <div className="md:col-span-2 flex items-center gap-2 text-xs text-gray-500 bg-white/[0.02] border border-white/5 rounded-lg px-3 py-2">
          <span className="text-gray-600">Inquiring about:</span>
          <span className="text-neon-orange font-semibold truncate">{vehicleTitle}</span>
          <span className="ml-auto text-gray-600 font-mono text-[11px]">#{vehicle.id}</span>
        </div>

        {error && (
          <div className="md:col-span-2 flex items-center gap-2 p-3 bg-red-500/10 border border-red-500/30 rounded-lg text-red-400 text-sm">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <div className="md:col-span-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          <button
            type="submit"
            disabled={submitting}
            className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-neon-cyan to-neon-pink text-black font-bold rounded-xl hover:opacity-90 transition-opacity disabled:opacity-60 disabled:cursor-not-allowed"
          >
            {submitting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Sending…
              </>
            ) : (
              <>
                <Send className="w-4 h-4" />
                Send Inquiry
              </>
            )}
          </button>
          <p className="text-xs text-gray-500 leading-relaxed">
            By submitting you agree to be contacted about this vehicle. We never share your info.
          </p>
        </div>
      </form>
    </div>
  );
};

export default RequestMoreInfoForm;
