import React, { useState, useMemo } from 'react';
import { Search, SlidersHorizontal, X, ArrowUpDown, Heart, Loader2 } from 'lucide-react';
import { Vehicle, priceRanges, getBodyTypes, getMakes } from '@/data/vehicles';
import VehicleCard from './VehicleCard';

interface InventorySectionProps {
  vehicles: Vehicle[];
  loading?: boolean;
  favorites: Set<number>;
  onToggleFavorite: (id: number) => void;
  onScheduleTestDrive: (vehicle: Vehicle) => void;
}

const InventorySection: React.FC<InventorySectionProps> = ({
  vehicles,
  loading = false,
  favorites,
  onToggleFavorite,
  onScheduleTestDrive,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedBodyType, setSelectedBodyType] = useState('All');
  const [selectedMake, setSelectedMake] = useState('All');
  const [selectedPriceRange, setSelectedPriceRange] = useState(0);
  const [sortBy, setSortBy] = useState('featured');
  const [showFilters, setShowFilters] = useState(false);
  const [showFavoritesOnly, setShowFavoritesOnly] = useState(false);

  const bodyTypes = useMemo(() => getBodyTypes(vehicles), [vehicles]);
  const makes = useMemo(() => getMakes(vehicles), [vehicles]);

  const filteredVehicles = useMemo(() => {
    let filtered = vehicles.filter((v) => {
      // Search
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        const searchStr = `${v.year} ${v.make} ${v.model} ${v.trim} ${v.exteriorColor} ${v.bodyType}`.toLowerCase();
        if (!searchStr.includes(q)) return false;
      }
      // Body type
      if (selectedBodyType !== 'All' && v.bodyType !== selectedBodyType) return false;
      // Make
      if (selectedMake !== 'All' && v.make !== selectedMake) return false;
      // Price range
      const range = priceRanges[selectedPriceRange];
      if (v.price < range.min || v.price >= range.max) return false;
      // Favorites
      if (showFavoritesOnly && !favorites.has(v.id)) return false;
      return true;
    });

    // Sort
    switch (sortBy) {
      case 'price-low':
        filtered.sort((a, b) => a.price - b.price);
        break;
      case 'price-high':
        filtered.sort((a, b) => b.price - a.price);
        break;
      case 'year-new':
        filtered.sort((a, b) => b.year - a.year);
        break;
      case 'mileage-low':
        filtered.sort((a, b) => a.mileage - b.mileage);
        break;
      default:
        // Available first, then by id
        filtered.sort((a, b) => {
          if (a.status === 'sold' && b.status !== 'sold') return 1;
          if (a.status !== 'sold' && b.status === 'sold') return -1;
          return 0;
        });
    }

    return filtered;
  }, [vehicles, searchQuery, selectedBodyType, selectedMake, selectedPriceRange, sortBy, showFavoritesOnly, favorites]);

  const activeFilterCount = [
    selectedBodyType !== 'All',
    selectedMake !== 'All',
    selectedPriceRange !== 0,
    showFavoritesOnly,
  ].filter(Boolean).length;

  const clearFilters = () => {
    setSearchQuery('');
    setSelectedBodyType('All');
    setSelectedMake('All');
    setSelectedPriceRange(0);
    setShowFavoritesOnly(false);
    setSortBy('featured');
  };

  return (
    <section id="inventory" className="py-20 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Section header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-5xl font-black text-white mb-4">
            Our <span className="gradient-text-neon">Inventory</span>
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Browse our hand-picked selection of quality pre-owned vehicles. Every car is inspected and ready to drive.
          </p>
        </div>

        {/* Search & Filter bar */}
        <div className="mb-8 space-y-4">
          <div className="flex flex-col md:flex-row gap-3">
            {/* Search */}
            <div className="relative flex-1">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search by make, model, year, color..."
                className="w-full pl-12 pr-4 py-3.5 bg-white/[0.03] border border-white/10 rounded-xl text-white placeholder-gray-500 focus:border-neon-cyan focus:outline-none transition-colors"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Filter toggle */}
            <button
              onClick={() => setShowFilters(!showFilters)}
              className={`flex items-center gap-2 px-5 py-3.5 rounded-xl font-semibold transition-colors ${
                showFilters || activeFilterCount > 0
                  ? 'bg-neon-pink/10 border border-neon-pink/40 text-neon-pink'
                  : 'bg-white/[0.03] border border-white/10 text-gray-300 hover:border-white/20'
              }`}
            >
              <SlidersHorizontal className="w-5 h-5" />
              Filters
              {activeFilterCount > 0 && (
                <span className="ml-1 px-2 py-0.5 bg-neon-pink text-white text-xs font-bold rounded-full">
                  {activeFilterCount}
                </span>
              )}
            </button>

            {/* Sort */}
            <div className="flex items-center gap-2">
              <ArrowUpDown className="w-4 h-4 text-gray-500" />
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="px-4 py-3.5 bg-white/[0.03] border border-white/10 rounded-xl text-white focus:border-neon-cyan focus:outline-none transition-colors"
              >
                <option value="featured">Featured</option>
                <option value="price-low">Price: Low to High</option>
                <option value="price-high">Price: High to Low</option>
                <option value="year-new">Year: Newest First</option>
                <option value="mileage-low">Mileage: Lowest First</option>
              </select>
            </div>
          </div>

          {/* Filter options */}
          {showFilters && (
            <div className="p-5 bg-white/[0.02] border border-white/5 rounded-xl animate-slide-in">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {/* Body type */}
                <div>
                  <label className="block text-sm text-gray-400 mb-2 font-medium">Body Type</label>
                  <div className="flex flex-wrap gap-2">
                    {bodyTypes.map((type) => (
                      <button
                        key={type}
                        onClick={() => setSelectedBodyType(type)}
                        className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                          selectedBodyType === type
                            ? 'bg-neon-pink/20 border border-neon-pink/40 text-neon-pink'
                            : 'bg-white/[0.03] border border-white/5 text-gray-400 hover:text-white hover:border-white/10'
                        }`}
                      >
                        {type}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Make */}
                <div>
                  <label className="block text-sm text-gray-400 mb-2 font-medium">Make</label>
                  <select
                    value={selectedMake}
                    onChange={(e) => setSelectedMake(e.target.value)}
                    className="w-full px-3 py-2 bg-black border border-white/10 rounded-lg text-white text-sm focus:border-neon-cyan focus:outline-none"
                  >
                    {makes.map((make) => (
                      <option key={make} value={make}>{make}</option>
                    ))}
                  </select>
                </div>

                {/* Price range */}
                <div>
                  <label className="block text-sm text-gray-400 mb-2 font-medium">Price Range</label>
                  <select
                    value={selectedPriceRange}
                    onChange={(e) => setSelectedPriceRange(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-black border border-white/10 rounded-lg text-white text-sm focus:border-neon-cyan focus:outline-none"
                  >
                    {priceRanges.map((range, i) => (
                      <option key={i} value={i}>{range.label}</option>
                    ))}
                  </select>
                </div>

                {/* Favorites filter */}
                <div>
                  <label className="block text-sm text-gray-400 mb-2 font-medium">Saved</label>
                  <button
                    onClick={() => setShowFavoritesOnly(!showFavoritesOnly)}
                    className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                      showFavoritesOnly
                        ? 'bg-neon-pink/20 border border-neon-pink/40 text-neon-pink'
                        : 'bg-white/[0.03] border border-white/5 text-gray-400 hover:text-white'
                    }`}
                  >
                    <Heart className={`w-4 h-4 ${showFavoritesOnly ? 'fill-current' : ''}`} />
                    My Favorites ({favorites.size})
                  </button>
                </div>
              </div>

              {activeFilterCount > 0 && (
                <button
                  onClick={clearFilters}
                  className="mt-4 text-sm text-neon-cyan hover:text-neon-cyan/80 font-medium transition-colors"
                >
                  Clear all filters
                </button>
              )}
            </div>
          )}
        </div>

        {/* Results count */}
        <div className="mb-6 flex items-center justify-between">
          <p className="text-gray-400 text-sm">
            Showing <span className="text-white font-semibold">{filteredVehicles.length}</span> of{' '}
            <span className="text-white font-semibold">{vehicles.length}</span> vehicles
          </p>
        </div>

        {/* Loading state */}
        {loading ? (
          <div className="flex flex-col items-center justify-center py-20">
            <Loader2 className="w-10 h-10 text-neon-pink animate-spin mb-4" />
            <p className="text-gray-400 text-lg">Loading inventory...</p>
          </div>
        ) : filteredVehicles.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredVehicles.map((vehicle) => (
              <VehicleCard
                key={vehicle.id}
                vehicle={vehicle}
                isFavorite={favorites.has(vehicle.id)}
                onToggleFavorite={onToggleFavorite}
                onScheduleTestDrive={onScheduleTestDrive}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <div className="text-gray-500 mb-4">
              <Search className="w-12 h-12 mx-auto opacity-50" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">No vehicles found</h3>
            <p className="text-gray-400 mb-4">Try adjusting your search or filters</p>
            <button
              onClick={clearFilters}
              className="px-6 py-2.5 bg-neon-pink/10 border border-neon-pink/30 text-neon-pink font-semibold rounded-lg hover:bg-neon-pink/20 transition-colors"
            >
              Clear All Filters
            </button>
          </div>
        )}
      </div>
    </section>
  );
};

export default InventorySection;
