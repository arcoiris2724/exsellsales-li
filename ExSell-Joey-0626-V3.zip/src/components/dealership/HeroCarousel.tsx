import React, { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { ChevronLeft, ChevronRight, Gauge, Fuel, Settings2, Eye } from 'lucide-react';
import { Vehicle } from '@/data/vehicles';

interface HeroCarouselProps {
  vehicles: Vehicle[];
}

const HeroCarousel: React.FC<HeroCarouselProps> = ({ vehicles }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [isPaused, setIsPaused] = useState(false);

  const featured = vehicles
    .filter((v) => v.status === 'available' && v.image)
    .slice(0, 5);

  const next = useCallback(() => {
    if (isTransitioning || featured.length === 0) return;
    setIsTransitioning(true);
    setCurrentIndex((prev) => (prev + 1) % featured.length);
    setTimeout(() => setIsTransitioning(false), 600);
  }, [isTransitioning, featured.length]);

  const prev = useCallback(() => {
    if (isTransitioning || featured.length === 0) return;
    setIsTransitioning(true);
    setCurrentIndex((prev) => (prev - 1 + featured.length) % featured.length);
    setTimeout(() => setIsTransitioning(false), 600);
  }, [isTransitioning, featured.length]);

  // Auto-rotate every 5 seconds
  useEffect(() => {
    if (isPaused || featured.length <= 1) return;
    const timer = setInterval(next, 5000);
    return () => clearInterval(timer);
  }, [next, isPaused, featured.length]);

  if (featured.length === 0) return null;

  const vehicle = featured[currentIndex];

  return (
    <div
      className="relative w-full"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
    >
      {/* Main carousel container */}
      <div className="relative rounded-2xl overflow-hidden border border-white/10 group">
        {/* Glow effects */}
        <div className="absolute -inset-4 bg-gradient-to-br from-neon-pink/15 via-neon-orange/10 to-neon-cyan/15 rounded-3xl blur-2xl opacity-60 group-hover:opacity-80 transition-opacity duration-500" />

        <div className="relative">
          {/* Image */}
          <Link to={`/inventory/${vehicle.id}`} className="block">
            <div className="relative aspect-[16/10] overflow-hidden bg-[#0a0a0a]">
              <img
                key={vehicle.id}
                src={vehicle.image}
                alt={`${vehicle.year} ${vehicle.make} ${vehicle.model}`}
                className="w-full h-full object-cover transition-all duration-700 ease-out group-hover:scale-105"
                style={{
                  animation: 'heroFadeIn 0.6s ease-out',
                }}
              />

              {/* Gradient overlays */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
              <div className="absolute inset-0 bg-gradient-to-r from-black/40 via-transparent to-transparent" />

              {/* Featured badge */}
              <div className="absolute top-4 left-4 flex items-center gap-2">
                <div className="px-3 py-1.5 bg-gradient-to-r from-neon-pink to-neon-orange text-white text-xs font-bold rounded-full uppercase tracking-wider shadow-lg shadow-neon-pink/30">
                  Featured
                </div>
                <div className="px-3 py-1.5 bg-neon-green/90 text-black text-xs font-bold rounded-full uppercase tracking-wider">
                  Available
                </div>
              </div>

              {/* View Details hover overlay */}
              <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <span className="px-6 py-3 bg-white/10 backdrop-blur-md text-white font-bold rounded-xl border border-white/20 flex items-center gap-2 shadow-2xl">
                  <Eye className="w-5 h-5" />
                  View Details
                </span>
              </div>

              {/* Vehicle info overlay at bottom */}
              <div className="absolute bottom-0 left-0 right-0 p-5">
                <div className="flex items-end justify-between">
                  <div>
                    <h3 className="text-2xl xl:text-3xl font-black text-white leading-tight drop-shadow-lg">
                      {vehicle.year} {vehicle.make} {vehicle.model}
                    </h3>
                    {vehicle.trim && (
                      <p className="text-gray-300 text-sm font-medium mt-0.5">{vehicle.trim}</p>
                    )}
                    <div className="flex items-center gap-4 mt-2">
                      <div className="flex items-center gap-1.5 text-gray-300">
                        <Gauge className="w-3.5 h-3.5 text-neon-pink" />
                        <span className="text-xs font-medium">{(vehicle.mileage / 1000).toFixed(0)}K mi</span>
                      </div>
                      <div className="flex items-center gap-1.5 text-gray-300">
                        <Fuel className="w-3.5 h-3.5 text-neon-green" />
                        <span className="text-xs font-medium">{vehicle.fuelType}</span>
                      </div>
                      <div className="flex items-center gap-1.5 text-gray-300">
                        <Settings2 className="w-3.5 h-3.5 text-neon-cyan" />
                        <span className="text-xs font-medium">{vehicle.transmission}</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="px-4 py-2 bg-black/60 backdrop-blur-sm rounded-xl border border-neon-orange/30">
                      <span className="text-neon-orange font-display font-bold text-2xl neon-text-orange">
                        ${vehicle.price.toLocaleString()}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </Link>

          {/* Navigation arrows */}
          {featured.length > 1 && (
            <>
              <button
                onClick={(e) => { e.preventDefault(); prev(); }}
                className="absolute left-3 top-1/2 -translate-y-1/2 p-2.5 bg-black/50 backdrop-blur-sm rounded-full text-white hover:bg-black/70 hover:scale-110 transition-all opacity-0 group-hover:opacity-100 z-10"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <button
                onClick={(e) => { e.preventDefault(); next(); }}
                className="absolute right-3 top-1/2 -translate-y-1/2 p-2.5 bg-black/50 backdrop-blur-sm rounded-full text-white hover:bg-black/70 hover:scale-110 transition-all opacity-0 group-hover:opacity-100 z-10"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </>
          )}
        </div>
      </div>

      {/* Thumbnail strip below carousel */}
      {featured.length > 1 && (
        <div className="flex gap-2 mt-3 justify-center">
          {featured.map((v, i) => (
            <button
              key={v.id}
              onClick={() => {
                if (!isTransitioning) {
                  setIsTransitioning(true);
                  setCurrentIndex(i);
                  setTimeout(() => setIsTransitioning(false), 600);
                }
              }}
              className={`relative overflow-hidden rounded-lg transition-all duration-300 ${
                i === currentIndex
                  ? 'w-20 h-12 border-2 border-neon-pink shadow-lg shadow-neon-pink/20 scale-105'
                  : 'w-16 h-10 border border-white/10 opacity-50 hover:opacity-80 hover:border-white/30'
              }`}
            >
              <img
                src={v.image}
                alt={`${v.year} ${v.make} ${v.model}`}
                className="w-full h-full object-cover"
              />
              {i === currentIndex && (
                <div className="absolute inset-0 bg-neon-pink/10" />
              )}
            </button>
          ))}
        </div>
      )}

      {/* Progress dots */}
      {featured.length > 1 && (
        <div className="flex gap-1.5 mt-2 justify-center">
          {featured.map((_, i) => (
            <button
              key={i}
              onClick={() => {
                if (!isTransitioning) {
                  setIsTransitioning(true);
                  setCurrentIndex(i);
                  setTimeout(() => setIsTransitioning(false), 600);
                }
              }}
              className={`h-1 rounded-full transition-all duration-500 ${
                i === currentIndex
                  ? 'w-8 bg-gradient-to-r from-neon-pink to-neon-orange'
                  : 'w-2 bg-white/20 hover:bg-white/40'
              }`}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default HeroCarousel;
