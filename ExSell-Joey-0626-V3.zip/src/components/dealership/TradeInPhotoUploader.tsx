import React, { useRef, useState } from 'react';
import {
  Loader2, AlertCircle, Upload, X, CheckCircle2, GripVertical,
} from 'lucide-react';
import {
  compressImage,
  formatFileSize,
  rotateImage,
  dataUrlToFile,
  readFileAsDataUrl,
  type ProcessedImage,
} from '@/lib/imageCompression';

/**
 * Trade-In photo uploader.
 *
 * Self-contained slot grid extracted from TradeInSection.tsx. The customer can:
 *  - tap any slot to pick a photo (mobile = camera roll / capture)
 *  - drag-and-drop slot cards to reorder them so the most important shot is first
 *  - replace or remove a photo
 *
 * Photos are EXIF-rotated (so iPhone shots don't end up sideways) and then
 * compressed in-browser via the existing src/lib/imageCompression helpers
 * BEFORE they're handed back to the parent form for upload.
 */

export type PhotoSlotKey = 'front' | 'back' | 'left' | 'right' | 'interior' | 'odometer';

export interface PhotoSlot {
  key: PhotoSlotKey;
  label: string;
  hint: string;
  file: File | null;
  thumbnail: string | null;
  originalSize: number;
  compressedSize: number;
  status: 'empty' | 'processing' | 'ready' | 'uploading' | 'done' | 'error';
  errorMessage?: string;
  publicUrl?: string;
}

export const PHOTO_SLOTS: Array<{ key: PhotoSlotKey; label: string; hint: string }> = [
  { key: 'front',    label: 'Front',      hint: 'Front of the vehicle' },
  { key: 'back',     label: 'Back',       hint: 'Rear / bumper' },
  { key: 'left',     label: 'Left Side',  hint: "Driver's side, full length" },
  { key: 'right',    label: 'Right Side', hint: 'Passenger side, full length' },
  { key: 'interior', label: 'Interior',   hint: 'Dashboard / seats' },
  { key: 'odometer', label: 'Odometer',   hint: 'Mileage on the cluster' },
];

export const MIN_PHOTOS = 2;
export const MAX_PHOTOS = 6;

export const initialSlots = (): PhotoSlot[] =>
  PHOTO_SLOTS.map((s) => ({
    ...s,
    file: null,
    thumbnail: null,
    originalSize: 0,
    compressedSize: 0,
    status: 'empty',
  }));

// ---------------------------------------------------------------------------
// EXIF orientation reader (JPEGs only). Returns 1–8 per the EXIF spec; we only
// auto-rotate the three non-mirrored rotations (3, 6, 8) which cover ~all
// real-world iPhone/Android photos.
// ---------------------------------------------------------------------------
async function readExifOrientation(file: File): Promise<number> {
  const type = file.type.toLowerCase();
  if (!type.includes('jpeg') && !type.includes('jpg')) return 1;
  try {
    const buf = await file.slice(0, 65536).arrayBuffer();
    const view = new DataView(buf);
    if (view.byteLength < 4) return 1;
    if (view.getUint16(0, false) !== 0xffd8) return 1; // not a JPEG SOI
    const length = view.byteLength;
    let offset = 2;
    while (offset < length) {
      if (offset + 2 > length) return 1;
      const marker = view.getUint16(offset, false);
      offset += 2;
      if (marker === 0xffe1) {
        // APP1 segment — look for "Exif\0\0"
        if (offset + 8 > length) return 1;
        if (view.getUint32(offset + 2, false) !== 0x45786966) return 1;
        const tiffOffset = offset + 8;
        if (tiffOffset + 8 > length) return 1;
        const little = view.getUint16(tiffOffset, false) === 0x4949;
        const firstIFD = view.getUint32(tiffOffset + 4, little);
        const dirStart = tiffOffset + firstIFD;
        if (dirStart + 2 > length) return 1;
        const tags = view.getUint16(dirStart, little);
        for (let i = 0; i < tags; i++) {
          const entry = dirStart + 2 + i * 12;
          if (entry + 10 > length) return 1;
          if (view.getUint16(entry, little) === 0x0112) {
            return view.getUint16(entry + 8, little);
          }
        }
        return 1;
      } else if ((marker & 0xff00) !== 0xff00) {
        return 1; // not a marker — bail
      } else {
        if (offset + 2 > length) return 1;
        offset += view.getUint16(offset, false);
      }
    }
  } catch {
    // fall through
  }
  return 1;
}

/** Map EXIF orientation -> rotation degrees we need to apply on-canvas. */
const ORIENTATION_ROTATION: Record<number, number> = {
  3: 180,
  6: 90,
  8: 270,
};

/**
 * Apply EXIF orientation correction to a file, then compress it.
 * Exposed so the parent component (or other consumers) can reuse the same
 * pipeline if they ever need to.
 */
export async function processPhotoFile(file: File): Promise<ProcessedImage> {
  let working = file;
  const orientation = await readExifOrientation(file);
  const deg = ORIENTATION_ROTATION[orientation];
  if (deg) {
    try {
      const dataUrl = await readFileAsDataUrl(file);
      const rotatedUrl = await rotateImage(dataUrl, deg);
      working = dataUrlToFile(rotatedUrl, file.name.replace(/\.[^.]+$/, '.jpg'));
    } catch (err) {
      // If rotation fails for any reason, fall back to the original file —
      // a sideways photo is still better than a failed upload.
      console.warn('EXIF auto-rotate failed, using original file:', err);
    }
  }
  return compressImage(working, {
    maxWidth: 1600,
    maxHeight: 1600,
    quality: 0.8,
    format: 'image/jpeg',
  });
}

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

interface TradeInPhotoUploaderProps {
  photos: PhotoSlot[];
  onPhotosChange: (next: PhotoSlot[]) => void;
  disabled?: boolean;
}

export const TradeInPhotoUploader: React.FC<TradeInPhotoUploaderProps> = ({
  photos,
  onPhotosChange,
  disabled,
}) => {
  const fileInputs = useRef<Record<string, HTMLInputElement | null>>({});
  const [dragIndex, setDragIndex] = useState<number | null>(null);
  const [dragOverIndex, setDragOverIndex] = useState<number | null>(null);

  const updateSlot = (key: PhotoSlotKey, patch: Partial<PhotoSlot>) => {
    onPhotosChange(photos.map((p) => (p.key === key ? { ...p, ...patch } : p)));
  };

  const handlePick = (key: PhotoSlotKey) => {
    if (disabled) return;
    fileInputs.current[key]?.click();
  };

  const handleFileChange = async (
    key: PhotoSlotKey,
    e: React.ChangeEvent<HTMLInputElement>,
  ) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      updateSlot(key, { status: 'error', errorMessage: 'Please choose an image file.' });
      return;
    }

    updateSlot(key, { status: 'processing', errorMessage: undefined });

    try {
      const processed = await processPhotoFile(file);
      // Re-read latest array via callback form to avoid stale closure
      onPhotosChange(
        photos.map((p) =>
          p.key === key
            ? {
                ...p,
                file: processed.file,
                thumbnail: processed.thumbnail,
                originalSize: processed.originalSize,
                compressedSize: processed.compressedSize,
                status: 'ready',
                errorMessage: undefined,
              }
            : p,
        ),
      );
    } catch (err: any) {
      console.error('Photo processing failed:', err);
      updateSlot(key, {
        status: 'error',
        errorMessage: err?.message || 'Failed to process image.',
      });
    }
  };

  const handleRemove = (key: PhotoSlotKey) => {
    onPhotosChange(
      photos.map((p) =>
        p.key === key
          ? {
              key: p.key,
              label: p.label,
              hint: p.hint,
              file: null,
              thumbnail: null,
              originalSize: 0,
              compressedSize: 0,
              status: 'empty',
            }
          : p,
      ),
    );
  };

  // -------- Drag-and-drop reordering --------
  const handleDragStart = (idx: number) => (e: React.DragEvent) => {
    if (disabled) return;
    setDragIndex(idx);
    e.dataTransfer.effectAllowed = 'move';
    // Some browsers require data to start a drag
    try { e.dataTransfer.setData('text/plain', String(idx)); } catch {}
  };

  const handleDragOver = (idx: number) => (e: React.DragEvent) => {
    if (dragIndex === null) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    if (dragOverIndex !== idx) setDragOverIndex(idx);
  };

  const handleDragLeave = (idx: number) => () => {
    if (dragOverIndex === idx) setDragOverIndex(null);
  };

  const handleDrop = (idx: number) => (e: React.DragEvent) => {
    e.preventDefault();
    const from = dragIndex;
    setDragIndex(null);
    setDragOverIndex(null);
    if (from === null || from === idx) return;
    const next = photos.slice();
    const [moved] = next.splice(from, 1);
    next.splice(idx, 0, moved);
    onPhotosChange(next);
  };

  const handleDragEnd = () => {
    setDragIndex(null);
    setDragOverIndex(null);
  };

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
      {photos.map((slot, idx) => (
        <PhotoSlotCard
          key={slot.key}
          slot={slot}
          index={idx}
          isDragging={dragIndex === idx}
          isDragTarget={dragOverIndex === idx && dragIndex !== null && dragIndex !== idx}
          onPick={() => handlePick(slot.key)}
          onRemove={() => handleRemove(slot.key)}
          inputRef={(el) => { fileInputs.current[slot.key] = el; }}
          onFileChange={(e) => handleFileChange(slot.key, e)}
          onDragStart={handleDragStart(idx)}
          onDragOver={handleDragOver(idx)}
          onDragLeave={handleDragLeave(idx)}
          onDrop={handleDrop(idx)}
          onDragEnd={handleDragEnd}
          disabled={disabled}
        />
      ))}
    </div>
  );
};

// ---------------------------------------------------------------------------
// Slot card
// ---------------------------------------------------------------------------

interface PhotoSlotCardProps {
  slot: PhotoSlot;
  index: number;
  isDragging: boolean;
  isDragTarget: boolean;
  onPick: () => void;
  onRemove: () => void;
  inputRef: (el: HTMLInputElement | null) => void;
  onFileChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onDragStart: (e: React.DragEvent) => void;
  onDragOver: (e: React.DragEvent) => void;
  onDragLeave: () => void;
  onDrop: (e: React.DragEvent) => void;
  onDragEnd: () => void;
  disabled?: boolean;
}

const PhotoSlotCard: React.FC<PhotoSlotCardProps> = ({
  slot, index, isDragging, isDragTarget,
  onPick, onRemove, inputRef, onFileChange,
  onDragStart, onDragOver, onDragLeave, onDrop, onDragEnd,
  disabled,
}) => {
  const isProcessing = slot.status === 'processing';
  const isUploading = slot.status === 'uploading';
  const isError = slot.status === 'error';
  const hasImage =
    (slot.status === 'ready' || slot.status === 'done' || slot.status === 'uploading') &&
    !!slot.thumbnail;

  // The whole card is draggable so customers can grab it from anywhere,
  // not just the small handle. We disable drag while a file is uploading.
  const draggable = !disabled && !isUploading && !isProcessing;

  return (
    <div
      draggable={draggable}
      onDragStart={onDragStart}
      onDragOver={onDragOver}
      onDragLeave={onDragLeave}
      onDrop={onDrop}
      onDragEnd={onDragEnd}
      className={`relative aspect-[4/3] rounded-xl border-2 overflow-hidden transition-all ${
        isDragging ? 'opacity-40 scale-95' : ''
      } ${
        isDragTarget ? 'border-neon-orange ring-2 ring-neon-orange/40 scale-[1.02]' :
        isError
          ? 'border-red-500/50 bg-red-500/5'
          : hasImage
          ? slot.status === 'done'
            ? 'border-neon-green/40 bg-black'
            : 'border-neon-cyan/40 bg-black'
          : 'border-dashed border-white/15 bg-white/[0.02] hover:border-neon-orange/40 hover:bg-neon-orange/5'
      } ${draggable ? 'cursor-grab active:cursor-grabbing' : ''}`}
    >
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={onFileChange}
        disabled={disabled}
      />

      {/* Position / drag-handle pill — top-left */}
      <div
        className="absolute top-1.5 left-1.5 z-10 inline-flex items-center gap-1 px-1.5 py-0.5 bg-black/70 backdrop-blur-sm border border-white/20 rounded text-[10px] text-white font-bold pointer-events-none"
        title="Drag to reorder"
      >
        <GripVertical className="w-2.5 h-2.5 opacity-80" />
        <span>#{index + 1}</span>
      </div>

      {hasImage && slot.thumbnail ? (
        <>
          <img
            src={slot.thumbnail}
            alt={slot.label}
            className="absolute inset-0 w-full h-full object-cover pointer-events-none"
            draggable={false}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent pointer-events-none" />

          {isUploading && (
            <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
              <Loader2 className="w-6 h-6 text-neon-cyan animate-spin" />
            </div>
          )}

          {!isUploading && (
            <button
              type="button"
              onClick={onRemove}
              title="Remove photo"
              className="absolute top-1.5 right-1.5 z-10 w-7 h-7 bg-black/70 hover:bg-red-500 border border-white/20 rounded-full flex items-center justify-center text-white transition-colors"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}

          <div className="absolute bottom-0 left-0 right-0 p-2 pointer-events-none">
            <div className="text-[11px] font-bold text-white drop-shadow flex items-center justify-between gap-1">
              <span className="truncate">{slot.label}</span>
              {slot.status === 'done' && (
                <CheckCircle2 className="w-3 h-3 text-neon-green flex-shrink-0" />
              )}
            </div>
            {slot.compressedSize > 0 && (
              <div className="text-[10px] text-gray-300/80 mt-0.5">
                {formatFileSize(slot.compressedSize)}
              </div>
            )}
          </div>

          {!isUploading && (
            <button
              type="button"
              onClick={onPick}
              className="absolute bottom-1.5 right-1.5 z-10 px-2 py-1 bg-black/70 hover:bg-neon-cyan/20 border border-white/20 hover:border-neon-cyan/50 rounded text-[10px] text-white font-semibold transition-colors"
            >
              Replace
            </button>
          )}
        </>
      ) : (
        <button
          type="button"
          onClick={onPick}
          disabled={isProcessing || disabled}
          className="absolute inset-0 w-full h-full flex flex-col items-center justify-center gap-1.5 p-3 text-center disabled:cursor-wait"
        >
          {isProcessing ? (
            <Loader2 className="w-6 h-6 text-neon-cyan animate-spin" />
          ) : isError ? (
            <AlertCircle className="w-6 h-6 text-red-400" />
          ) : (
            <div className="w-9 h-9 rounded-full bg-neon-orange/10 border border-neon-orange/30 flex items-center justify-center">
              <Upload className="w-4 h-4 text-neon-orange" />
            </div>
          )}
          <div className="text-xs font-bold text-white">{slot.label}</div>
          <div className="text-[10px] text-gray-500 leading-tight">
            {isProcessing
              ? 'Processing…'
              : isError
              ? slot.errorMessage || 'Failed'
              : slot.hint}
          </div>
        </button>
      )}
    </div>
  );
};

export default TradeInPhotoUploader;
