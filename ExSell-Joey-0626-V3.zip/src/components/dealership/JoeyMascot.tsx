import React, { useState, useEffect, useCallback, useRef } from 'react';
import { X, ChevronRight, MessageCircle, ArrowDown, GripVertical } from 'lucide-react';
import JoeyAvatar, { JoeyPose } from './JoeyAvatar';
import JoeyChatPanel from './JoeyChatPanel';

const STORAGE_KEY = 'exsell-joey-dismissed';
const POSITION_KEY = 'exsell-joey-position';
const SOUND_PREF_KEY = 'exsell-joey-notif-sound';
const BROWSER_NOTIF_KEY = 'exsell-joey-browser-notif';
const MOBILE_BP = 640;

interface JoeyMessage {
  text: string;
  highlight?: string;
  scrollTo?: string;
  pose?: JoeyPose;
}

const MESSAGES: JoeyMessage[] = [
  { text: "Hey there! I'm Joey, your guide to Ex$ell Car Sales!", pose: 'happy' },
  { text: "Scroll down to browse our Inventory — find your dream ride right here!", highlight: "Inventory", scrollTo: "inventory", pose: 'talking' },
  { text: "Check out our Services section to see how we can help with trade-ins, detailing & more.", highlight: "Services", scrollTo: "services", pose: 'talking' },
  { text: "Wondering what makes us different? Visit Why Us to find out!", highlight: "Why Us", scrollTo: "why-us", pose: 'thinking' },
  { text: "Ready to talk? Hit Contact Us or call us anytime at (631) 388-4426!", highlight: "Contact Us", scrollTo: "contact", pose: 'happy' },
];

interface SectionReaction { pose: JoeyPose; tooltip: string; glowColor: string; }

const SECTION_REACTIONS: Record<string, SectionReaction> = {
  hero: { pose: 'idle', tooltip: '', glowColor: '#FF0080' },
  inventory: { pose: 'excited', tooltip: 'Hot rides right here!', glowColor: '#BFFF00' },
  services: { pose: 'wrench', tooltip: 'We keep you rolling!', glowColor: '#00F0FF' },
  'trade-in': { pose: 'pointing', tooltip: 'Trade in your ride!', glowColor: '#FF8C00' },
  'why-us': { pose: 'thinking', tooltip: "Here's why we're #1", glowColor: '#FF8C00' },
  reviews: { pose: 'happy', tooltip: 'Our fans speak up!', glowColor: '#FF0080' },
  contact: { pose: 'pointing', tooltip: 'Reach out below!', glowColor: '#FF0080' },
};

const SECTION_PRIORITY = ['contact', 'reviews', 'why-us', 'trade-in', 'services', 'inventory', 'hero'];



interface Position { x: number; y: number; }

function loadPosition(): Position | null {
  try {
    const raw = localStorage.getItem(POSITION_KEY);
    if (raw) {
      const pos = JSON.parse(raw) as Position;
      if (typeof pos.x === 'number' && typeof pos.y === 'number' && pos.x >= 0 && pos.y >= 0 && pos.x <= window.innerWidth - 40 && pos.y <= window.innerHeight - 40) return pos;
    }
  } catch {}
  return null;
}

function savePosition(pos: Position) {
  try { localStorage.setItem(POSITION_KEY, JSON.stringify(pos)); } catch {}
}

// ── Notification sound via Web Audio API ──
let audioCtxSingleton: AudioContext | null = null;

function getAudioContext(): AudioContext | null {
  try {
    if (!audioCtxSingleton || audioCtxSingleton.state === 'closed') {
      audioCtxSingleton = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    if (audioCtxSingleton.state === 'suspended') audioCtxSingleton.resume();
    return audioCtxSingleton;
  } catch { return null; }
}

function playNotificationChime() {
  const ctx = getAudioContext();
  if (!ctx) return;
  const now = ctx.currentTime;
  const notes = [
    { freq: 1046.5, delay: 0, dur: 0.3, vol: 0.15 },
    { freq: 1318.5, delay: 0.1, dur: 0.35, vol: 0.12 },
    { freq: 1568, delay: 0.2, dur: 0.35, vol: 0.1 },
  ];
  for (const n of notes) {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(n.freq, now + n.delay);
    gain.gain.setValueAtTime(0, now);
    gain.gain.setValueAtTime(n.vol, now + n.delay);
    gain.gain.exponentialRampToValueAtTime(0.001, now + n.delay + n.dur);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now + n.delay);
    osc.stop(now + n.delay + n.dur);
  }
}

// ── Browser notification helpers ──
function canShowBrowserNotifications(): boolean {
  return 'Notification' in window && Notification.permission === 'granted';
}

async function requestBrowserNotificationPermission(): Promise<boolean> {
  if (!('Notification' in window)) return false;
  if (Notification.permission === 'granted') return true;
  if (Notification.permission === 'denied') return false;
  try { return (await Notification.requestPermission()) === 'granted'; } catch { return false; }
}

function showBrowserNotification(text: string) {
  if (!canShowBrowserNotifications()) return;
  try {
    const n = new Notification('Joey from Ex$ell Car Sales', {
      body: text.length > 120 ? text.slice(0, 117) + '...' : text,
      icon: 'https://d64gsuwffb70l.cloudfront.net/6917af11eb66b8b0c2b0bc86_1774223659449_0339845b.jpg',
      tag: 'joey-chat',
      renotify: true,
      silent: true,
    });
    setTimeout(() => n.close(), 5000);
    n.onclick = () => { window.focus(); n.close(); };
  } catch {}
}

const PANEL_WIDTH = 400;
const PANEL_HEIGHT = 500;
const AVATAR_SIZE = 80;

const JoeyMascot: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [currentMessageIndex, setCurrentMessageIndex] = useState(0);
  const [displayedText, setDisplayedText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [hasBeenDismissed, setHasBeenDismissed] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [showPulse, setShowPulse] = useState(true);
  const [isAnimatingOut, setIsAnimatingOut] = useState(false);
  const [isWaving, setIsWaving] = useState(false);
  const [currentPose, setCurrentPose] = useState<JoeyPose>('idle');
  const typingRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const autoAdvanceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const waveTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const [chatMode, setChatMode] = useState(false);
  const chatPoseActiveRef = useRef(false);

  const [activeSection, setActiveSection] = useState<string>('hero');
  const [sectionTooltip, setSectionTooltip] = useState<string>('');
  const [tooltipGlow, setTooltipGlow] = useState<string>('#FF0080');
  const [tooltipVisible, setTooltipVisible] = useState(false);
  const visibleSectionsRef = useRef<Set<string>>(new Set());
  const tooltipTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const prevSectionRef = useRef<string>('hero');

  const [position, setPosition] = useState<Position | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const dragStartRef = useRef<{ x: number; y: number; posX: number; posY: number } | null>(null);
  const hasDraggedRef = useRef(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const [windowSize, setWindowSize] = useState({ w: window.innerWidth, h: window.innerHeight });
  const isMobile = windowSize.w < MOBILE_BP;

  // ── Notification system state ──
  const [unreadCount, setUnreadCount] = useState(0);
  const [soundEnabled, setSoundEnabled] = useState(() => {
    try { return localStorage.getItem(SOUND_PREF_KEY) === 'true'; } catch { return false; }
  });
  const [notificationsEnabled, setNotificationsEnabled] = useState(() => {
    try { return localStorage.getItem(BROWSER_NOTIF_KEY) === 'true' && canShowBrowserNotifications(); } catch { return false; }
  });
  const [tabFocused, setTabFocused] = useState(() => document.hasFocus());
  const [badgeAnimating, setBadgeAnimating] = useState(false);

  // Refs to avoid stale closures in callbacks
  const panelVisibleRef = useRef(false);
  const soundEnabledRef = useRef(soundEnabled);
  const notificationsEnabledRef = useRef(notificationsEnabled);
  const tabFocusedRef = useRef(tabFocused);

  useEffect(() => { soundEnabledRef.current = soundEnabled; }, [soundEnabled]);
  useEffect(() => { notificationsEnabledRef.current = notificationsEnabled; }, [notificationsEnabled]);
  useEffect(() => { tabFocusedRef.current = tabFocused; }, [tabFocused]);

  // Persist preferences
  useEffect(() => { try { localStorage.setItem(SOUND_PREF_KEY, soundEnabled ? 'true' : 'false'); } catch {} }, [soundEnabled]);
  useEffect(() => { try { localStorage.setItem(BROWSER_NOTIF_KEY, notificationsEnabled ? 'true' : 'false'); } catch {} }, [notificationsEnabled]);

  // Track tab focus
  useEffect(() => {
    const onVis = () => setTabFocused(!document.hidden);
    const onFocus = () => setTabFocused(true);
    const onBlur = () => setTabFocused(false);
    document.addEventListener('visibilitychange', onVis);
    window.addEventListener('focus', onFocus);
    window.addEventListener('blur', onBlur);
    return () => { document.removeEventListener('visibilitychange', onVis); window.removeEventListener('focus', onFocus); window.removeEventListener('blur', onBlur); };
  }, []);

  const handleSoundToggle = useCallback(() => {
    setSoundEnabled((prev) => { const next = !prev; if (next) playNotificationChime(); return next; });
  }, []);

  const handleNotificationsToggle = useCallback(async () => {
    if (notificationsEnabled) { setNotificationsEnabled(false); return; }
    const granted = await requestBrowserNotificationPermission();
    setNotificationsEnabled(granted);
  }, [notificationsEnabled]);

  // Handle new message from Joey (stable callback using refs)
  const handleNewMessage = useCallback((text: string) => {
    if (!panelVisibleRef.current) {
      setUnreadCount((prev) => prev + 1);
      setBadgeAnimating(true);
      setTimeout(() => setBadgeAnimating(false), 600);
      if (soundEnabledRef.current) playNotificationChime();
      if (notificationsEnabledRef.current && !tabFocusedRef.current) showBrowserNotification(text);
    }
  }, []);

  useEffect(() => {
    const handleResize = () => setWindowSize({ w: window.innerWidth, h: window.innerHeight });
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => { const saved = loadPosition(); if (saved) setPosition(saved); }, []);

  const isOnRightSide = position ? (position.x + PANEL_WIDTH > windowSize.w) : false;
  const isNearTop = position ? (position.y < PANEL_HEIGHT) : true; // default position is at top, so panels open below

  const isBubbleActive = isOpen && !isMinimized && !chatMode;
  const isChatActive = chatMode && isOpen && !isMinimized;

  useEffect(() => { panelVisibleRef.current = isChatActive; }, [isChatActive]);

  // IntersectionObserver for section tracking
  useEffect(() => {
    const sectionIds = ['hero', 'inventory', 'services', 'trade-in', 'why-us', 'reviews', 'contact'];

    const elements: Element[] = [];
    sectionIds.forEach((id) => { const el = document.getElementById(id); if (el) elements.push(el); });
    if (!elements.length) return;

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => { if (entry.isIntersecting) visibleSectionsRef.current.add(entry.target.id); else visibleSectionsRef.current.delete(entry.target.id); });
      let chosen = 'hero';
      for (const s of SECTION_PRIORITY) { if (visibleSectionsRef.current.has(s)) { chosen = s; break; } }
      setActiveSection(chosen);
    }, { root: null, rootMargin: '-20% 0px -20% 0px', threshold: 0 });
    elements.forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const reaction = SECTION_REACTIONS[activeSection];
    if (!reaction) return;
    if (!isBubbleActive && !isChatActive) setCurrentPose(reaction.pose);
    if (!isChatActive && activeSection !== prevSectionRef.current && reaction.tooltip) {
      prevSectionRef.current = activeSection;
      setSectionTooltip(reaction.tooltip); setTooltipGlow(reaction.glowColor); setTooltipVisible(true);
      if (tooltipTimeoutRef.current) clearTimeout(tooltipTimeoutRef.current);
      tooltipTimeoutRef.current = setTimeout(() => setTooltipVisible(false), 3000);
    } else if (!reaction.tooltip) { prevSectionRef.current = activeSection; setTooltipVisible(false); }
  }, [activeSection, isBubbleActive, isChatActive]);

  useEffect(() => () => { if (tooltipTimeoutRef.current) clearTimeout(tooltipTimeoutRef.current); }, []);

  useEffect(() => {
    try {
      if (localStorage.getItem(STORAGE_KEY) === 'true') {
        setHasBeenDismissed(true); setIsMinimized(true);
        const t = setTimeout(() => setIsVisible(true), 3000);
        return () => clearTimeout(t);
      }
    } catch {}
    const t = setTimeout(() => {
      setIsVisible(true); setIsWaving(true); setCurrentPose('waving');
      waveTimeoutRef.current = setTimeout(() => {
        setIsWaving(false); setCurrentPose('idle');
        setTimeout(() => { setIsOpen(true); setIsTyping(true); setCurrentPose('talking'); }, 400);
      }, 3000);
    }, 2500);
    return () => { clearTimeout(t); if (waveTimeoutRef.current) clearTimeout(waveTimeoutRef.current); };
  }, []);

  // Typing effect (tour mode only)
  useEffect(() => {
    if (!isTyping || !isOpen || chatMode) return;
    const message = MESSAGES[currentMessageIndex]?.text || '';
    let ci = 0; setDisplayedText(''); setCurrentPose('talking');
    const typeChar = () => {
      if (ci < message.length) { setDisplayedText(message.slice(0, ci + 1)); ci++; typingRef.current = setTimeout(typeChar, 25 + Math.random() * 20); }
      else { setIsTyping(false); setCurrentPose(MESSAGES[currentMessageIndex]?.pose || 'idle'); if (currentMessageIndex < MESSAGES.length - 1) autoAdvanceRef.current = setTimeout(() => goToNextMessage(), 4500); }
    };
    typingRef.current = setTimeout(typeChar, 300);
    return () => { if (typingRef.current) clearTimeout(typingRef.current); if (autoAdvanceRef.current) clearTimeout(autoAdvanceRef.current); };
  }, [isTyping, currentMessageIndex, isOpen, chatMode]);

  const goToNextMessage = useCallback(() => {
    if (autoAdvanceRef.current) clearTimeout(autoAdvanceRef.current);
    if (currentMessageIndex < MESSAGES.length - 1) { setCurrentMessageIndex((p) => p + 1); setIsTyping(true); }
  }, [currentMessageIndex]);

  const goToPrevMessage = useCallback(() => {
    if (autoAdvanceRef.current) clearTimeout(autoAdvanceRef.current);
    if (typingRef.current) clearTimeout(typingRef.current);
    if (currentMessageIndex > 0) { setCurrentMessageIndex((p) => p - 1); setIsTyping(true); }
  }, [currentMessageIndex]);

  const handleDismiss = useCallback(() => {
    if (autoAdvanceRef.current) clearTimeout(autoAdvanceRef.current);
    if (typingRef.current) clearTimeout(typingRef.current);
    setIsAnimatingOut(true);
    setTimeout(() => {
      setIsOpen(false); setIsMinimized(true); setHasBeenDismissed(true);
      setIsAnimatingOut(false); setShowPulse(false); chatPoseActiveRef.current = false;
      setCurrentPose(SECTION_REACTIONS[activeSection]?.pose || 'idle');
      localStorage.setItem(STORAGE_KEY, 'true');
    }, 400);
  }, [activeSection]);

  const handleChatClose = useCallback(() => handleDismiss(), [handleDismiss]);
  const handleChatPoseChange = useCallback((pose: JoeyPose) => { chatPoseActiveRef.current = true; setCurrentPose(pose); }, []);

  const handleAvatarClick = useCallback(() => {
    if (hasDraggedRef.current) { hasDraggedRef.current = false; return; }
    if (isMinimized || !isOpen) {
      setIsMinimized(false); setIsOpen(true); setShowPulse(false); setTooltipVisible(false);
      setUnreadCount(0);
      if (hasBeenDismissed) { setChatMode(true); setCurrentPose('happy'); }
      else { setChatMode(false); setCurrentMessageIndex(0); setIsTyping(true); setCurrentPose('happy'); }
    }
  }, [isMinimized, isOpen, hasBeenDismissed]);

  const handleScrollTo = useCallback((id: string) => { if (!id) return; document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' }); }, []);

  // Drag handlers
  const handleDragStart = useCallback((cx: number, cy: number) => {
    const c = containerRef.current; if (!c) return;
    const r = c.getBoundingClientRect();
    dragStartRef.current = { x: cx, y: cy, posX: r.left, posY: r.top }; hasDraggedRef.current = false;
  }, []);

  const handleDragMove = useCallback((cx: number, cy: number) => {
    if (!dragStartRef.current) return;
    const dx = cx - dragStartRef.current.x, dy = cy - dragStartRef.current.y;
    if (!isDragging && (Math.abs(dx) > 5 || Math.abs(dy) > 5)) setIsDragging(true);
    if (Math.abs(dx) > 5 || Math.abs(dy) > 5) hasDraggedRef.current = true;
    setPosition({ x: Math.max(0, Math.min(window.innerWidth - AVATAR_SIZE, dragStartRef.current.posX + dx)), y: Math.max(0, Math.min(window.innerHeight - AVATAR_SIZE, dragStartRef.current.posY + dy)) });
  }, [isDragging]);

  const handleDragEnd = useCallback(() => {
    if (dragStartRef.current && position) savePosition(position);
    dragStartRef.current = null; setTimeout(() => setIsDragging(false), 50);
  }, [position]);

  useEffect(() => {
    const mm = (e: MouseEvent) => { if (dragStartRef.current) { e.preventDefault(); handleDragMove(e.clientX, e.clientY); } };
    const mu = () => { if (dragStartRef.current) handleDragEnd(); };
    window.addEventListener('mousemove', mm); window.addEventListener('mouseup', mu);
    return () => { window.removeEventListener('mousemove', mm); window.removeEventListener('mouseup', mu); };
  }, [handleDragMove, handleDragEnd]);

  useEffect(() => {
    const tm = (e: TouchEvent) => { if (dragStartRef.current && e.touches.length === 1) handleDragMove(e.touches[0].clientX, e.touches[0].clientY); };
    const te = () => { if (dragStartRef.current) handleDragEnd(); };
    window.addEventListener('touchmove', tm, { passive: false }); window.addEventListener('touchend', te);
    return () => { window.removeEventListener('touchmove', tm); window.removeEventListener('touchend', te); };
  }, [handleDragMove, handleDragEnd]);

  const handleResetPosition = useCallback(() => { setPosition(null); try { localStorage.removeItem(POSITION_KEY); } catch {} }, []);

  // Lock body scroll on mobile when panel is open
  useEffect(() => {
    if (isMobile && (isBubbleActive || isChatActive)) { document.body.style.overflow = 'hidden'; return () => { document.body.style.overflow = ''; }; }
  }, [isMobile, isBubbleActive, isChatActive]);

  if (!isVisible) return null;

  const currentMessage = MESSAGES[currentMessageIndex];
  const avatarGlowColor = SECTION_REACTIONS[activeSection]?.glowColor || '#FF0080';
  const showTourBubble = isOpen && !isMinimized && !chatMode;
  const showChatPanel = isOpen && !isMinimized && chatMode;
  const chatPanelMounted = chatMode; // stays true after first activation

  const containerStyle: React.CSSProperties = position
    ? { position: 'fixed', left: position.x, top: position.y, bottom: 'auto', zIndex: 90 }
    : { position: 'fixed', top: 42, left: 16, zIndex: 90 };

  const desktopPanelStyle: React.CSSProperties = {
    position: 'absolute',
    ...(isNearTop ? { top: 'calc(100% + 12px)' } : { bottom: 'calc(100% + 12px)' }),
    ...(isOnRightSide ? { right: 0 } : { left: 0 }),
  };


  const tailSide = isOnRightSide ? 'right-8' : 'left-8';

  // ── Compute wrapper style for the single chat panel instance ──
  const chatWrapperStyle: React.CSSProperties = !showChatPanel
    ? { position: 'fixed', left: '-9999px', top: '-9999px', width: '1px', height: '1px', overflow: 'hidden', opacity: 0, pointerEvents: 'none' }
    : isMobile
    ? { position: 'fixed', bottom: 0, left: 8, right: 8, zIndex: 101 }
    : desktopPanelStyle;

  return (
    <>
      {/* ── Mobile backdrop when chat panel is visible ── */}
      {isMobile && showChatPanel && (
        <div className="fixed inset-0 z-[100]" style={{ pointerEvents: 'auto' }}>
          <div
            className={`absolute inset-0 bg-black/60 transition-opacity duration-300 ${isAnimatingOut ? 'opacity-0' : 'opacity-100'}`}
            onClick={handleDismiss}
            style={{ animation: !isAnimatingOut ? 'joeyBackdropIn 0.3s ease-out' : undefined }}
          />
        </div>
      )}

      {/* ── Mobile backdrop when tour bubble is visible ── */}
      {isMobile && showTourBubble && (
        <div className="fixed inset-0 z-[100] flex flex-col justify-end" style={{ pointerEvents: 'auto' }}>
          <div
            className={`absolute inset-0 bg-black/60 transition-opacity duration-300 ${isAnimatingOut ? 'opacity-0' : 'opacity-100'}`}
            onClick={handleDismiss}
            style={{ animation: !isAnimatingOut ? 'joeyBackdropIn 0.3s ease-out' : undefined }}
          />
          <div className="relative z-10 mx-2 mb-0">
            {renderMobileTourBubble({
              isAnimatingOut, displayedText, currentMessage, isTyping, handleScrollTo,
              currentMessageIndex, goToPrevMessage, goToNextMessage, handleDismiss,
              autoAdvanceRef, typingRef, setCurrentMessageIndex, setIsTyping,
            })}
          </div>
        </div>
      )}

      {/* ── Avatar + Desktop Panels container ── */}
      <div ref={containerRef} className={isDragging ? 'cursor-grabbing' : ''} style={containerStyle}>
        <div className="relative">

          {/* ── SINGLE Chat Panel instance — always mounted when chatMode is true ── */}
          {chatPanelMounted && (
            <div style={chatWrapperStyle}>
              <JoeyChatPanel
                onClose={handleChatClose}
                onPoseChange={handleChatPoseChange}
                onScrollTo={handleScrollTo}
                isAnimatingOut={isAnimatingOut}
                alignRight={isOnRightSide}
                panelBelow={isNearTop}

                isMobile={isMobile && showChatPanel}
                visible={showChatPanel}
                onNewMessage={handleNewMessage}
                soundEnabled={soundEnabled}
                onSoundToggle={handleSoundToggle}
                notificationsEnabled={notificationsEnabled}
                onNotificationsToggle={handleNotificationsToggle}
              />
            </div>
          )}

          {/* ── Tour Speech Bubble (DESKTOP ONLY) ── */}
          {!isMobile && showTourBubble && (
            <div
              className={`transition-all duration-500 ${isAnimatingOut ? 'opacity-0 translate-y-4 scale-95' : 'opacity-100 translate-y-0 scale-100'}`}
              style={{ ...desktopPanelStyle, width: 'min(360px, calc(100vw - 32px))', animation: !isAnimatingOut ? 'joeyBubbleIn 0.5s cubic-bezier(0.16, 1, 0.3, 1)' : undefined }}
            >
              <div className="relative rounded-2xl border border-white/[0.08] overflow-hidden" style={{ background: 'linear-gradient(135deg, rgba(10, 10, 18, 0.95), rgba(18, 8, 30, 0.95))', backdropFilter: 'blur(24px) saturate(1.5)', WebkitBackdropFilter: 'blur(24px) saturate(1.5)', boxShadow: '0 8px 60px rgba(0,0,0,0.5), 0 0 80px rgba(255,0,128,0.08), inset 0 1px 0 rgba(255,255,255,0.06)' }}>
                <div className="h-[2px] w-full" style={{ background: 'linear-gradient(90deg, transparent, #FF0080, #FF8C00, #BFFF00, #00F0FF, transparent)' }} />
                <div className="flex items-center justify-between px-4 pt-3 pb-2">
                  <div className="flex items-center gap-2">
                    <div className="relative"><div className="w-2 h-2 bg-neon-green rounded-full animate-pulse" /><div className="absolute inset-0 w-2 h-2 bg-neon-green rounded-full animate-ping opacity-40" /></div>
                    <span className="text-xs font-bold text-white/60 uppercase tracking-wider" style={{ fontFamily: 'Orbitron, sans-serif' }}>Joey — Your Guide</span>
                  </div>
                  <button onClick={handleDismiss} className="p-1 rounded-lg text-white/30 hover:text-white/70 hover:bg-white/5 transition-all" aria-label="Close Joey"><X className="w-4 h-4" /></button>
                </div>
                <div className="px-4 pb-3 min-h-[80px] flex items-start">
                  <p className="text-sm text-white/80 leading-relaxed">
                    {renderHighlightedText(displayedText, currentMessage?.highlight)}
                    {isTyping && <span className="inline-block w-[2px] h-4 bg-neon-cyan ml-0.5 align-middle animate-pulse" />}
                  </p>
                </div>
                {!isTyping && currentMessage?.scrollTo && (
                  <div className="px-4 pb-3">
                    <button onClick={() => handleScrollTo(currentMessage.scrollTo!)} className="flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold text-neon-cyan bg-neon-cyan/10 border border-neon-cyan/20 hover:bg-neon-cyan/20 hover:border-neon-cyan/40 transition-all group">
                      <ArrowDown className="w-3 h-3 group-hover:animate-bounce" />Jump to {currentMessage.highlight}
                    </button>
                  </div>
                )}
                <div className="px-4 pb-3">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-1.5">
                      {MESSAGES.map((_, idx) => (
                        <button key={idx} onClick={() => { if (autoAdvanceRef.current) clearTimeout(autoAdvanceRef.current); if (typingRef.current) clearTimeout(typingRef.current); setCurrentMessageIndex(idx); setIsTyping(true); }}
                          className={`h-1.5 rounded-full transition-all duration-300 ${idx === currentMessageIndex ? 'w-6 bg-gradient-to-r from-neon-pink to-neon-orange' : idx < currentMessageIndex ? 'w-1.5 bg-neon-pink/40' : 'w-1.5 bg-white/15'}`}
                          aria-label={`Go to message ${idx + 1}`} />
                      ))}
                    </div>
                    <span className="text-[10px] text-white/30 font-mono">{currentMessageIndex + 1}/{MESSAGES.length}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button onClick={goToPrevMessage} disabled={currentMessageIndex === 0} className="flex-1 flex items-center justify-center gap-1 px-3 py-2 rounded-lg text-xs font-semibold text-white/50 hover:text-white/80 hover:bg-white/5 disabled:opacity-30 disabled:cursor-not-allowed transition-all"><ChevronRight className="w-3 h-3 rotate-180" />Back</button>
                    {currentMessageIndex < MESSAGES.length - 1 ? (
                      <button onClick={goToNextMessage} className="flex-1 flex items-center justify-center gap-1 px-3 py-2 rounded-xl text-xs font-bold text-white transition-all hover:shadow-lg hover:shadow-neon-pink/20 hover:scale-[1.02] active:scale-[0.98]" style={{ background: 'linear-gradient(135deg, #FF0080, #FF8C00)' }}>Next<ChevronRight className="w-3 h-3" /></button>
                    ) : (
                      <button onClick={handleDismiss} className="flex-1 flex items-center justify-center gap-1 px-3 py-2 rounded-xl text-xs font-bold transition-all hover:shadow-lg hover:shadow-neon-cyan/20 hover:scale-[1.02] active:scale-[0.98]" style={{ background: 'linear-gradient(135deg, #00F0FF, #BFFF00)', color: '#000' }}>Got it, thanks!</button>
                    )}
                  </div>
                </div>
              </div>
              {isNearTop ? (
                <div className={`absolute -top-2 ${tailSide} w-4 h-4 rotate-45`} style={{ background: 'rgba(18, 8, 30, 0.95)', borderLeft: '1px solid rgba(255,255,255,0.08)', borderTop: '1px solid rgba(255,255,255,0.08)' }} />
              ) : (
                <div className={`absolute -bottom-2 ${tailSide} w-4 h-4 rotate-45`} style={{ background: 'rgba(18, 8, 30, 0.95)', borderRight: '1px solid rgba(255,255,255,0.08)', borderBottom: '1px solid rgba(255,255,255,0.08)' }} />
              )}

            </div>
          )}

          {/* ── Contextual Section Tooltip ── */}
          {!showChatPanel && !showTourBubble && tooltipVisible && sectionTooltip && (
            <div className={`absolute top-1/2 -translate-y-1/2 pointer-events-none ${isOnRightSide ? 'right-[72px]' : 'left-[72px]'}`} style={{ animation: isOnRightSide ? 'joeyTooltipInRight 0.35s cubic-bezier(0.16,1,0.3,1)' : 'joeyTooltipIn 0.35s cubic-bezier(0.16,1,0.3,1)' }}>
              <div className="relative px-3 py-1.5 rounded-lg whitespace-nowrap" style={{ background: 'rgba(10,10,18,0.92)', backdropFilter: 'blur(12px)', border: `1px solid ${tooltipGlow}40`, boxShadow: `0 0 20px ${tooltipGlow}15, 0 4px 20px rgba(0,0,0,0.4)` }}>
                <div className="absolute top-0 left-2 right-2 h-[1.5px] rounded-full" style={{ background: tooltipGlow, opacity: 0.6 }} />
                <span className="text-xs font-bold" style={{ color: tooltipGlow, textShadow: `0 0 8px ${tooltipGlow}60`, fontFamily: 'Orbitron, sans-serif' }}>{sectionTooltip}</span>
                {isOnRightSide ? (
                  <div className="absolute top-1/2 -right-[6px] -translate-y-1/2 w-0 h-0" style={{ borderTop: '5px solid transparent', borderBottom: '5px solid transparent', borderLeft: `6px solid ${tooltipGlow}40` }} />
                ) : (
                  <div className="absolute top-1/2 -left-[6px] -translate-y-1/2 w-0 h-0" style={{ borderTop: '5px solid transparent', borderBottom: '5px solid transparent', borderRight: `6px solid ${tooltipGlow}40` }} />
                )}
              </div>
            </div>
          )}

          {/* Joey Avatar */}
          <div className="relative flex items-end gap-1">
            {(isMinimized || !isOpen) && (
              <div className="absolute -top-5 left-1/2 -translate-x-1/2 flex items-center gap-0.5 opacity-0 hover:opacity-100 transition-opacity cursor-grab"
                onMouseDown={(e) => { e.preventDefault(); handleDragStart(e.clientX, e.clientY); }}
                onTouchStart={(e) => { if (e.touches.length === 1) handleDragStart(e.touches[0].clientX, e.touches[0].clientY); }}>
                <GripVertical className="w-3 h-3 text-white/30" />
              </div>
            )}

            <button
              onMouseDown={(e) => { if (isMinimized || !isOpen) handleDragStart(e.clientX, e.clientY); }}
              onTouchStart={(e) => { if ((isMinimized || !isOpen) && e.touches.length === 1) handleDragStart(e.touches[0].clientX, e.touches[0].clientY); }}
              onClick={handleAvatarClick}
              className={`relative group transition-all duration-300 ${isDragging ? 'cursor-grabbing scale-110' : isMinimized || !isOpen ? 'cursor-grab hover:scale-110' : ''}`}
              aria-label={isMinimized ? `Chat with Joey${unreadCount > 0 ? ` (${unreadCount} unread)` : ''}` : 'Joey mascot'}
              style={{ animation: isVisible && !position ? 'joeyAvatarIn 0.6s cubic-bezier(0.16,1,0.3,1)' : undefined }}
            >
              <div className={`absolute -inset-2 rounded-full transition-all duration-700 ${showPulse && !isOpen ? 'opacity-100' : 'opacity-0 group-hover:opacity-60'}`} style={{ background: `conic-gradient(from 0deg, ${avatarGlowColor}, #FF8C00, #BFFF00, #00F0FF, ${avatarGlowColor})`, animation: showPulse && !isOpen ? 'joeyRingSpin 3s linear infinite' : undefined, filter: 'blur(8px)' }} />

              {(isMinimized || !isOpen) && tooltipVisible && (
                <div className="absolute -inset-1.5 rounded-full transition-all duration-500" style={{ border: `2px solid ${avatarGlowColor}`, boxShadow: `0 0 12px ${avatarGlowColor}50, inset 0 0 8px ${avatarGlowColor}20`, animation: 'joeyGlowPulse 1.5s ease-in-out infinite' }} />
              )}

              {(isMinimized || !isOpen) && !hasBeenDismissed && (
                <div className="absolute -inset-1 rounded-full border-2 border-neon-pink animate-ping opacity-30" />
              )}

              {unreadCount > 0 && (isMinimized || !isOpen) && (
                <div className="absolute -inset-1.5 rounded-full" style={{ border: '2px solid #FF0080', boxShadow: '0 0 16px rgba(255,0,128,0.5), 0 0 32px rgba(255,0,128,0.2)', animation: 'joeyUnreadPulse 1.2s ease-in-out infinite' }} />
              )}

              <div className={`relative w-16 h-16 rounded-full overflow-visible flex items-center justify-center transition-all duration-500 ${isDragging ? 'ring-2 ring-neon-cyan/50 ring-offset-2 ring-offset-black' : ''}`}
                style={{
                  boxShadow: isDragging ? '0 0 30px rgba(0,240,255,0.5), 0 0 60px rgba(0,240,255,0.2)'
                    : unreadCount > 0 && (isMinimized || !isOpen) ? '0 0 25px rgba(255,0,128,0.5), 0 0 60px rgba(255,0,128,0.2)'
                    : tooltipVisible && (isMinimized || !isOpen) ? `0 0 20px ${avatarGlowColor}40, 0 0 60px ${avatarGlowColor}15`
                    : '0 0 20px rgba(255,0,128,0.3), 0 0 60px rgba(255,0,128,0.1)',
                  animation: isDragging ? undefined : 'joeyFloat 3s ease-in-out infinite',
                }}>
                <JoeyAvatar pose={currentPose} isTalking={isTyping && !chatMode} isWaving={isWaving} size={64} />
              </div>

              {/* Unread badge */}
              {unreadCount > 0 && (isMinimized || !isOpen) && (
                <div className="absolute -top-2 -right-2 z-10" style={{ animation: badgeAnimating ? 'joeyBadgeBounce 0.6s cubic-bezier(0.16,1,0.3,1)' : undefined }}>
                  <div className="relative flex items-center justify-center rounded-full border-2 border-black" style={{ background: 'linear-gradient(135deg, #FF0080, #FF8C00)', boxShadow: '0 0 12px rgba(255,0,128,0.6), 0 2px 8px rgba(0,0,0,0.4)', minWidth: unreadCount > 9 ? '28px' : '24px', height: '24px', padding: '0 5px' }}>
                    <span className="text-white font-black leading-none relative z-10" style={{ fontSize: unreadCount > 9 ? '10px' : '11px', fontFamily: 'Orbitron, sans-serif', textShadow: '0 1px 2px rgba(0,0,0,0.3)' }}>
                      {unreadCount > 99 ? '99+' : unreadCount}
                    </span>
                    <div className="absolute inset-0 rounded-full" style={{ background: 'linear-gradient(135deg, #FF0080, #FF8C00)', animation: 'joeyBadgePulse 2s ease-in-out infinite', filter: 'blur(4px)', opacity: 0.5 }} />
                  </div>
                </div>
              )}

              {/* Chat icon badge (no unread) */}
              {(isMinimized || !isOpen) && unreadCount === 0 && (
                <div className="absolute -top-1 -left-1 w-6 h-6 rounded-full flex items-center justify-center border border-white/20" style={{ background: hasBeenDismissed ? 'linear-gradient(135deg, #00F0FF, #BFFF00)' : 'linear-gradient(135deg, #FF0080, #FF8C00)', boxShadow: hasBeenDismissed ? '0 0 10px rgba(0,240,255,0.4)' : '0 0 10px rgba(255,0,128,0.4)' }}>
                  <MessageCircle className="w-3 h-3" style={{ color: hasBeenDismissed ? '#000' : '#fff' }} />
                </div>
              )}

              <div className="absolute bottom-0 right-0 w-4 h-4 rounded-full bg-neon-green border-2 border-black">
                <div className="absolute inset-0 rounded-full bg-neon-green animate-ping opacity-40" />
              </div>
            </button>

            {position && (isMinimized || !isOpen) && !isDragging && (
              <button onClick={handleResetPosition} className="absolute -bottom-5 left-1/2 -translate-x-1/2 text-[9px] text-white/30 hover:text-white/60 transition-colors whitespace-nowrap" title="Reset Joey's position">reset</button>
            )}
          </div>
        </div>

        <style>{`
          @keyframes joeyBubbleIn { from { opacity:0; transform:translateY(16px) scale(0.9); } to { opacity:1; transform:translateY(0) scale(1); } }
          @keyframes joeyAvatarIn { from { opacity:0; transform:scale(0) rotate(-180deg); } 60% { transform:scale(1.15) rotate(10deg); } to { opacity:1; transform:scale(1) rotate(0deg); } }
          @keyframes joeyFloat { 0%,100% { transform:translateY(0); } 50% { transform:translateY(-6px); } }
          @keyframes joeyRingSpin { from { transform:rotate(0deg); } to { transform:rotate(360deg); } }
          @keyframes joeyTooltipIn { from { opacity:0; transform:translateX(-8px) scale(0.9); } to { opacity:1; transform:translateX(0) scale(1); } }
          @keyframes joeyTooltipInRight { from { opacity:0; transform:translateX(8px) scale(0.9); } to { opacity:1; transform:translateX(0) scale(1); } }
          @keyframes joeyGlowPulse { 0%,100% { opacity:0.6; transform:scale(1); } 50% { opacity:1; transform:scale(1.05); } }
          @keyframes joeySheetIn { from { opacity:0; transform:translateY(100%); } to { opacity:1; transform:translateY(0); } }
          @keyframes joeySheetOut { from { opacity:1; transform:translateY(0); } to { opacity:0; transform:translateY(100%); } }
          @keyframes joeyBackdropIn { from { opacity:0; } to { opacity:1; } }
          @keyframes joeyBadgeBounce { 0% { transform:scale(0); } 40% { transform:scale(1.3); } 60% { transform:scale(0.9); } 80% { transform:scale(1.1); } 100% { transform:scale(1); } }
          @keyframes joeyBadgePulse { 0%,100% { opacity:0.4; transform:scale(1); } 50% { opacity:0.7; transform:scale(1.15); } }
          @keyframes joeyUnreadPulse { 0%,100% { opacity:0.5; transform:scale(1); } 50% { opacity:0.9; transform:scale(1.06); } }
        `}</style>
      </div>
    </>
  );
};

// ── Mobile tour bubble (extracted to keep main render clean) ──
function renderMobileTourBubble(props: {
  isAnimatingOut: boolean;
  displayedText: string;
  currentMessage: JoeyMessage | undefined;
  isTyping: boolean;
  handleScrollTo: (id: string) => void;
  currentMessageIndex: number;
  goToPrevMessage: () => void;
  goToNextMessage: () => void;
  handleDismiss: () => void;
  autoAdvanceRef: React.MutableRefObject<ReturnType<typeof setTimeout> | null>;
  typingRef: React.MutableRefObject<ReturnType<typeof setTimeout> | null>;
  setCurrentMessageIndex: React.Dispatch<React.SetStateAction<number>>;
  setIsTyping: React.Dispatch<React.SetStateAction<boolean>>;
}) {
  const { isAnimatingOut, displayedText, currentMessage, isTyping, handleScrollTo, currentMessageIndex, goToPrevMessage, goToNextMessage, handleDismiss, autoAdvanceRef, typingRef, setCurrentMessageIndex, setIsTyping } = props;

  return (
    <div className={`transition-all duration-500 ${isAnimatingOut ? 'opacity-0 translate-y-full' : 'opacity-100 translate-y-0'}`} style={{ animation: !isAnimatingOut ? 'joeySheetIn 0.35s cubic-bezier(0.16,1,0.3,1)' : undefined }}>
      <div className="relative rounded-2xl rounded-b-none border border-white/[0.08] border-b-0 overflow-hidden" style={{ background: 'linear-gradient(135deg, rgba(10,10,18,0.97), rgba(18,8,30,0.97))', backdropFilter: 'blur(24px) saturate(1.5)', WebkitBackdropFilter: 'blur(24px) saturate(1.5)', boxShadow: '0 -8px 60px rgba(0,0,0,0.5), 0 0 80px rgba(255,0,128,0.08)' }}>
        <div className="flex justify-center pt-2 pb-0"><div className="w-10 h-1 rounded-full bg-white/20" /></div>
        <div className="h-[2px] w-full mt-1" style={{ background: 'linear-gradient(90deg, transparent, #FF0080, #FF8C00, #BFFF00, #00F0FF, transparent)' }} />
        <div className="flex items-center justify-between px-4 pt-3 pb-2">
          <div className="flex items-center gap-2">
            <div className="relative"><div className="w-2 h-2 bg-neon-green rounded-full animate-pulse" /><div className="absolute inset-0 w-2 h-2 bg-neon-green rounded-full animate-ping opacity-40" /></div>
            <span className="text-xs font-bold text-white/60 uppercase tracking-wider" style={{ fontFamily: 'Orbitron, sans-serif' }}>Joey — Your Guide</span>
          </div>
          <button onClick={handleDismiss} className="p-2.5 min-w-[44px] min-h-[44px] flex items-center justify-center rounded-lg text-white/30 hover:text-white/70 hover:bg-white/5 transition-all" aria-label="Close Joey"><X className="w-5 h-5" /></button>
        </div>
        <div className="px-4 pb-3 min-h-[80px] flex items-start">
          <p className="text-sm text-white/80 leading-relaxed">
            {renderHighlightedText(displayedText, currentMessage?.highlight)}
            {isTyping && <span className="inline-block w-[2px] h-4 bg-neon-cyan ml-0.5 align-middle animate-pulse" />}
          </p>
        </div>
        {!isTyping && currentMessage?.scrollTo && (
          <div className="px-4 pb-3">
            <button onClick={() => handleScrollTo(currentMessage.scrollTo!)} className="flex items-center gap-2 px-4 py-3 min-h-[44px] rounded-lg text-sm font-semibold text-neon-cyan bg-neon-cyan/10 border border-neon-cyan/20 hover:bg-neon-cyan/20 hover:border-neon-cyan/40 transition-all group">
              <ArrowDown className="w-4 h-4 group-hover:animate-bounce" />Jump to {currentMessage.highlight}
            </button>
          </div>
        )}
        <div className="px-4 pb-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-1.5">
              {MESSAGES.map((_, idx) => (
                <button key={idx} onClick={() => { if (autoAdvanceRef.current) clearTimeout(autoAdvanceRef.current); if (typingRef.current) clearTimeout(typingRef.current); setCurrentMessageIndex(idx); setIsTyping(true); }}
                  className={`h-2 rounded-full transition-all duration-300 min-w-[8px] min-h-[8px] ${idx === currentMessageIndex ? 'w-8 bg-gradient-to-r from-neon-pink to-neon-orange' : idx < currentMessageIndex ? 'w-2 bg-neon-pink/40' : 'w-2 bg-white/15'}`}
                  aria-label={`Go to message ${idx + 1}`} />
              ))}
            </div>
            <span className="text-[11px] text-white/30 font-mono">{currentMessageIndex + 1}/{MESSAGES.length}</span>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={goToPrevMessage} disabled={currentMessageIndex === 0} className="flex-1 flex items-center justify-center gap-1 px-3 py-3 min-h-[44px] rounded-lg text-sm font-semibold text-white/50 hover:text-white/80 hover:bg-white/5 disabled:opacity-30 disabled:cursor-not-allowed transition-all"><ChevronRight className="w-4 h-4 rotate-180" />Back</button>
            {currentMessageIndex < MESSAGES.length - 1 ? (
              <button onClick={goToNextMessage} className="flex-1 flex items-center justify-center gap-1 px-3 py-3 min-h-[44px] rounded-xl text-sm font-bold text-white transition-all hover:shadow-lg hover:shadow-neon-pink/20 hover:scale-[1.02] active:scale-[0.98]" style={{ background: 'linear-gradient(135deg, #FF0080, #FF8C00)' }}>Next<ChevronRight className="w-4 h-4" /></button>
            ) : (
              <button onClick={handleDismiss} className="flex-1 flex items-center justify-center gap-1 px-3 py-3 min-h-[44px] rounded-xl text-sm font-bold transition-all hover:shadow-lg hover:shadow-neon-cyan/20 hover:scale-[1.02] active:scale-[0.98]" style={{ background: 'linear-gradient(135deg, #00F0FF, #BFFF00)', color: '#000' }}>Got it, thanks!</button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function renderHighlightedText(text: string, highlight?: string) {
  if (!highlight || !text.includes(highlight)) return <>{text}</>;
  const parts = text.split(highlight);
  return <>{parts[0]}<span className="text-neon-cyan font-bold neon-text-cyan">{highlight}</span>{parts.slice(1).join(highlight)}</>;
}

export default JoeyMascot;
