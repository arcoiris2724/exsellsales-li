import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import { Phone, Mail, MapPin, Clock, Facebook, Instagram, MessageSquare, ChevronUp, Shield, Cookie, FileText, Users, Star, Trophy } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { DEFAULT_CONTACT, DEFAULT_FOOTER, HOMEPAGE_SECTIONS } from '@/data/homepageDefaults';
import type { ContactSectionContent, FooterContent } from '@/data/homepageDefaults';

const LOGO_URL = 'https://d64gsuwffb70l.cloudfront.net/6917af11eb66b8b0c2b0bc86_1774223659449_0339845b.jpg';

const Footer: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [contact, setContact] = useState<ContactSectionContent>(DEFAULT_CONTACT);
  const [footer, setFooter] = useState<FooterContent>(DEFAULT_FOOTER);

  useEffect(() => {
    let cancelled = false;
    Promise.all([
      supabase.from('site_content').select('content').eq('section', HOMEPAGE_SECTIONS.contact).single(),
      supabase.from('site_content').select('content').eq('section', HOMEPAGE_SECTIONS.footer).single(),
    ]).then(([contactRes, footerRes]) => {
      if (cancelled) return;
      if (contactRes.data?.content) setContact(contactRes.data.content as ContactSectionContent);
      if (footerRes.data?.content) setFooter(footerRes.data.content as FooterContent);
    });
    return () => { cancelled = true; };
  }, []);

  const scrollTo = (id: string) => {
    if (location.pathname !== '/') {
      navigate('/');
      setTimeout(() => {
        const el = document.getElementById(id);
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      }, 200);
    } else {
      const el = document.getElementById(id);
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="relative bg-[#050505] border-t border-white/5">
      {/* Back to top */}
      <div className="absolute -top-5 left-1/2 -translate-x-1/2">
        <button onClick={scrollToTop}
          className="p-3 bg-gradient-to-r from-neon-pink to-neon-orange rounded-full text-white shadow-lg shadow-neon-pink/20 hover:scale-110 transition-transform">
          <ChevronUp className="w-5 h-5" />
        </button>
      </div>

      <div className="max-w-7xl mx-auto px-4 pt-16 pb-8">
        {/* Large centered logo banner */}
        <div className="flex flex-col items-center mb-12">
          <div className="relative group mb-4">
            <div className="absolute -inset-6 bg-gradient-to-br from-neon-pink/25 via-neon-orange/20 to-neon-cyan/25 rounded-2xl blur-2xl opacity-70 group-hover:opacity-100 transition-opacity" />
            <div className="absolute -inset-1 rounded-xl bg-gradient-to-br from-neon-pink/50 via-neon-orange/40 to-neon-cyan/50 p-[1px]">
              <div className="w-full h-full rounded-xl bg-[#050505]" />
            </div>
            <img src={LOGO_URL} alt="Ex$ell Car Sales" className="relative h-28 md:h-36 w-auto rounded-xl shadow-xl shadow-neon-pink/10 z-10" />
          </div>
          <h3 className="text-2xl md:text-3xl font-black gradient-text-neon tracking-tight">
            EX$ELL CAR SALES LI
          </h3>
          <p className="text-gray-500 text-sm mt-2 max-w-md text-center">
            {footer.tagline}
          </p>
          <div className="flex gap-3 mt-4">
            <a href={contact.facebookUrl} target="_blank" rel="noopener noreferrer"
              className="p-3 bg-white/[0.03] border border-white/5 rounded-lg text-gray-500 hover:text-neon-cyan hover:border-neon-cyan/30 transition-all">
              <Facebook className="w-5 h-5" />
            </a>
            <a href={contact.instagramUrl} target="_blank" rel="noopener noreferrer"
              className="p-3 bg-white/[0.03] border border-white/5 rounded-lg text-gray-500 hover:text-neon-pink hover:border-neon-pink/30 transition-all">
              <Instagram className="w-5 h-5" />
            </a>
            <a href={`sms:${contact.phone}`}
              className="p-3 bg-white/[0.03] border border-white/5 rounded-lg text-gray-500 hover:text-neon-green hover:border-neon-green/30 transition-all">
              <MessageSquare className="w-5 h-5" />
            </a>
          </div>
        </div>

        <div className="h-px bg-gradient-to-r from-transparent via-white/10 to-transparent mb-10" />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-10 mb-12">
          {/* Quick Links */}
          <div>
            <h3 className="text-white font-bold mb-4 text-sm uppercase tracking-wider">Quick Links</h3>
            <ul className="space-y-3">
              {footer.quickLinks.map((link, i) => (
                <li key={i}>
                  {link.type === 'scroll' ? (
                    <button onClick={() => scrollTo(link.target)} className="text-gray-500 hover:text-neon-cyan text-sm transition-colors">
                      {link.label}
                    </button>
                  ) : (
                    <Link to={link.target} className="text-gray-500 hover:text-neon-cyan text-sm transition-colors">
                      {link.label}
                    </Link>
                  )}
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-white font-bold mb-4 text-sm uppercase tracking-wider">Our Services</h3>
            <ul className="space-y-3">
              {footer.services.map((service, i) => (
                <li key={i}>
                  <button onClick={() => scrollTo('services')} className="text-gray-500 hover:text-neon-pink text-sm transition-colors">
                    {service}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-white font-bold mb-4 text-sm uppercase tracking-wider">Contact Us</h3>
            <ul className="space-y-4">
              <li>
                <a href={`tel:${contact.phone}`} className="flex items-center gap-3 text-gray-500 hover:text-neon-green transition-colors group">
                  <Phone className="w-4 h-4 text-neon-green group-hover:scale-110 transition-transform" />
                  <span className="text-sm">{contact.phoneDisplay}</span>
                </a>
              </li>
              <li>
                <a href={`mailto:${contact.email}`} className="flex items-center gap-3 text-gray-500 hover:text-neon-cyan transition-colors group">
                  <Mail className="w-4 h-4 text-neon-cyan group-hover:scale-110 transition-transform" />
                  <span className="text-sm">{contact.email}</span>
                </a>
              </li>
              <li>
                <div className="flex items-center gap-3 text-gray-500">
                  <MapPin className="w-4 h-4 text-neon-orange" />
                  <span className="text-sm">{contact.address}</span>
                </div>
              </li>
              <li>
                <div className="flex items-start gap-3 text-gray-500">
                  <Clock className="w-4 h-4 text-neon-pink mt-0.5" />
                  <div className="text-sm">
                    <div>{contact.hoursWeekday}</div>
                    <div>{contact.hoursSunday}</div>
                  </div>
                </div>
              </li>
            </ul>
            <a href={`tel:${contact.phone}`}
              className="mt-6 inline-flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-neon-pink to-neon-orange text-white font-bold text-sm rounded-lg hover:opacity-90 transition-opacity">
              <Phone className="w-4 h-4" /> Call Now
            </a>
          </div>
        </div>

        <div className="h-px bg-gradient-to-r from-transparent via-white/10 to-transparent mb-8" />

        {/* Bottom bar */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="text-gray-600 text-sm">
            &copy; {new Date().getFullYear()} {footer.copyrightName}. All rights reserved.
          </div>
          <div className="flex items-center gap-4 text-gray-600 text-sm flex-wrap justify-center">
            <Link to="/about" className="flex items-center gap-1.5 hover:text-neon-cyan transition-colors">
              <Users className="w-3.5 h-3.5" /> About Us
            </Link>
            <span className="text-white/10">|</span>
            <Link to="/sold" className="flex items-center gap-1.5 hover:text-neon-orange transition-colors">
              <Trophy className="w-3.5 h-3.5" /> Sold List
            </Link>
            <span className="text-white/10">|</span>
            <Link to="/reviews" className="flex items-center gap-1.5 hover:text-neon-orange transition-colors">
              <Star className="w-3.5 h-3.5" /> Reviews
            </Link>
            <span className="text-white/10">|</span>
            <Link to="/privacy-policy" className="flex items-center gap-1.5 hover:text-neon-cyan transition-colors">
              <Shield className="w-3.5 h-3.5" /> Privacy Policy
            </Link>
            <span className="text-white/10">|</span>
            <Link to="/terms-of-service" className="flex items-center gap-1.5 hover:text-neon-cyan transition-colors">
              <FileText className="w-3.5 h-3.5" /> Terms of Service
            </Link>
            <span className="text-white/10">|</span>
            <button onClick={() => window.dispatchEvent(new CustomEvent('open-cookie-settings'))}
              className="flex items-center gap-1.5 hover:text-neon-orange transition-colors">
              <Cookie className="w-3.5 h-3.5" /> Cookie Settings
            </button>
            <span className="text-white/10">|</span>
            <span>{footer.websiteUrl}</span>
            <span className="text-white/10">|</span>
            <span>{footer.locationText}</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
