import React, { useState, useEffect, useRef, useCallback } from 'react';
import { X, Send, Clock, MapPin, Car, Wrench, Phone, HelpCircle, ArrowDown, Sparkles, Volume2, VolumeX, Loader2, Zap, Bell, BellOff, BellRing } from 'lucide-react';

import type { JoeyPose } from './JoeyAvatar';
import { supabaseUrl, supabaseKey } from '@/lib/supabase';
import { fetchVehicles, type Vehicle } from '@/data/vehicles';

const VOICE_PREF_KEY = 'exsell-joey-voice';
const HISTORY_KEY = 'exsell-joey-history';

interface ChatMessage {
  id: string;
  sender: 'user' | 'joey';
  text: string;
  timestamp: Date;
  scrollTo?: string;
  links?: { label: string; href?: string; scrollTo?: string }[];
}

// Conversation history entry for the AI (lightweight, sent to edge function)
interface ConversationEntry {
  role: 'user' | 'assistant';
  content: string;
}
const QUICK_TOPICS = [
  { label: 'Hours', icon: Clock, query: "What are your business hours?" },
  { label: 'Inventory', icon: Car, query: "What cars do you have available?" },
  { label: 'Trade-In', icon: Sparkles, query: "How do trade-ins work?" },
  { label: 'Location', icon: MapPin, query: "Where are you located?" },
  { label: 'Services', icon: Wrench, query: "What services do you offer?" },
  { label: 'Contact', icon: Phone, query: "How can I contact you?" },
  { label: 'Help', icon: HelpCircle, query: "What can you help me with?" },
];


// Build a concise inventory summary string from vehicles data
function buildInventorySummary(vehicles: Vehicle[]): string {
  if (!vehicles.length) return '';

  const available = vehicles.filter(v => v.status === 'available');
  const sold = vehicles.filter(v => v.status === 'sold');

  const lines = available.map(v =>
    `${v.year} ${v.make} ${v.model} ${v.trim} — $${v.price.toLocaleString()}, ${v.mileage.toLocaleString()} mi, ${v.exteriorColor}, ${v.bodyType}, ${v.engine}, ${v.drivetrain}`
  );

  let summary = `${available.length} vehicles available:\n${lines.join('\n')}`;
  if (sold.length > 0) {
    summary += `\n\n${sold.length} recently sold (not available).`;
  }

  return summary;
}

// Load conversation history from localStorage
function loadHistory(): ConversationEntry[] {
  try {
    const raw = localStorage.getItem(HISTORY_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed.slice(-30); // Keep last 30 entries
    }
  } catch {}
  return [];
}

function saveHistory(history: ConversationEntry[]) {
  try {
    localStorage.setItem(HISTORY_KEY, JSON.stringify(history.slice(-30)));
  } catch {}
}

interface JoeyChatPanelProps {
  onClose: () => void;
  onPoseChange: (pose: JoeyPose) => void;
  onScrollTo: (id: string) => void;
  isAnimatingOut: boolean;
  alignRight?: boolean;
  panelBelow?: boolean;
  isMobile?: boolean;
  /** When false, the panel is hidden but stays mounted (keeps chat alive) */
  visible?: boolean;
  /** Called when Joey finishes typing a new response */
  onNewMessage?: (text: string) => void;
  /** Notification sound enabled */
  soundEnabled?: boolean;
  /** Toggle notification sound */
  onSoundToggle?: () => void;
  /** Browser notifications enabled */
  notificationsEnabled?: boolean;
  /** Toggle browser notifications */
  onNotificationsToggle?: () => void;
}

const JoeyChatPanel: React.FC<JoeyChatPanelProps> = ({
  onClose,
  onPoseChange,
  onScrollTo,
  isAnimatingOut,
  alignRight = false,
  panelBelow = false,
  isMobile = false,
  visible = true,
  onNewMessage,
  soundEnabled = false,
  onSoundToggle,
  notificationsEnabled = false,
  onNotificationsToggle,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isJoeyTyping, setIsJoeyTyping] = useState(false);
  const [displayedResponse, setDisplayedResponse] = useState('');
  const [pendingResponse, setPendingResponse] = useState<{
    text: string;
    scrollTo?: string;
    links?: { label: string; href?: string; scrollTo?: string }[];
  } | null>(null);
  const [isAiLoading, setIsAiLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const typingRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Conversation history for multi-turn dialogue
  const [conversationHistory, setConversationHistory] = useState<ConversationEntry[]>(() => loadHistory());

  // Inventory summary for AI context
  // Inventory summary + raw vehicles list for local response generation
  const inventorySummaryRef = useRef<string>('');
  const vehiclesRef = useRef<Vehicle[]>([]);

  // ── Voice state ──
  const [voiceEnabled, setVoiceEnabled] = useState(() => {
    try {
      return localStorage.getItem(VOICE_PREF_KEY) === 'true';
    } catch {
      return false;
    }
  });
  const [isVoiceLoading, setIsVoiceLoading] = useState(false);
  const [isVoicePlaying, setIsVoicePlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const currentAudioUrlRef = useRef<string | null>(null);

  // Persist voice preference
  useEffect(() => {
    try {
      localStorage.setItem(VOICE_PREF_KEY, voiceEnabled ? 'true' : 'false');
    } catch {}
  }, [voiceEnabled]);

  // Cleanup audio on unmount
  useEffect(() => {
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
      if (currentAudioUrlRef.current) {
        URL.revokeObjectURL(currentAudioUrlRef.current);
        currentAudioUrlRef.current = null;
      }
    };
  }, []);

  // Fetch inventory on mount for local response context
  useEffect(() => {
    let cancelled = false;
    fetchVehicles().then((vehicles) => {
      if (!cancelled) {
        vehiclesRef.current = vehicles;
        inventorySummaryRef.current = buildInventorySummary(vehicles);
      }
    }).catch(() => {
      // Silently fail — chat will still work without inventory data
    });
    return () => { cancelled = true; };
  }, []);


  // ── Speak Joey's message via TTS ──
  // NOTE: Voice (TTS) is currently DISABLED to reduce API costs.
  // The joey-voice edge function call is commented out below.
  // To re-enable in the future: uncomment the fetch block and remove the early return.
  const speakText = useCallback(async (_text: string) => {
    // Voice disabled — no TTS API calls are made.
    return;

    /* === ORIGINAL VOICE CODE (kept for future re-enable) ===
    if (!voiceEnabled) return;

    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current = null;
    }
    if (currentAudioUrlRef.current) {
      URL.revokeObjectURL(currentAudioUrlRef.current);
      currentAudioUrlRef.current = null;
    }

    setIsVoiceLoading(true);
    setIsVoicePlaying(false);

    try {
      const response = await fetch(`${supabaseUrl}/functions/v1/joey-voice`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${supabaseKey}`,
        },
        body: JSON.stringify({ text: _text }),
      });

      if (!response.ok) {
        console.error('Joey voice error:', response.status);
        setIsVoiceLoading(false);
        return;
      }

      const audioBlob = await response.blob();
      const url = URL.createObjectURL(audioBlob);
      currentAudioUrlRef.current = url;

      const audio = new Audio(url);
      audioRef.current = audio;

      audio.onplay = () => {
        setIsVoicePlaying(true);
        setIsVoiceLoading(false);
      };
      audio.onended = () => {
        setIsVoicePlaying(false);
        if (currentAudioUrlRef.current === url) {
          URL.revokeObjectURL(url);
          currentAudioUrlRef.current = null;
        }
      };
      audio.onerror = () => {
        setIsVoicePlaying(false);
        setIsVoiceLoading(false);
        console.error('Audio playback error');
      };

      await audio.play();
    } catch (err) {
      console.error('Voice generation failed:', err);
      setIsVoiceLoading(false);
      setIsVoicePlaying(false);
    }
    === END ORIGINAL VOICE CODE === */
  }, []);


  // Toggle voice
  const toggleVoice = useCallback(() => {
    setVoiceEnabled((prev) => {
      const next = !prev;
      if (!next) {
        if (audioRef.current) {
          audioRef.current.pause();
          audioRef.current = null;
        }
        setIsVoicePlaying(false);
        setIsVoiceLoading(false);
      }
      return next;
    });
  }, []);

  // Welcome message on mount
  useEffect(() => {
    const hasHistory = conversationHistory.length > 0;
    const welcomeMsg: ChatMessage = {
      id: 'welcome',
      sender: 'joey',
      text: hasHistory
        ? "Welcome back! I remember our chat. What else can I help you with?"
        : "Hey! I'm Joey, your AI car-buying assistant. Ask me anything about our inventory, trade-ins, or services — I've got real answers!",

    };
    setMessages([welcomeMsg]);
    onPoseChange('happy');

    setTimeout(() => inputRef.current?.focus(), 300);
  }, []);

  // Auto-scroll to bottom when messages change (only when visible)
  useEffect(() => {
    if (visible) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, displayedResponse, isJoeyTyping, isAiLoading, visible]);

  // Typewriter effect for Joey's response
  useEffect(() => {
    if (!pendingResponse) return;

    setIsJoeyTyping(true);
    setDisplayedResponse('');
    let charIndex = 0;
    const text = pendingResponse.text;

    const typeChar = () => {
      if (charIndex < text.length) {
        setDisplayedResponse(text.slice(0, charIndex + 1));
        charIndex++;
        typingRef.current = setTimeout(typeChar, 14 + Math.random() * 12);
      } else {
        // Done typing — commit the message
        setIsJoeyTyping(false);
        const finalMsg: ChatMessage = {
          id: `joey-${Date.now()}`,
          sender: 'joey',
          text: pendingResponse.text,
          timestamp: new Date(),
          scrollTo: pendingResponse.scrollTo,
          links: pendingResponse.links,
        };
        setMessages((prev) => [...prev, finalMsg]);
        setDisplayedResponse('');

        // Notify parent that Joey finished a new message
        if (onNewMessage) {
          onNewMessage(pendingResponse.text);
        }

        // Speak the response if voice is enabled
        speakText(pendingResponse.text);

        // Auto-scroll to section if specified
        if (pendingResponse.scrollTo) {
          setTimeout(() => onScrollTo(pendingResponse!.scrollTo!), 600);
        }

        setPendingResponse(null);
      }
    };

    typingRef.current = setTimeout(typeChar, 200);

    return () => {
      if (typingRef.current) clearTimeout(typingRef.current);
    };
  }, [pendingResponse, speakText, onNewMessage]);

  // ── Send message — LOCAL keyword-based responses (NO AI API calls) ──
  // NOTE: AI chat is currently DISABLED to reduce API costs.
  // The joey-chat edge function call has been replaced with local canned responses.
  // To re-enable AI in the future: replace the body of sendToAI below with the
  // original fetch-based implementation that calls /functions/v1/joey-chat.
  const sendToAI = useCallback(async (userMessage: string, currentHistory: ConversationEntry[]) => {
    setIsAiLoading(true);

    // Simulate a brief "thinking" delay so the UI feels natural
    await new Promise((r) => setTimeout(r, 350 + Math.random() * 250));

    const q = userMessage.toLowerCase();
    const vehicles = vehiclesRef.current;
    const available = vehicles.filter((v) => v.status === 'available');

    // Helper: pick a pose
    let pose: JoeyPose = 'happy';
    let responseText = '';
    let scrollTo: string | undefined;
    let links: { label: string; href?: string; scrollTo?: string }[] | undefined;

    // ── Keyword matching ──
    if (/(hour|open|close|when.*open|what time)/i.test(q)) {
      pose = 'happy';
      responseText =
        "We're open Monday–Saturday 9:00 AM to 6:00 PM, and Sunday by appointment. Stop by anytime during business hours, or give us a call!";
      links = [
        { label: 'Contact Us', scrollTo: 'contact' },
        { label: 'Call Now', scrollTo: 'contact' },
      ];
    } else if (/(locat|address|where|direction|map)/i.test(q)) {
      pose = 'happy';
      responseText =
        "You can find our address and a map down in the contact section. We'd love to have you stop by and check out the inventory in person!";
      scrollTo = 'contact';
      links = [{ label: 'See Location', scrollTo: 'contact' }];
    } else if (/(financ|loan|credit|monthly|apr|interest|down payment)/i.test(q)) {
      pose = 'thinking';
      responseText =
        "Heads up — we don't offer in-house financing or lender referrals. We're a cash / pre-approved-funds dealership, so buyers handle their own funding through their own bank, credit union, or lender of choice. Once you're funded, we make the rest easy!";
      links = [
        { label: 'Browse Inventory', scrollTo: 'inventory' },
        { label: 'Contact Us', scrollTo: 'contact' },
      ];
    } else if (/(trade.?in|trade my|appraise|appraisal|value my)/i.test(q)) {
      pose = 'pointing';
      responseText =
        "Yes — we love trade-ins! Scroll down to our Trade-In Valuation form and tell us about your vehicle (year, make, model, mileage, condition). We'll come back with a fair, no-pressure offer — usually within the same business day.";
      scrollTo = 'trade-in';
      links = [
        { label: 'Trade-In Form', scrollTo: 'trade-in' },
        { label: 'Contact Us', scrollTo: 'contact' },
      ];


    } else if (/(service|repair|maintenance|oil change|wrench|fix)/i.test(q)) {
      pose = 'pointing';
      responseText =
        "We offer full automotive services including inspections, maintenance, and repairs. Check out our services section for the full list, or reach out and we'll take care of you!";
      scrollTo = 'services';
      links = [
        { label: 'View Services', scrollTo: 'services' },
        { label: 'Contact Us', scrollTo: 'contact' },
      ];
    } else if (/(contact|phone|call|email|reach)/i.test(q)) {
      pose = 'happy';
      responseText =
        "Easiest way is to scroll to the contact section — you'll find our phone number, email, and a quick contact form there. We respond fast!";
      scrollTo = 'contact';
      links = [{ label: 'Contact Section', scrollTo: 'contact' }];
    } else if (/(suv|truck|sedan|coupe|minivan|van|jeep|honda|toyota|ford|gmc|nissan|chevy|kia|mercedes|maserati)/i.test(q)) {
      // Try to match make/body type
      const matches = available.filter((v) => {
        const hay = `${v.make} ${v.model} ${v.bodyType}`.toLowerCase();
        return q.split(/\s+/).some((word) => word.length > 2 && hay.includes(word));
      });
      pose = 'pointing';
      if (matches.length > 0) {
        const sample = matches.slice(0, 3).map((v) => `${v.year} ${v.make} ${v.model}`).join(', ');
        responseText = `Yes! We've got ${matches.length} match${matches.length === 1 ? '' : 'es'} on the lot${matches.length > 0 ? `: ${sample}${matches.length > 3 ? ', and more' : ''}` : ''}. Scroll down to inventory to see them all.`;
      } else {
        responseText =
          "I don't see an exact match in our current inventory, but new cars come in often! Check out what's on the lot now, or contact us and we'll keep an eye out for you.";
      }
      scrollTo = 'inventory';
      links = [
        { label: 'View Inventory', scrollTo: 'inventory' },
        { label: 'Contact Us', scrollTo: 'contact' },
      ];
    } else if (/(inventory|car|vehicle|stock|available|what.*have|what.*sell)/i.test(q)) {
      pose = 'pointing';
      if (available.length > 0) {
        const sample = available.slice(0, 3).map((v) => `${v.year} ${v.make} ${v.model}`).join(', ');
        responseText = `We currently have ${available.length} vehicle${available.length === 1 ? '' : 's'} available — including ${sample}${available.length > 3 ? ', and more' : ''}. Scroll down to see the full lineup with photos and details!`;
      } else {
        responseText =
          "Our inventory is updating right now. Scroll down to see what's currently on the lot, or contact us and we'll let you know as soon as something matching your needs comes in!";
      }
      scrollTo = 'inventory';
      links = [{ label: 'Browse Inventory', scrollTo: 'inventory' }];
    } else if (/(price|cost|how much|cheap|expensive|budget|under|less than)/i.test(q)) {
      pose = 'pointing';
      if (available.length > 0) {
        const prices = available.map((v) => v.price).filter((p) => p > 0).sort((a, b) => a - b);
        const min = prices[0];
        const max = prices[prices.length - 1];
        responseText = `Our current inventory ranges from about $${min.toLocaleString()} to $${max.toLocaleString()}. Each listing has full pricing details — scroll down to find one that fits your budget!`;
      } else {
        responseText = "Pricing is listed on each vehicle in our inventory section — scroll down to take a look!";
      }
      scrollTo = 'inventory';
      links = [{ label: 'See Prices', scrollTo: 'inventory' }];
    } else if (/(test drive|drive it|try it)/i.test(q)) {
      pose = 'pointing';
      responseText =
        "Absolutely — book a test drive anytime! Pick a vehicle from our inventory and click the 'Test Drive' button on the listing, or contact us to schedule one.";
      links = [
        { label: 'Browse Inventory', scrollTo: 'inventory' },
        { label: 'Contact Us', scrollTo: 'contact' },
      ];
    } else if (/(warranty|guarantee|return|refund)/i.test(q)) {
      pose = 'happy';
      responseText =
        "Great question! For warranty and return details on a specific vehicle, contact us directly — we'll walk you through everything that applies to that car.";
      links = [{ label: 'Contact Us', scrollTo: 'contact' }];
    } else if (/(review|testimonial|rating|google)/i.test(q)) {
      pose = 'happy';
      responseText =
        "Our customers love us! Check out the testimonials section for real reviews, or look us up on Google for the latest ratings.";
      scrollTo = 'testimonials';
      links = [{ label: 'See Reviews', scrollTo: 'testimonials' }];
    } else if (/(hi|hello|hey|yo|sup|hola|howdy)/i.test(q) && q.length < 25) {
      pose = 'happy';
      responseText =
        "Hey there! Welcome in. I can point you to our inventory, services, hours, location, or trade-ins — what are you looking for today?";
      links = [
        { label: 'Browse Inventory', scrollTo: 'inventory' },
        { label: 'Contact Us', scrollTo: 'contact' },
      ];
    } else if (/(thank|thanks|thx|appreciate)/i.test(q)) {
      pose = 'happy';
      responseText = "You got it! Anytime. Let me know if anything else comes up.";
    } else if (/(help|what.*do|what.*can|menu|options)/i.test(q)) {
      pose = 'happy';
      responseText =
        "I can help you with: current inventory, trade-ins, services, hours, location, and contact info. Use the quick-topic buttons below or just ask! (Heads up — we don't offer in-house financing, so buyers handle their own funding.)";
      links = [
        { label: 'Inventory', scrollTo: 'inventory' },
        { label: 'Contact', scrollTo: 'contact' },
      ];

    } else {
      // Default fallback
      pose = 'thinking';
      responseText =
        "Good question! For specifics like that, the best move is to contact us directly — we'll get you a real answer fast. In the meantime, feel free to browse the inventory or check out our services!";
      links = [
        { label: 'Contact Us', scrollTo: 'contact' },
        { label: 'Browse Inventory', scrollTo: 'inventory' },
        { label: 'Our Services', scrollTo: 'services' },
      ];
    }

    // Update conversation history (kept locally so "Welcome back" works)
    const newHistory: ConversationEntry[] = [
      ...currentHistory,
      { role: 'user', content: userMessage },
      { role: 'assistant', content: responseText },
    ];
    setConversationHistory(newHistory);
    saveHistory(newHistory);

    // Trigger pose change
    onPoseChange(pose);

    // Set the pending response for typewriter effect
    setPendingResponse({
      text: responseText,
      scrollTo,
      links,
    });

    setIsAiLoading(false);
  }, [onPoseChange]);


  const handleSend = useCallback(
    (text?: string) => {
      const query = (text || inputValue).trim();
      if (!query || isJoeyTyping || isAiLoading) return;

      const userMsg: ChatMessage = {
        id: `user-${Date.now()}`,
        sender: 'user',
        text: query,
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, userMsg]);
      setInputValue('');

      // Set pose to talking while waiting for AI
      onPoseChange('talking');

      // Send to AI with current conversation history
      sendToAI(query, conversationHistory);
    },
    [inputValue, isJoeyTyping, isAiLoading, onPoseChange, conversationHistory, sendToAI]
  );

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleQuickTopic = (query: string) => {
    handleSend(query);
  };

  const handleLinkClick = (link: { label: string; href?: string; scrollTo?: string }) => {
    if (link.href) {
      window.open(link.href, '_blank', 'noopener,noreferrer');
    } else if (link.scrollTo) {
      onScrollTo(link.scrollTo);
    }
  };

  // Clear conversation history
  const handleClearHistory = useCallback(() => {
    setConversationHistory([]);
    saveHistory([]);
    setMessages([{
      id: 'welcome-reset',
      sender: 'joey',
      text: "Fresh start! I'm Joey, your AI car-buying assistant. What can I help you with?",
      timestamp: new Date(),
    }]);
    onPoseChange('happy');
  }, [onPoseChange]);

  const isBusy = isJoeyTyping || isAiLoading;

  // Determine tail position class based on alignment (desktop only)
  const tailHorizontalClass = alignRight ? 'right-8' : 'left-8';

  // ── Mobile bottom-sheet wrapper vs desktop floating panel ──
  const panelAnimation = isMobile
    ? (isAnimatingOut ? 'joeySheetOut 0.35s ease-in forwards' : 'joeySheetIn 0.35s cubic-bezier(0.16, 1, 0.3, 1)')
    : (!isAnimatingOut ? 'joeyBubbleIn 0.5s cubic-bezier(0.16, 1, 0.3, 1)' : undefined);

  // When not visible, hide the panel but keep it mounted so chat state persists
  if (!visible) {
    return (
      <div
        aria-hidden="true"
        style={{
          position: 'fixed',
          left: '-9999px',
          top: '-9999px',
          width: '1px',
          height: '1px',
          overflow: 'hidden',
          opacity: 0,
          pointerEvents: 'none',
        }}
      >
        {/* Keep the component mounted so typewriter/AI calls continue */}
      </div>
    );
  }

  return (
    <div
      className={`relative transition-all duration-500 ${
        isMobile
          ? 'w-full'
          : 'w-[340px] sm:w-[380px]'
      } ${
        isAnimatingOut && !isMobile
          ? 'opacity-0 translate-y-4 scale-95'
          : !isAnimatingOut
          ? 'opacity-100 translate-y-0 scale-100'
          : ''
      }`}
      style={{
        animation: panelAnimation,
      }}
    >
      <div
        className={`rounded-2xl border border-white/[0.08] overflow-hidden flex flex-col ${
          isMobile ? 'rounded-b-none border-b-0' : ''
        }`}
        style={{
          background: 'linear-gradient(135deg, rgba(10, 10, 18, 0.97), rgba(18, 8, 30, 0.97))',
          backdropFilter: 'blur(24px) saturate(1.5)',
          WebkitBackdropFilter: 'blur(24px) saturate(1.5)',
          boxShadow: isMobile
            ? '0 -8px 60px rgba(0, 0, 0, 0.5), 0 0 80px rgba(255, 0, 128, 0.08)'
            : '0 8px 60px rgba(0, 0, 0, 0.5), 0 0 80px rgba(255, 0, 128, 0.08), 0 0 120px rgba(0, 240, 255, 0.04), inset 0 1px 0 rgba(255, 255, 255, 0.06)',
          maxHeight: isMobile ? '80vh' : '460px',
        }}
      >
        {/* Mobile drag handle */}
        {isMobile && (
          <div className="flex justify-center pt-2 pb-0 flex-shrink-0">
            <div className="w-10 h-1 rounded-full bg-white/20" />
          </div>
        )}

        {/* Top neon accent */}
        <div
          className="h-[2px] w-full flex-shrink-0"
          style={{
            background:
              'linear-gradient(90deg, transparent, #FF0080, #FF8C00, #BFFF00, #00F0FF, transparent)',
          }}
        />

        {/* Header */}
        <div className={`flex items-center justify-between flex-shrink-0 ${
          isMobile ? 'px-4 pt-3 pb-2' : 'px-4 pt-3 pb-2'
        }`}>
          <div className="flex items-center gap-2">
            <div className="relative">
              <div className="w-2 h-2 bg-neon-green rounded-full animate-pulse" />
              <div className="absolute inset-0 w-2 h-2 bg-neon-green rounded-full animate-ping opacity-40" />
            </div>
            <span
              className="text-xs font-bold text-white/60 uppercase tracking-wider"
              style={{ fontFamily: 'Orbitron, sans-serif' }}
            >
              Joey AI
            </span>
            {/* AI badge */}
            <div className="flex items-center gap-0.5 px-1.5 py-0.5 rounded-full bg-gradient-to-r from-neon-cyan/15 to-neon-green/15 border border-neon-cyan/20">
              <Zap className="w-2.5 h-2.5 text-neon-cyan" />
              <span className="text-[9px] font-bold text-neon-cyan/80 uppercase tracking-wider">AI</span>
            </div>
          </div>
          <div className="flex items-center gap-1">
            {/* Clear history button */}
            {conversationHistory.length > 0 && (
              <button
                onClick={handleClearHistory}
                className={`rounded-lg text-white/20 hover:text-white/50 hover:bg-white/5 transition-all ${
                  isMobile ? 'p-2.5 min-w-[44px] min-h-[44px] flex items-center justify-center' : 'p-1.5'
                }`}
                aria-label="Clear conversation"
                title="Clear conversation history"
              >
                <svg className={isMobile ? 'w-4.5 h-4.5' : 'w-3.5 h-3.5'} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M3 6h18" /><path d="M8 6V4h8v2" /><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6" />
                </svg>
              </button>
            )}

            {/* Notification sound toggle */}
            {onSoundToggle && (
              <button
                onClick={onSoundToggle}
                className={`relative rounded-lg transition-all ${
                  isMobile ? 'p-2.5 min-w-[44px] min-h-[44px] flex items-center justify-center' : 'p-1.5'
                } ${
                  soundEnabled
                    ? 'text-neon-orange bg-neon-orange/10 hover:bg-neon-orange/20'
                    : 'text-white/30 hover:text-white/50 hover:bg-white/5'
                }`}
                aria-label={soundEnabled ? 'Mute notifications' : 'Enable notification sound'}
                title={soundEnabled ? 'Notification sound ON' : 'Notification sound OFF'}
              >
                {soundEnabled ? (
                  <BellRing className={isMobile ? 'w-5 h-5' : 'w-4 h-4'} />
                ) : (
                  <BellOff className={isMobile ? 'w-5 h-5' : 'w-4 h-4'} />
                )}
                {soundEnabled && (
                  <div className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 bg-neon-orange rounded-full">
                    <div className="absolute inset-0 bg-neon-orange rounded-full animate-ping opacity-50" />
                  </div>
                )}
              </button>
            )}

            {/* Browser notification toggle */}
            {onNotificationsToggle && (
              <button
                onClick={onNotificationsToggle}
                className={`relative rounded-lg transition-all ${
                  isMobile ? 'p-2.5 min-w-[44px] min-h-[44px] flex items-center justify-center' : 'p-1.5'
                } ${
                  notificationsEnabled
                    ? 'text-neon-green bg-neon-green/10 hover:bg-neon-green/20'
                    : 'text-white/30 hover:text-white/50 hover:bg-white/5'
                }`}
                aria-label={notificationsEnabled ? 'Disable browser notifications' : 'Enable browser notifications'}
                title={notificationsEnabled ? 'Browser notifications ON' : 'Browser notifications OFF'}
              >
                {notificationsEnabled ? (
                  <Bell className={`${isMobile ? 'w-5 h-5' : 'w-4 h-4'}`} />
                ) : (
                  <Bell className={`${isMobile ? 'w-5 h-5' : 'w-4 h-4'} opacity-50`} />
                )}
                {notificationsEnabled && (
                  <div className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 bg-neon-green rounded-full">
                    <div className="absolute inset-0 bg-neon-green rounded-full animate-ping opacity-50" />
                  </div>
                )}
              </button>
            )}

            {/* Voice toggle button — HIDDEN: voice (TTS) is disabled to reduce API costs.
                Re-enable by removing the `false &&` condition below. */}
            {false && (
            <button
              onClick={toggleVoice}
              className={`relative rounded-lg transition-all ${
                isMobile ? 'p-2.5 min-w-[44px] min-h-[44px] flex items-center justify-center' : 'p-1.5'
              } ${
                voiceEnabled
                  ? 'text-neon-cyan bg-neon-cyan/10 hover:bg-neon-cyan/20'
                  : 'text-white/30 hover:text-white/50 hover:bg-white/5'
              }`}
              aria-label={voiceEnabled ? 'Mute Joey' : 'Enable Joey voice'}
              title={voiceEnabled ? 'Voice ON — click to mute' : 'Voice OFF — click to enable'}
            >
              {isVoiceLoading ? (
                <Loader2 className={`animate-spin text-neon-cyan ${isMobile ? 'w-5 h-5' : 'w-4 h-4'}`} />
              ) : isVoicePlaying ? (
                <div className="relative">
                  <Volume2 className={isMobile ? 'w-5 h-5' : 'w-4 h-4'} />
                  <div className="absolute -right-1 top-0 flex items-center gap-[1px]">
                    <div className="w-[2px] h-2 bg-neon-cyan rounded-full animate-pulse" style={{ animationDelay: '0ms' }} />
                    <div className="w-[2px] h-3 bg-neon-cyan rounded-full animate-pulse" style={{ animationDelay: '150ms' }} />
                    <div className="w-[2px] h-1.5 bg-neon-cyan rounded-full animate-pulse" style={{ animationDelay: '300ms' }} />
                  </div>
                </div>
              ) : voiceEnabled ? (
                <Volume2 className={isMobile ? 'w-5 h-5' : 'w-4 h-4'} />
              ) : (
                <VolumeX className={isMobile ? 'w-5 h-5' : 'w-4 h-4'} />
              )}
              {voiceEnabled && !isVoiceLoading && (
                <div className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 bg-neon-cyan rounded-full">
                  <div className="absolute inset-0 bg-neon-cyan rounded-full animate-ping opacity-50" />
                </div>
              )}
            </button>
            )}

            <button
              onClick={onClose}
              className={`rounded-lg text-white/30 hover:text-white/70 hover:bg-white/5 transition-all ${
                isMobile ? 'p-2.5 min-w-[44px] min-h-[44px] flex items-center justify-center' : 'p-1'
              }`}
              aria-label="Close chat"
            >
              <X className={isMobile ? 'w-5 h-5' : 'w-4 h-4'} />
            </button>
          </div>
        </div>

        {/* Voice status bar */}
        {voiceEnabled && (isVoiceLoading || isVoicePlaying) && (
          <div className="px-4 pb-1 flex-shrink-0">
            <div className="flex items-center gap-2 px-2 py-1 rounded-md bg-neon-cyan/5 border border-neon-cyan/10">
              {isVoiceLoading ? (
                <>
                  <Loader2 className="w-3 h-3 animate-spin text-neon-cyan/60" />
                  <span className="text-[10px] text-neon-cyan/60 font-medium">Generating voice...</span>
                </>
              ) : (
                <>
                  <div className="flex items-end gap-[2px]">
                    {[...Array(5)].map((_, i) => (
                      <div
                        key={i}
                        className="w-[2px] bg-neon-cyan rounded-full"
                        style={{
                          height: `${6 + Math.random() * 8}px`,
                          animation: `joeyVoiceBar 0.4s ease-in-out ${i * 0.08}s infinite alternate`,
                        }}
                      />
                    ))}
                  </div>
                  <span className="text-[10px] text-neon-cyan/60 font-medium">Joey is speaking...</span>
                  <button
                    onClick={() => {
                      if (audioRef.current) {
                        audioRef.current.pause();
                        audioRef.current = null;
                      }
                      setIsVoicePlaying(false);
                    }}
                    className={`ml-auto text-[10px] text-white/40 hover:text-white/70 transition-colors ${
                      isMobile ? 'min-h-[44px] min-w-[44px] flex items-center justify-center' : ''
                    }`}
                  >
                    Stop
                  </button>
                </>
              )}
            </div>
          </div>
        )}

        {/* Messages area */}
        <div className={`flex-1 overflow-y-auto px-3 pb-2 space-y-2.5 thin-scrollbar ${
          isMobile ? 'min-h-[160px] max-h-[40vh]' : 'min-h-[140px] max-h-[260px]'
        }`}>
          {messages.map((msg) => (
            <div key={msg.id}>
              <div
                className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[85%] px-3 py-2 rounded-2xl leading-relaxed ${
                    isMobile ? 'text-sm' : 'text-[13px]'
                  } ${
                    msg.sender === 'user'
                      ? 'bg-gradient-to-r from-neon-pink/20 to-neon-orange/20 border border-neon-pink/20 text-white/90 rounded-br-md'
                      : 'bg-white/[0.04] border border-white/[0.06] text-white/80 rounded-bl-md'
                  }`}
                >
                  {msg.text}
                </div>
              </div>
              {msg.sender === 'joey' && msg.links && msg.links.length > 0 && (
                <div className="flex flex-wrap gap-1.5 mt-1.5 ml-1">
                  {msg.links.map((link, idx) => (
                    <button
                      key={idx}
                      onClick={() => handleLinkClick(link)}
                      className={`flex items-center gap-1 rounded-lg font-semibold text-neon-cyan bg-neon-cyan/10 border border-neon-cyan/20 hover:bg-neon-cyan/20 hover:border-neon-cyan/40 transition-all group ${
                        isMobile
                          ? 'px-3 py-2.5 text-xs min-h-[44px]'
                          : 'px-2.5 py-1 text-[11px]'
                      }`}
                    >
                      {link.scrollTo && (
                        <ArrowDown className={`group-hover:animate-bounce ${isMobile ? 'w-3.5 h-3.5' : 'w-2.5 h-2.5'}`} />
                      )}
                      {link.href && (
                        <MapPin className={isMobile ? 'w-3.5 h-3.5' : 'w-2.5 h-2.5'} />
                      )}
                      {link.label}
                    </button>
                  ))}
                </div>
              )}
            </div>
          ))}

          {/* AI loading indicator */}
          {isAiLoading && !isJoeyTyping && (
            <div className="flex justify-start">
              <div className={`max-w-[85%] px-3 py-2 rounded-2xl rounded-bl-md bg-white/[0.04] border border-white/[0.06] leading-relaxed text-white/80 ${
                isMobile ? 'text-sm' : 'text-[13px]'
              }`}>
                <span className="flex items-center gap-2">
                  <span className="flex gap-0.5">
                    <span
                      className="w-1.5 h-1.5 bg-neon-cyan rounded-full animate-bounce"
                      style={{ animationDelay: '0ms' }}
                    />
                    <span
                      className="w-1.5 h-1.5 bg-neon-pink rounded-full animate-bounce"
                      style={{ animationDelay: '150ms' }}
                    />
                    <span
                      className="w-1.5 h-1.5 bg-neon-green rounded-full animate-bounce"
                      style={{ animationDelay: '300ms' }}
                    />
                  </span>
                  <span className="text-[11px] text-white/30 italic">Joey is thinking...</span>
                </span>
              </div>
            </div>
          )}

          {/* Joey typing indicator + live text */}
          {isJoeyTyping && (
            <div className="flex justify-start">
              <div className={`max-w-[85%] px-3 py-2 rounded-2xl rounded-bl-md bg-white/[0.04] border border-white/[0.06] leading-relaxed text-white/80 ${
                isMobile ? 'text-sm' : 'text-[13px]'
              }`}>
                {displayedResponse || (
                  <span className="flex items-center gap-1">
                    <span className="flex gap-0.5">
                      <span
                        className="w-1.5 h-1.5 bg-neon-cyan rounded-full animate-bounce"
                        style={{ animationDelay: '0ms' }}
                      />
                      <span
                        className="w-1.5 h-1.5 bg-neon-pink rounded-full animate-bounce"
                        style={{ animationDelay: '150ms' }}
                      />
                      <span
                        className="w-1.5 h-1.5 bg-neon-green rounded-full animate-bounce"
                        style={{ animationDelay: '300ms' }}
                      />
                    </span>
                  </span>
                )}
                {displayedResponse && (
                  <span className="inline-block w-[2px] h-3.5 bg-neon-cyan ml-0.5 align-middle animate-pulse" />
                )}
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick topic chips — horizontal scroll on mobile, wrap on desktop */}
        <div className={`flex-shrink-0 ${isMobile ? 'px-2 pb-2' : 'px-3 pb-2'}`}>
          <div
            className={`flex gap-1.5 ${
              isMobile
                ? 'overflow-x-auto flex-nowrap pb-1 -mx-1 px-1 joey-chips-scroll'
                : 'flex-wrap'
            }`}
          >
            {QUICK_TOPICS.map((topic) => {
              const Icon = topic.icon;
              return (
                <button
                  key={topic.label}
                  onClick={() => handleQuickTopic(topic.query)}
                  disabled={isBusy}
                  className={`flex items-center gap-1 rounded-full font-semibold text-white/50 bg-white/[0.04] border border-white/[0.08] hover:text-white/80 hover:bg-white/[0.08] hover:border-white/[0.15] disabled:opacity-30 disabled:cursor-not-allowed transition-all ${
                    isMobile
                      ? 'flex-shrink-0 px-3.5 py-2.5 text-xs min-h-[44px]'
                      : 'px-2 py-1 text-[10px]'
                  }`}
                >
                  <Icon className={isMobile ? 'w-3.5 h-3.5 flex-shrink-0' : 'w-2.5 h-2.5'} />
                  <span className="whitespace-nowrap">{topic.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Input area */}
        <div className={`flex-shrink-0 ${isMobile ? 'px-3 pb-4' : 'px-3 pb-3'}`}>
          <div
            className={`flex items-center gap-2 rounded-xl border border-white/[0.1] transition-all focus-within:border-neon-cyan/40 focus-within:shadow-[0_0_15px_rgba(0,240,255,0.1)] ${
              isMobile ? 'px-3 py-3' : 'px-3 py-2'
            }`}
            style={{
              background: 'rgba(255, 255, 255, 0.03)',
            }}
          >
            <input
              ref={inputRef}
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder={isBusy ? "Joey is responding..." : "Ask Joey anything..."}
              disabled={isBusy}
              className={`flex-1 bg-transparent text-white/90 placeholder:text-white/25 outline-none disabled:opacity-50 ${
                isMobile ? 'text-base min-h-[24px]' : 'text-[13px]'
              }`}
              // Prevent iOS zoom on focus by using 16px font
              style={isMobile ? { fontSize: '16px' } : undefined}
            />
            <button
              onClick={() => handleSend()}
              disabled={!inputValue.trim() || isBusy}
              className={`rounded-lg transition-all disabled:opacity-20 disabled:cursor-not-allowed hover:bg-white/5 ${
                isMobile ? 'p-2.5 min-w-[44px] min-h-[44px] flex items-center justify-center -mr-1' : 'p-1.5'
              }`}
              aria-label="Send message"
            >
              <Send
                className={isMobile ? 'w-5 h-5' : 'w-4 h-4'}
                style={{
                  color:
                    inputValue.trim() && !isBusy ? '#00F0FF' : 'rgba(255,255,255,0.2)',
                  filter:
                    inputValue.trim() && !isBusy
                      ? 'drop-shadow(0 0 4px rgba(0, 240, 255, 0.4))'
                      : 'none',
                }}
              />
            </button>
          </div>
          {/* Helper text */}
          <div className="flex items-center justify-center gap-1 mt-1.5">
            <Zap className="w-2.5 h-2.5 text-white/15" />
            <span className="text-[9px] text-white/15 font-medium">Quick answers — for anything else, contact us</span>
          </div>

        </div>
      </div>

      {/* Speech bubble tail — desktop only (mobile uses bottom sheet, no tail) */}
      {!isMobile && (
        <>
          {panelBelow ? (
            // Tail points UP toward the avatar (panel is below avatar)
            <div
              className={`absolute -top-2 ${tailHorizontalClass} w-4 h-4 rotate-45`}
              style={{
                background:
                  'linear-gradient(135deg, rgba(18, 8, 30, 0.97), rgba(18, 8, 30, 0.97))',
                borderLeft: '1px solid rgba(255, 255, 255, 0.08)',
                borderTop: '1px solid rgba(255, 255, 255, 0.08)',
              }}
            />
          ) : (
            // Tail points DOWN toward the avatar (panel is above avatar) — default
            <div
              className={`absolute -bottom-2 ${tailHorizontalClass} w-4 h-4 rotate-45`}
              style={{
                background:
                  'linear-gradient(135deg, rgba(18, 8, 30, 0.97), rgba(18, 8, 30, 0.97))',
                borderRight: '1px solid rgba(255, 255, 255, 0.08)',
                borderBottom: '1px solid rgba(255, 255, 255, 0.08)',
              }}
            />
          )}
        </>
      )}

      {/* Animations */}
      <style>{`
        @keyframes joeyVoiceBar {
          from { height: 4px; }
          to { height: 12px; }
        }
        @keyframes joeySheetIn {
          from {
            opacity: 0;
            transform: translateY(100%);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        @keyframes joeySheetOut {
          from {
            opacity: 1;
            transform: translateY(0);
          }
          to {
            opacity: 0;
            transform: translateY(100%);
          }
        }
        /* Hide scrollbar for chips on mobile but keep scrollable */
        .joey-chips-scroll {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
        .joey-chips-scroll::-webkit-scrollbar {
          display: none;
        }
      `}</style>
    </div>
  );
};

export default JoeyChatPanel;
