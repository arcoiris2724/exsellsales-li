import React, { useState } from 'react';
import { X, PhoneCall, Loader2, Send } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';
import { trackConversion } from '@/hooks/useAnalytics';

interface CallbackModalProps {
  open: boolean;
  onClose: () => void;
  /** Where the modal was opened from, for analytics segmentation. */
  source?: string;
}

/**
 * Lightweight "Request a Callback" modal for after-hours visitors. Collects a
 * name + phone number, stores the lead in the existing `leads` table, fires a
 * conversion event, and confirms with a toast.
 */
const CallbackModal: React.FC<CallbackModalProps> = ({ open, onClose, source = 'mobile_bar' }) => {
  const { toast } = useToast();
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [errors, setErrors] = useState<{ name?: string; phone?: string }>({});

  if (!open) return null;

  const validate = () => {
    const e: { name?: string; phone?: string } = {};
    if (!name.trim()) e.name = 'Please enter your name';
    const digits = phone.replace(/\D/g, '');
    if (!phone.trim()) e.phone = 'Please enter your phone number';
    else if (digits.length < 10) e.phone = 'Enter a valid phone number';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async (ev: React.FormEvent) => {
    ev.preventDefault();
    if (!validate()) return;
    setSubmitting(true);
    try {
      const { error } = await supabase.from('leads').insert({
        name: name.trim(),
        phone: phone.trim(),
        email: null,
        subject: 'callback',
        message: 'Requested a callback via mobile CTA bar.',
        vehicle_interest: null,
        preferred_date: null,
        preferred_time: null,
        lead_type: 'callback',
      });
      if (error) throw error;

      trackConversion('callback_request', { source });

      toast({
        title: 'Callback requested',
        description: "Thanks! We'll call you back as soon as we can.",
      });
      setName('');
      setPhone('');
      setErrors({});
      onClose();
    } catch (err) {
      console.error('Callback request failed:', err);
      toast({
        title: 'Something went wrong',
        description: 'Please try again or call us directly at (631) 388-4426.',
        variant: 'destructive',
      });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[70] flex items-end sm:items-center justify-center">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/70 backdrop-blur-sm"
        onClick={() => !submitting && onClose()}
      />

      {/* Panel */}
      <div className="relative w-full sm:max-w-md bg-[#0c0c0c] border border-white/10 rounded-t-2xl sm:rounded-2xl p-6 shadow-2xl animate-slide-in">
        <button
          onClick={() => !submitting && onClose()}
          className="absolute top-4 right-4 p-1.5 rounded-lg text-gray-500 hover:text-white hover:bg-white/5 transition-colors"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-2">
          <div className="p-2.5 bg-neon-orange/10 rounded-xl">
            <PhoneCall className="w-6 h-6 text-neon-orange" />
          </div>
          <div>
            <h3 className="text-xl font-black text-white">Request a Callback</h3>
            <p className="text-sm text-gray-500">Leave your number — we'll call you back.</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 mt-5">
          <div>
            <label className="block text-sm text-gray-400 mb-1.5 font-medium">Your Name *</label>
            <input
              type="text"
              value={name}
              onChange={(e) => {
                setName(e.target.value);
                if (errors.name) setErrors((p) => ({ ...p, name: undefined }));
              }}
              placeholder="Full name"
              disabled={submitting}
              className={`w-full px-4 py-3 bg-black border rounded-lg text-white placeholder-gray-600 focus:outline-none transition-colors disabled:opacity-50 ${
                errors.name ? 'border-red-500' : 'border-white/10 focus:border-neon-orange'
              }`}
            />
            {errors.name && <p className="text-red-400 text-xs mt-1">{errors.name}</p>}
          </div>

          <div>
            <label className="block text-sm text-gray-400 mb-1.5 font-medium">Phone Number *</label>
            <input
              type="tel"
              value={phone}
              onChange={(e) => {
                setPhone(e.target.value);
                if (errors.phone) setErrors((p) => ({ ...p, phone: undefined }));
              }}
              placeholder="(555) 123-4567"
              disabled={submitting}
              className={`w-full px-4 py-3 bg-black border rounded-lg text-white placeholder-gray-600 focus:outline-none transition-colors disabled:opacity-50 ${
                errors.phone ? 'border-red-500' : 'border-white/10 focus:border-neon-orange'
              }`}
            />
            {errors.phone && <p className="text-red-400 text-xs mt-1">{errors.phone}</p>}
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="w-full flex items-center justify-center gap-2 py-3.5 bg-gradient-to-r from-neon-orange to-neon-pink text-white font-bold rounded-xl hover:opacity-90 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {submitting ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" /> Sending...
              </>
            ) : (
              <>
                <Send className="w-5 h-5" /> Request Callback
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
};

export default CallbackModal;
