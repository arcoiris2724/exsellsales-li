import React, { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { Cookie, Settings } from 'lucide-react';
import CookieSettingsModal, {
  CookiePreferences,
} from './CookieSettingsModal';

const STORAGE_KEY = 'exsell-cookie-consent';

interface StoredConsent {
  preferences: CookiePreferences;
  timestamp: string;
  version: number;
}

const DEFAULT_PREFERENCES: CookiePreferences = {
  essential: true,
  analytics: false,
  marketing: false,
  personalization: false,
};

const CONSENT_VERSION = 1;

const CookieConsentBanner: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [preferences, setPreferences] =
    useState<CookiePreferences>(DEFAULT_PREFERENCES);
  const [isAnimatingOut, setIsAnimatingOut] = useState(false);

  // Check localStorage on mount
  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed: StoredConsent = JSON.parse(stored);
        // Only hide banner if consent version matches
        if (parsed.version === CONSENT_VERSION && parsed.preferences) {
          setPreferences(parsed.preferences);
          setIsVisible(false);
          return;
        }
      }
    } catch {
      // If parsing fails, show banner
    }
    // Small delay so banner slides in after page load
    const timer = setTimeout(() => setIsVisible(true), 1200);
    return () => clearTimeout(timer);
  }, []);


  // Listen for custom event to re-open cookie settings from footer or other components
  useEffect(() => {
    const handleOpenCookieSettings = () => {
      // Load current preferences from localStorage
      try {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) {
          const parsed: StoredConsent = JSON.parse(stored);
          if (parsed.preferences) {
            setPreferences(parsed.preferences);
          }
        }
      } catch {}
      setIsSettingsOpen(true);
    };
    window.addEventListener('open-cookie-settings', handleOpenCookieSettings);
    return () => window.removeEventListener('open-cookie-settings', handleOpenCookieSettings);
  }, []);


  const saveConsent = useCallback(
    (prefs: CookiePreferences) => {
      const consent: StoredConsent = {
        preferences: prefs,
        timestamp: new Date().toISOString(),
        version: CONSENT_VERSION,
      };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(consent));
      setPreferences(prefs);
      setIsAnimatingOut(true);
      setTimeout(() => {
        setIsVisible(false);
        setIsSettingsOpen(false);
        setIsAnimatingOut(false);
      }, 400);
    },
    []
  );

  const handleAcceptAll = useCallback(() => {
    saveConsent({
      essential: true,
      analytics: true,
      marketing: true,
      personalization: true,
    });
  }, [saveConsent]);

  const handleRejectNonEssential = useCallback(() => {
    saveConsent({
      essential: true,
      analytics: false,
      marketing: false,
      personalization: false,
    });
  }, [saveConsent]);

  const handleSaveSettings = useCallback(() => {
    saveConsent(preferences);
  }, [saveConsent, preferences]);

  const handleOpenSettings = useCallback(() => {
    setIsSettingsOpen(true);
  }, []);

  const handleCloseSettings = useCallback(() => {
    setIsSettingsOpen(false);
  }, []);

  if (!isVisible && !isSettingsOpen) return null;

  return (
    <>
      {/* Banner */}
      {isVisible && (
        <div
          className={`fixed bottom-0 left-0 right-0 z-[100] p-4 sm:p-5 transition-all duration-500 ${
            isAnimatingOut
              ? 'translate-y-full opacity-0'
              : 'translate-y-0 opacity-100'
          }`}
          style={{
            animation: !isAnimatingOut
              ? 'cookieBannerSlideUp 0.6s cubic-bezier(0.16, 1, 0.3, 1)'
              : undefined,
          }}
        >
          <div
            className="max-w-6xl mx-auto rounded-2xl border border-white/[0.08] overflow-hidden"
            style={{
              background:
                'linear-gradient(135deg, rgba(10, 10, 15, 0.92), rgba(15, 8, 25, 0.92))',
              backdropFilter: 'blur(24px) saturate(1.5)',
              WebkitBackdropFilter: 'blur(24px) saturate(1.5)',
              boxShadow:
                '0 -4px 60px rgba(0, 0, 0, 0.4), 0 0 80px rgba(255, 0, 128, 0.06), 0 0 120px rgba(0, 240, 255, 0.03), inset 0 1px 0 rgba(255, 255, 255, 0.05)',
            }}
          >
            {/* Neon accent line at top */}
            <div
              className="h-[2px] w-full"
              style={{
                background:
                  'linear-gradient(90deg, transparent, #FF0080, #FF8C00, #BFFF00, #00F0FF, transparent)',
              }}
            />

            <div className="p-4 sm:p-6">
              <div className="flex flex-col lg:flex-row lg:items-center gap-4 lg:gap-6">
                {/* Icon + Text */}
                <div className="flex items-start gap-3 flex-1 min-w-0">
                  <div
                    className="flex-shrink-0 w-10 h-10 sm:w-12 sm:h-12 rounded-xl flex items-center justify-center"
                    style={{
                      background:
                        'linear-gradient(135deg, rgba(255, 0, 128, 0.15), rgba(255, 140, 0, 0.15))',
                      border: '1px solid rgba(255, 0, 128, 0.2)',
                      boxShadow: '0 0 20px rgba(255, 0, 128, 0.1)',
                    }}
                  >
                    <Cookie className="w-5 h-5 sm:w-6 sm:h-6 text-[#FF0080]" />
                  </div>

                  <div className="flex-1 min-w-0">
                    <h3
                      className="text-sm sm:text-base font-bold text-white mb-1"
                      style={{ fontFamily: 'Orbitron, sans-serif' }}
                    >
                      We Value Your Privacy
                    </h3>
                    <p className="text-xs sm:text-sm text-white/50 leading-relaxed">
                      We use cookies and similar tracking technologies to
                      enhance your browsing experience, serve personalized
                      content, and analyze our traffic. By clicking{' '}
                      <span className="text-white/70 font-medium">
                        "Accept All"
                      </span>
                      , you consent to our use of cookies. Read our{' '}
                      <Link
                        to="/privacy-policy"
                        className="text-[#00F0FF] hover:text-[#00F0FF]/80 underline underline-offset-2 decoration-[#00F0FF]/30 hover:decoration-[#00F0FF]/60 transition-colors"
                      >
                        Privacy Policy
                      </Link>{' '}
                      for more information.
                    </p>
                  </div>
                </div>

                {/* Buttons */}
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 sm:gap-3 flex-shrink-0">
                  {/* Cookie Settings link */}
                  <button
                    onClick={handleOpenSettings}
                    className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-medium text-white/50 hover:text-white/80 hover:bg-white/5 transition-all duration-200 order-3 sm:order-1"
                  >
                    <Settings className="w-4 h-4" />
                    <span>Cookie Settings</span>
                  </button>

                  {/* Reject Non-Essential */}
                  <button
                    onClick={handleRejectNonEssential}
                    className="px-5 py-2.5 rounded-xl border border-white/15 text-xs sm:text-sm font-semibold text-white/70 hover:text-white hover:border-white/30 hover:bg-white/5 transition-all duration-200 order-2"
                  >
                    Reject Non-Essential
                  </button>

                  {/* Accept All */}
                  <button
                    onClick={handleAcceptAll}
                    className="px-6 py-2.5 rounded-xl text-xs sm:text-sm font-bold text-white transition-all duration-200 hover:shadow-lg hover:shadow-[#FF0080]/25 hover:scale-[1.03] active:scale-[0.97] order-1 sm:order-3"
                    style={{
                      background: 'linear-gradient(135deg, #FF0080, #FF8C00)',
                      boxShadow: '0 0 20px rgba(255, 0, 128, 0.2)',
                    }}
                  >
                    Accept All
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Settings Modal */}
      <CookieSettingsModal
        isOpen={isSettingsOpen}
        onClose={handleCloseSettings}
        preferences={preferences}
        onPreferencesChange={setPreferences}
        onSave={handleSaveSettings}
      />

      {/* Slide-up animation keyframes */}
      <style>{`
        @keyframes cookieBannerSlideUp {
          from {
            transform: translateY(100%);
            opacity: 0;
          }
          to {
            transform: translateY(0);
            opacity: 1;
          }
        }
      `}</style>
    </>
  );
};

export default CookieConsentBanner;
