import React, { useState, useEffect } from 'react';
import { Car, Handshake, Shield, Wrench, FileCheck, Truck, Star, Heart, Gem, TrendingUp, TrendingDown, Clock, Building2, Sparkles, Eye, Target, ThumbsUp, ShieldCheck, Users, CheckCircle, Phone, Mail, MapPin, DollarSign, Zap, Award } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { DEFAULT_SERVICES_SECTION, HOMEPAGE_SECTIONS } from '@/data/homepageDefaults';
import type { ServicesSectionContent } from '@/data/homepageDefaults';

const iconMap: Record<string, React.ElementType> = {
  Car, Handshake, Shield, Wrench, FileCheck, Truck, Star, Heart, Gem, TrendingUp, TrendingDown,
  Clock, Building2, Sparkles, Eye, Target, ThumbsUp, ShieldCheck, Users, CheckCircle, Phone,
  Mail, MapPin, DollarSign, Zap, Award,
};

const ServicesSection: React.FC = () => {
  const [content, setContent] = useState<ServicesSectionContent>(DEFAULT_SERVICES_SECTION);

  useEffect(() => {
    let cancelled = false;
    supabase.from('site_content').select('content').eq('section', HOMEPAGE_SECTIONS.services).single()
      .then(({ data }) => {
        if (!cancelled && data?.content) setContent(data.content as ServicesSectionContent);
      });
    return () => { cancelled = true; };
  }, []);

  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="services" className="py-20 px-4 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-neon-pink/[0.02] to-transparent" />

      <div className="relative max-w-7xl mx-auto">
        <div className="text-center mb-14">
          <h2 className="text-3xl md:text-5xl font-black text-white mb-4">
            {content.title} <span className="gradient-text-neon">{content.titleHighlight}</span>
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            {content.subtitle}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {content.services.map((service, i) => {
            const IconComp = iconMap[service.icon] || Star;
            return (
              <div key={i}
                className={`group p-6 bg-white/[0.02] rounded-xl border ${service.borderColor} hover:bg-white/[0.04] transition-all duration-300 hover:-translate-y-1`}>
                <div className={`w-12 h-12 ${service.bgColor} rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                  <IconComp className={`w-6 h-6 ${service.color}`} />
                </div>
                <h3 className="text-lg font-bold text-white mb-2">{service.title}</h3>
                <p className="text-gray-400 text-sm leading-relaxed">{service.description}</p>
              </div>
            );
          })}
        </div>

        {/* CTA */}
        <div className="mt-14 text-center">
          <div className="inline-flex flex-col sm:flex-row gap-4">
            <a href={`tel:${content.ctaPhone}`}
              className="px-8 py-4 bg-gradient-to-r from-neon-pink to-neon-orange text-white font-bold text-lg rounded-xl hover:opacity-90 transition-opacity neon-pulse">
              Call Us: {content.ctaPhoneDisplay}
            </a>
            <button onClick={() => scrollTo('contact')}
              className="px-8 py-4 border-2 border-neon-cyan/50 text-neon-cyan font-bold text-lg rounded-xl hover:bg-neon-cyan/10 transition-colors">
              Send Us a Message
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
