import React, { useState, useEffect } from 'react';
import { Phone, X, MessageSquare, Calendar, PhoneCall } from 'lucide-react';
import { useCompare } from '@/contexts/CompareContext';
import { trackConversion } from '@/hooks/useAnalytics';
import CallbackModal from './CallbackModal';

const FloatingCTA: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isVisible, setIsVisible] = useState(false);
  const [callbackOpen, setCallbackOpen] = useState(false);
  const { compareList } = useCompare();

  useEffect(() => {
    const handleScroll = () => {
      setIsVisible(window.scrollY > 400);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  if (!isVisible) {
    // Still render the modal so it can be controlled even when collapsed.
    return (
      <CallbackModal open={callbackOpen} onClose={() => setCallbackOpen(false)} source="floating_cta" />
    );
  }

  // On mobile, a fixed bottom call/text bar occupies the bottom edge, so lift the
  // floating button above it. The comparison tray lifts it further still.
  const bottomOffset =
    compareList.length > 0 ? 'bottom-40 lg:bottom-24' : 'bottom-24 lg:bottom-6';

  return (
    <>
      <div className={`fixed ${bottomOffset} right-6 z-50 transition-all duration-300`}>
        {/* Expanded options */}
        {isOpen && (
          <div className="mb-3 space-y-2 animate-slide-in">
            <a
              href="tel:6313884426"
              onClick={() => trackConversion('call_click', { source: 'floating_cta' })}
              className="flex items-center gap-3 px-4 py-3 bg-neon-green/90 text-black font-bold rounded-xl shadow-lg shadow-neon-green/20 hover:bg-neon-green transition-colors"
            >
              <Phone className="w-5 h-5" />
              <span>Call Now</span>
            </a>
            <a
              href="sms:6313884426"
              onClick={() => trackConversion('text_click', { source: 'floating_cta' })}
              className="flex items-center gap-3 px-4 py-3 bg-neon-cyan/90 text-black font-bold rounded-xl shadow-lg shadow-neon-cyan/20 hover:bg-neon-cyan transition-colors"
            >
              <MessageSquare className="w-5 h-5" />
              <span>Text Us</span>
            </a>
            <button
              onClick={() => {
                setIsOpen(false);
                setCallbackOpen(true);
              }}
              className="w-full flex items-center gap-3 px-4 py-3 bg-neon-orange/90 text-black font-bold rounded-xl shadow-lg shadow-neon-orange/20 hover:bg-neon-orange transition-colors"
            >
              <PhoneCall className="w-5 h-5" />
              <span>Request Callback</span>
            </button>
            <button
              onClick={() => {
                setIsOpen(false);
                const el = document.getElementById('contact');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }}
              className="w-full flex items-center gap-3 px-4 py-3 bg-neon-pink/90 text-black font-bold rounded-xl shadow-lg shadow-neon-pink/20 hover:bg-neon-pink transition-colors"
            >
              <Calendar className="w-5 h-5" />
              <span>Book Appointment</span>
            </button>
          </div>
        )}

        {/* Main button */}
        <button
          onClick={() => setIsOpen(!isOpen)}
          className={`p-4 rounded-full shadow-lg transition-all duration-300 ${
            isOpen
              ? 'bg-white/10 backdrop-blur-sm text-white border border-white/20 rotate-0'
              : 'bg-gradient-to-r from-neon-pink to-neon-orange text-white neon-pulse'
          }`}
        >
          {isOpen ? <X className="w-6 h-6" /> : <Phone className="w-6 h-6" />}
        </button>
      </div>

      <CallbackModal open={callbackOpen} onClose={() => setCallbackOpen(false)} source="floating_cta" />
    </>
  );
};

export default FloatingCTA;
