import React, { useState, useCallback, useEffect, useMemo, useRef } from 'react';
import { ChevronLeft, ChevronRight, X, Maximize2, Camera, Grid3X3, Play } from 'lucide-react';

interface ImageGalleryProps {
  images: string[];
  alt: string;
  videoUrl?: string;
}

type ImageCategory = 'all' | 'exterior' | 'interior';

// Heuristic to categorize images based on index patterns
// In a real scenario with 15-30 images, typically first half are exterior, second half interior
function categorizeImages(images: string[]): { exterior: number[]; interior: number[]; } {
  if (images.length <= 2) {
    return { exterior: images.map((_, i) => i), interior: [] };
  }
  const midpoint = Math.ceil(images.length / 2);
  return {
    exterior: images.slice(0, midpoint).map((_, i) => i),
    interior: images.slice(midpoint).map((_, i) => i + midpoint),
  };
}

const ImageGallery: React.FC<ImageGalleryProps> = ({ images, alt, videoUrl }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [fullscreen, setFullscreen] = useState(false);
  const [category, setCategory] = useState<ImageCategory>('all');
  const [showGrid, setShowGrid] = useState(false);
  const thumbnailRef = useRef<HTMLDivElement>(null);
  const allImages = images.length > 0 ? images : ['/placeholder.svg'];
  const hasMultipleImages = allImages.length > 1;
  const hasVideo = !!videoUrl;

  const { exterior, interior } = useMemo(() => categorizeImages(allImages), [allImages]);

  const filteredIndices = useMemo(() => {
    switch (category) {
      case 'exterior': return exterior;
      case 'interior': return interior;
      default: return allImages.map((_, i) => i);
    }
  }, [category, exterior, interior, allImages]);

  // Find position of currentIndex in filtered list
  const currentFilteredPos = filteredIndices.indexOf(currentIndex);
  const effectivePos = currentFilteredPos >= 0 ? currentFilteredPos : 0;

  const next = useCallback(() => {
    const nextPos = (effectivePos + 1) % filteredIndices.length;
    setCurrentIndex(filteredIndices[nextPos]);
  }, [effectivePos, filteredIndices]);

  const prev = useCallback(() => {
    const prevPos = (effectivePos - 1 + filteredIndices.length) % filteredIndices.length;
    setCurrentIndex(filteredIndices[prevPos]);
  }, [effectivePos, filteredIndices]);

  // When category changes, jump to first image in that category
  useEffect(() => {
    if (filteredIndices.length > 0 && !filteredIndices.includes(currentIndex)) {
      setCurrentIndex(filteredIndices[0]);
    }
  }, [category, filteredIndices, currentIndex]);

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight') next();
      else if (e.key === 'ArrowLeft') prev();
      else if (e.key === 'Escape') {
        setFullscreen(false);
        setShowGrid(false);
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [next, prev]);

  useEffect(() => {
    if (fullscreen || showGrid) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => { document.body.style.overflow = ''; };
  }, [fullscreen, showGrid]);

  // Auto-scroll thumbnail strip to keep active thumb visible
  useEffect(() => {
    if (thumbnailRef.current) {
      const container = thumbnailRef.current;
      const activeThumb = container.children[effectivePos] as HTMLElement;
      if (activeThumb) {
        const containerRect = container.getBoundingClientRect();
        const thumbRect = activeThumb.getBoundingClientRect();
        if (thumbRect.left < containerRect.left || thumbRect.right > containerRect.right) {
          activeThumb.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
        }
      }
    }
  }, [currentIndex, effectivePos]);

  const showCategories = allImages.length > 4 && interior.length > 0;

  return (
    <>
      <div className="space-y-3">
        {/* Category tabs + controls */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            {showCategories && (
              <div className="flex gap-1 bg-white/[0.03] border border-white/5 rounded-lg p-0.5">
                {[
                  { key: 'all' as ImageCategory, label: 'All', count: allImages.length },
                  { key: 'exterior' as ImageCategory, label: 'Exterior', count: exterior.length },
                  { key: 'interior' as ImageCategory, label: 'Interior', count: interior.length },
                ].map((tab) => (
                  <button
                    key={tab.key}
                    onClick={() => setCategory(tab.key)}
                    className={`px-3 py-1.5 text-xs font-bold rounded-md transition-all ${
                      category === tab.key
                        ? 'bg-neon-pink/20 text-neon-pink border border-neon-pink/30'
                        : 'text-gray-500 hover:text-gray-300'
                    }`}
                  >
                    {tab.label}
                    <span className="ml-1 text-[10px] opacity-60">({tab.count})</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="flex items-center gap-2">
            {/* Image count */}
            <div className="flex items-center gap-1.5 text-gray-500 text-xs">
              <Camera className="w-3.5 h-3.5" />
              <span>{allImages.length} photos</span>
              {hasVideo && (
                <>
                  <span className="mx-1">+</span>
                  <Play className="w-3 h-3" />
                  <span>Video</span>
                </>
              )}
            </div>

            {/* Grid view toggle */}
            {allImages.length > 4 && (
              <button
                onClick={() => setShowGrid(true)}
                className="p-1.5 rounded-lg border border-white/10 text-gray-500 hover:text-white hover:border-white/20 transition-all"
                title="View all photos"
              >
                <Grid3X3 className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Main image */}
        <div className="relative group rounded-2xl overflow-hidden bg-[#0a0a0a] border border-white/5">
          <div className="aspect-[16/10] relative">
            <img
              src={allImages[currentIndex]}
              alt={`${alt} - Image ${currentIndex + 1}`}
              className="w-full h-full object-cover transition-transform duration-500"
              style={{ animation: 'heroFadeIn 0.4s ease-out' }}
              key={currentIndex}
            />
            {/* Gradient overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/30 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />

            {/* Navigation arrows */}
            {filteredIndices.length > 1 && (
              <>
                <button
                  onClick={prev}
                  className="absolute left-3 top-1/2 -translate-y-1/2 p-2.5 bg-black/60 backdrop-blur-sm rounded-full text-white hover:bg-black/80 transition-all opacity-0 group-hover:opacity-100"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <button
                  onClick={next}
                  className="absolute right-3 top-1/2 -translate-y-1/2 p-2.5 bg-black/60 backdrop-blur-sm rounded-full text-white hover:bg-black/80 transition-all opacity-0 group-hover:opacity-100"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </>
            )}

            {/* Fullscreen button */}
            <button
              onClick={() => setFullscreen(true)}
              className="absolute top-3 right-3 p-2.5 bg-black/60 backdrop-blur-sm rounded-full text-white hover:bg-black/80 transition-all opacity-0 group-hover:opacity-100"
            >
              <Maximize2 className="w-4 h-4" />
            </button>

            {/* Category label */}
            {showCategories && (
              <div className="absolute top-3 left-3 px-2.5 py-1 bg-black/60 backdrop-blur-sm rounded-full text-white text-xs font-medium">
                {currentIndex < exterior.length + (exterior[0] || 0) && exterior.includes(currentIndex)
                  ? 'Exterior'
                  : interior.includes(currentIndex)
                  ? 'Interior'
                  : 'Photo'
                }
              </div>
            )}

            {/* Image counter */}
            {filteredIndices.length > 1 && (
              <div className="absolute bottom-3 right-3 px-3 py-1.5 bg-black/70 backdrop-blur-sm rounded-full text-white text-sm font-medium">
                {effectivePos + 1} / {filteredIndices.length}
              </div>
            )}
          </div>
        </div>

        {/* Thumbnails */}
        {filteredIndices.length > 1 && (
          <div ref={thumbnailRef} className="flex gap-2 overflow-x-auto pb-1 scrollbar-thin">
            {filteredIndices.map((imgIdx, pos) => (
              <button
                key={imgIdx}
                onClick={() => setCurrentIndex(imgIdx)}
                className={`relative flex-shrink-0 rounded-lg overflow-hidden border-2 transition-all ${
                  imgIdx === currentIndex
                    ? 'w-20 h-14 md:w-24 md:h-16 border-neon-pink shadow-lg shadow-neon-pink/20 scale-105'
                    : 'w-16 h-11 md:w-20 md:h-14 border-white/10 opacity-60 hover:opacity-100 hover:border-white/30'
                }`}
              >
                <img
                  src={allImages[imgIdx]}
                  alt={`${alt} thumbnail ${pos + 1}`}
                  className="w-full h-full object-cover"
                  loading="lazy"
                />
                {imgIdx === currentIndex && (
                  <div className="absolute inset-0 bg-neon-pink/10" />
                )}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Fullscreen modal */}
      {fullscreen && (
        <div className="fixed inset-0 z-[200] bg-black/95 backdrop-blur-xl flex items-center justify-center">
          <button
            onClick={() => setFullscreen(false)}
            className="absolute top-4 right-4 p-3 bg-white/10 rounded-full text-white hover:bg-white/20 transition-colors z-10"
          >
            <X className="w-6 h-6" />
          </button>

          {/* Category tabs in fullscreen */}
          {showCategories && (
            <div className="absolute top-4 left-1/2 -translate-x-1/2 flex gap-1 bg-black/60 backdrop-blur-sm rounded-lg p-1 z-10">
              {[
                { key: 'all' as ImageCategory, label: 'All' },
                { key: 'exterior' as ImageCategory, label: 'Exterior' },
                { key: 'interior' as ImageCategory, label: 'Interior' },
              ].map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => setCategory(tab.key)}
                  className={`px-4 py-1.5 text-sm font-bold rounded-md transition-all ${
                    category === tab.key
                      ? 'bg-neon-pink/20 text-neon-pink'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          )}

          <div className="relative w-full h-full flex items-center justify-center p-4 md:p-12">
            <img
              src={allImages[currentIndex]}
              alt={`${alt} - Image ${currentIndex + 1}`}
              className="max-w-full max-h-full object-contain rounded-lg"
              key={`fs-${currentIndex}`}
              style={{ animation: 'heroFadeIn 0.3s ease-out' }}
            />

            {filteredIndices.length > 1 && (
              <>
                <button
                  onClick={prev}
                  className="absolute left-4 top-1/2 -translate-y-1/2 p-3 bg-white/10 rounded-full text-white hover:bg-white/20 transition-colors"
                >
                  <ChevronLeft className="w-6 h-6" />
                </button>
                <button
                  onClick={next}
                  className="absolute right-4 top-1/2 -translate-y-1/2 p-3 bg-white/10 rounded-full text-white hover:bg-white/20 transition-colors"
                >
                  <ChevronRight className="w-6 h-6" />
                </button>
              </>
            )}

            {/* Counter */}
            <div className="absolute top-4 right-20 px-3 py-1.5 bg-black/50 backdrop-blur-sm rounded-full text-white text-sm font-medium">
              {effectivePos + 1} / {filteredIndices.length}
            </div>

            {/* Thumbnail strip at bottom */}
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2 max-w-[90vw] overflow-x-auto p-2 bg-black/50 backdrop-blur-sm rounded-xl scrollbar-thin">
              {filteredIndices.map((imgIdx) => (
                <button
                  key={imgIdx}
                  onClick={() => setCurrentIndex(imgIdx)}
                  className={`flex-shrink-0 w-16 h-11 rounded-md overflow-hidden border-2 transition-all ${
                    imgIdx === currentIndex
                      ? 'border-neon-pink'
                      : 'border-transparent opacity-50 hover:opacity-100'
                  }`}
                >
                  <img src={allImages[imgIdx]} alt="" className="w-full h-full object-cover" loading="lazy" />
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Grid view modal */}
      {showGrid && (
        <div className="fixed inset-0 z-[200] bg-black/95 backdrop-blur-xl overflow-y-auto">
          <div className="max-w-6xl mx-auto px-4 py-6">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-4">
                <h3 className="text-xl font-bold text-white">All Photos ({allImages.length})</h3>
                {showCategories && (
                  <div className="flex gap-1 bg-white/[0.03] border border-white/5 rounded-lg p-0.5">
                    {[
                      { key: 'all' as ImageCategory, label: 'All', count: allImages.length },
                      { key: 'exterior' as ImageCategory, label: 'Exterior', count: exterior.length },
                      { key: 'interior' as ImageCategory, label: 'Interior', count: interior.length },
                    ].map((tab) => (
                      <button
                        key={tab.key}
                        onClick={() => setCategory(tab.key)}
                        className={`px-3 py-1.5 text-xs font-bold rounded-md transition-all ${
                          category === tab.key
                            ? 'bg-neon-pink/20 text-neon-pink border border-neon-pink/30'
                            : 'text-gray-500 hover:text-gray-300'
                        }`}
                      >
                        {tab.label} ({tab.count})
                      </button>
                    ))}
                  </div>
                )}
              </div>
              <button
                onClick={() => setShowGrid(false)}
                className="p-2 bg-white/10 rounded-full text-white hover:bg-white/20 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
              {filteredIndices.map((imgIdx, pos) => (
                <button
                  key={imgIdx}
                  onClick={() => {
                    setCurrentIndex(imgIdx);
                    setShowGrid(false);
                    setFullscreen(true);
                  }}
                  className="relative aspect-[16/10] rounded-xl overflow-hidden border border-white/5 hover:border-neon-pink/40 transition-all group"
                >
                  <img
                    src={allImages[imgIdx]}
                    alt={`${alt} - ${pos + 1}`}
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors flex items-center justify-center">
                    <Maximize2 className="w-6 h-6 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                  <div className="absolute bottom-2 left-2 px-2 py-0.5 bg-black/60 backdrop-blur-sm rounded text-white text-xs font-medium">
                    {pos + 1}
                  </div>
                  {showCategories && (
                    <div className="absolute top-2 right-2 px-2 py-0.5 bg-black/60 backdrop-blur-sm rounded text-[10px] font-bold text-gray-300 uppercase tracking-wider">
                      {exterior.includes(imgIdx) ? 'Ext' : 'Int'}
                    </div>
                  )}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default ImageGallery;
