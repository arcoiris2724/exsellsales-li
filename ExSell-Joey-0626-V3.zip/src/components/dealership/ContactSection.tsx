import React, { useState, useEffect } from 'react';
import { Phone, Mail, MapPin, Clock, Send, CheckCircle, MessageSquare, Instagram, Facebook, Loader2, AlertCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { DEFAULT_CONTACT, HOMEPAGE_SECTIONS } from '@/data/homepageDefaults';
import type { ContactSectionContent } from '@/data/homepageDefaults';

const ContactSection: React.FC = () => {
  const [content, setContent] = useState<ContactSectionContent>(DEFAULT_CONTACT);
  const [formData, setFormData] = useState({
    name: '', email: '', phone: '', subject: 'general', message: '',
  });
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    let cancelled = false;
    supabase.from('site_content').select('content').eq('section', HOMEPAGE_SECTIONS.contact).single()
      .then(({ data }) => {
        if (!cancelled && data?.content) setContent(data.content as ContactSectionContent);
      });
    return () => { cancelled = true; };
  }, []);

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.name.trim()) newErrors.name = 'Name is required';
    if (!formData.phone.trim()) newErrors.phone = 'Phone is required';
    if (!formData.message.trim()) newErrors.message = 'Message is required';
    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Invalid email format';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitError('');
    if (!validate()) return;
    setSubmitting(true);
    try {
      const { error } = await supabase.from('leads').insert({
        name: formData.name.trim(), phone: formData.phone.trim(),
        email: formData.email.trim() || null, subject: formData.subject,
        message: formData.message.trim(), vehicle_interest: null,
        preferred_date: null, preferred_time: null, lead_type: 'contact',
      });
      if (error) throw error;
      setSubmitted(true);
    } catch (err: any) {
      console.error('Failed to submit contact form:', err);
      setSubmitError(`Something went wrong. Please try again or call us directly at ${content.phoneDisplay}.`);
    } finally { setSubmitting(false); }
  };

  const handleChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) setErrors((prev) => ({ ...prev, [field]: '' }));
    if (submitError) setSubmitError('');
  };

  return (
    <section id="contact" className="py-20 px-4 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-neon-green/[0.02] to-transparent" />

      <div className="relative max-w-7xl mx-auto">
        <div className="text-center mb-14">
          <h2 className="text-3xl md:text-5xl font-black text-white mb-4">
            {content.title} <span className="gradient-text-neon">{content.titleHighlight}</span>
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            {content.subtitle}
          </p>
        </div>

        <div className="grid lg:grid-cols-5 gap-8">
          {/* Contact info */}
          <div className="lg:col-span-2 space-y-6">
            <a href={`tel:${content.phone}`}
              className="flex items-center gap-4 p-5 bg-white/[0.02] rounded-xl border border-neon-pink/20 hover:border-neon-pink/40 hover:bg-neon-pink/5 transition-all group">
              <div className="p-3 bg-neon-pink/10 rounded-xl group-hover:scale-110 transition-transform">
                <Phone className="w-6 h-6 text-neon-pink" />
              </div>
              <div>
                <div className="text-white font-bold text-lg">{content.phoneDisplay}</div>
                <div className="text-gray-500 text-sm">{content.phoneLabel}</div>
              </div>
            </a>

            <a href={`mailto:${content.email}`}
              className="flex items-center gap-4 p-5 bg-white/[0.02] rounded-xl border border-neon-cyan/20 hover:border-neon-cyan/40 hover:bg-neon-cyan/5 transition-all group">
              <div className="p-3 bg-neon-cyan/10 rounded-xl group-hover:scale-110 transition-transform">
                <Mail className="w-6 h-6 text-neon-cyan" />
              </div>
              <div>
                <div className="text-white font-bold">{content.email}</div>
                <div className="text-gray-500 text-sm">{content.emailLabel}</div>
              </div>
            </a>

            <div className="flex items-center gap-4 p-5 bg-white/[0.02] rounded-xl border border-neon-green/20">
              <div className="p-3 bg-neon-green/10 rounded-xl">
                <MapPin className="w-6 h-6 text-neon-green" />
              </div>
              <div>
                <div className="text-white font-bold">{content.address}</div>
                <div className="text-gray-500 text-sm">{content.addressLabel}</div>
              </div>
            </div>

            <div className="flex items-center gap-4 p-5 bg-white/[0.02] rounded-xl border border-neon-orange/20">
              <div className="p-3 bg-neon-orange/10 rounded-xl">
                <Clock className="w-6 h-6 text-neon-orange" />
              </div>
              <div>
                <div className="text-white font-bold">Business Hours</div>
                <div className="text-gray-500 text-sm">{content.hoursWeekday}</div>
                <div className="text-gray-500 text-sm">{content.hoursSunday}</div>
              </div>
            </div>

            {/* Social links */}
            <div className="flex gap-3 pt-2">
              <a href={content.facebookUrl} target="_blank" rel="noopener noreferrer"
                className="p-3 bg-white/[0.03] border border-white/5 rounded-xl text-gray-400 hover:text-neon-cyan hover:border-neon-cyan/30 transition-all">
                <Facebook className="w-5 h-5" />
              </a>
              <a href={content.instagramUrl} target="_blank" rel="noopener noreferrer"
                className="p-3 bg-white/[0.03] border border-white/5 rounded-xl text-gray-400 hover:text-neon-pink hover:border-neon-pink/30 transition-all">
                <Instagram className="w-5 h-5" />
              </a>
              <a href={`sms:${content.phone}`}
                className="p-3 bg-white/[0.03] border border-white/5 rounded-xl text-gray-400 hover:text-neon-green hover:border-neon-green/30 transition-all">
                <MessageSquare className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Contact form */}
          <div className="lg:col-span-3">
            {submitted ? (
              <div className="h-full flex items-center justify-center p-8 bg-white/[0.02] rounded-2xl border border-neon-green/20">
                <div className="text-center space-y-4">
                  <div className="w-16 h-16 mx-auto bg-neon-green/10 rounded-full flex items-center justify-center">
                    <CheckCircle className="w-8 h-8 text-neon-green" />
                  </div>
                  <h3 className="text-2xl font-bold text-white">Message Sent!</h3>
                  <p className="text-gray-400 max-w-sm mx-auto">
                    Thanks for reaching out! We'll get back to you within a few hours. Feel free to call us at{' '}
                    <a href={`tel:${content.phone}`} className="text-neon-pink font-semibold">{content.phoneDisplay}</a> for immediate assistance.
                  </p>
                  <button onClick={() => { setSubmitted(false); setFormData({ name: '', email: '', phone: '', subject: 'general', message: '' }); }}
                    className="px-6 py-2.5 bg-neon-green/10 border border-neon-green/30 text-neon-green font-semibold rounded-lg hover:bg-neon-green/20 transition-colors">
                    Send Another Message
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="p-6 md:p-8 bg-white/[0.02] rounded-2xl border border-white/5 space-y-5">
                {submitError && (
                  <div className="flex items-center gap-3 p-4 bg-red-500/10 border border-red-500/20 rounded-xl">
                    <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0" />
                    <p className="text-red-400 text-sm">{submitError}</p>
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm text-gray-400 mb-1.5 font-medium">Full Name *</label>
                    <input type="text" value={formData.name} onChange={(e) => handleChange('name', e.target.value)}
                      placeholder="Your name" disabled={submitting}
                      className={`w-full px-4 py-3 bg-black border rounded-lg text-white placeholder-gray-600 focus:outline-none transition-colors disabled:opacity-50 ${errors.name ? 'border-red-500' : 'border-white/10 focus:border-neon-cyan'}`} />
                    {errors.name && <p className="text-red-400 text-xs mt-1">{errors.name}</p>}
                  </div>
                  <div>
                    <label className="block text-sm text-gray-400 mb-1.5 font-medium">Phone *</label>
                    <input type="tel" value={formData.phone} onChange={(e) => handleChange('phone', e.target.value)}
                      placeholder="(555) 123-4567" disabled={submitting}
                      className={`w-full px-4 py-3 bg-black border rounded-lg text-white placeholder-gray-600 focus:outline-none transition-colors disabled:opacity-50 ${errors.phone ? 'border-red-500' : 'border-white/10 focus:border-neon-cyan'}`} />
                    {errors.phone && <p className="text-red-400 text-xs mt-1">{errors.phone}</p>}
                  </div>
                </div>

                <div>
                  <label className="block text-sm text-gray-400 mb-1.5 font-medium">Email</label>
                  <input type="email" value={formData.email} onChange={(e) => handleChange('email', e.target.value)}
                    placeholder="your@email.com" disabled={submitting}
                    className={`w-full px-4 py-3 bg-black border rounded-lg text-white placeholder-gray-600 focus:outline-none transition-colors disabled:opacity-50 ${errors.email ? 'border-red-500' : 'border-white/10 focus:border-neon-cyan'}`} />
                  {errors.email && <p className="text-red-400 text-xs mt-1">{errors.email}</p>}
                </div>

                <div>
                  <label className="block text-sm text-gray-400 mb-1.5 font-medium">Subject</label>
                  <select value={formData.subject} onChange={(e) => handleChange('subject', e.target.value)} disabled={submitting}
                    className="w-full px-4 py-3 bg-black border border-white/10 rounded-lg text-white focus:border-neon-cyan focus:outline-none transition-colors disabled:opacity-50">
                    <option value="general">General Inquiry</option>
                    <option value="vehicle">Vehicle Question</option>
                    <option value="trade-in">Trade-In Valuation</option>
                    <option value="detailing">Detailing Services</option>
                    <option value="test-drive">Schedule Test Drive</option>
                  </select>

                </div>

                <div>
                  <label className="block text-sm text-gray-400 mb-1.5 font-medium">Message *</label>
                  <textarea value={formData.message} onChange={(e) => handleChange('message', e.target.value)}
                    rows={5} placeholder="Tell us how we can help..." disabled={submitting}
                    className={`w-full px-4 py-3 bg-black border rounded-lg text-white placeholder-gray-600 focus:outline-none transition-colors resize-none disabled:opacity-50 ${errors.message ? 'border-red-500' : 'border-white/10 focus:border-neon-cyan'}`} />
                  {errors.message && <p className="text-red-400 text-xs mt-1">{errors.message}</p>}
                </div>

                <button type="submit" disabled={submitting}
                  className="w-full flex items-center justify-center gap-2 py-4 bg-gradient-to-r from-neon-pink to-neon-orange text-white font-bold text-lg rounded-xl hover:opacity-90 transition-opacity neon-pulse disabled:opacity-50 disabled:cursor-not-allowed disabled:animate-none">
                  {submitting ? (
                    <><Loader2 className="w-5 h-5 animate-spin" /> Sending...</>
                  ) : (
                    <><Send className="w-5 h-5" /> Send Message</>
                  )}
                </button>

                <p className="text-xs text-gray-500 text-center">
                  We typically respond within 1-2 hours during business hours.
                </p>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
