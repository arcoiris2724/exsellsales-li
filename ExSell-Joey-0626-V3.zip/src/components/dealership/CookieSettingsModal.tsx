import React from 'react';
import { X, Shield, BarChart3, Megaphone, UserCog, Lock } from 'lucide-react';

export interface CookiePreferences {
  essential: boolean;
  analytics: boolean;
  marketing: boolean;
  personalization: boolean;
}

interface CookieSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  preferences: CookiePreferences;
  onPreferencesChange: (prefs: CookiePreferences) => void;
  onSave: () => void;
}

interface CategoryToggleProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  enabled: boolean;
  locked?: boolean;
  accentColor: string;
  glowClass: string;
  onChange: (enabled: boolean) => void;
}

const CategoryToggle: React.FC<CategoryToggleProps> = ({
  icon, title, description, enabled, locked = false, accentColor, glowClass, onChange,
}) => {
  return (
    <div
      className="relative p-4 rounded-xl border transition-all duration-300"
      style={enabled
        ? { borderColor: `${accentColor}66`, backgroundColor: `${accentColor}0D` }
        : { borderColor: 'rgba(255,255,255,0.1)', backgroundColor: 'rgba(255,255,255,0.02)' }
      }
    >
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-start gap-3 flex-1 min-w-0">
          <div className={`flex-shrink-0 w-10 h-10 rounded-lg flex items-center justify-center transition-all duration-300 ${enabled ? glowClass : 'bg-white/5'}`}>
            {icon}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <h4 className="text-sm font-semibold text-white">{title}</h4>
              {locked && (
                <span className="flex items-center gap-1 text-[10px] font-medium text-white/40 bg-white/5 px-1.5 py-0.5 rounded">
                  <Lock className="w-2.5 h-2.5" />
                  Required
                </span>
              )}
            </div>
            <p className="text-xs text-white/50 mt-1 leading-relaxed">{description}</p>
          </div>
        </div>
        <button
          onClick={() => !locked && onChange(!enabled)}
          disabled={locked}
          className={`relative flex-shrink-0 w-11 h-6 rounded-full transition-all duration-300 focus:outline-none ${locked ? 'cursor-not-allowed opacity-60' : 'cursor-pointer'}`}
          style={{ background: enabled ? 'linear-gradient(135deg, #FF0080, #FF8C00)' : 'rgba(255,255,255,0.1)' }}
          aria-label={`Toggle ${title}`}
          aria-checked={enabled}
          role="switch"
        >
          <span className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white shadow-md transition-transform duration-300 ${enabled ? 'translate-x-5' : 'translate-x-0'}`} />
        </button>
      </div>
    </div>
  );
};

const CookieSettingsModal: React.FC<CookieSettingsModalProps> = ({
  isOpen, onClose, preferences, onPreferencesChange, onSave,
}) => {
  if (!isOpen) return null;

  const handleToggle = (key: keyof CookiePreferences, value: boolean) => {
    onPreferencesChange({ ...preferences, [key]: value });
  };

  const handleAcceptAll = () => {
    onPreferencesChange({ essential: true, analytics: true, marketing: true, personalization: true });
    setTimeout(() => onSave(), 150);
  };

  const handleRejectNonEssential = () => {
    onPreferencesChange({ essential: true, analytics: false, marketing: false, personalization: false });
    setTimeout(() => onSave(), 150);
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={onClose} />
      <div
        className="relative w-full max-w-lg max-h-[90vh] overflow-y-auto rounded-2xl border border-white/10 shadow-2xl"
        style={{
          background: 'linear-gradient(135deg, rgba(10,10,10,0.97), rgba(20,10,30,0.97))',
          boxShadow: '0 0 60px rgba(255,0,128,0.08), 0 0 120px rgba(0,240,255,0.04), 0 25px 50px rgba(0,0,0,0.5)',
        }}
      >
        <div className="sticky top-0 z-10 flex items-center justify-between p-5 pb-4 border-b border-white/10 bg-inherit rounded-t-2xl">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #FF0080, #FF8C00)', boxShadow: '0 0 20px rgba(255,0,128,0.3)' }}>
              <Shield className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white" style={{ fontFamily: 'Orbitron, sans-serif' }}>Cookie Settings</h3>
              <p className="text-xs text-white/40">Manage your privacy preferences</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-white/50 hover:text-white transition-all duration-200" aria-label="Close cookie settings">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="px-5 pt-4 pb-2">
          <p className="text-sm text-white/60 leading-relaxed">
            We use cookies and similar technologies to enhance your browsing experience, analyze site traffic, and personalize content. You can choose which categories to allow below. Essential cookies are always active as they are necessary for the website to function.
          </p>
        </div>

        <div className="px-5 py-3 space-y-3">
          <CategoryToggle icon={<Shield className="w-5 h-5 text-[#00F0FF]" />} title="Essential Cookies" description="Required for core website functionality including security, session management, and accessibility. These cannot be disabled." enabled={preferences.essential} locked={true} accentColor="#00F0FF" glowClass="bg-[#00F0FF]/10" onChange={() => {}} />
          <CategoryToggle icon={<BarChart3 className="w-5 h-5 text-[#BFFF00]" />} title="Analytics Cookies" description="Help us understand how visitors interact with our website by collecting anonymous usage data. This helps us improve our services." enabled={preferences.analytics} locked={false} accentColor="#BFFF00" glowClass="bg-[#BFFF00]/10" onChange={(val) => handleToggle('analytics', val)} />
          <CategoryToggle icon={<Megaphone className="w-5 h-5 text-[#FF0080]" />} title="Marketing Cookies" description="Used to deliver relevant advertisements and track ad campaign performance. These cookies may be set by our advertising partners." enabled={preferences.marketing} locked={false} accentColor="#FF0080" glowClass="bg-[#FF0080]/10" onChange={(val) => handleToggle('marketing', val)} />
          <CategoryToggle icon={<UserCog className="w-5 h-5 text-[#FF8C00]" />} title="Personalization Cookies" description="Allow us to remember your preferences and customize your experience, such as saved vehicles, recently viewed listings, and display settings." enabled={preferences.personalization} locked={false} accentColor="#FF8C00" glowClass="bg-[#FF8C00]/10" onChange={(val) => handleToggle('personalization', val)} />
        </div>

        <div className="sticky bottom-0 p-5 pt-4 border-t border-white/10 bg-inherit rounded-b-2xl">
          <div className="flex flex-col sm:flex-row gap-2">
            <button onClick={handleRejectNonEssential} className="flex-1 px-4 py-2.5 rounded-xl border border-white/15 text-sm font-semibold text-white/70 hover:text-white hover:border-white/30 hover:bg-white/5 transition-all duration-200">Reject Non-Essential</button>
            <button onClick={onSave} className="flex-1 px-4 py-2.5 rounded-xl border border-[#00F0FF]/30 text-sm font-semibold text-[#00F0FF] hover:bg-[#00F0FF]/10 hover:border-[#00F0FF]/50 transition-all duration-200">Save My Preferences</button>
            <button onClick={handleAcceptAll} className="flex-1 px-4 py-2.5 rounded-xl text-sm font-bold text-white transition-all duration-200 hover:shadow-lg hover:shadow-[#FF0080]/20 hover:scale-[1.02] active:scale-[0.98]" style={{ background: 'linear-gradient(135deg, #FF0080, #FF8C00)' }}>Accept All</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CookieSettingsModal;
