import React, { useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { X, Megaphone, ArrowRight } from 'lucide-react';
import { fetchSectionContent } from '@/hooks/useSiteContent';
import { HOMEPAGE_SECTIONS, DEFAULT_ANNOUNCEMENT_BANNER, type AnnouncementBannerContent } from '@/data/homepageDefaults';

const THEME_MAP: Record<AnnouncementBannerContent['theme'], string> = {
  pink: 'from-neon-pink via-rose-500 to-neon-orange',
  orange: 'from-neon-orange via-amber-500 to-yellow-500',
  cyan: 'from-neon-cyan via-blue-500 to-indigo-500',
  green: 'from-neon-green via-emerald-500 to-teal-500',
  purple: 'from-neon-purple via-violet-500 to-fuchsia-500',
};

/**
 * Site-wide announcement bar driven by the CMS (`announcement_banner` section).
 * Renders nothing unless an admin has enabled it in the Content Manager.
 * Dismissals are remembered per-message for the browser session.
 */
const AnnouncementBanner: React.FC = () => {
  const [banner, setBanner] = useState<AnnouncementBannerContent | null>(null);
  const [dismissed, setDismissed] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    let active = true;
    fetchSectionContent(HOMEPAGE_SECTIONS.announcement)
      .then((data) => {
        if (active && data) {
          // Merge with defaults so legacy/partial rows never break rendering.
          setBanner({ ...DEFAULT_ANNOUNCEMENT_BANNER, ...(data as Partial<AnnouncementBannerContent>) });
        }
      })
      .catch(() => {});
    return () => {
      active = false;
    };
  }, []);


  // Per-message session dismissal key — editing the message re-shows the bar.
  const dismissKey = banner ? `announce_dismissed:${banner.message}` : '';

  useEffect(() => {
    if (!dismissKey) return;
    try {
      setDismissed(sessionStorage.getItem(dismissKey) === '1');
    } catch {
      /* ignore */
    }
  }, [dismissKey]);

  if (!banner || !banner.enabled || !banner.message.trim() || dismissed) return null;

  const handleDismiss = () => {
    setDismissed(true);
    try {
      if (dismissKey) sessionStorage.setItem(dismissKey, '1');
    } catch {
      /* ignore */
    }
  };

  const handleCta = (e: React.MouseEvent) => {
    e.preventDefault();
    const { ctaType, ctaTarget } = banner;
    if (!ctaTarget) return;
    switch (ctaType) {
      case 'scroll': {
        if (location.pathname !== '/') {
          navigate('/');
          setTimeout(() => {
            document.getElementById(ctaTarget)?.scrollIntoView({ behavior: 'smooth' });
          }, 250);
        } else {
          document.getElementById(ctaTarget)?.scrollIntoView({ behavior: 'smooth' });
        }
        break;
      }
      case 'route':
        navigate(ctaTarget);
        break;
      case 'external':
        window.open(ctaTarget, '_blank', 'noopener,noreferrer');
        break;
      case 'phone':
        window.location.href = `tel:${ctaTarget}`;
        break;
      default:
        break;
    }
  };

  const gradient = THEME_MAP[banner.theme] || THEME_MAP.pink;
  const showCta = banner.ctaType !== 'none' && banner.ctaLabel.trim() && banner.ctaTarget.trim();

  return (
    <div className={`relative w-full bg-gradient-to-r ${gradient} text-white`}>
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center gap-3 py-2 text-sm font-semibold">
          <Megaphone className="w-4 h-4 flex-shrink-0 hidden sm:block" />

          {banner.marquee ? (
            <div className="flex-1 overflow-hidden">
              <div className="whitespace-nowrap animate-marquee inline-block">
                <span className="mx-8">{banner.message}</span>
                <span className="mx-8">{banner.message}</span>
                <span className="mx-8">{banner.message}</span>
              </div>
            </div>
          ) : (
            <span className="flex-1 text-center sm:text-left leading-snug">
              {banner.message}
            </span>
          )}

          {showCta && (
            <button
              onClick={handleCta}
              className="flex-shrink-0 inline-flex items-center gap-1.5 bg-white/20 hover:bg-white/30 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-bold transition-colors whitespace-nowrap"
            >
              {banner.ctaLabel}
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}

          {banner.dismissible && (
            <button
              onClick={handleDismiss}
              aria-label="Dismiss announcement"
              className="flex-shrink-0 p-1 rounded-full hover:bg-white/20 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
      <style>{`
        @keyframes announceMarquee {
          0% { transform: translateX(0); }
          100% { transform: translateX(-33.333%); }
        }
        .animate-marquee {
          animation: announceMarquee 18s linear infinite;
        }
      `}</style>
    </div>

  );
};

export default AnnouncementBanner;
