import React from 'react';
import { useNavigate } from 'react-router-dom';
import { X, ArrowRight, Scale, Trash2 } from 'lucide-react';
import { useCompare } from '@/contexts/CompareContext';

const ComparisonTray: React.FC = () => {
  const { compareList, removeFromCompare, clearCompare } = useCompare();
  const navigate = useNavigate();

  if (compareList.length === 0) return null;

  const emptySlots = 2 - compareList.length; // minimum 2 to compare

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 animate-slide-in">
      {/* Backdrop blur bar */}
      <div className="bg-[#0a0a0a]/95 backdrop-blur-xl border-t border-neon-cyan/20 shadow-[0_-4px_30px_rgba(0,240,255,0.1)]">
        <div className="max-w-7xl mx-auto px-4 py-3">
          <div className="flex items-center gap-4">
            {/* Label */}
            <div className="flex items-center gap-2 flex-shrink-0">
              <div className="w-9 h-9 bg-neon-cyan/10 rounded-lg flex items-center justify-center">
                <Scale className="w-4.5 h-4.5 text-neon-cyan" />
              </div>
              <div className="hidden sm:block">
                <div className="text-white font-bold text-sm leading-tight">Compare</div>
                <div className="text-gray-500 text-xs">{compareList.length}/3 selected</div>
              </div>
            </div>

            {/* Divider */}
            <div className="w-px h-10 bg-white/10 flex-shrink-0" />

            {/* Vehicle cards */}
            <div className="flex items-center gap-3 flex-1 overflow-x-auto scrollbar-hide">
              {compareList.map((vehicle) => (
                <div
                  key={vehicle.id}
                  className="flex items-center gap-3 px-3 py-2 bg-white/[0.04] rounded-xl border border-white/10 flex-shrink-0 group hover:border-neon-cyan/30 transition-colors"
                >
                  <div className="w-14 h-10 rounded-lg overflow-hidden flex-shrink-0">
                    <img
                      src={vehicle.image || (vehicle.images?.length > 0 ? vehicle.images[0] : '/placeholder.svg')}
                      alt={`${vehicle.year} ${vehicle.make} ${vehicle.model}`}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="min-w-0">
                    <div className="text-white text-sm font-semibold truncate max-w-[140px]">
                      {vehicle.year} {vehicle.make} {vehicle.model}
                    </div>
                    <div className="text-neon-orange text-xs font-bold">
                      ${vehicle.price.toLocaleString()}
                    </div>
                  </div>
                  <button
                    onClick={() => removeFromCompare(vehicle.id)}
                    className="p-1 rounded-md text-gray-500 hover:text-red-400 hover:bg-red-400/10 transition-colors flex-shrink-0"
                    title="Remove from comparison"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}

              {/* Empty slots indicator */}
              {compareList.length < 2 && (
                <div className="flex items-center gap-2 px-4 py-3 border border-dashed border-white/10 rounded-xl flex-shrink-0">
                  <div className="w-14 h-10 rounded-lg bg-white/[0.03] flex items-center justify-center">
                    <span className="text-gray-600 text-lg">+</span>
                  </div>
                  <span className="text-gray-500 text-sm whitespace-nowrap">
                    Add {emptySlots > 1 ? `${emptySlots} more` : '1 more'} to compare
                  </span>
                </div>
              )}
            </div>

            {/* Actions */}
            <div className="flex items-center gap-2 flex-shrink-0">
              <button
                onClick={clearCompare}
                className="p-2.5 rounded-lg border border-white/10 text-gray-400 hover:text-red-400 hover:border-red-400/30 hover:bg-red-400/5 transition-all"
                title="Clear all"
              >
                <Trash2 className="w-4 h-4" />
              </button>
              <button
                onClick={() => {
                  if (compareList.length >= 2) {
                    navigate('/compare');
                  }
                }}
                disabled={compareList.length < 2}
                className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-sm transition-all ${
                  compareList.length >= 2
                    ? 'bg-gradient-to-r from-neon-cyan to-neon-green text-black hover:opacity-90 neon-glow-cyan cursor-pointer'
                    : 'bg-white/[0.05] text-gray-500 border border-white/10 cursor-not-allowed'
                }`}
              >
                Compare Now
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ComparisonTray;
