import React from 'react';
import { Gauge, Fuel, Settings2, Palette, Car, Hash, Calendar, Cog, MapPin } from 'lucide-react';
import { Vehicle } from '@/data/vehicles';

interface VehicleSpecsProps {
  vehicle: Vehicle;
}

const VehicleSpecs: React.FC<VehicleSpecsProps> = ({ vehicle }) => {
  const specGroups = [
    {
      title: 'Performance & Drivetrain',
      specs: [
        { icon: Settings2, label: 'Engine', value: vehicle.engine, color: 'text-neon-pink' },
        { icon: Cog, label: 'Transmission', value: vehicle.transmission, color: 'text-neon-cyan' },
        { icon: Car, label: 'Drivetrain', value: vehicle.drivetrain, color: 'text-neon-green' },
        { icon: Fuel, label: 'Fuel Type', value: vehicle.fuelType, color: 'text-neon-orange' },
      ],
    },
    {
      title: 'Details',
      specs: [
        { icon: Calendar, label: 'Year', value: String(vehicle.year), color: 'text-neon-cyan' },
        { icon: Car, label: 'Body Type', value: vehicle.bodyType, color: 'text-neon-pink' },
        { icon: Gauge, label: 'Mileage', value: `${vehicle.mileage.toLocaleString()} miles`, color: 'text-neon-green' },
        { icon: Hash, label: 'VIN', value: vehicle.vin || 'Contact for VIN', color: 'text-neon-orange' },
      ],
    },
    {
      title: 'Appearance',
      specs: [
        { icon: Palette, label: 'Exterior Color', value: vehicle.exteriorColor, color: 'text-neon-purple' },
        { icon: Palette, label: 'Interior Color', value: vehicle.interiorColor, color: 'text-neon-yellow' },
        { icon: Car, label: 'Trim', value: vehicle.trim || 'Standard', color: 'text-neon-cyan' },
        { icon: MapPin, label: 'Location', value: 'Long Island, NY', color: 'text-neon-green' },
      ],
    },
  ];

  return (
    <div className="space-y-6">
      <h3 className="text-xl font-bold text-white flex items-center gap-2">
        <Settings2 className="w-5 h-5 text-neon-cyan" />
        Vehicle Specifications
      </h3>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {specGroups.map((group) => (
          <div
            key={group.title}
            className="p-5 bg-white/[0.02] rounded-xl border border-white/5 hover:border-white/10 transition-colors"
          >
            <h4 className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-4">
              {group.title}
            </h4>
            <div className="space-y-3">
              {group.specs.map((spec) => (
                <div key={spec.label} className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <spec.icon className={`w-4 h-4 ${spec.color}`} />
                    <span className="text-sm text-gray-400">{spec.label}</span>
                  </div>
                  <span className="text-sm text-white font-medium text-right max-w-[50%] truncate">
                    {spec.value}
                  </span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Full specs table */}
      <div className="p-5 bg-white/[0.02] rounded-xl border border-white/5">
        <h4 className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-4">
          Complete Specifications
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-2">
          {[
            { label: 'Make', value: vehicle.make },
            { label: 'Model', value: vehicle.model },
            { label: 'Year', value: String(vehicle.year) },
            { label: 'Trim', value: vehicle.trim || 'Standard' },
            { label: 'Body Type', value: vehicle.bodyType },
            { label: 'Engine', value: vehicle.engine },
            { label: 'Transmission', value: vehicle.transmission },
            { label: 'Drivetrain', value: vehicle.drivetrain },
            { label: 'Fuel Type', value: vehicle.fuelType },
            { label: 'Mileage', value: `${vehicle.mileage.toLocaleString()} mi` },
            { label: 'Exterior Color', value: vehicle.exteriorColor },
            { label: 'Interior Color', value: vehicle.interiorColor },
            { label: 'VIN', value: vehicle.vin || 'Contact dealer' },
            { label: 'Status', value: vehicle.status === 'available' ? 'Available' : vehicle.status === 'pending' ? 'Sale Pending' : 'Sold' },
          ].map((row, i) => (
            <div
              key={row.label}
              className={`flex items-center justify-between py-2.5 ${
                i < 12 ? 'border-b border-white/5' : ''
              }`}
            >
              <span className="text-sm text-gray-500">{row.label}</span>
              <span className="text-sm text-white font-medium">{row.value}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default VehicleSpecs;
