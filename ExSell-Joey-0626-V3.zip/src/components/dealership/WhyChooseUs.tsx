import React, { useState, useEffect } from 'react';
import { CheckCircle, TrendingDown, Clock, Users, ShieldCheck, Sparkles, Star, Heart, Gem, TrendingUp, Building2, Eye, Target, ThumbsUp, Wrench, FileCheck, Truck, Shield, Award, Handshake, Phone, Mail, MapPin, DollarSign, Zap, Car } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { DEFAULT_WHY_CHOOSE_US, HOMEPAGE_SECTIONS } from '@/data/homepageDefaults';
import type { WhyChooseUsContent } from '@/data/homepageDefaults';

const LOGO_URL = 'https://d64gsuwffb70l.cloudfront.net/6917af11eb66b8b0c2b0bc86_1774223659449_0339845b.jpg';

const iconMap: Record<string, React.ElementType> = {
  CheckCircle, TrendingDown, Clock, Users, ShieldCheck, Sparkles, Star, Heart, Gem, TrendingUp,
  Building2, Eye, Target, ThumbsUp, Wrench, FileCheck, Truck, Shield, Award, Handshake,
  Phone, Mail, MapPin, DollarSign, Zap, Car,
};

const WhyChooseUs: React.FC = () => {
  const [content, setContent] = useState<WhyChooseUsContent>(DEFAULT_WHY_CHOOSE_US);

  useEffect(() => {
    let cancelled = false;
    supabase.from('site_content').select('content').eq('section', HOMEPAGE_SECTIONS.whyChooseUs).single()
      .then(({ data }) => {
        if (!cancelled && data?.content) setContent(data.content as WhyChooseUsContent);
      });
    return () => { cancelled = true; };
  }, []);

  return (
    <section id="why-us" className="py-20 px-4 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0">
        <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-neon-pink/30 to-transparent" />
        <div className="absolute bottom-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-neon-cyan/30 to-transparent" />
      </div>

      <div className="relative max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left - Logo & tagline */}
          <div className="space-y-8">
            <div>
              <h2 className="text-3xl md:text-5xl font-black text-white mb-4">
                {content.title}{' '}
                <span className="gradient-text-neon">{content.titleHighlight}</span>
              </h2>
              <p className="text-gray-400 text-lg leading-relaxed">
                {content.description}
              </p>
            </div>

            {/* DOMINANT Logo showcase */}
            <div className="relative inline-block group">
              <div className="absolute -inset-8 rounded-3xl bg-gradient-to-br from-neon-pink/20 via-neon-orange/15 to-neon-cyan/20 blur-2xl opacity-70 group-hover:opacity-100 transition-opacity duration-500" />
              <div className="absolute -inset-4 rounded-2xl bg-gradient-to-br from-neon-pink/25 via-neon-orange/20 to-neon-cyan/25 blur-xl" />
              <div className="absolute -inset-1.5 rounded-2xl bg-gradient-to-br from-neon-pink via-neon-orange to-neon-cyan p-[2px]">
                <div className="w-full h-full rounded-2xl bg-black" />
              </div>
              <img src={LOGO_URL} alt="Ex$ell Car Sales" className="relative w-72 md:w-96 rounded-2xl shadow-2xl shadow-neon-pink/15 z-10" />
              <div className="absolute -top-2 -left-2 w-4 h-4 bg-neon-pink rounded-full blur-[2px] animate-pulse z-20" />
              <div className="absolute -top-2 -right-2 w-4 h-4 bg-neon-orange rounded-full blur-[2px] animate-pulse z-20" style={{ animationDelay: '0.5s' }} />
              <div className="absolute -bottom-2 -left-2 w-4 h-4 bg-neon-cyan rounded-full blur-[2px] animate-pulse z-20" style={{ animationDelay: '1s' }} />
              <div className="absolute -bottom-2 -right-2 w-4 h-4 bg-neon-green rounded-full blur-[2px] animate-pulse z-20" style={{ animationDelay: '1.5s' }} />
            </div>

            <div className="flex items-center gap-6">
              {content.stats.map((stat, i) => (
                <React.Fragment key={i}>
                  {i > 0 && <div className="w-px h-12 bg-white/10" />}
                  <div className="text-center">
                    <div className={`text-3xl font-display font-bold ${stat.color}`}>{stat.value}</div>
                    <div className="text-xs text-gray-500 font-medium">{stat.label}</div>
                  </div>
                </React.Fragment>
              ))}
            </div>
          </div>

          {/* Right - Reasons grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {content.reasons.map((reason, i) => {
              const IconComp = iconMap[reason.icon] || Star;
              return (
                <div key={i} className="p-5 bg-white/[0.02] rounded-xl border border-white/5 hover:border-white/10 transition-all duration-300 group">
                  <IconComp className={`w-8 h-8 ${reason.color} mb-3 group-hover:scale-110 transition-transform`} />
                  <h3 className="text-white font-bold mb-1">{reason.title}</h3>
                  <p className="text-gray-500 text-sm leading-relaxed">{reason.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};

export default WhyChooseUs;
