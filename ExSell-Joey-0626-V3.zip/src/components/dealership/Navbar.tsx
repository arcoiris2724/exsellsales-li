import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import { Phone, Menu, X, MapPin, Clock, Scale, Info, Star, Trophy } from 'lucide-react';

import { useCompare } from '@/contexts/CompareContext';
import JoeyLogo from './JoeyLogo';
import AnnouncementBanner from './AnnouncementBanner';



const Navbar: React.FC = () => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const { compareList } = useCompare();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollTo = (id: string) => {
    setMobileMenuOpen(false);
    if (location.pathname !== '/') {
      navigate('/');
      setTimeout(() => {
        const el = document.getElementById(id);
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      }, 200);
    } else {
      const el = document.getElementById(id);
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const goHome = () => {
    setMobileMenuOpen(false);
    if (location.pathname !== '/') {
      navigate('/');
    } else {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const navLinks = [
    { label: 'Home', id: 'hero' },
    { label: 'Inventory', id: 'inventory' },
    { label: 'Services', id: 'services' },
    { label: 'Trade-In', id: 'trade-in' },
    { label: 'Why Us', id: 'why-us' },
    { label: 'Contact', id: 'contact' },
  ];


  // Pages that are dedicated routes (not scroll-to sections)
  const pageLinks = [
    { label: 'Sold List', path: '/sold', icon: Trophy },
    { label: 'Reviews', path: '/reviews', icon: Star },
    { label: 'About Us', path: '/about', icon: Info },
  ];


  return (
    <>
      {/* CMS-driven announcement banner (site-wide) */}
      <AnnouncementBanner />

      {/* Top bar */}
      <div className="bg-gradient-to-r from-neon-pink/10 via-neon-orange/10 to-neon-cyan/10 border-b border-white/5">

        <div className="max-w-7xl mx-auto px-4 py-2 flex items-center justify-between text-sm">
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2 text-gray-400">
              <MapPin className="w-3.5 h-3.5 text-neon-green" />
              <span>Long Island, NY</span>
            </div>
            <div className="hidden sm:flex items-center gap-2 text-gray-400">
              <Clock className="w-3.5 h-3.5 text-neon-cyan" />
              <span>Mon-Fri: 7AM-5PM | Sat: 7AM-2PM | Sun: Closed</span>

            </div>
          </div>
          <a
            href="tel:6313884426"
            className="flex items-center gap-2 text-neon-green hover:text-neon-cyan transition-colors font-semibold"
          >
            <Phone className="w-3.5 h-3.5" />
            <span>(631) 388-4426</span>
          </a>
        </div>
      </div>

      {/* Main navbar */}
      <nav
        className={`sticky top-0 z-50 transition-all duration-300 ${
          scrolled
            ? 'bg-black/95 backdrop-blur-xl shadow-lg shadow-neon-pink/5 border-b border-white/5'
            : 'bg-black/80 backdrop-blur-md'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4">
          <div
            className={`flex items-center justify-between transition-all duration-300 ${
              scrolled ? 'h-20 lg:h-24' : 'h-24 lg:h-28'
            }`}
          >
            {/* Logo — Joey avatar as brand mark */}
            <button onClick={goHome} className="flex items-center gap-3 group flex-shrink-0">
              <div className="relative">
                <div className="absolute -inset-2 bg-gradient-to-br from-neon-pink/30 via-neon-orange/20 to-neon-cyan/30 rounded-full blur-lg opacity-50 group-hover:opacity-100 transition-opacity duration-500" />
                <div
                  className={`relative transition-all duration-300 group-hover:scale-110 ${
                    scrolled ? 'w-12 h-12 lg:w-14 lg:h-14' : 'w-14 h-14 lg:w-16 lg:h-16'
                  }`}
                >
                  <JoeyLogo size={scrolled ? 56 : 64} showGlow={true} />
                </div>
              </div>
              <div className="hidden md:flex flex-col">
                <span className="text-xl lg:text-2xl font-black tracking-tight gradient-text-neon leading-tight">
                  EX$ELL
                </span>
                <span className="text-[10px] lg:text-xs font-bold text-gray-400 uppercase tracking-[0.2em]">
                  Car Sales LI
                </span>
              </div>
            </button>


            {/* Desktop nav links */}
            <div className="hidden lg:flex items-center gap-0.5 flex-1 justify-center px-2">
              {navLinks.map((link) => (
                <button
                  key={link.id}
                  onClick={() => scrollTo(link.id)}
                  className="whitespace-nowrap px-2 xl:px-3 py-2 text-[13px] xl:text-sm font-semibold text-gray-300 hover:text-white transition-colors relative group"
                >
                  {link.label}
                  <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-0 h-0.5 bg-gradient-to-r from-neon-pink to-neon-orange transition-all duration-300 group-hover:w-full" />
                </button>
              ))}
              {pageLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`whitespace-nowrap px-2 xl:px-3 py-2 text-[13px] xl:text-sm font-semibold transition-colors relative group ${
                    location.pathname === link.path
                      ? 'text-neon-pink'
                      : 'text-gray-300 hover:text-white'
                  }`}
                >
                  {link.label}
                  <span
                    className={`absolute bottom-0 left-1/2 -translate-x-1/2 h-0.5 bg-gradient-to-r from-neon-pink to-neon-orange transition-all duration-300 ${
                      location.pathname === link.path ? 'w-full' : 'w-0 group-hover:w-full'
                    }`}
                  />
                </Link>
              ))}
            </div>

            {/* CTA buttons + Compare */}
            <div className="hidden lg:flex items-center gap-2 flex-shrink-0">
              {/* Compare button - shows when vehicles are selected */}
              {compareList.length > 0 && (
                <Link
                  to="/compare"
                  className="relative flex items-center gap-1.5 px-3 py-2.5 bg-neon-cyan/10 border border-neon-cyan/30 text-neon-cyan font-bold text-[13px] rounded-lg hover:bg-neon-cyan/20 transition-colors whitespace-nowrap"
                >
                  <Scale className="w-4 h-4" />
                  <span className="hidden xl:inline">Compare</span>
                  <span className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-neon-cyan text-black text-[10px] font-black rounded-full flex items-center justify-center">
                    {compareList.length}
                  </span>
                </Link>
              )}
              <a
                href="tel:6313884426"
                className="flex items-center gap-1.5 px-3.5 xl:px-5 py-2.5 bg-gradient-to-r from-neon-pink to-neon-orange text-white font-bold text-[13px] xl:text-sm rounded-lg neon-pulse hover:opacity-90 transition-opacity whitespace-nowrap"
              >
                <Phone className="w-4 h-4" />
                Call Now
              </a>
              {/* Contact Us shown only at xl where there's room (Contact nav link covers lg) */}
              <button
                onClick={() => scrollTo('contact')}
                className="hidden xl:inline-flex px-5 py-2.5 border border-neon-cyan/50 text-neon-cyan font-bold text-sm rounded-lg hover:bg-neon-cyan/10 transition-colors whitespace-nowrap"
              >
                Contact Us
              </button>
            </div>


            {/* Mobile menu button + compare badge */}
            <div className="flex items-center gap-2 lg:hidden">
              {compareList.length > 0 && (
                <Link
                  to="/compare"
                  className="relative p-2 text-neon-cyan"
                >
                  <Scale className="w-5 h-5" />
                  <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-neon-cyan text-black text-[9px] font-black rounded-full flex items-center justify-center">
                    {compareList.length}
                  </span>
                </Link>
              )}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-2 text-gray-300 hover:text-white"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-black/98 backdrop-blur-xl border-t border-white/5 animate-slide-in">
            <div className="px-4 py-4 space-y-1">
              {navLinks.map((link) => (
                <button
                  key={link.id}
                  onClick={() => scrollTo(link.id)}
                  className="block w-full text-left px-4 py-3 text-gray-300 hover:text-white hover:bg-white/5 rounded-lg transition-colors font-medium"
                >
                  {link.label}
                </button>
              ))}
              {pageLinks.map((link) => {
                const Icon = link.icon;
                return (
                  <Link
                    key={link.path}
                    to={link.path}
                    onClick={() => setMobileMenuOpen(false)}
                    className={`flex items-center gap-2 w-full px-4 py-3 rounded-lg transition-colors font-medium ${
                      location.pathname === link.path
                        ? 'text-neon-pink bg-neon-pink/5'
                        : 'text-gray-300 hover:text-white hover:bg-white/5'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    {link.label}
                  </Link>
                );
              })}
              {compareList.length > 0 && (
                <Link
                  to="/compare"
                  onClick={() => setMobileMenuOpen(false)}
                  className="flex items-center gap-2 w-full px-4 py-3 text-neon-cyan hover:bg-neon-cyan/5 rounded-lg transition-colors font-medium"
                >
                  <Scale className="w-4 h-4" />
                  Compare Vehicles ({compareList.length})
                </Link>
              )}
              <div className="pt-3 space-y-2">
                <a
                  href="tel:6313884426"
                  className="flex items-center justify-center gap-2 w-full px-5 py-3 bg-gradient-to-r from-neon-pink to-neon-orange text-white font-bold rounded-lg"
                >
                  <Phone className="w-4 h-4" />
                  Call (631) 388-4426
                </a>
                <button
                  onClick={() => scrollTo('contact')}
                  className="w-full px-5 py-3 border border-neon-cyan/50 text-neon-cyan font-bold rounded-lg hover:bg-neon-cyan/10 transition-colors"
                >
                  Contact Us
                </button>
              </div>
            </div>
          </div>
        )}
      </nav>
    </>
  );
};

export default Navbar;
