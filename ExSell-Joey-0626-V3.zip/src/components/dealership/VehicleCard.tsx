import React from 'react';
import { Link } from 'react-router-dom';
import { Heart, Gauge, Fuel, Settings2, Eye, Scale, Camera, Video } from 'lucide-react';
import { Vehicle } from '@/data/vehicles';
import { useCompare } from '@/contexts/CompareContext';

interface VehicleCardProps {
  vehicle: Vehicle;
  isFavorite: boolean;
  onToggleFavorite: (id: number) => void;
  onScheduleTestDrive: (vehicle: Vehicle) => void;
}

const VehicleCard: React.FC<VehicleCardProps> = ({
  vehicle,
  isFavorite,
  onToggleFavorite,
  onScheduleTestDrive,
}) => {
  const { addToCompare, removeFromCompare, isInCompare, canAddMore } = useCompare();
  const isSold = vehicle.status === 'sold';
  const inCompare = isInCompare(vehicle.id);
  const hasVideo = !!vehicle.videoUrl;
  const imageCount = vehicle.images?.length || 1;

  const handleCompareToggle = (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    if (inCompare) {
      removeFromCompare(vehicle.id);
    } else {
      addToCompare(vehicle);
    }
  };

  return (
    <div
      className={`group relative bg-[#0a0a0a] rounded-xl border transition-all duration-300 overflow-hidden ${
        inCompare
          ? 'border-neon-cyan/40 shadow-lg shadow-neon-cyan/10 ring-1 ring-neon-cyan/20'
          : isSold
          ? 'border-red-500/20 opacity-75'
          : 'border-white/5 hover:border-neon-pink/40 hover:shadow-lg hover:shadow-neon-pink/10'
      }`}
    >
      {/* Image - wrapped in Link */}
      <Link to={`/inventory/${vehicle.id}`} className="block relative aspect-[16/10] overflow-hidden">
        <img
          src={vehicle.image}
          alt={`${vehicle.year} ${vehicle.make} ${vehicle.model}`}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        {/* Overlay gradient */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />

        {/* Status badge */}
        {isSold ? (
          <div className="absolute top-3 left-3 px-3 py-1 bg-red-600 text-white text-xs font-bold rounded-full uppercase tracking-wider">
            Sold
          </div>
        ) : vehicle.status === 'pending' ? (
          <div className="absolute top-3 left-3 px-3 py-1 bg-yellow-500/90 text-black text-xs font-bold rounded-full uppercase tracking-wider">
            Pending
          </div>
        ) : (
          <div className="absolute top-3 left-3 px-3 py-1 bg-neon-green/90 text-black text-xs font-bold rounded-full uppercase tracking-wider">
            Available
          </div>
        )}

        {/* Compare selected indicator overlay */}
        {inCompare && (
          <div className="absolute top-3 left-[110px] px-2.5 py-1 bg-neon-cyan/90 text-black text-xs font-bold rounded-full uppercase tracking-wider flex items-center gap-1">
            <Scale className="w-3 h-3" />
            Comparing
          </div>
        )}

        {/* Quick view on hover */}
        {!isSold && (
          <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none">
            <span className="px-5 py-2.5 bg-white/10 backdrop-blur-md text-white font-semibold rounded-lg border border-white/20 flex items-center gap-2">
              <Eye className="w-4 h-4" />
              View Details
            </span>
          </div>
        )}

        {/* Media badges - bottom left */}
        <div className="absolute bottom-3 left-3 flex items-center gap-1.5">
          {imageCount > 1 && (
            <div className="flex items-center gap-1 px-2 py-1 bg-black/70 backdrop-blur-sm rounded-md text-white text-[10px] font-medium">
              <Camera className="w-3 h-3" />
              {imageCount}
            </div>
          )}
          {hasVideo && (
            <div className="flex items-center gap-1 px-2 py-1 bg-neon-pink/80 backdrop-blur-sm rounded-md text-white text-[10px] font-bold">
              <Video className="w-3 h-3" />
              VIDEO
            </div>
          )}
        </div>

        {/* Price tag */}
        <div className="absolute bottom-3 right-3">
          <div className="px-3 py-1.5 bg-black/80 backdrop-blur-sm rounded-lg border border-neon-orange/30">
            <span className="text-neon-orange font-display font-bold text-lg">
              {vehicle.price > 0 ? `$${vehicle.price.toLocaleString()}` : 'Call for Price'}
            </span>
          </div>
        </div>

      </Link>

      {/* Favorite button */}
      <button
        onClick={(e) => {
          e.stopPropagation();
          e.preventDefault();
          onToggleFavorite(vehicle.id);
        }}
        className={`absolute top-3 right-3 z-10 p-2 rounded-full backdrop-blur-sm transition-all duration-300 ${
          isFavorite
            ? 'bg-neon-pink text-white shadow-lg shadow-neon-pink/30'
            : 'bg-black/40 text-white/70 hover:bg-neon-pink/20 hover:text-neon-pink'
        }`}
      >
        <Heart className={`w-4 h-4 ${isFavorite ? 'fill-current' : ''}`} />
      </button>

      {/* Compare button - positioned below favorite */}
      {!isSold && (
        <button
          onClick={handleCompareToggle}
          disabled={!inCompare && !canAddMore}
          className={`absolute top-14 right-3 z-10 p-2 rounded-full backdrop-blur-sm transition-all duration-300 ${
            inCompare
              ? 'bg-neon-cyan text-black shadow-lg shadow-neon-cyan/30'
              : canAddMore
              ? 'bg-black/40 text-white/70 hover:bg-neon-cyan/20 hover:text-neon-cyan'
              : 'bg-black/20 text-white/30 cursor-not-allowed'
          }`}
          title={inCompare ? 'Remove from comparison' : canAddMore ? 'Add to comparison' : 'Comparison full (max 3)'}
        >
          <Scale className="w-4 h-4" />
        </button>
      )}

      {/* Content */}
      <div className="p-4 space-y-3">
        {/* Title - also a link */}
        <Link to={`/inventory/${vehicle.id}`} className="block">
          <h3 className="text-white font-bold text-lg leading-tight group-hover:text-neon-cyan transition-colors">
            {vehicle.year} {vehicle.make} {vehicle.model}
          </h3>
          <p className="text-gray-500 text-sm font-medium">{vehicle.trim}</p>
        </Link>

        {/* Specs */}
        <div className="grid grid-cols-3 gap-2">
          <div className="flex items-center gap-1.5 text-gray-400">
            <Gauge className="w-3.5 h-3.5 text-neon-pink" />
            <span className="text-xs">{(vehicle.mileage / 1000).toFixed(0)}K mi</span>
          </div>
          <div className="flex items-center gap-1.5 text-gray-400">
            <Fuel className="w-3.5 h-3.5 text-neon-green" />
            <span className="text-xs">{vehicle.fuelType}</span>
          </div>
          <div className="flex items-center gap-1.5 text-gray-400">
            <Settings2 className="w-3.5 h-3.5 text-neon-cyan" />
            <span className="text-xs">{vehicle.drivetrain}</span>
          </div>
        </div>

        {/* Color & Transmission */}
        <div className="flex items-center gap-2 text-xs text-gray-500">
          <span>{vehicle.exteriorColor}</span>
          <span className="w-1 h-1 bg-gray-600 rounded-full" />
          <span>{vehicle.transmission}</span>
          <span className="w-1 h-1 bg-gray-600 rounded-full" />
          <span>{vehicle.engine}</span>
        </div>

        {/* Actions */}
        {!isSold && (
          <div className="flex gap-2 pt-1">
            <Link
              to={`/inventory/${vehicle.id}`}
              className="flex-1 py-2.5 bg-gradient-to-r from-neon-pink to-neon-orange text-white text-sm font-bold rounded-lg hover:opacity-90 transition-opacity text-center"
            >
              View Details
            </Link>
            <button
              onClick={handleCompareToggle}
              disabled={!inCompare && !canAddMore}
              className={`px-3 py-2.5 text-sm font-bold rounded-lg transition-all flex items-center gap-1.5 ${
                inCompare
                  ? 'bg-neon-cyan/10 border border-neon-cyan/40 text-neon-cyan'
                  : canAddMore
                  ? 'border border-neon-cyan/30 text-neon-cyan hover:bg-neon-cyan/10'
                  : 'border border-white/10 text-gray-500 cursor-not-allowed'
              }`}
            >
              <Scale className="w-3.5 h-3.5" />
              {inCompare ? 'Added' : 'Compare'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default VehicleCard;
