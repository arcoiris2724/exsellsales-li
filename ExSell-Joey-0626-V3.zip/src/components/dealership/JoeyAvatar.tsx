import React, { useState, useEffect, useRef } from 'react';

export type JoeyPose = 'idle' | 'waving' | 'talking' | 'happy' | 'thinking' | 'excited' | 'wrench' | 'pointing';

const MASTER_LOGO = 'https://d64gsuwffb70l.cloudfront.net/6917af11eb66b8b0c2b0bc86_1774223659449_0339845b.jpg';

interface JoeyAvatarProps {
  pose?: JoeyPose;
  isTalking?: boolean;
  isWaving?: boolean;
  size?: number;
  className?: string;
}

/**
 * Joey mascot avatar using the original master character image.
 * Pose changes are expressed through glow colors, subtle transforms,
 * and overlay effects since the base image is static.
 */
const JoeyAvatar: React.FC<JoeyAvatarProps> = ({
  pose = 'idle',
  isTalking = false,
  isWaving = false,
  size = 64,
  className = '',
}) => {
  const [mouthFrame, setMouthFrame] = useState(false);
  const mouthRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Talking animation cycle
  useEffect(() => {
    if (isTalking) {
      mouthRef.current = setInterval(() => {
        setMouthFrame((prev) => !prev);
      }, 120);
    } else {
      setMouthFrame(false);
      if (mouthRef.current) clearInterval(mouthRef.current);
    }
    return () => {
      if (mouthRef.current) clearInterval(mouthRef.current);
    };
  }, [isTalking]);

  const showWave = isWaving || pose === 'waving';
  const isExcited = pose === 'excited';
  const isHappy = pose === 'happy';
  const isThinking = pose === 'thinking';

  // Pose-based glow color
  const glowColor = (() => {
    switch (pose) {
      case 'excited': return '#BFFF00';
      case 'happy': return '#FF0080';
      case 'thinking': return '#FF8C00';
      case 'wrench': return '#00F0FF';
      case 'pointing': return '#FF0080';
      case 'waving': return '#BFFF00';
      case 'talking': return '#00F0FF';
      default: return '#FF0080';
    }
  })();

  // Pose-based transform
  const poseTransform = (() => {
    if (showWave) return 'rotate(-5deg) scale(1.02)';
    if (isExcited) return 'scale(1.06)';
    if (isHappy) return 'scale(1.03)';
    if (isThinking) return 'rotate(3deg) scale(0.98)';
    if (isTalking) return mouthFrame ? 'scale(1.01)' : 'scale(1.0)';
    return 'scale(1)';
  })();

  // Pose-based animation
  const poseAnimation = (() => {
    if (showWave) return 'joeyWaveRock 1.5s ease-in-out 2';
    if (isExcited) return 'joeyExcitedBounce 0.6s ease-in-out infinite';
    if (isTalking) return 'joeyTalkPulse 0.3s ease-in-out infinite';
    return undefined;
  })();

  return (
    <div
      className={`relative ${className}`}
      style={{ width: size, height: size }}
    >
      {/* Pose-reactive glow ring */}
      <div
        className="absolute -inset-1 rounded-full transition-all duration-500"
        style={{
          boxShadow: `0 0 ${isExcited ? 20 : 12}px ${glowColor}40, 0 0 ${isExcited ? 40 : 25}px ${glowColor}15`,
          border: `1.5px solid ${glowColor}30`,
          opacity: pose === 'idle' && !isTalking ? 0.4 : 0.8,
        }}
      />

      {/* Main avatar image */}
      <div
        className="relative w-full h-full rounded-full overflow-hidden"
        style={{
          transform: poseTransform,
          animation: poseAnimation,
          transition: 'transform 0.3s ease-out',
        }}
      >
        <img
          src={MASTER_LOGO}
          alt="Joey mascot"
          className="w-full h-full object-cover"
          style={{
            filter: isExcited
              ? 'brightness(1.15) contrast(1.1) saturate(1.2)'
              : isThinking
              ? 'brightness(0.95) saturate(0.9)'
              : 'brightness(1.05) contrast(1.05)',
            transition: 'filter 0.4s ease',
          }}
          draggable={false}
        />

        {/* Talking indicator overlay */}
        {isTalking && (
          <div
            className="absolute inset-0 rounded-full pointer-events-none"
            style={{
              boxShadow: `inset 0 0 15px ${glowColor}30`,
              animation: 'joeyTalkGlow 0.3s ease-in-out infinite alternate',
            }}
          />
        )}

        {/* Excited sparkle overlay */}
        {isExcited && (
          <div className="absolute inset-0 rounded-full pointer-events-none overflow-hidden">
            <div
              className="absolute top-1 right-1 w-2 h-2 rounded-full"
              style={{
                background: '#BFFF00',
                boxShadow: '0 0 6px #BFFF00',
                animation: 'joeySparkle 0.7s ease-in-out infinite',
              }}
            />
            <div
              className="absolute bottom-2 left-1 w-1.5 h-1.5 rounded-full"
              style={{
                background: '#FF8C00',
                boxShadow: '0 0 4px #FF8C00',
                animation: 'joeySparkle 0.9s ease-in-out infinite 0.3s',
              }}
            />
            <div
              className="absolute top-3 left-2 w-1 h-1 rounded-full"
              style={{
                background: '#FF0080',
                boxShadow: '0 0 4px #FF0080',
                animation: 'joeySparkle 0.8s ease-in-out infinite 0.15s',
              }}
            />
          </div>
        )}

        {/* Happy glow overlay */}
        {isHappy && !isExcited && (
          <div
            className="absolute inset-0 rounded-full pointer-events-none"
            style={{
              background: 'radial-gradient(circle at 50% 50%, rgba(255, 0, 128, 0.08), transparent 70%)',
            }}
          />
        )}

        {/* Thinking overlay */}
        {isThinking && (
          <div className="absolute -top-1 -right-1 pointer-events-none">
            <div
              className="flex gap-0.5"
              style={{ animation: 'joeyThinkDots 2s ease-in-out infinite' }}
            >
              <div className="w-1 h-1 rounded-full bg-white/50" style={{ animationDelay: '0s' }} />
              <div className="w-1.5 h-1.5 rounded-full bg-white/40" style={{ animationDelay: '0.3s' }} />
              <div className="w-2 h-2 rounded-full bg-white/30" style={{ animationDelay: '0.6s' }} />
            </div>
          </div>
        )}

        {/* Shine overlay */}
        <div
          className="absolute inset-0 rounded-full pointer-events-none"
          style={{
            background: 'linear-gradient(135deg, rgba(255,255,255,0.1) 0%, transparent 50%, rgba(0,0,0,0.1) 100%)',
          }}
        />
      </div>

      {/* Waving hand indicator */}
      {showWave && (
        <div
          className="absolute -right-1 -top-1 text-lg pointer-events-none"
          style={{
            animation: 'joeyHandWave 1.5s ease-in-out 2',
            transformOrigin: 'bottom center',
          }}
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M7.5 12.5L5 10C4.5 9.5 4.5 8.5 5 8C5.5 7.5 6.5 7.5 7 8L9.5 10.5M9.5 10.5L7 6C6.5 5.2 6.8 4.2 7.5 3.8C8.3 3.3 9.3 3.6 9.8 4.3L12 8M9.5 10.5L12 8M12 8L10.5 4.5C10.1 3.7 10.5 2.7 11.3 2.3C12.1 1.9 13.1 2.3 13.5 3.1L15 7M15 7L14 4C13.7 3.2 14.1 2.2 14.9 1.9C15.7 1.5 16.7 1.9 17 2.7L19 9C19.8 11.5 19 14.5 17 16.5L15.5 18C13.5 20 10.5 20 8.5 18L4.5 14C4 13.5 4 12.5 4.5 12C5 11.5 6 11.5 6.5 12L7.5 12.5" stroke="#BFFF00" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </div>
      )}

      {/* Wrench indicator */}
      {pose === 'wrench' && (
        <div
          className="absolute -right-1.5 -bottom-0.5 pointer-events-none"
          style={{
            animation: 'joeyWrenchTurn 2s ease-in-out infinite',
            transformOrigin: 'center center',
          }}
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z" stroke="#00F0FF" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </div>
      )}

      {/* Pointing indicator */}
      {pose === 'pointing' && (
        <div
          className="absolute -right-2 bottom-0 pointer-events-none"
          style={{
            animation: 'joeyPointBounce 1.5s ease-in-out infinite',
          }}
        >
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 5v14M19 12l-7 7-7-7" stroke="#FF0080" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </div>
      )}

      <style>{`
        @keyframes joeyWaveRock {
          0%, 100% { transform: rotate(0deg) scale(1); }
          15% { transform: rotate(-8deg) scale(1.02); }
          30% { transform: rotate(6deg) scale(1.02); }
          45% { transform: rotate(-6deg) scale(1.01); }
          60% { transform: rotate(4deg) scale(1.01); }
          75% { transform: rotate(-2deg) scale(1); }
        }
        @keyframes joeyExcitedBounce {
          0%, 100% { transform: scale(1.04) translateY(0); }
          50% { transform: scale(1.08) translateY(-2px); }
        }
        @keyframes joeyTalkPulse {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.015); }
        }
        @keyframes joeyTalkGlow {
          from { box-shadow: inset 0 0 10px rgba(0, 240, 255, 0.15); }
          to { box-shadow: inset 0 0 20px rgba(0, 240, 255, 0.3); }
        }
        @keyframes joeySparkle {
          0%, 100% { opacity: 0; transform: scale(0.5); }
          50% { opacity: 1; transform: scale(1.2); }
        }
        @keyframes joeyHandWave {
          0%, 100% { transform: rotate(0deg); }
          15% { transform: rotate(-20deg); }
          30% { transform: rotate(15deg); }
          45% { transform: rotate(-15deg); }
          60% { transform: rotate(10deg); }
          75% { transform: rotate(-5deg); }
        }
        @keyframes joeyWrenchTurn {
          0%, 100% { transform: rotate(0deg); }
          25% { transform: rotate(-15deg); }
          75% { transform: rotate(15deg); }
        }
        @keyframes joeyPointBounce {
          0%, 100% { transform: translateY(0); opacity: 0.7; }
          50% { transform: translateY(3px); opacity: 1; }
        }
        @keyframes joeyThinkDots {
          0%, 100% { opacity: 0.3; }
          50% { opacity: 1; }
        }
      `}</style>
    </div>
  );
};

export default JoeyAvatar;
