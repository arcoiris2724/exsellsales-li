import React, { useState } from 'react';
import { X, Phone, Calendar, Heart, ChevronLeft, ChevronRight, Gauge, Fuel, Settings2, Palette, Car, Hash } from 'lucide-react';
import { Vehicle } from '@/data/vehicles';

interface VehicleModalProps {
  vehicle: Vehicle;
  isFavorite: boolean;
  onToggleFavorite: (id: number) => void;
  onClose: () => void;
  onScheduleTestDrive: (vehicle: Vehicle) => void;
}

const VehicleModal: React.FC<VehicleModalProps> = ({
  vehicle,
  isFavorite,
  onToggleFavorite,
  onClose,
  onScheduleTestDrive,
}) => {
  const [currentImage, setCurrentImage] = useState(0);

  const allImages = vehicle.images.length > 0 ? vehicle.images : [vehicle.image];

  const nextImage = () => setCurrentImage((prev) => (prev + 1) % allImages.length);
  const prevImage = () => setCurrentImage((prev) => (prev - 1 + allImages.length) % allImages.length);

  const specs = [
    { icon: Gauge, label: 'Mileage', value: `${vehicle.mileage.toLocaleString()} mi`, color: 'text-neon-pink' },
    { icon: Settings2, label: 'Transmission', value: vehicle.transmission, color: 'text-neon-cyan' },
    { icon: Car, label: 'Drivetrain', value: vehicle.drivetrain, color: 'text-neon-green' },
    { icon: Fuel, label: 'Fuel Type', value: vehicle.fuelType, color: 'text-neon-orange' },
    { icon: Palette, label: 'Exterior', value: vehicle.exteriorColor, color: 'text-neon-purple' },
    { icon: Palette, label: 'Interior', value: vehicle.interiorColor, color: 'text-neon-yellow' },
    { icon: Settings2, label: 'Engine', value: vehicle.engine, color: 'text-neon-pink' },
    { icon: Hash, label: 'VIN', value: vehicle.vin, color: 'text-neon-cyan' },
  ];

  return (
    <div className="fixed inset-0 z-[100] flex items-start justify-center overflow-y-auto py-4 md:py-8 px-4">
      {/* Backdrop */}
      <div className="fixed inset-0 bg-black/80 backdrop-blur-sm" onClick={onClose} />

      {/* Modal */}
      <div className="relative w-full max-w-4xl bg-[#0a0a0a] rounded-2xl border border-white/10 shadow-2xl animate-slide-in">
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-2 bg-black/60 backdrop-blur-sm rounded-full text-gray-400 hover:text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Image gallery */}
        <div className="relative aspect-[16/9] rounded-t-2xl overflow-hidden">
          <img
            src={allImages[currentImage]}
            alt={`${vehicle.year} ${vehicle.make} ${vehicle.model}`}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-transparent to-transparent" />

          {allImages.length > 1 && (
            <>
              <button onClick={prevImage} className="absolute left-3 top-1/2 -translate-y-1/2 p-2 bg-black/50 backdrop-blur-sm rounded-full text-white hover:bg-black/70 transition-colors">
                <ChevronLeft className="w-5 h-5" />
              </button>
              <button onClick={nextImage} className="absolute right-3 top-1/2 -translate-y-1/2 p-2 bg-black/50 backdrop-blur-sm rounded-full text-white hover:bg-black/70 transition-colors">
                <ChevronRight className="w-5 h-5" />
              </button>
              <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
                {allImages.map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setCurrentImage(i)}
                    className={`w-2.5 h-2.5 rounded-full transition-colors ${i === currentImage ? 'bg-neon-pink' : 'bg-white/30'}`}
                  />
                ))}
              </div>
            </>
          )}
        </div>

        {/* Content */}
        <div className="p-6 md:p-8 space-y-6">
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
            <div>
              <h2 className="text-2xl md:text-3xl font-bold text-white">
                {vehicle.year} {vehicle.make} {vehicle.model}
              </h2>
              <p className="text-gray-400 text-lg">{vehicle.trim}</p>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => onToggleFavorite(vehicle.id)}
                className={`p-3 rounded-xl border transition-all ${
                  isFavorite
                    ? 'bg-neon-pink/10 border-neon-pink/40 text-neon-pink'
                    : 'border-white/10 text-gray-400 hover:text-neon-pink hover:border-neon-pink/30'
                }`}
              >
                <Heart className={`w-5 h-5 ${isFavorite ? 'fill-current' : ''}`} />
              </button>
              <div className="text-right">
                <div className="text-3xl font-display font-bold text-neon-orange">
                  ${vehicle.price.toLocaleString()}
                </div>
                <div className="text-xs text-gray-500">Cash / pre-approved funds</div>
              </div>
            </div>
          </div>

          {/* Description */}
          <p className="text-gray-400 leading-relaxed">{vehicle.description}</p>

          {/* Specs grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {specs.map((spec, i) => (
              <div key={i} className="p-3 bg-white/[0.03] rounded-xl border border-white/5">
                <div className="flex items-center gap-2 mb-1">
                  <spec.icon className={`w-4 h-4 ${spec.color}`} />
                  <span className="text-xs text-gray-500">{spec.label}</span>
                </div>
                <div className="text-sm text-white font-medium truncate">{spec.value}</div>
              </div>
            ))}
          </div>

          {/* Features */}
          <div>
            <h3 className="text-lg font-bold text-white mb-3">Key Features</h3>
            <div className="flex flex-wrap gap-2">
              {vehicle.features.map((feature, i) => (
                <span
                  key={i}
                  className="px-3 py-1.5 bg-white/[0.03] border border-white/5 rounded-full text-sm text-gray-300"
                >
                  {feature}
                </span>
              ))}
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex flex-col sm:flex-row gap-3 pt-2">
            <a
              href="tel:6313884426"
              className="flex-1 flex items-center justify-center gap-2 py-3.5 bg-gradient-to-r from-neon-pink to-neon-orange text-white font-bold rounded-xl hover:opacity-90 transition-opacity"
            >
              <Phone className="w-5 h-5" />
              Call About This Vehicle
            </a>
            <button
              onClick={() => onScheduleTestDrive(vehicle)}
              className="flex-1 flex items-center justify-center gap-2 py-3.5 border-2 border-neon-cyan/50 text-neon-cyan font-bold rounded-xl hover:bg-neon-cyan/10 transition-colors"
            >
              <Calendar className="w-5 h-5" />
              Schedule Test Drive
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VehicleModal;
