import React, { useState } from 'react';
import {
  Send, User, Mail, Phone, CheckCircle2, Loader2, AlertCircle,
  Car, Calendar, Gauge, Hash, Palette, FileText, RefreshCw, ShieldCheck,
  Camera, Move,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import {
  TradeInPhotoUploader,
  initialSlots,
  MIN_PHOTOS,
  MAX_PHOTOS,
  type PhotoSlot,
  type PhotoSlotKey,
} from './TradeInPhotoUploader';

/**
 * Dedicated Trade-In Valuation form (homepage section `#trade-in`).
 *
 * Submits to the `leads` table with lead_type='trade-in' and subject='trade-in',
 * uploads 2-6 customer photos of the vehicle to the `trade-in-photos` storage
 * bucket (per-lead folder), persists the public URLs into `leads.trade_in_photos`
 * (jsonb), then fires the lead-notify edge function so the dealer sees the
 * full trade-in summary in their inbox.
 *
 * The photo slot UI + EXIF auto-rotation + client-side compression live in
 * the sibling `TradeInPhotoUploader.tsx`.
 */

type Condition = 'excellent' | 'good' | 'fair' | 'poor';

const CONDITION_OPTIONS: Array<{
  value: Condition;
  label: string;
  description: string;
  color: string;
  border: string;
  bg: string;
}> = [
  {
    value: 'excellent',
    label: 'Excellent',
    description: 'Like new — no visible flaws, clean title, full service history.',
    color: 'text-neon-green',
    border: 'border-neon-green/40',
    bg: 'bg-neon-green/10',
  },
  {
    value: 'good',
    label: 'Good',
    description: 'Minor wear — small scratches/dings, runs great, well maintained.',
    color: 'text-neon-cyan',
    border: 'border-neon-cyan/40',
    bg: 'bg-neon-cyan/10',
  },
  {
    value: 'fair',
    label: 'Fair',
    description: 'Visible wear — paint/interior issues or needs minor repairs.',
    color: 'text-neon-orange',
    border: 'border-neon-orange/40',
    bg: 'bg-neon-orange/10',
  },
  {
    value: 'poor',
    label: 'Poor',
    description: 'Significant issues — mechanical, body damage, or salvage title.',
    color: 'text-neon-pink',
    border: 'border-neon-pink/40',
    bg: 'bg-neon-pink/10',
  },
];

interface UploadedPhoto {
  label: string;
  slot: PhotoSlotKey;
  url: string;
  path: string;
  size: number;
  uploaded_at: string;
  order: number;
}

const TradeInSection: React.FC = () => {
  // Vehicle details
  const [year, setYear] = useState('');
  const [make, setMake] = useState('');
  const [model, setModel] = useState('');
  const [trim, setTrim] = useState('');
  const [mileage, setMileage] = useState('');
  const [vin, setVin] = useState('');
  const [condition, setCondition] = useState<Condition>('good');
  const [exteriorColor, setExteriorColor] = useState('');
  const [interiorColor, setInteriorColor] = useState('');
  const [notes, setNotes] = useState('');

  // Contact info
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');

  // Photos (order matters — index 0 = most important shot per the customer)
  const [photos, setPhotos] = useState<PhotoSlot[]>(initialSlots);

  const [submitting, setSubmitting] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<{ done: number; total: number } | null>(null);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const photoCount = photos.filter((p) => p.status === 'ready' || p.status === 'done').length;

  const buildVehicleTitle = (): string => {
    const parts = [year.trim(), make.trim(), model.trim(), trim.trim()].filter(Boolean);
    return parts.join(' ');
  };

  const validate = (): string | null => {
    if (!year.trim() || !/^(19|20)\d{2}$/.test(year.trim())) return 'Please enter a valid 4-digit year (e.g. 2018).';
    if (!make.trim()) return 'Please enter the vehicle make (e.g. Toyota).';
    if (!model.trim()) return 'Please enter the vehicle model (e.g. Camry).';
    if (!mileage.trim() || !/^\d+$/.test(mileage.replace(/,/g, ''))) return 'Please enter mileage as a number.';
    if (vin.trim() && vin.trim().length !== 17) return 'VIN must be exactly 17 characters (or leave blank).';
    if (photoCount < MIN_PHOTOS) return `Please add at least ${MIN_PHOTOS} photos of your vehicle (you have ${photoCount}).`;
    if (!name.trim()) return 'Please enter your name.';
    if (!phone.trim() || phone.replace(/\D/g, '').length < 10) return 'Please enter a valid phone number.';
    if (email.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) return 'Please enter a valid email address.';
    return null;
  };

  const resetForm = () => {
    setYear('');
    setMake('');
    setModel('');
    setTrim('');
    setMileage('');
    setVin('');
    setCondition('good');
    setExteriorColor('');
    setInteriorColor('');
    setNotes('');
    setName('');
    setPhone('');
    setEmail('');
    setPhotos(initialSlots());
    setSubmitted(false);
    setError(null);
    setUploadProgress(null);
  };

  /**
   * Upload all "ready" photos to storage under `{leadId}/`, preserving the
   * customer's chosen order via a numeric prefix + an `order` field.
   */
  const uploadPhotos = async (leadId: number): Promise<UploadedPhoto[]> => {
    // Preserve the customer's drag-reordered sequence.
    const readyPhotos = photos
      .map((p, idx) => ({ p, idx }))
      .filter(({ p }) => p.status === 'ready' && p.file);

    if (readyPhotos.length === 0) return [];

    setUploadProgress({ done: 0, total: readyPhotos.length });
    const uploaded: UploadedPhoto[] = [];
    let doneCount = 0;

    for (const { p: photo, idx } of readyPhotos) {
      setPhotos((prev) => prev.map((slot) =>
        slot.key === photo.key ? { ...slot, status: 'uploading' } : slot
      ));

      try {
        const ts = Date.now();
        const orderPrefix = String(idx + 1).padStart(2, '0');
        const path = `${leadId}/${orderPrefix}-${photo.key}-${ts}.jpg`;

        const { error: uploadError } = await supabase.storage
          .from('trade-in-photos')
          .upload(path, photo.file as File, {
            cacheControl: '3600',
            upsert: false,
            contentType: 'image/jpeg',
          });

        if (uploadError) throw uploadError;

        const { data: urlData } = supabase.storage
          .from('trade-in-photos')
          .getPublicUrl(path);

        const publicUrl = urlData.publicUrl;

        uploaded.push({
          label: photo.label,
          slot: photo.key,
          url: publicUrl,
          path,
          size: photo.compressedSize,
          uploaded_at: new Date().toISOString(),
          order: idx + 1,
        });

        setPhotos((prev) => prev.map((slot) =>
          slot.key === photo.key ? { ...slot, status: 'done', publicUrl } : slot
        ));
      } catch (uploadErr: any) {
        console.error(`Failed to upload photo ${photo.key}:`, uploadErr);
        setPhotos((prev) => prev.map((slot) =>
          slot.key === photo.key
            ? { ...slot, status: 'error', errorMessage: uploadErr?.message || 'Upload failed.' }
            : slot
        ));
        // continue — partial uploads are better than dropping the whole submission
      }

      doneCount += 1;
      setUploadProgress({ done: doneCount, total: readyPhotos.length });
    }

    return uploaded;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const err = validate();
    if (err) {
      setError(err);
      return;
    }
    setError(null);
    setSubmitting(true);

    const vehicleTitle = buildVehicleTitle();
    const conditionLabel = CONDITION_OPTIONS.find((c) => c.value === condition)?.label || condition;
    const cleanMileage = mileage.replace(/,/g, '');

    const baseSummary = [
      `TRADE-IN VALUATION REQUEST`,
      ``,
      `Vehicle: ${vehicleTitle}`,
      `Mileage: ${Number(cleanMileage).toLocaleString()} mi`,
      vin.trim() ? `VIN: ${vin.trim().toUpperCase()}` : null,
      `Condition: ${conditionLabel}`,
      exteriorColor.trim() ? `Exterior color: ${exteriorColor.trim()}` : null,
      interiorColor.trim() ? `Interior color: ${interiorColor.trim()}` : null,
      ``,
      notes.trim() ? `Customer notes:\n${notes.trim()}` : null,
    ].filter(Boolean).join('\n');

    try {
      const { data: insertData, error: insertError } = await supabase
        .from('leads')
        .insert({
          name: name.trim(),
          email: email.trim() || null,
          phone: phone.trim(),
          subject: 'trade-in',
          message: baseSummary,
          vehicle_interest: vehicleTitle,
          lead_type: 'trade-in',
          status: 'new',
          trade_in_photos: [],
        })
        .select()
        .single();

      if (insertError) throw insertError;
      const leadId: number = insertData.id;

      const uploadedPhotos = await uploadPhotos(leadId);

      let finalMessage = baseSummary;
      if (uploadedPhotos.length > 0) {
        finalMessage =
          baseSummary +
          `\n\nAttached photos (${uploadedPhotos.length}, in customer's preferred order):\n` +
          uploadedPhotos
            .map((p) => `${p.order}. ${p.label}: ${p.url}`)
            .join('\n');

        await supabase
          .from('leads')
          .update({
            trade_in_photos: uploadedPhotos,
            message: finalMessage,
          })
          .eq('id', leadId);
      }

      try {
        await supabase.functions.invoke('lead-notify', {
          body: {
            lead_id: leadId,
            name: name.trim(),
            email: email.trim() || null,
            phone: phone.trim(),
            message: finalMessage,
            vehicle_id: null,
            vehicle_title: `Trade-In: ${vehicleTitle}`,
            vehicle_price: null,
            vehicle_url: `${window.location.origin}/#trade-in`,
            source: 'trade_in_form',
            trade_in_photos: uploadedPhotos,
          },
        });
      } catch (notifyErr) {
        console.warn('lead-notify invoke failed (trade-in lead still saved):', notifyErr);
      }

      if (email.trim()) {
        try {
          await fetch('https://famous.ai/api/crm/69c07f5eedda49fd18b3c790/subscribe', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              email: email.trim(),
              name: name.trim(),
              source: 'trade-in',
              tags: ['trade-in', 'lead'],
            }),
          });
        } catch {}
      }

      setSubmitted(true);
    } catch (dbErr: any) {
      console.error('Failed to submit trade-in lead:', dbErr);
      setError(dbErr?.message || 'Something went wrong. Please call (631) 388-4426 instead.');
    } finally {
      setSubmitting(false);
      setUploadProgress(null);
    }
  };

  return (
    <section id="trade-in" className="py-20 px-4 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-neon-orange/[0.03] to-transparent" />

      <div className="relative max-w-5xl mx-auto">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-neon-orange/10 border border-neon-orange/30 rounded-full text-neon-orange text-xs font-bold uppercase tracking-wider mb-4">
            <RefreshCw className="w-3.5 h-3.5" />
            Trade-In Valuation
          </div>
          <h2 className="text-3xl md:text-5xl font-black text-white mb-4">
            Trade In Your <span className="gradient-text-neon">Current Ride</span>
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Tell us about your vehicle, add a few photos, and we'll come back with a fair, no-pressure trade-in offer —
            usually within the same business day. No fees. No obligation.
          </p>

          <div className="mt-6 flex flex-wrap items-center justify-center gap-3 text-xs">
            <span className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white/[0.03] border border-white/10 rounded-full text-gray-300">
              <ShieldCheck className="w-3.5 h-3.5 text-neon-green" />
              No-pressure appraisal
            </span>
            <span className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white/[0.03] border border-white/10 rounded-full text-gray-300">
              <Phone className="w-3.5 h-3.5 text-neon-cyan" />
              Same-day callback
            </span>
            <span className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white/[0.03] border border-white/10 rounded-full text-gray-300">
              <Car className="w-3.5 h-3.5 text-neon-pink" />
              Apply value toward any inventory vehicle
            </span>
          </div>
        </div>

        {submitted ? (
          <div className="p-8 md:p-10 bg-gradient-to-br from-neon-green/10 via-neon-cyan/5 to-transparent rounded-2xl border border-neon-green/30">
            <div className="flex items-start gap-4">
              <div className="w-14 h-14 bg-neon-green/20 rounded-full flex items-center justify-center flex-shrink-0">
                <CheckCircle2 className="w-7 h-7 text-neon-green" />
              </div>
              <div className="flex-1">
                <h3 className="text-2xl font-bold text-white mb-2">Trade-In Request Received</h3>
                <p className="text-gray-300 text-sm leading-relaxed">
                  Thanks <span className="text-neon-green font-semibold">{name.split(' ')[0] || 'there'}</span>!
                  We got the details on your <span className="text-neon-orange font-semibold">{buildVehicleTitle()}</span>{' '}
                  along with <span className="text-neon-cyan font-semibold">{photos.filter((p) => p.status === 'done').length} photo{photos.filter((p) => p.status === 'done').length === 1 ? '' : 's'}</span>.
                  A member of the Ex$ell Sales team will reach out to you at{' '}
                  <span className="text-white font-mono">{phone}</span> with a preliminary valuation —
                  usually within the same business day.
                </p>
                <div className="mt-5 flex flex-wrap gap-2">
                  <a
                    href="tel:6313884426"
                    className="inline-flex items-center gap-2 px-4 py-2.5 bg-neon-green/10 border border-neon-green/30 text-neon-green text-sm font-semibold rounded-lg hover:bg-neon-green/20 transition-colors"
                  >
                    <Phone className="w-4 h-4" />
                    Call (631) 388-4426
                  </a>
                  <button
                    onClick={resetForm}
                    className="inline-flex items-center gap-2 px-4 py-2.5 border border-white/10 text-gray-400 text-sm rounded-lg hover:text-white hover:border-white/30 transition-colors"
                  >
                    Submit another trade-in
                  </button>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <form
            onSubmit={handleSubmit}
            className="p-6 md:p-10 bg-gradient-to-br from-neon-cyan/5 via-neon-pink/5 to-transparent rounded-2xl border border-neon-orange/20"
          >
            {/* SECTION: Vehicle */}
            <div className="mb-8">
              <h3 className="flex items-center gap-2 text-sm font-bold text-neon-orange uppercase tracking-wider mb-4">
                <Car className="w-4 h-4" />
                Your Vehicle
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
                <FieldWrap label="Year" required icon={Calendar} className="md:col-span-3">
                  <input
                    type="text"
                    inputMode="numeric"
                    value={year}
                    onChange={(e) => setYear(e.target.value.replace(/\D/g, '').slice(0, 4))}
                    placeholder="2018"
                    className="form-input-tradein"
                    required
                  />
                </FieldWrap>

                <FieldWrap label="Make" required icon={Car} className="md:col-span-3">
                  <input
                    type="text"
                    value={make}
                    onChange={(e) => setMake(e.target.value)}
                    placeholder="Toyota"
                    className="form-input-tradein"
                    required
                  />
                </FieldWrap>

                <FieldWrap label="Model" required icon={Car} className="md:col-span-3">
                  <input
                    type="text"
                    value={model}
                    onChange={(e) => setModel(e.target.value)}
                    placeholder="Camry"
                    className="form-input-tradein"
                    required
                  />
                </FieldWrap>

                <FieldWrap label="Trim" icon={Car} className="md:col-span-3">
                  <input
                    type="text"
                    value={trim}
                    onChange={(e) => setTrim(e.target.value)}
                    placeholder="SE / XLE / Limited"
                    className="form-input-tradein"
                  />
                </FieldWrap>

                <FieldWrap label="Mileage" required icon={Gauge} className="md:col-span-4">
                  <input
                    type="text"
                    inputMode="numeric"
                    value={mileage}
                    onChange={(e) => setMileage(e.target.value.replace(/[^\d,]/g, ''))}
                    placeholder="68,500"
                    className="form-input-tradein"
                    required
                  />
                </FieldWrap>

                <FieldWrap label="VIN" hint="optional" icon={Hash} className="md:col-span-8">
                  <input
                    type="text"
                    value={vin}
                    onChange={(e) => setVin(e.target.value.toUpperCase().replace(/[^A-HJ-NPR-Z0-9]/g, '').slice(0, 17))}
                    placeholder="17-character VIN (helps us give a more accurate quote)"
                    className="form-input-tradein font-mono tracking-wider"
                  />
                </FieldWrap>

                <FieldWrap label="Exterior Color" icon={Palette} className="md:col-span-6">
                  <input
                    type="text"
                    value={exteriorColor}
                    onChange={(e) => setExteriorColor(e.target.value)}
                    placeholder="Pearl White"
                    className="form-input-tradein"
                  />
                </FieldWrap>

                <FieldWrap label="Interior Color" icon={Palette} className="md:col-span-6">
                  <input
                    type="text"
                    value={interiorColor}
                    onChange={(e) => setInteriorColor(e.target.value)}
                    placeholder="Black Leather"
                    className="form-input-tradein"
                  />
                </FieldWrap>
              </div>
            </div>

            {/* SECTION: Condition */}
            <div className="mb-8">
              <h3 className="flex items-center gap-2 text-sm font-bold text-neon-orange uppercase tracking-wider mb-4">
                <ShieldCheck className="w-4 h-4" />
                Overall Condition <span className="text-neon-pink">*</span>
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                {CONDITION_OPTIONS.map((opt) => {
                  const isActive = condition === opt.value;
                  return (
                    <label
                      key={opt.value}
                      className={`relative cursor-pointer p-4 rounded-xl border-2 transition-all ${
                        isActive
                          ? `${opt.bg} ${opt.border}`
                          : 'bg-white/[0.02] border-white/10 hover:border-white/20'
                      }`}
                    >
                      <input
                        type="radio"
                        name="condition"
                        value={opt.value}
                        checked={isActive}
                        onChange={() => setCondition(opt.value)}
                        className="sr-only"
                      />
                      <div className="flex items-center justify-between mb-1.5">
                        <span className={`font-bold text-sm ${isActive ? opt.color : 'text-white'}`}>
                          {opt.label}
                        </span>
                        <div
                          className={`w-4 h-4 rounded-full border-2 flex items-center justify-center transition-all ${
                            isActive ? `${opt.border} ${opt.bg}` : 'border-white/20'
                          }`}
                        >
                          {isActive && <div className={`w-1.5 h-1.5 rounded-full ${opt.color.replace('text-', 'bg-')}`} />}
                        </div>
                      </div>
                      <p className="text-[11px] text-gray-400 leading-snug">{opt.description}</p>
                    </label>
                  );
                })}
              </div>
            </div>

            {/* SECTION: Photos */}
            <div className="mb-8">
              <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
                <h3 className="flex items-center gap-2 text-sm font-bold text-neon-orange uppercase tracking-wider">
                  <Camera className="w-4 h-4" />
                  Photos <span className="text-neon-pink">*</span>
                  <span className="text-gray-500 normal-case font-normal text-xs ml-1">
                    ({photoCount}/{MAX_PHOTOS} added · min {MIN_PHOTOS})
                  </span>
                </h3>
                <span className="inline-flex items-center gap-1.5 text-[11px] text-gray-500">
                  <Move className="w-3 h-3" />
                  Drag tiles to reorder · #1 is your hero shot
                </span>
              </div>

              <TradeInPhotoUploader
                photos={photos}
                onPhotosChange={setPhotos}
                disabled={submitting}
              />

              <p className="mt-3 text-xs text-gray-500 flex items-start gap-1.5">
                <AlertCircle className="w-3 h-3 text-neon-orange flex-shrink-0 mt-0.5" />
                <span>
                  Add at least {MIN_PHOTOS} photos. Photos are auto-rotated (no more sideways iPhone
                  shots) and compressed in your browser before upload.
                </span>
              </p>
            </div>

            {/* SECTION: Notes */}
            <div className="mb-8">
              <FieldWrap label="Additional Notes" hint="optional" icon={FileText} multiline>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={4}
                  placeholder="Anything we should know? Accidents, modifications, recent service, outstanding loan/lien, tire condition, etc."
                  className="form-input-tradein resize-none"
                />
              </FieldWrap>
            </div>

            {/* SECTION: Contact */}
            <div className="mb-6 pt-6 border-t border-white/5">
              <h3 className="flex items-center gap-2 text-sm font-bold text-neon-orange uppercase tracking-wider mb-4">
                <User className="w-4 h-4" />
                Your Contact Info
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FieldWrap label="Full Name" required icon={User}>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Jane Smith"
                    className="form-input-tradein"
                    required
                  />
                </FieldWrap>

                <FieldWrap label="Phone" required icon={Phone}>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="(631) 555-0123"
                    className="form-input-tradein"
                    required
                  />
                </FieldWrap>

                <FieldWrap label="Email" hint="optional" icon={Mail} className="md:col-span-2">
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="jane@example.com"
                    className="form-input-tradein"
                  />
                </FieldWrap>
              </div>
            </div>

            {error && (
              <div className="flex items-center gap-2 p-3 mb-4 bg-red-500/10 border border-red-500/30 rounded-lg text-red-400 text-sm">
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {uploadProgress && (
              <div className="flex items-center gap-2 p-3 mb-4 bg-neon-cyan/10 border border-neon-cyan/30 rounded-lg text-neon-cyan text-sm">
                <Loader2 className="w-4 h-4 flex-shrink-0 animate-spin" />
                <span>Uploading photos… {uploadProgress.done}/{uploadProgress.total}</span>
              </div>
            )}

            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
              <button
                type="submit"
                disabled={submitting}
                className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-8 py-3.5 bg-gradient-to-r from-neon-pink to-neon-orange text-white font-bold rounded-xl hover:opacity-90 transition-opacity disabled:opacity-60 disabled:cursor-not-allowed neon-pulse"
              >
                {submitting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    {uploadProgress ? 'Uploading…' : 'Sending…'}
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4" />
                    Request Trade-In Quote
                  </>
                )}
              </button>
              <p className="text-xs text-gray-500 leading-relaxed">
                By submitting you agree to be contacted about your trade-in. We never share your info.
                Final value subject to in-person inspection.
              </p>
            </div>
          </form>
        )}
      </div>

      {/* Local input styling — reuses neon palette */}
      <style>{`
        .form-input-tradein {
          width: 100%;
          padding-left: 2.5rem;
          padding-right: 0.75rem;
          padding-top: 0.625rem;
          padding-bottom: 0.625rem;
          background-color: rgba(0,0,0,0.4);
          border: 1px solid rgba(255,255,255,0.1);
          border-radius: 0.5rem;
          color: white;
          font-size: 0.875rem;
        }
        .form-input-tradein::placeholder { color: rgba(255,255,255,0.25); }
        .form-input-tradein:focus { outline: none; border-color: rgb(255,128,0); }
        textarea.form-input-tradein { padding-top: 0.75rem; }
      `}</style>
    </section>
  );
};

const FieldWrap: React.FC<{
  label: string;
  icon: React.ElementType;
  required?: boolean;
  hint?: string;
  multiline?: boolean;
  className?: string;
  children: React.ReactNode;
}> = ({ label, icon: Icon, required, hint, multiline, className, children }) => (
  <div className={className}>
    <label className="block text-xs font-semibold text-gray-400 mb-1.5 uppercase tracking-wider">
      {label}
      {required && <span className="text-neon-pink"> *</span>}
      {hint && <span className="text-gray-600 normal-case font-normal"> ({hint})</span>}
    </label>
    <div className="relative">
      <Icon className={`absolute left-3 ${multiline ? 'top-3' : 'top-1/2 -translate-y-1/2'} w-4 h-4 text-gray-500 pointer-events-none`} />
      {children}
    </div>
  </div>
);

export default TradeInSection;
