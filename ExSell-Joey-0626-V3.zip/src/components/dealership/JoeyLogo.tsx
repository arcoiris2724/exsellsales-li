import React from 'react';

const MASTER_LOGO = 'https://d64gsuwffb70l.cloudfront.net/6917af11eb66b8b0c2b0bc86_1774223659449_0339845b.jpg';

interface JoeyLogoProps {
  size?: number;
  className?: string;
  showGlow?: boolean;
}

/**
 * Joey logo / brand mark using the original master character image.
 * Wrapped with neon glow ring and animated effects.
 */
const JoeyLogo: React.FC<JoeyLogoProps> = ({ size = 56, className = '', showGlow = true }) => {
  return (
    <div
      className={`relative flex-shrink-0 ${className}`}
      style={{ width: size, height: size }}
    >
      {/* Animated neon glow ring */}
      {showGlow && (
        <div
          className="absolute -inset-[3px] rounded-full"
          style={{
            background: 'conic-gradient(from 0deg, #FF0080, #FF8C00, #BFFF00, #00F0FF, #FF0080)',
            animation: 'joeyLogoRingSpin 6s linear infinite',
            filter: 'blur(3px)',
            opacity: 0.6,
          }}
        />
      )}

      {/* Inner border ring */}
      <div
        className="absolute inset-0 rounded-full"
        style={{
          border: '2px solid rgba(255, 255, 255, 0.15)',
          boxShadow: showGlow
            ? '0 0 15px rgba(255, 0, 128, 0.3), 0 0 30px rgba(0, 240, 255, 0.15), inset 0 0 10px rgba(0, 0, 0, 0.5)'
            : '0 0 10px rgba(0, 0, 0, 0.3)',
        }}
      />

      {/* Master logo image */}
      <img
        src={MASTER_LOGO}
        alt="Joey — Ex$ell mascot"
        className="relative w-full h-full rounded-full object-cover"
        style={{
          filter: showGlow ? 'brightness(1.05) contrast(1.05)' : undefined,
        }}
        draggable={false}
      />

      {/* Subtle shine overlay */}
      <div
        className="absolute inset-0 rounded-full pointer-events-none"
        style={{
          background: 'linear-gradient(135deg, rgba(255,255,255,0.12) 0%, transparent 50%, rgba(0,0,0,0.15) 100%)',
        }}
      />

      <style>{`
        @keyframes joeyLogoRingSpin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
};

export default JoeyLogo;
