import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Star, ChevronLeft, ChevronRight, Quote, ArrowRight } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { DEFAULT_TESTIMONIALS, HOMEPAGE_SECTIONS } from '@/data/homepageDefaults';
import type { TestimonialsSectionContent } from '@/data/homepageDefaults';
import { useGoogleReviews } from '@/hooks/useGoogleReviews';
import GoogleReviewBadge from './GoogleReviewBadge';

const TestimonialsSection: React.FC = () => {
  const [content, setContent] = useState<TestimonialsSectionContent>(DEFAULT_TESTIMONIALS);
  const [currentIndex, setCurrentIndex] = useState(0);

  // Live Google rating → overrides the static overallRating/reviewCount when available.
  const { rating: liveRating, userRatingCount: liveCount } = useGoogleReviews();


  useEffect(() => {
    let cancelled = false;
    supabase.from('site_content').select('content').eq('section', HOMEPAGE_SECTIONS.testimonials).single()
      .then(({ data }) => {
        if (!cancelled && data?.content) setContent(data.content as TestimonialsSectionContent);
      });
    return () => { cancelled = true; };
  }, []);

  const visibleCount = typeof window !== 'undefined' && window.innerWidth >= 1024 ? 3 : typeof window !== 'undefined' && window.innerWidth >= 768 ? 2 : 1;

  const testimonials = content.testimonials;

  const next = () => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length);
  };

  const prev = () => {
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  const getVisibleTestimonials = () => {
    const result = [];
    for (let i = 0; i < Math.min(visibleCount, testimonials.length); i++) {
      result.push(testimonials[(currentIndex + i) % testimonials.length]);
    }
    return result;
  };

  return (
    <section id="reviews" className="py-20 px-4 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-neon-cyan/[0.02] to-transparent" />

      <div className="relative max-w-7xl mx-auto">
        <div className="text-center mb-14">
          <h2 className="text-3xl md:text-5xl font-black text-white mb-4">
            {content.title} <span className="gradient-text-neon">{content.titleHighlight}</span> Say
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            {content.subtitle}
          </p>
          <div className="flex items-center justify-center gap-2 mt-4">
            <div className="flex gap-0.5">
              {[1, 2, 3, 4, 5].map((s) => (
                <Star key={s} className="w-5 h-5 text-neon-orange fill-neon-orange" />
              ))}
            </div>
            <span className="text-white font-bold">
              {liveRating != null ? liveRating.toFixed(1) : content.overallRating}
            </span>
            <span className="text-gray-500">
              based on{' '}
              {liveCount != null ? liveCount.toLocaleString() : content.reviewCount} reviews
            </span>
          </div>

          {/* Live Google badge — links to /reviews, hides until Place ID + data are ready */}
          <div className="flex justify-center mt-4">
            <GoogleReviewBadge variant="pill" />
          </div>
        </div>


        {/* Testimonials carousel */}
        <div className="relative">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {getVisibleTestimonials().map((testimonial, i) => (
              <div
                key={`${currentIndex}-${i}`}
                className="p-6 bg-white/[0.02] rounded-xl border border-white/5 hover:border-neon-orange/20 transition-all duration-300 animate-fade-in"
              >
                <Quote className="w-8 h-8 text-neon-orange/30 mb-4" />

                {/* Stars */}
                <div className="flex gap-0.5 mb-4">
                  {Array.from({ length: testimonial.rating }).map((_, s) => (
                    <Star key={s} className="w-4 h-4 text-neon-orange fill-neon-orange" />
                  ))}
                </div>

                {/* Text */}
                <p className="text-gray-300 leading-relaxed mb-6 text-sm">
                  "{testimonial.text}"
                </p>

                {/* Author */}
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-white font-bold">{testimonial.name}</div>
                    <div className="text-gray-500 text-xs">{testimonial.location}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-neon-cyan text-xs font-medium">Purchased</div>
                    <div className="text-gray-400 text-xs">{testimonial.vehicle}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Navigation */}
          <div className="flex items-center justify-center gap-4 mt-8">
            <button onClick={prev}
              className="p-2 bg-white/[0.03] border border-white/10 rounded-full text-gray-400 hover:text-white hover:border-white/20 transition-colors">
              <ChevronLeft className="w-5 h-5" />
            </button>
            <div className="flex gap-2">
              {testimonials.map((_, i) => (
                <button key={i} onClick={() => setCurrentIndex(i)}
                  className={`w-2 h-2 rounded-full transition-colors ${i === currentIndex ? 'bg-neon-orange' : 'bg-white/20'}`} />
              ))}
            </div>
            <button onClick={next}
              className="p-2 bg-white/[0.03] border border-white/10 rounded-full text-gray-400 hover:text-white hover:border-white/20 transition-colors">
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>

          {/* See All Reviews CTA */}
          <div className="text-center mt-8">
            <Link to="/reviews"
              className="inline-flex items-center gap-2 px-6 py-3 border border-neon-orange/30 text-neon-orange font-semibold text-sm rounded-lg hover:bg-neon-orange/10 hover:border-neon-orange/50 transition-all group">
              See All Customer Reviews
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
