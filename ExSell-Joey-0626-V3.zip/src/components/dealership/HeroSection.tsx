import React, { useState, useEffect } from 'react';
import { ChevronDown, Shield, Award, Handshake, Star, Heart, Gem, TrendingUp, TrendingDown, Clock, Building2, Sparkles, Eye, Target, ThumbsUp, Wrench, FileCheck, Truck, ShieldCheck, Users, CheckCircle, Phone, Mail, MapPin, DollarSign, Zap, Car } from 'lucide-react';
import { Vehicle, fetchVehicles } from '@/data/vehicles';
import HeroCarousel from './HeroCarousel';
import CarCloud from './CarCloud';
import GoogleReviewBadge from './GoogleReviewBadge';
import { supabase } from '@/lib/supabase';
import { DEFAULT_HERO_SECTION, HOMEPAGE_SECTIONS } from '@/data/homepageDefaults';
import type { HeroSectionContent } from '@/data/homepageDefaults';

const LOGO_URL = 'https://d64gsuwffb70l.cloudfront.net/6917af11eb66b8b0c2b0bc86_1774223659449_0339845b.jpg';


// Icon resolver
const iconMap: Record<string, React.ElementType> = {
  Shield, Award, Handshake, Star, Heart, Gem, TrendingUp, TrendingDown, Clock, Building2,
  Sparkles, Eye, Target, ThumbsUp, Wrench, FileCheck, Truck, ShieldCheck, Users, CheckCircle,
  Phone, Mail, MapPin, DollarSign, Zap, Car,
};

const HeroSection: React.FC = () => {
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [heroMode, setHeroMode] = useState<'carousel' | 'cloud'>('carousel');
  const [content, setContent] = useState<HeroSectionContent>(DEFAULT_HERO_SECTION);

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      try {
        const [vehicleData, contentData] = await Promise.all([
          fetchVehicles(),
          supabase.from('site_content').select('content').eq('section', HOMEPAGE_SECTIONS.hero).single(),
        ]);
        if (!cancelled) {
          setVehicles(vehicleData);
          if (contentData.data?.content) {
            setContent(contentData.data.content as HeroSectionContent);
          }
        }
      } catch {}
    };
    load();
    return () => { cancelled = true; };
  }, []);

  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  const availableVehicles = vehicles.filter(v => v.status !== 'sold');
  const featuredVehicles = availableVehicles.filter(v => v.image).slice(0, 5);

  return (
    <section id="hero" className="relative min-h-[95vh] flex items-center overflow-hidden">
      {/* Background effects */}
      <div className="absolute inset-0 bg-black">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-neon-pink/20 rounded-full blur-[120px] animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-neon-cyan/15 rounded-full blur-[120px] animate-pulse" style={{ animationDelay: '1s' }} />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-neon-orange/10 rounded-full blur-[150px]" />
        <div className="absolute inset-0 opacity-[0.03]" style={{ backgroundImage: 'linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)', backgroundSize: '60px 60px' }} />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 w-full">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-8 items-center">
          {/* Left content */}
          <div className="space-y-8">
            <div className="flex flex-wrap items-center gap-3">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-neon-green/10 border border-neon-green/30 rounded-full">
                <span className="w-2 h-2 bg-neon-green rounded-full animate-pulse" />
                <span className="text-neon-green text-sm font-semibold">{content.badgeText}</span>
              </div>
              {/* Live Google rating badge — hides until a real Place ID + data are available */}
              <GoogleReviewBadge variant="pill" />
            </div>


            <h1 className="text-5xl md:text-6xl lg:text-7xl font-black leading-[0.95] tracking-tight">
              {content.headlineLines.map((line, i) => (
                <React.Fragment key={i}>
                  {i > 0 && <br />}
                  <span className={i === 1 ? 'gradient-text-neon' : 'text-white'}>{line}</span>
                </React.Fragment>
              ))}
            </h1>

            <p className="text-lg md:text-xl text-gray-400 max-w-lg leading-relaxed">
              {content.subtitle}
            </p>

            <div className="flex flex-col sm:flex-row gap-4">
              <button onClick={() => scrollTo('inventory')}
                className="px-8 py-4 bg-gradient-to-r from-neon-pink via-neon-orange to-neon-pink bg-[length:200%_100%] hover:bg-right text-white font-bold text-lg rounded-xl neon-pulse transition-all duration-500 transform hover:scale-105">
                {content.ctaPrimary}
              </button>
              <button onClick={() => scrollTo('contact')}
                className="px-8 py-4 border-2 border-neon-cyan/50 text-neon-cyan font-bold text-lg rounded-xl hover:bg-neon-cyan/10 hover:border-neon-cyan transition-all duration-300 transform hover:scale-105">
                {content.ctaSecondary}
              </button>
            </div>

            {/* Trust badges */}
            <div className="flex flex-wrap gap-6 pt-4">
              {content.trustBadges.map((badge, i) => {
                const IconComp = iconMap[badge.icon] || Shield;
                const colors = ['text-neon-green', 'text-neon-orange', 'text-neon-cyan', 'text-neon-pink', 'text-neon-purple'];
                return (
                  <div key={i} className="flex items-center gap-2 text-gray-400">
                    <IconComp className={`w-5 h-5 ${colors[i % colors.length]}`} />
                    <span className="text-sm font-medium">{badge.text}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right - Dynamic Featured Vehicles Showcase */}
          <div className="hidden lg:block">
            {featuredVehicles.length > 0 ? (
              <div className="space-y-4">
                <div className="flex items-center justify-end gap-2">
                  <button onClick={() => setHeroMode('carousel')}
                    className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all ${heroMode === 'carousel' ? 'bg-neon-pink/20 border border-neon-pink/40 text-neon-pink' : 'border border-white/10 text-gray-500 hover:text-gray-300 hover:border-white/20'}`}>
                    Featured Cars
                  </button>
                  <button onClick={() => setHeroMode('cloud')}
                    className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all ${heroMode === 'cloud' ? 'bg-neon-cyan/20 border border-neon-cyan/40 text-neon-cyan' : 'border border-white/10 text-gray-500 hover:text-gray-300 hover:border-white/20'}`}>
                    Car Cloud
                  </button>
                </div>
                {heroMode === 'carousel' ? (
                  <HeroCarousel vehicles={vehicles} />
                ) : (
                  <div className="relative rounded-2xl overflow-hidden border border-white/10 bg-black/40 backdrop-blur-sm" style={{ minHeight: '400px' }}>
                    <CarCloud vehicles={vehicles} />
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center justify-center">
                <div className="relative group">
                  <div className="absolute -inset-12 rounded-[2.5rem] bg-gradient-to-br from-neon-pink/20 via-neon-orange/15 to-neon-cyan/20 blur-3xl animate-pulse opacity-80" />
                  <div className="absolute -inset-8 rounded-[2rem] bg-gradient-to-tr from-neon-orange/25 via-neon-pink/20 to-neon-cyan/25 blur-2xl opacity-70" style={{ animationDelay: '0.5s' }} />
                  <div className="absolute -inset-4 rounded-3xl bg-gradient-to-br from-neon-pink/30 via-neon-orange/25 to-neon-cyan/30 blur-xl opacity-90" />
                  <div className="absolute -inset-2 rounded-3xl bg-gradient-to-br from-neon-pink via-neon-orange to-neon-cyan p-[2px]">
                    <div className="w-full h-full rounded-3xl bg-black" />
                  </div>
                  <img src={LOGO_URL} alt="Ex$ell Car Sales" className="relative w-[550px] h-auto rounded-3xl shadow-2xl shadow-neon-pink/20 animate-float z-10" />
                  <div className="absolute -top-3 -left-3 w-6 h-6 bg-neon-pink rounded-full blur-sm animate-pulse z-20" />
                  <div className="absolute -top-3 -right-3 w-6 h-6 bg-neon-orange rounded-full blur-sm animate-pulse z-20" style={{ animationDelay: '0.3s' }} />
                  <div className="absolute -bottom-3 -left-3 w-6 h-6 bg-neon-cyan rounded-full blur-sm animate-pulse z-20" style={{ animationDelay: '0.6s' }} />
                  <div className="absolute -bottom-3 -right-3 w-6 h-6 bg-neon-green rounded-full blur-sm animate-pulse z-20" style={{ animationDelay: '0.9s' }} />
                </div>
              </div>
            )}
          </div>

          {/* Mobile logo */}
          <div className="lg:hidden flex justify-center -mt-2 mb-4">
            <div className="relative">
              <div className="absolute -inset-6 rounded-2xl bg-gradient-to-br from-neon-pink/25 via-neon-orange/20 to-neon-cyan/25 blur-2xl opacity-80" />
              <div className="absolute -inset-1 rounded-2xl bg-gradient-to-br from-neon-pink via-neon-orange to-neon-cyan p-[2px]">
                <div className="w-full h-full rounded-2xl bg-black" />
              </div>
              <img src={LOGO_URL} alt="Ex$ell Car Sales" className="relative w-72 sm:w-80 h-auto rounded-2xl shadow-xl shadow-neon-pink/15 z-10" />
            </div>
          </div>
        </div>

        {/* Stats bar */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-4">
          {content.stats.map((stat, i) => (
            <div key={i} className="text-center p-4 bg-white/[0.03] backdrop-blur-sm rounded-xl border border-white/5 hover:border-white/10 transition-colors">
              <div className={`text-2xl md:text-3xl font-display font-bold ${stat.color}`}>{stat.value}</div>
              <div className="text-gray-500 text-sm mt-1 font-medium">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Scroll indicator */}
      <button onClick={() => scrollTo('inventory')} className="absolute bottom-8 left-1/2 -translate-x-1/2 text-gray-500 hover:text-neon-cyan transition-colors animate-bounce">
        <ChevronDown className="w-8 h-8" />
      </button>
    </section>
  );
};

export default HeroSection;
