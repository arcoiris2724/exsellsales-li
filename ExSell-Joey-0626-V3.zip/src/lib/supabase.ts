import { createClient } from '@supabase/supabase-js';


// Initialize database client
export const supabaseUrl = 'https://kikohjhgiikomczgbvou.databasepad.com';
export const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImMzYzc2NjgwLTMwNTQtNGNhZS05ZDRhLTUxOWM1YWRkNzZlNSJ9.eyJwcm9qZWN0SWQiOiJraWtvaGpoZ2lpa29tY3pnYnZvdSIsInJvbGUiOiJhbm9uIiwiaWF0IjoxNzc0MjIzNzUyLCJleHAiOjIwODk1ODM3NTIsImlzcyI6ImZhbW91cy5kYXRhYmFzZXBhZCIsImF1ZCI6ImZhbW91cy5jbGllbnRzIn0.8iWgGXmFDFB9QOtjKsyMYWcH4pIHXRboacUfZDhaKfY';
const supabase = createClient(supabaseUrl, supabaseKey, {
  realtime: {
    params: {
      eventsPerSecond: 2,
    },
  },
  // Disable automatic realtime connection to prevent binary decode errors
  global: {
    headers: {},
  },
});

// Disconnect realtime on init to prevent background WebSocket errors
// Realtime will only connect when explicitly subscribed to channels
try {
  supabase.realtime.disconnect();
} catch {
  // Ignore if already disconnected
}

export { supabase };
