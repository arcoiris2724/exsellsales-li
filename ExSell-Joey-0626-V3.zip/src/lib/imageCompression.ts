/**
 * Client-side image compression and processing utilities
 * Uses Canvas API for resizing, compression, and thumbnail generation
 */

export interface CompressionOptions {
  maxWidth?: number;
  maxHeight?: number;
  quality?: number; // 0-1
  format?: 'image/jpeg' | 'image/png' | 'image/webp';
}

export interface ProcessedImage {
  file: File;
  thumbnail: string; // data URL
  originalSize: number;
  compressedSize: number;
  width: number;
  height: number;
  compressionRatio: number;
}

const DEFAULT_OPTIONS: CompressionOptions = {
  maxWidth: 1920,
  maxHeight: 1080,
  quality: 0.82,
  format: 'image/jpeg',
};

const THUMBNAIL_SIZE = 200;

/**
 * Load an image from a File object
 */
export function loadImage(file: File): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('Failed to load image'));
    img.src = URL.createObjectURL(file);
  });
}

/**
 * Load an image from a data URL or blob URL
 */
export function loadImageFromUrl(url: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('Failed to load image'));
    img.src = url;
  });
}

/**
 * Compress an image file with the given options
 */
export async function compressImage(
  file: File,
  options: CompressionOptions = {}
): Promise<ProcessedImage> {
  const opts = { ...DEFAULT_OPTIONS, ...options };
  const originalSize = file.size;

  // Load the image
  const img = await loadImage(file);
  const { width: origW, height: origH } = img;

  // Calculate new dimensions maintaining aspect ratio
  let newWidth = origW;
  let newHeight = origH;

  if (opts.maxWidth && newWidth > opts.maxWidth) {
    newHeight = Math.round((opts.maxWidth / newWidth) * newHeight);
    newWidth = opts.maxWidth;
  }
  if (opts.maxHeight && newHeight > opts.maxHeight) {
    newWidth = Math.round((opts.maxHeight / newHeight) * newWidth);
    newHeight = opts.maxHeight;
  }

  // Create canvas for compressed image
  const canvas = document.createElement('canvas');
  canvas.width = newWidth;
  canvas.height = newHeight;
  const ctx = canvas.getContext('2d')!;

  // Use high-quality image smoothing
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(img, 0, 0, newWidth, newHeight);

  // Convert to blob
  const blob = await new Promise<Blob>((resolve, reject) => {
    canvas.toBlob(
      (b) => (b ? resolve(b) : reject(new Error('Canvas toBlob failed'))),
      opts.format,
      opts.quality
    );
  });

  // If compressed is larger than original (e.g., small PNGs), use original
  const useOriginal = blob.size >= originalSize && originalSize < 500_000;
  const finalFile = useOriginal
    ? file
    : new File([blob], file.name.replace(/\.[^.]+$/, '.jpg'), {
        type: opts.format || 'image/jpeg',
      });

  // Generate thumbnail
  const thumbnail = generateThumbnailFromCanvas(img);

  // Clean up
  URL.revokeObjectURL(img.src);

  return {
    file: finalFile,
    thumbnail,
    originalSize,
    compressedSize: finalFile.size,
    width: newWidth,
    height: newHeight,
    compressionRatio: Math.round((1 - finalFile.size / originalSize) * 100),
  };
}

/**
 * Generate a thumbnail data URL from an image element
 */
function generateThumbnailFromCanvas(img: HTMLImageElement): string {
  const canvas = document.createElement('canvas');
  const aspectRatio = img.width / img.height;

  if (aspectRatio > 1) {
    canvas.width = THUMBNAIL_SIZE;
    canvas.height = Math.round(THUMBNAIL_SIZE / aspectRatio);
  } else {
    canvas.height = THUMBNAIL_SIZE;
    canvas.width = Math.round(THUMBNAIL_SIZE * aspectRatio);
  }

  const ctx = canvas.getContext('2d')!;
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'medium';
  ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

  return canvas.toDataURL('image/jpeg', 0.6);
}

/**
 * Rotate an image by the given degrees (90, 180, 270)
 */
export async function rotateImage(
  dataUrl: string,
  degrees: number
): Promise<string> {
  const img = await loadImageFromUrl(dataUrl);
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d')!;

  const rad = (degrees * Math.PI) / 180;
  const isVertical = degrees === 90 || degrees === 270;

  canvas.width = isVertical ? img.height : img.width;
  canvas.height = isVertical ? img.width : img.height;

  ctx.translate(canvas.width / 2, canvas.height / 2);
  ctx.rotate(rad);
  ctx.drawImage(img, -img.width / 2, -img.height / 2);

  return canvas.toDataURL('image/jpeg', 0.92);
}


/**
 * Convert a data URL to a File object
 */
export function dataUrlToFile(dataUrl: string, filename: string): File {
  const arr = dataUrl.split(',');
  const mime = arr[0].match(/:(.*?);/)?.[1] || 'image/jpeg';
  const bstr = atob(arr[1]);
  let n = bstr.length;
  const u8arr = new Uint8Array(n);
  while (n--) {
    u8arr[n] = bstr.charCodeAt(n);
  }
  return new File([u8arr], filename, { type: mime });
}

/**
 * Format file size for display
 */
export function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

/**
 * Recommended Open Graph social-share dimensions / aspect ratio.
 */
export const OG_IMAGE_WIDTH = 1200;
export const OG_IMAGE_HEIGHT = 630;
export const OG_IMAGE_RATIO = OG_IMAGE_WIDTH / OG_IMAGE_HEIGHT; // ≈ 1.9048

/**
 * Resize/crop an image File to the recommended 1200x630 OG dimensions.
 * Uses a "cover" center-crop so the result always fills the exact target
 * canvas without distortion (matching the 1.91:1 social-share aspect ratio).
 */
export async function resizeToOgImage(
  file: File,
  options: { quality?: number; format?: 'image/jpeg' | 'image/webp' } = {}
): Promise<File> {
  const { quality = 0.85, format = 'image/jpeg' } = options;

  const img = await loadImage(file);
  const { width: srcW, height: srcH } = img;

  const canvas = document.createElement('canvas');
  canvas.width = OG_IMAGE_WIDTH;
  canvas.height = OG_IMAGE_HEIGHT;
  const ctx = canvas.getContext('2d')!;
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';

  // "cover" center-crop math: figure out the largest source rectangle that
  // matches the target aspect ratio, centered on the original image.
  const srcRatio = srcW / srcH;
  let sx = 0;
  let sy = 0;
  let sw = srcW;
  let sh = srcH;

  if (srcRatio > OG_IMAGE_RATIO) {
    // Source is wider than target → crop the sides
    sw = Math.round(srcH * OG_IMAGE_RATIO);
    sx = Math.round((srcW - sw) / 2);
  } else if (srcRatio < OG_IMAGE_RATIO) {
    // Source is taller than target → crop top/bottom
    sh = Math.round(srcW / OG_IMAGE_RATIO);
    sy = Math.round((srcH - sh) / 2);
  }

  ctx.drawImage(img, sx, sy, sw, sh, 0, 0, OG_IMAGE_WIDTH, OG_IMAGE_HEIGHT);

  const blob = await new Promise<Blob>((resolve, reject) => {
    canvas.toBlob(
      (b) => (b ? resolve(b) : reject(new Error('Canvas toBlob failed'))),
      format,
      quality
    );
  });

  URL.revokeObjectURL(img.src);

  const ext = format === 'image/webp' ? 'webp' : 'jpg';
  const baseName = file.name.replace(/\.[^.]+$/, '');
  return new File([blob], `${baseName}-og.${ext}`, { type: format });
}

/**
 * Returns true when an image's aspect ratio is "far" from the ideal 1.91:1
 * OG ratio (default tolerance ±8%), meaning it may look cropped/letterboxed
 * when shared on social media.
 */
export function isFarFromOgRatio(
  width: number,
  height: number,
  tolerance = 0.08
): boolean {
  if (!width || !height) return false;
  const ratio = width / height;
  return Math.abs(ratio - OG_IMAGE_RATIO) / OG_IMAGE_RATIO > tolerance;
}


/**
 * Read a File as a data URL
 */
export function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsDataURL(file);
  });
}
