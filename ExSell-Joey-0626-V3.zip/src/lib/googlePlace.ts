/**
 * Shared Google Business Profile configuration for ExSell Sales LLC.
 *
 * Business:   ExSell Sales LLC
 * Address:    442 Tate St, Suite A, Holbrook, NY 11741
 * Phone:      (631) 388-4426
 * CID:        6682940155181132926
 * Maps URL:   https://maps.google.com/?cid=6682940155181132926
 *
 * The constant `GOOGLE_PLACE_ID` below is a hard-coded *fallback* placeholder.
 * In production the real Place ID is stored in the `site_content` table under
 * the section key `google_place` and read at runtime via the `usePlaceConfig`
 * hook. An admin can paste the live Place ID into the admin UI (Admin →
 * Content → Integrations → Google Place ID) and every live-reviews component
 * (badge, /reviews page, JSON-LD) will pick it up automatically — no redeploy.
 *
 * HOW TO GET THE REAL PLACE ID (manual, 30 seconds):
 *   1. Open https://developers.google.com/maps/documentation/places/web-service/place-id
 *   2. Paste "ExSell Sales LLC, 442 Tate St, Holbrook, NY 11741" into the finder
 *   3. Copy the "ChIJ..." string and paste it into the Admin → Content panel
 */

export const GOOGLE_PLACE_ID = 'ChIJ_4HuqBtJ6IkRfuzD1KmSvlw'; // verified ExSell Sales LLC Place ID

export const BUSINESS_QUERY = 'ExSell Sales LLC, 442 Tate St, Holbrook, NY 11741';

export const GOOGLE_BUSINESS_CID = '6682940155181132926';

export const GOOGLE_BUSINESS_URL = `https://maps.google.com/?cid=${GOOGLE_BUSINESS_CID}`;

/** Official Facebook page URL for Ex$ell Sales LLC. Used for social links + JSON-LD sameAs. */
export const FACEBOOK_PAGE_URL = 'https://www.facebook.com/ExSellSales';
export const FACEBOOK_REVIEWS_URL = `${FACEBOOK_PAGE_URL}/reviews`;

/** Builds the "Write a review" URL for any given Place ID. */
export const buildWriteReviewUrl = (placeId: string = GOOGLE_PLACE_ID): string =>
  `https://search.google.com/local/writereview?placeid=${placeId}`;

/** Builds the embeddable Google Maps URL for any given Place ID. */
export const buildMapsEmbedUrl = (placeId: string = GOOGLE_PLACE_ID): string =>
  `https://www.google.com/maps/embed/v1/place?key=AIzaSyBFw0Qbyq9zTFTd-tUY6dZWTgaQzuU17R8&q=place_id:${placeId}`;

/** Query-based fallback embed used when no real Place ID is configured yet. */
export const GOOGLE_MAPS_EMBED_FALLBACK = `https://www.google.com/maps?q=${encodeURIComponent(
  BUSINESS_QUERY
)}&output=embed`;

/**
 * Returns true when the given Place ID is still the hard-coded placeholder
 * (or empty / clearly invalid). The placeholder Place ID starts with
 * `ChIJN1t_tD` — that's the canonical Google example used in their docs.
 */
export const isPlaceholderPlaceId = (id: string = GOOGLE_PLACE_ID): boolean => {
  if (!id || typeof id !== 'string') return true;
  const trimmed = id.trim();
  if (trimmed.length < 10) return true;
  if (trimmed.startsWith('ChIJN1t_tD')) return true;
  return false;
};

/**
 * Cleans up a Place ID string before it's used. Most importantly it repairs the
 * common copy/paste mistake where the "ChIJ" prefix gets duplicated
 * (e.g. "ChIJChIJ_4Huq..." becomes "ChIJ_4Huq..."), and strips whitespace.
 */
export const normalizePlaceId = (id: string | undefined | null): string => {
  let v = (id || '').trim();
  // Collapse a doubled "ChIJ" prefix from accidental double-paste.
  while (v.startsWith('ChIJChIJ')) v = v.slice(4);
  return v;
};


/** Section key under which the live Place ID is stored in `site_content`. */
export const GOOGLE_PLACE_SECTION = 'google_place';

export interface GooglePlaceConfig {
  placeId: string;
}
