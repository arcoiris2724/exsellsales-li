/**
 * Lightweight business-hours helper used by the mobile CTA bar to show an
 * "Open now" / "Opens at 9am" status indicator. Hours are kept as a simple
 * constant here so they work without a network round-trip; if a richer source
 * (GooglePlaceConfig opening_hours) becomes available it can override these.
 *
 * Index 0 = Sunday ... 6 = Saturday. `null` means closed that day.
 * Times are local 24h values on the visitor's device clock.
 */
export interface DayHours {
  open: number; // hour 0-23 (decimal allowed, e.g. 9.5 = 9:30am)
  close: number;
}

export const DEALERSHIP_HOURS: (DayHours | null)[] = [
  null, // Sunday — closed
  { open: 9, close: 19 }, // Monday
  { open: 9, close: 19 }, // Tuesday
  { open: 9, close: 19 }, // Wednesday
  { open: 9, close: 19 }, // Thursday
  { open: 9, close: 19 }, // Friday
  { open: 9, close: 18 }, // Saturday
];

const DAY_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

function formatHour(h: number): string {
  const whole = Math.floor(h);
  const mins = Math.round((h - whole) * 60);
  const period = whole >= 12 ? 'pm' : 'am';
  let display = whole % 12;
  if (display === 0) display = 12;
  return mins > 0 ? `${display}:${mins.toString().padStart(2, '0')}${period}` : `${display}${period}`;
}

export interface OpenStatus {
  isOpen: boolean;
  /** Short human label, e.g. "Open now" or "Opens at 9am". */
  label: string;
  /** Longer detail, e.g. "Closes at 7pm" or "Opens Mon 9am". */
  detail: string;
}

/**
 * Computes the current open/closed status based on the device's local time.
 * @param now Optional date override (used for testing).
 */
export function getOpenStatus(now: Date = new Date()): OpenStatus {
  const day = now.getDay();
  const hourNow = now.getHours() + now.getMinutes() / 60;
  const today = DEALERSHIP_HOURS[day];

  if (today && hourNow >= today.open && hourNow < today.close) {
    return {
      isOpen: true,
      label: 'Open now',
      detail: `Closes at ${formatHour(today.close)}`,
    };
  }

  // Closed — find the next opening within the next 7 days.
  if (today && hourNow < today.open) {
    return {
      isOpen: false,
      label: `Opens at ${formatHour(today.open)}`,
      detail: `Opens today at ${formatHour(today.open)}`,
    };
  }

  for (let i = 1; i <= 7; i++) {
    const idx = (day + i) % 7;
    const dh = DEALERSHIP_HOURS[idx];
    if (dh) {
      const dayLabel = i === 1 ? 'tomorrow' : DAY_NAMES[idx];
      return {
        isOpen: false,
        label: `Opens ${i === 1 ? 'tomorrow' : DAY_NAMES[idx].slice(0, 3)} ${formatHour(dh.open)}`,
        detail: `Opens ${dayLabel} at ${formatHour(dh.open)}`,
      };
    }
  }

  return { isOpen: false, label: 'Currently closed', detail: 'Currently closed' };
}
