import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { Search, Loader2, Gauge, Fuel, Settings2, Camera, Video, X, ArrowLeft, Trophy, TrendingUp, Phone, Calendar, RefreshCw } from 'lucide-react';
import { Vehicle, fetchSoldVehicles, getBodyTypes, getMakes, isUsingFallbackData } from '@/data/vehicles';
import FallbackBanner from '@/components/dealership/FallbackBanner';

import Navbar from '@/components/dealership/Navbar';
import Footer from '@/components/dealership/Footer';
import { usePageSEO } from '@/hooks/usePageSEO';

const SoldVehicles: React.FC = () => {
  usePageSEO('sold');

  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedMake, setSelectedMake] = useState('All');
  const [selectedBodyType, setSelectedBodyType] = useState('All');
  const [sortBy, setSortBy] = useState('newest');
  const [usingFallback, setUsingFallback] = useState(false);
  const [retrying, setRetrying] = useState(false);

  const loadSoldVehicles = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchSoldVehicles();
      setVehicles(data);
      setUsingFallback(isUsingFallbackData());
    } catch {
      setUsingFallback(true);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    window.scrollTo(0, 0);
    loadSoldVehicles();
  }, [loadSoldVehicles]);

  const handleRetry = useCallback(async () => {
    setRetrying(true);
    try {
      const data = await fetchSoldVehicles();
      setVehicles(data);
      setUsingFallback(isUsingFallbackData());
    } catch {
      setUsingFallback(true);
    } finally {
      setRetrying(false);
    }
  }, []);

  const makes = useMemo(() => getMakes(vehicles), [vehicles]);
  const bodyTypes = useMemo(() => getBodyTypes(vehicles), [vehicles]);

  const filtered = useMemo(() => {
    let list = [...vehicles];
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      list = list.filter(v =>
        `${v.year} ${v.make} ${v.model} ${v.trim} ${v.exteriorColor} ${v.bodyType}`.toLowerCase().includes(q)
      );
    }
    if (selectedMake !== 'All') list = list.filter(v => v.make === selectedMake);
    if (selectedBodyType !== 'All') list = list.filter(v => v.bodyType === selectedBodyType);
    switch (sortBy) {
      case 'price-low': list.sort((a, b) => a.price - b.price); break;
      case 'price-high': list.sort((a, b) => b.price - a.price); break;
      case 'year-new': list.sort((a, b) => b.year - a.year); break;
      default: break; // newest = default DB order
    }
    return list;
  }, [vehicles, searchQuery, selectedMake, selectedBodyType, sortBy]);

  const totalValue = vehicles.reduce((sum, v) => sum + v.price, 0);

  return (
    <div className="min-h-screen bg-black text-white">
      <Navbar />

      {/* Hero Banner */}
      <section className="relative py-20 md:py-28 px-4 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-red-900/20 via-black to-neon-orange/10" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(255,50,50,0.15),transparent_60%)]" />
        <div className="relative max-w-7xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-red-500/10 border border-red-500/20 rounded-full text-red-400 text-sm font-semibold mb-6">
            <Trophy className="w-4 h-4" />
            Previously Sold Vehicles
          </div>
          <h1 className="text-4xl md:text-6xl font-black mb-4">
            Our <span className="bg-gradient-to-r from-red-400 via-neon-orange to-neon-pink bg-clip-text text-transparent">Sold List</span>
          </h1>
          <p className="text-gray-400 text-lg md:text-xl max-w-2xl mx-auto mb-8">
            Check out the vehicles we've successfully matched with happy owners. This is proof of the quality rides that move through our lot.
          </p>

          {/* Stats */}
          <div className="flex flex-wrap justify-center gap-6 md:gap-10">
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-black text-neon-orange">{vehicles.length}</div>
              <div className="text-gray-500 text-sm font-medium mt-1">Vehicles Sold</div>
            </div>
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-black text-neon-green">${(totalValue / 1000).toFixed(0)}K+</div>
              <div className="text-gray-500 text-sm font-medium mt-1">Total Value Delivered</div>
            </div>
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-black text-neon-cyan">100%</div>
              <div className="text-gray-500 text-sm font-medium mt-1">Happy Customers</div>
            </div>
          </div>
        </div>
      </section>

      {/* Fallback banner */}
      {usingFallback && !loading && (
        <FallbackBanner onRetry={handleRetry} retrying={retrying} context="sold" />
      )}

      {/* CTA Banner */}
      <div className="max-w-7xl mx-auto px-4 mb-8">
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-neon-pink/10 via-neon-orange/10 to-neon-cyan/10 border border-white/5 p-6 md:p-8">
          <div className="absolute top-0 right-0 w-64 h-64 bg-neon-pink/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
          <div className="relative flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-neon-green/10 rounded-xl">
                <TrendingUp className="w-6 h-6 text-neon-green" />
              </div>
              <div>
                <h3 className="text-white font-bold text-lg">Looking for something similar?</h3>
                <p className="text-gray-400 text-sm">We're always sourcing new inventory. Call us about what you're looking for!</p>
              </div>
            </div>
            <div className="flex gap-3">
              <Link
                to="/"
                className="px-5 py-2.5 border border-neon-cyan/40 text-neon-cyan font-bold text-sm rounded-lg hover:bg-neon-cyan/10 transition-colors whitespace-nowrap"
              >
                View Current Inventory
              </Link>
              <a
                href="tel:6313884426"
                className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-neon-pink to-neon-orange text-white font-bold text-sm rounded-lg hover:opacity-90 transition-opacity whitespace-nowrap"
              >
                <Phone className="w-4 h-4" />
                Call Us
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="max-w-7xl mx-auto px-4 mb-8">
        <div className="flex flex-col md:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search sold vehicles..."
              className="w-full pl-12 pr-10 py-3.5 bg-white/[0.03] border border-white/10 rounded-xl text-white placeholder-gray-500 focus:border-neon-cyan focus:outline-none transition-colors"
            />
            {searchQuery && (
              <button onClick={() => setSearchQuery('')} className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
          <select
            value={selectedMake}
            onChange={e => setSelectedMake(e.target.value)}
            className="px-4 py-3.5 bg-white/[0.03] border border-white/10 rounded-xl text-white focus:border-neon-cyan focus:outline-none"
          >
            {makes.map(m => <option key={m} value={m}>{m === 'All' ? 'All Makes' : m}</option>)}
          </select>
          <select
            value={selectedBodyType}
            onChange={e => setSelectedBodyType(e.target.value)}
            className="px-4 py-3.5 bg-white/[0.03] border border-white/10 rounded-xl text-white focus:border-neon-cyan focus:outline-none"
          >
            {bodyTypes.map(t => <option key={t} value={t}>{t === 'All' ? 'All Types' : t}</option>)}
          </select>
          <select
            value={sortBy}
            onChange={e => setSortBy(e.target.value)}
            className="px-4 py-3.5 bg-white/[0.03] border border-white/10 rounded-xl text-white focus:border-neon-cyan focus:outline-none"
          >
            <option value="newest">Recently Sold</option>
            <option value="price-high">Price: High to Low</option>
            <option value="price-low">Price: Low to High</option>
            <option value="year-new">Year: Newest</option>
          </select>
        </div>
        <p className="text-gray-500 text-sm mt-3">
          Showing <span className="text-white font-semibold">{filtered.length}</span> of{' '}
          <span className="text-white font-semibold">{vehicles.length}</span> sold vehicles
        </p>
      </div>

      {/* Vehicle Grid */}
      <div className="max-w-7xl mx-auto px-4 pb-20">
        {loading ? (
          <div className="flex flex-col items-center justify-center py-20">
            <Loader2 className="w-10 h-10 text-neon-pink animate-spin mb-4" />
            <p className="text-gray-400 text-lg">Loading sold vehicles...</p>
          </div>
        ) : filtered.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filtered.map(vehicle => (
              <SoldVehicleCard key={vehicle.id} vehicle={vehicle} />
            ))}
          </div>
        ) : vehicles.length === 0 ? (
          <div className="text-center py-20">
            <Trophy className="w-16 h-16 mx-auto text-gray-700 mb-4" />
            <h3 className="text-xl font-bold text-white mb-2">
              {usingFallback ? 'No sold vehicles in sample data' : 'No sold vehicles yet'}
            </h3>
            <p className="text-gray-400 mb-4 max-w-md mx-auto">
              {usingFallback
                ? 'The database connection failed. Your actual sold vehicles are stored in the database. Try refreshing or check the Admin panel.'
                : 'When you mark vehicles as "Sold" in the Admin panel, they\'ll appear here automatically.'
              }
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
              <Link
                to="/"
                className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-neon-pink to-neon-orange text-white font-bold rounded-lg hover:opacity-90 transition-opacity"
              >
                <ArrowLeft className="w-4 h-4" />
                Browse Available Inventory
              </Link>
              {usingFallback && (
                <button
                  onClick={handleRetry}
                  disabled={retrying}
                  className="inline-flex items-center gap-2 px-6 py-3 border border-amber-500/30 text-amber-300 font-bold rounded-lg hover:bg-amber-500/10 transition-colors disabled:opacity-50"
                >
                  <RefreshCw className={`w-4 h-4 ${retrying ? 'animate-spin' : ''}`} />
                  {retrying ? 'Retrying...' : 'Retry Database'}
                </button>
              )}
            </div>
          </div>
        ) : (
          <div className="text-center py-16">
            <Search className="w-12 h-12 mx-auto text-gray-700 mb-4" />
            <h3 className="text-xl font-bold text-white mb-2">No matches found</h3>
            <p className="text-gray-400 mb-4">Try adjusting your search or filters</p>
            <button
              onClick={() => { setSearchQuery(''); setSelectedMake('All'); setSelectedBodyType('All'); }}
              className="px-6 py-2.5 bg-neon-pink/10 border border-neon-pink/30 text-neon-pink font-semibold rounded-lg hover:bg-neon-pink/20 transition-colors"
            >
              Clear Filters
            </button>
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
};

/* ─── Sold Vehicle Card ─── */
const SoldVehicleCard: React.FC<{ vehicle: Vehicle }> = ({ vehicle }) => {
  const imageCount = vehicle.images?.length || 1;
  const hasVideo = !!vehicle.videoUrl;

  const soldDate = vehicle.soldDate
    ? new Date(vehicle.soldDate + 'T00:00:00').toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
    : vehicle.updated_at
      ? new Date(vehicle.updated_at).toLocaleDateString('en-US', { month: 'short', year: 'numeric' })
      : null;

  const displayPrice = vehicle.soldPrice || vehicle.price;
  const hadDifferentSalePrice = vehicle.soldPrice && vehicle.soldPrice !== vehicle.price;

  return (
    <div className="group relative bg-[#0a0a0a] rounded-xl border border-white/5 hover:border-red-500/30 transition-all duration-300 overflow-hidden">
      {/* Image */}
      <Link to={`/inventory/${vehicle.id}`} className="block relative aspect-[16/10] overflow-hidden">
        <img
          src={vehicle.image}
          alt={`${vehicle.year} ${vehicle.make} ${vehicle.model}`}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105 grayscale-[30%] group-hover:grayscale-0"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />

        {/* SOLD badge */}
        <div className="absolute top-3 left-3 px-3 py-1.5 bg-red-600 text-white text-xs font-black rounded-full uppercase tracking-wider flex items-center gap-1.5 shadow-lg shadow-red-600/30">
          <svg className="w-3 h-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="20 6 9 17 4 12" />
          </svg>
          SOLD
        </div>

        {/* Sold date */}
        {soldDate && (
          <div className="absolute top-3 right-3 px-2.5 py-1 bg-black/70 backdrop-blur-sm rounded-md text-gray-300 text-[11px] font-medium flex items-center gap-1">
            <Calendar className="w-3 h-3 text-gray-400" />
            {soldDate}
          </div>
        )}

        {/* Media badges */}
        <div className="absolute bottom-3 left-3 flex items-center gap-1.5">
          {imageCount > 1 && (
            <div className="flex items-center gap-1 px-2 py-1 bg-black/70 backdrop-blur-sm rounded-md text-white text-[10px] font-medium">
              <Camera className="w-3 h-3" />
              {imageCount}
            </div>
          )}
          {hasVideo && (
            <div className="flex items-center gap-1 px-2 py-1 bg-neon-pink/80 backdrop-blur-sm rounded-md text-white text-[10px] font-bold">
              <Video className="w-3 h-3" />
              VIDEO
            </div>
          )}
        </div>

        {/* Price display */}
        <div className="absolute bottom-3 right-3">
          <div className="px-3 py-1.5 bg-black/80 backdrop-blur-sm rounded-lg border border-red-500/30">
            {hadDifferentSalePrice ? (
              <div className="flex flex-col items-end">
                <span className="text-gray-500 text-[10px] line-through decoration-gray-600">
                  ${vehicle.price.toLocaleString()}
                </span>
                <span className="text-red-400 font-bold text-sm">
                  Sold: ${vehicle.soldPrice!.toLocaleString()}
                </span>
              </div>
            ) : displayPrice > 0 ? (
              <span className="text-red-400 font-bold text-lg line-through decoration-red-500/50 decoration-2">
                ${displayPrice.toLocaleString()}
              </span>
            ) : (
              <span className="text-red-400 font-bold text-sm">
                Price N/A
              </span>
            )}
          </div>
        </div>

      </Link>

      {/* Content */}
      <div className="p-4 space-y-3">
        <Link to={`/inventory/${vehicle.id}`} className="block">
          <h3 className="text-white font-bold text-lg leading-tight group-hover:text-red-400 transition-colors">
            {vehicle.year} {vehicle.make} {vehicle.model}
          </h3>
          <p className="text-gray-500 text-sm font-medium">{vehicle.trim}</p>
        </Link>

        {/* Specs */}
        <div className="grid grid-cols-3 gap-2">
          <div className="flex items-center gap-1.5 text-gray-400">
            <Gauge className="w-3.5 h-3.5 text-red-400" />
            <span className="text-xs">{(vehicle.mileage / 1000).toFixed(0)}K mi</span>
          </div>
          <div className="flex items-center gap-1.5 text-gray-400">
            <Fuel className="w-3.5 h-3.5 text-neon-green" />
            <span className="text-xs">{vehicle.fuelType}</span>
          </div>
          <div className="flex items-center gap-1.5 text-gray-400">
            <Settings2 className="w-3.5 h-3.5 text-neon-cyan" />
            <span className="text-xs">{vehicle.drivetrain}</span>
          </div>
        </div>

        {/* Color & Transmission */}
        <div className="flex items-center gap-2 text-xs text-gray-500">
          <span>{vehicle.exteriorColor}</span>
          <span className="w-1 h-1 bg-gray-600 rounded-full" />
          <span>{vehicle.transmission}</span>
          <span className="w-1 h-1 bg-gray-600 rounded-full" />
          <span>{vehicle.engine}</span>
        </div>

        {/* CTA */}
        <div className="flex gap-2 pt-1">
          <Link
            to={`/inventory/${vehicle.id}`}
            className="flex-1 py-2.5 bg-white/[0.04] border border-white/10 text-gray-300 text-sm font-bold rounded-lg hover:bg-white/[0.08] hover:text-white transition-all text-center"
          >
            View Details
          </Link>
          <a
            href="tel:6313884426"
            className="px-4 py-2.5 bg-gradient-to-r from-neon-pink to-neon-orange text-white text-sm font-bold rounded-lg hover:opacity-90 transition-opacity flex items-center gap-1.5"
          >
            <Phone className="w-3.5 h-3.5" />
            Find Similar
          </a>
        </div>
      </div>
    </div>
  );
};

export default SoldVehicles;
