import React, { useState, useMemo } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import {
  ArrowLeft, X, Scale, ChevronRight, Check, Minus,
  Car, Gauge, Fuel, Settings2, Palette, Calendar,
  DollarSign, Cog, Zap, Shield, Plus
} from 'lucide-react';
import { Vehicle } from '@/data/vehicles';
import { useCompare } from '@/contexts/CompareContext';
import Navbar from '@/components/dealership/Navbar';
import Footer from '@/components/dealership/Footer';
import ComparisonTray from '@/components/dealership/ComparisonTray';

// Helper to find best/worst values for highlighting
function findBestValue(
  vehicles: Vehicle[],
  getter: (v: Vehicle) => number,
  lowerIsBetter = false
): number | null {
  if (vehicles.length < 2) return null;
  const values = vehicles.map(getter);
  return lowerIsBetter ? Math.min(...values) : Math.max(...values);
}

const Compare: React.FC = () => {
  const { compareList, removeFromCompare, clearCompare } = useCompare();
  const navigate = useNavigate();
  const [highlightDiffs, setHighlightDiffs] = useState(true);

  // Scroll to top on mount
  React.useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  // Collect all unique features across compared vehicles
  const allFeatures = useMemo(() => {
    const featureSet = new Set<string>();
    compareList.forEach((v) => v.features.forEach((f) => featureSet.add(f)));
    return Array.from(featureSet).sort();
  }, [compareList]);

  // Check if values differ across vehicles for a given spec
  const valuesDiffer = (getter: (v: Vehicle) => string | number): boolean => {
    if (compareList.length < 2) return false;
    const values = compareList.map(getter);
    return !values.every((val) => val === values[0]);
  };

  // Spec rows configuration
  const specRows = [
    { label: 'Year', getter: (v: Vehicle) => v.year, icon: Calendar, lowerIsBetter: false, format: (val: number | string) => String(val) },
    { label: 'Price', getter: (v: Vehicle) => v.price, icon: DollarSign, lowerIsBetter: true, format: (val: number | string) => `$${Number(val).toLocaleString()}` },
    { label: 'Mileage', getter: (v: Vehicle) => v.mileage, icon: Gauge, lowerIsBetter: true, format: (val: number | string) => `${(Number(val) / 1000).toFixed(1)}K mi` },
    { label: 'Engine', getter: (v: Vehicle) => v.engine, icon: Zap, format: (val: number | string) => String(val) },
    { label: 'Transmission', getter: (v: Vehicle) => v.transmission, icon: Cog, format: (val: number | string) => String(val) },
    { label: 'Drivetrain', getter: (v: Vehicle) => v.drivetrain, icon: Settings2, format: (val: number | string) => String(val) },
    { label: 'Fuel Type', getter: (v: Vehicle) => v.fuelType, icon: Fuel, format: (val: number | string) => String(val) },
    { label: 'Body Type', getter: (v: Vehicle) => v.bodyType, icon: Car, format: (val: number | string) => String(val) },
    { label: 'Exterior Color', getter: (v: Vehicle) => v.exteriorColor, icon: Palette, format: (val: number | string) => String(val) },
    { label: 'Interior Color', getter: (v: Vehicle) => v.interiorColor, icon: Palette, format: (val: number | string) => String(val) },
  ];

  // Calculate monthly payment
  const calcMonthly = (price: number): string => {
    const p = price * 0.9;
    const r = 6.9 / 100 / 12;
    const n = 60;
    const m = p * (r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
    return `$${Math.round(m).toLocaleString()}/mo`;
  };

  if (compareList.length === 0) {
    return (
      <div className="min-h-screen bg-black text-white">
        <Navbar />
        <div className="flex flex-col items-center justify-center py-40 px-4">
          <div className="w-20 h-20 bg-neon-cyan/10 rounded-2xl flex items-center justify-center mb-6">
            <Scale className="w-10 h-10 text-neon-cyan" />
          </div>
          <h2 className="text-3xl font-black text-white mb-3">No Vehicles to Compare</h2>
          <p className="text-gray-400 text-lg mb-8 text-center max-w-md">
            Add 2-3 vehicles from our inventory to compare them side by side.
          </p>
          <button
            onClick={() => {
              navigate('/');
              setTimeout(() => {
                document.getElementById('inventory')?.scrollIntoView({ behavior: 'smooth' });
              }, 100);
            }}
            className="px-8 py-4 bg-gradient-to-r from-neon-pink to-neon-orange text-white font-bold text-lg rounded-xl hover:opacity-90 transition-opacity neon-pulse"
          >
            Browse Inventory
          </button>
        </div>
        <Footer />
      </div>
    );
  }

  const colWidth = compareList.length === 2 ? 'w-1/2' : 'w-1/3';

  return (
    <div className="min-h-screen bg-black text-white">
      <Navbar />

      {/* Breadcrumb */}
      <div className="bg-[#050505] border-b border-white/5">
        <div className="max-w-7xl mx-auto px-4 py-3">
          <div className="flex items-center gap-2 text-sm">
            <Link to="/" className="text-gray-500 hover:text-neon-cyan transition-colors">
              Home
            </Link>
            <ChevronRight className="w-3.5 h-3.5 text-gray-600" />
            <button
              onClick={() => {
                navigate('/');
                setTimeout(() => {
                  document.getElementById('inventory')?.scrollIntoView({ behavior: 'smooth' });
                }, 100);
              }}
              className="text-gray-500 hover:text-neon-cyan transition-colors"
            >
              Inventory
            </button>
            <ChevronRight className="w-3.5 h-3.5 text-gray-600" />
            <span className="text-white font-medium">Compare Vehicles</span>
          </div>
        </div>
      </div>

      {/* Header */}
      <div className="bg-[#080808] border-b border-white/5">
        <div className="max-w-7xl mx-auto px-4 py-5">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <button
                onClick={() => navigate(-1)}
                className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors group"
              >
                <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
                <span className="text-sm font-medium">Back</span>
              </button>
              <div>
                <h1 className="text-2xl md:text-3xl font-black text-white flex items-center gap-3">
                  <Scale className="w-7 h-7 text-neon-cyan" />
                  Vehicle <span className="gradient-text-neon">Comparison</span>
                </h1>
                <p className="text-gray-500 text-sm mt-1">
                  Comparing {compareList.length} vehicle{compareList.length > 1 ? 's' : ''} side by side
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              {/* Highlight differences toggle */}
              <button
                onClick={() => setHighlightDiffs(!highlightDiffs)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
                  highlightDiffs
                    ? 'bg-neon-cyan/10 border border-neon-cyan/30 text-neon-cyan'
                    : 'bg-white/[0.03] border border-white/10 text-gray-400 hover:text-white'
                }`}
              >
                <Zap className="w-4 h-4" />
                Highlight Differences
              </button>
              <button
                onClick={() => {
                  clearCompare();
                  navigate('/');
                  setTimeout(() => {
                    document.getElementById('inventory')?.scrollIntoView({ behavior: 'smooth' });
                  }, 100);
                }}
                className="px-4 py-2 rounded-lg text-sm font-semibold bg-white/[0.03] border border-white/10 text-gray-400 hover:text-red-400 hover:border-red-400/30 transition-all"
              >
                Clear All
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main comparison content */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Vehicle header cards with images */}
        <div className="grid gap-4" style={{ gridTemplateColumns: `200px repeat(${compareList.length}, 1fr)` }}>
          {/* Empty top-left cell */}
          <div />
          {compareList.map((vehicle) => (
            <div
              key={vehicle.id}
              className="relative bg-[#0a0a0a] rounded-2xl border border-white/5 overflow-hidden group hover:border-neon-cyan/20 transition-all"
            >
              {/* Remove button */}
              <button
                onClick={() => removeFromCompare(vehicle.id)}
                className="absolute top-3 right-3 z-10 p-1.5 bg-black/60 backdrop-blur-sm rounded-lg text-gray-400 hover:text-red-400 hover:bg-red-400/10 transition-all"
                title="Remove from comparison"
              >
                <X className="w-4 h-4" />
              </button>

              {/* Image */}
              <Link to={`/inventory/${vehicle.id}`} className="block">
                <div className="aspect-[16/10] overflow-hidden">
                  <img
                    src={vehicle.image || (vehicle.images?.length > 0 ? vehicle.images[0] : '/placeholder.svg')}
                    alt={`${vehicle.year} ${vehicle.make} ${vehicle.model}`}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                </div>
              </Link>

              {/* Info */}
              <div className="p-4">
                <Link
                  to={`/inventory/${vehicle.id}`}
                  className="block hover:text-neon-cyan transition-colors"
                >
                  <h3 className="text-white font-bold text-lg leading-tight">
                    {vehicle.year} {vehicle.make} {vehicle.model}
                  </h3>
                  {vehicle.trim && (
                    <p className="text-gray-500 text-sm mt-0.5">{vehicle.trim}</p>
                  )}
                </Link>

                <div className="mt-3 flex items-baseline gap-2">
                  <span className="text-2xl font-display font-bold text-neon-orange neon-text-orange">
                    ${vehicle.price.toLocaleString()}
                  </span>
                </div>
                <div className="text-xs text-gray-500 mt-1">
                  Est. {calcMonthly(vehicle.price)} <span className="text-gray-600">(60 mo, 10% down)</span>
                </div>

                {/* Quick action buttons */}
                <div className="mt-4 flex gap-2">
                  <Link
                    to={`/inventory/${vehicle.id}`}
                    className="flex-1 py-2 bg-gradient-to-r from-neon-pink to-neon-orange text-white text-xs font-bold rounded-lg hover:opacity-90 transition-opacity text-center"
                  >
                    View Details
                  </Link>
                  <a
                    href="tel:6313884426"
                    className="flex-1 py-2 border border-neon-cyan/30 text-neon-cyan text-xs font-bold rounded-lg hover:bg-neon-cyan/10 transition-colors text-center"
                  >
                    Call Now
                  </a>
                </div>
              </div>
            </div>
          ))}

          {/* Add another vehicle slot */}
          {compareList.length < 3 && (
            <button
              onClick={() => {
                navigate('/');
                setTimeout(() => {
                  document.getElementById('inventory')?.scrollIntoView({ behavior: 'smooth' });
                }, 100);
              }}
              className="flex flex-col items-center justify-center bg-[#0a0a0a] rounded-2xl border-2 border-dashed border-white/10 hover:border-neon-cyan/30 transition-all min-h-[300px] group"
            >
              <div className="w-14 h-14 bg-white/[0.03] rounded-xl flex items-center justify-center mb-3 group-hover:bg-neon-cyan/10 transition-colors">
                <Plus className="w-6 h-6 text-gray-500 group-hover:text-neon-cyan transition-colors" />
              </div>
              <span className="text-gray-500 group-hover:text-neon-cyan font-semibold text-sm transition-colors">
                Add Vehicle
              </span>
              <span className="text-gray-600 text-xs mt-1">
                Up to 3 total
              </span>
            </button>
          )}
        </div>

        {/* Specifications comparison table */}
        <div className="mt-10">
          <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
            <Settings2 className="w-5 h-5 text-neon-cyan" />
            Specifications
          </h2>

          <div className="bg-[#0a0a0a] rounded-2xl border border-white/5 overflow-hidden">
            {specRows.map((row, rowIdx) => {
              const differs = valuesDiffer((v) => String(row.getter(v)));
              const numericValues = compareList.map((v) => Number(row.getter(v)));
              const isNumeric = numericValues.every((n) => !isNaN(n));
              const bestVal = isNumeric && row.lowerIsBetter !== undefined
                ? findBestValue(compareList, (v) => Number(row.getter(v)), row.lowerIsBetter)
                : null;

              return (
                <div
                  key={row.label}
                  className={`grid items-center ${
                    rowIdx % 2 === 0 ? 'bg-white/[0.01]' : ''
                  } ${
                    highlightDiffs && differs ? 'bg-neon-cyan/[0.03]' : ''
                  }`}
                  style={{ gridTemplateColumns: `200px repeat(${compareList.length}, 1fr)` }}
                >
                  {/* Label */}
                  <div className="px-5 py-4 flex items-center gap-2.5 border-r border-white/5">
                    <row.icon className="w-4 h-4 text-gray-500 flex-shrink-0" />
                    <span className="text-sm font-medium text-gray-400">{row.label}</span>
                    {highlightDiffs && differs && (
                      <div className="w-1.5 h-1.5 bg-neon-cyan rounded-full flex-shrink-0" />
                    )}
                  </div>

                  {/* Values */}
                  {compareList.map((vehicle) => {
                    const val = row.getter(vehicle);
                    const numVal = Number(val);
                    const isBest = bestVal !== null && !isNaN(numVal) && numVal === bestVal && differs;

                    return (
                      <div
                        key={vehicle.id}
                        className={`px-5 py-4 text-sm font-semibold border-r border-white/5 last:border-r-0 ${
                          isBest && highlightDiffs
                            ? 'text-neon-green'
                            : highlightDiffs && differs
                            ? 'text-white'
                            : 'text-gray-300'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <span>{row.format ? row.format(val) : String(val)}</span>
                          {isBest && highlightDiffs && (
                            <span className="px-1.5 py-0.5 bg-neon-green/10 text-neon-green text-[10px] font-bold rounded uppercase tracking-wider">
                              Best
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              );
            })}

            {/* VIN row */}
            <div
              className="grid items-center bg-white/[0.01]"
              style={{ gridTemplateColumns: `200px repeat(${compareList.length}, 1fr)` }}
            >
              <div className="px-5 py-4 flex items-center gap-2.5 border-r border-white/5">
                <Shield className="w-4 h-4 text-gray-500 flex-shrink-0" />
                <span className="text-sm font-medium text-gray-400">VIN</span>
              </div>
              {compareList.map((vehicle) => (
                <div key={vehicle.id} className="px-5 py-4 text-sm font-mono text-gray-400 border-r border-white/5 last:border-r-0 truncate">
                  {vehicle.vin || 'N/A'}
                </div>
              ))}
            </div>

            {/* Status row */}
            <div
              className="grid items-center"
              style={{ gridTemplateColumns: `200px repeat(${compareList.length}, 1fr)` }}
            >
              <div className="px-5 py-4 flex items-center gap-2.5 border-r border-white/5">
                <Car className="w-4 h-4 text-gray-500 flex-shrink-0" />
                <span className="text-sm font-medium text-gray-400">Status</span>
              </div>
              {compareList.map((vehicle) => (
                <div key={vehicle.id} className="px-5 py-4 border-r border-white/5 last:border-r-0">
                  <span
                    className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${
                      vehicle.status === 'available'
                        ? 'bg-neon-green/10 text-neon-green'
                        : vehicle.status === 'pending'
                        ? 'bg-yellow-500/10 text-yellow-400'
                        : 'bg-red-500/10 text-red-400'
                    }`}
                  >
                    <div
                      className={`w-1.5 h-1.5 rounded-full ${
                        vehicle.status === 'available'
                          ? 'bg-neon-green'
                          : vehicle.status === 'pending'
                          ? 'bg-yellow-500 animate-pulse'
                          : 'bg-red-500'
                      }`}
                    />
                    {vehicle.status}
                  </span>
                </div>
              ))}
            </div>

            {/* Monthly payment row */}
            <div
              className="grid items-center bg-white/[0.01]"
              style={{ gridTemplateColumns: `200px repeat(${compareList.length}, 1fr)` }}
            >
              <div className="px-5 py-4 flex items-center gap-2.5 border-r border-white/5">
                <DollarSign className="w-4 h-4 text-gray-500 flex-shrink-0" />
                <span className="text-sm font-medium text-gray-400">Est. Monthly</span>
              </div>
              {compareList.map((vehicle) => {
                const monthly = calcMonthly(vehicle.price);
                const allMonthly = compareList.map((v) => {
                  const p = v.price * 0.9;
                  const r = 6.9 / 100 / 12;
                  const n = 60;
                  return p * (r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
                });
                const lowestMonthly = Math.min(...allMonthly);
                const thisMonthly = (() => {
                  const p = vehicle.price * 0.9;
                  const r = 6.9 / 100 / 12;
                  const n = 60;
                  return p * (r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
                })();
                const isBest = highlightDiffs && compareList.length >= 2 && Math.round(thisMonthly) === Math.round(lowestMonthly);

                return (
                  <div
                    key={vehicle.id}
                    className={`px-5 py-4 text-sm font-semibold border-r border-white/5 last:border-r-0 ${
                      isBest ? 'text-neon-green' : 'text-gray-300'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span>{monthly}</span>
                      {isBest && (
                        <span className="px-1.5 py-0.5 bg-neon-green/10 text-neon-green text-[10px] font-bold rounded uppercase tracking-wider">
                          Best
                        </span>
                      )}
                    </div>
                    <span className="text-gray-600 text-xs">60 mo, 10% down, 6.9% APR</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Features comparison */}
        {allFeatures.length > 0 && (
          <div className="mt-10">
            <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
              <Check className="w-5 h-5 text-neon-green" />
              Features & Equipment
            </h2>

            <div className="bg-[#0a0a0a] rounded-2xl border border-white/5 overflow-hidden">
              {allFeatures.map((feature, idx) => {
                const vehicleHasFeature = compareList.map((v) =>
                  v.features.some((f) => f.toLowerCase() === feature.toLowerCase())
                );
                const allHave = vehicleHasFeature.every(Boolean);
                const noneHave = vehicleHasFeature.every((h) => !h);
                const differs = !allHave && !noneHave;

                return (
                  <div
                    key={feature}
                    className={`grid items-center ${
                      idx % 2 === 0 ? 'bg-white/[0.01]' : ''
                    } ${
                      highlightDiffs && differs ? 'bg-neon-cyan/[0.03]' : ''
                    }`}
                    style={{ gridTemplateColumns: `200px repeat(${compareList.length}, 1fr)` }}
                  >
                    <div className="px-5 py-3 border-r border-white/5">
                      <span className="text-sm text-gray-400 flex items-center gap-2">
                        {feature}
                        {highlightDiffs && differs && (
                          <div className="w-1.5 h-1.5 bg-neon-cyan rounded-full flex-shrink-0" />
                        )}
                      </span>
                    </div>
                    {compareList.map((vehicle, vIdx) => {
                      const has = vehicleHasFeature[vIdx];
                      return (
                        <div
                          key={vehicle.id}
                          className="px-5 py-3 border-r border-white/5 last:border-r-0 flex items-center justify-center"
                        >
                          {has ? (
                            <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                              highlightDiffs && differs
                                ? 'bg-neon-green/20'
                                : 'bg-neon-green/10'
                            }`}>
                              <Check className="w-3.5 h-3.5 text-neon-green" />
                            </div>
                          ) : (
                            <div className="w-6 h-6 rounded-full bg-white/[0.03] flex items-center justify-center">
                              <Minus className="w-3.5 h-3.5 text-gray-600" />
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                );
              })}

              {/* Feature count summary row */}
              <div
                className="grid items-center bg-white/[0.03] border-t border-white/5"
                style={{ gridTemplateColumns: `200px repeat(${compareList.length}, 1fr)` }}
              >
                <div className="px-5 py-4 border-r border-white/5">
                  <span className="text-sm font-bold text-white">Total Features</span>
                </div>
                {compareList.map((vehicle) => {
                  const count = vehicle.features.length;
                  const maxCount = Math.max(...compareList.map((v) => v.features.length));
                  const isBest = highlightDiffs && compareList.length >= 2 && count === maxCount && !compareList.every((v) => v.features.length === maxCount);

                  return (
                    <div
                      key={vehicle.id}
                      className={`px-5 py-4 border-r border-white/5 last:border-r-0 text-center ${
                        isBest ? 'text-neon-green' : 'text-white'
                      }`}
                    >
                      <span className="text-lg font-bold">{count}</span>
                      {isBest && (
                        <span className="ml-2 px-1.5 py-0.5 bg-neon-green/10 text-neon-green text-[10px] font-bold rounded uppercase tracking-wider">
                          Most
                        </span>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* Description comparison */}
        {compareList.some((v) => v.description) && (
          <div className="mt-10">
            <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
              <Car className="w-5 h-5 text-neon-orange" />
              Vehicle Descriptions
            </h2>

            <div className={`grid gap-4`} style={{ gridTemplateColumns: `repeat(${compareList.length}, 1fr)` }}>
              {compareList.map((vehicle) => (
                <div
                  key={vehicle.id}
                  className="p-5 bg-[#0a0a0a] rounded-2xl border border-white/5"
                >
                  <h4 className="text-white font-bold text-sm mb-3">
                    {vehicle.year} {vehicle.make} {vehicle.model}
                  </h4>
                  <p className="text-gray-400 text-sm leading-relaxed">
                    {vehicle.description || 'No description available. Contact us for more details about this vehicle.'}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Summary / Verdict section */}
        <div className="mt-10 p-6 md:p-8 bg-gradient-to-r from-neon-pink/5 via-neon-orange/5 to-neon-cyan/5 rounded-2xl border border-white/5">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <h3 className="text-2xl font-bold text-white mb-1">
                Ready to make a decision?
              </h3>
              <p className="text-gray-400">
                Contact us to schedule a test drive or get more information about any of these vehicles.
              </p>
            </div>
            <div className="flex gap-3 flex-shrink-0">
              <a
                href="tel:6313884426"
                className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-neon-pink to-neon-orange text-white font-bold rounded-xl hover:opacity-90 transition-opacity"
              >
                Call Now
              </a>
              <button
                onClick={() => {
                  navigate('/');
                  setTimeout(() => {
                    document.getElementById('inventory')?.scrollIntoView({ behavior: 'smooth' });
                  }, 100);
                }}
                className="flex items-center gap-2 px-6 py-3 border-2 border-neon-cyan/50 text-neon-cyan font-bold rounded-xl hover:bg-neon-cyan/10 transition-colors"
              >
                Browse More
              </button>
            </div>
          </div>
        </div>
      </div>

      <Footer />
      <ComparisonTray />
    </div>
  );
};

export default Compare;
