import React, { useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import Navbar from '@/components/dealership/Navbar';
import Footer from '@/components/dealership/Footer';
import { FileText, ArrowLeft, Mail, Phone, MapPin } from 'lucide-react';
import { usePageSEO } from '@/hooks/usePageSEO';


const LAST_UPDATED = 'March 23, 2026';

const TermsOfService: React.FC = () => {
  usePageSEO('terms');
  const navigate = useNavigate();


  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });
  }, []);

  return (
    <div className="min-h-screen bg-black text-white">
      <Navbar />

      {/* Hero Banner */}
      <section className="relative overflow-hidden pt-8 pb-16">
        {/* Background effects */}
        <div className="absolute inset-0 bg-gradient-to-b from-neon-cyan/5 via-transparent to-transparent" />
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-neon-cyan/5 rounded-full blur-[120px]" />
        <div className="absolute top-0 right-1/4 w-96 h-96 bg-neon-pink/5 rounded-full blur-[120px]" />

        <div className="relative max-w-4xl mx-auto px-4">
          {/* Back button */}
          <button
            onClick={() => navigate('/')}
            className="inline-flex items-center gap-2 text-gray-400 hover:text-neon-cyan transition-colors mb-8 group"
          >
            <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
            <span className="text-sm font-medium">Back to Home</span>
          </button>

          {/* Title */}
          <div className="flex items-center gap-4 mb-6">
            <div className="p-3 bg-gradient-to-br from-neon-cyan/20 to-neon-green/20 border border-neon-cyan/20 rounded-xl">
              <FileText className="w-8 h-8 text-neon-cyan" />
            </div>
            <div>
              <h1 className="text-3xl md:text-4xl lg:text-5xl font-black gradient-text-neon">
                Terms of Service
              </h1>
              <p className="text-gray-500 text-sm mt-1">
                Last Updated: {LAST_UPDATED}
              </p>
            </div>
          </div>

          <p className="text-gray-400 text-lg leading-relaxed max-w-3xl">
            Welcome to Ex$ell Car Sales LI. These Terms of Service ("Terms") govern your use of our website,
            services, and any vehicle purchase transactions conducted with us. By accessing or using our website
            and services, you agree to be bound by these Terms. Please read them carefully before using our
            services or completing any vehicle purchase.
          </p>
        </div>
      </section>

      {/* Divider */}
      <div className="max-w-4xl mx-auto px-4">
        <div className="h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
      </div>

      {/* Terms Content */}
      <section className="max-w-4xl mx-auto px-4 py-12">
        <div className="space-y-12">

          {/* Section 1 */}
          <TermsSection number="1" title="Acceptance of Terms">
            <p className="text-gray-400 leading-relaxed mb-4">
              By accessing, browsing, or using the Ex$ell Car Sales LI website ("Site") or purchasing any vehicle
              or service from us, you acknowledge that you have read, understood, and agree to be bound by these
              Terms of Service, along with our{' '}
              <Link to="/privacy-policy" className="text-neon-cyan hover:text-neon-pink transition-colors underline underline-offset-2">
                Privacy Policy
              </Link>
              , which is incorporated herein by reference.
            </p>
            <p className="text-gray-400 leading-relaxed">
              If you do not agree with any part of these Terms, you must discontinue use of our website and
              services immediately. We reserve the right to modify these Terms at any time, and your continued
              use of the Site following any changes constitutes your acceptance of the revised Terms.
            </p>
          </TermsSection>

          {/* Section 2 */}
          <TermsSection number="2" title="Vehicle Purchase Agreements">
            <p className="text-gray-400 leading-relaxed mb-4">
              All vehicle purchases from Ex$ell Car Sales LI are subject to the execution of a separate,
              written Vehicle Purchase Agreement at the time of sale. These Terms supplement, but do not replace,
              the specific terms outlined in any signed purchase agreement.
            </p>

            <TermsSubsection title="Purchase Process">
              <p className="text-gray-400 leading-relaxed">
                Vehicle purchases require in-person completion of all necessary documentation, including but not
                limited to: the Bill of Sale, title transfer documents, odometer disclosure statements, and any
                applicable state-required forms. No vehicle sale is considered final until all documents have been
                properly executed by both parties and full payment has been received and cleared.
              </p>
            </TermsSubsection>

            <TermsSubsection title="Pricing & Availability">
              <p className="text-gray-400 leading-relaxed">
                All vehicle prices displayed on our website are subject to change without notice and do not include
                applicable taxes, registration fees, title fees, documentation fees, or any other government or
                dealer fees unless explicitly stated. Vehicle availability is not guaranteed — all vehicles are
                sold on a first-come, first-served basis. A vehicle listed on our website may have been sold,
                reserved, or removed from inventory prior to your inquiry.
              </p>
            </TermsSubsection>


            <TermsSubsection title="Payment Terms">
              <p className="text-gray-400 leading-relaxed">
                We accept payment via certified bank check, cashier's check, cash (subject to applicable reporting
                requirements), and wire transfer. Personal checks may be accepted at our sole discretion and may
                require a hold period before vehicle delivery. All payments must clear before vehicle delivery or
                title transfer. Ex$ell Car Sales LI does not arrange, originate, or facilitate vehicle financing —
                buyers are solely responsible for securing any independent funding prior to purchase.
              </p>
            </TermsSubsection>

            <TermsSubsection title="Vehicle Delivery">
              <p className="text-gray-400 leading-relaxed">
                Vehicle delivery or pickup is arranged upon completion of all purchase documentation and receipt
                of full payment. Risk of loss and title to the vehicle pass to the buyer upon delivery. We may
                offer delivery services at an additional cost — delivery terms and fees will be agreed upon
                separately in writing.
              </p>
            </TermsSubsection>
          </TermsSection>

          {/* Section 3 */}
          <TermsSection number="3" title="As-Is Disclaimer for Pre-Owned Vehicles">
            <div className="bg-neon-orange/5 border border-neon-orange/20 rounded-xl p-5 mb-5">
              <p className="text-neon-orange font-bold text-sm uppercase tracking-wider mb-2">
                Important Notice
              </p>
              <p className="text-gray-300 leading-relaxed">
                Unless otherwise stated in writing at the time of sale, all pre-owned vehicles sold by Ex$ell
                Car Sales LI are sold <strong className="text-white">"AS-IS"</strong> with{' '}
                <strong className="text-white">no warranty</strong>, either expressed or implied, including but
                not limited to any implied warranty of merchantability or fitness for a particular purpose.
              </p>
            </div>

            <TermsSubsection title="Buyer's Responsibility">
              <p className="text-gray-400 leading-relaxed">
                The buyer assumes all risk as to the quality, condition, and performance of the vehicle upon
                delivery. We strongly recommend that all prospective buyers conduct an independent pre-purchase
                inspection by a qualified mechanic of their choosing prior to completing any purchase. We will
                make reasonable accommodations to facilitate such inspections upon request.
              </p>
            </TermsSubsection>

            <TermsSubsection title="Vehicle Condition Disclosure">
              <p className="text-gray-400 leading-relaxed">
                We make every reasonable effort to accurately describe the condition of each vehicle in our
                inventory, including known mechanical issues, cosmetic imperfections, and accident history as
                disclosed by available vehicle history reports. However, pre-owned vehicles may have undisclosed
                defects, prior damage, or mechanical issues that are not immediately apparent. Vehicle descriptions,
                photographs, and mileage listed on our website are believed to be accurate at the time of listing
                but are not guaranteed.
              </p>
            </TermsSubsection>

            <TermsSubsection title="Vehicle History Reports">
              <p className="text-gray-400 leading-relaxed">
                Vehicle history reports (e.g., Carfax, AutoCheck) may be provided as a courtesy and for
                informational purposes only. These reports are generated by third-party providers and Ex$ell Car
                Sales LI makes no representations or warranties regarding the accuracy, completeness, or
                reliability of any information contained in such reports. A clean vehicle history report does not
                guarantee that a vehicle is free from defects or has not been in an unreported accident.
              </p>
            </TermsSubsection>

            <TermsSubsection title="No Return Policy">
              <p className="text-gray-400 leading-relaxed">
                All sales are final. Unless required by applicable law or agreed upon in a separate written
                agreement, we do not accept returns, offer refunds, or provide exchanges on any vehicle purchase.
                Buyers are encouraged to thoroughly inspect and test-drive any vehicle before completing the
                purchase.
              </p>
            </TermsSubsection>

            <TermsSubsection title="Extended Warranties">
              <p className="text-gray-400 leading-relaxed">
                Third-party extended warranty or vehicle service contracts may be available for purchase at the
                time of sale. Any such warranty is provided by the third-party warranty company and is subject
                to that company's terms, conditions, and coverage limitations. Ex$ell Car Sales LI is not
                responsible for claims, coverage disputes, or obligations under any third-party warranty.
              </p>
            </TermsSubsection>
          </TermsSection>

          {/* Section 4 */}
          <TermsSection number="4" title="Service Disclosures: As-Is Sales, History Reports & Detailing">
            <p className="text-gray-400 leading-relaxed mb-4">
              Ex$ell Car Sales LI focuses on three core offerings: quality pre-owned vehicle sales, vehicle
              history report transparency, and professional detailing services. The disclosures below clarify
              the scope, limitations, and buyer responsibilities associated with each.
            </p>

            <TermsSubsection title="As-Is Pre-Owned Vehicle Purchases">
              <p className="text-gray-400 leading-relaxed">
                As outlined in Section 3, all pre-owned vehicles are sold strictly on an{' '}
                <strong className="text-white">"AS-IS"</strong> basis unless a separate written agreement
                expressly states otherwise. Ex$ell Car Sales LI does not provide manufacturer warranties,
                certified pre-owned (CPO) coverage, or any implied guarantee regarding the future performance
                or longevity of any vehicle. Buyers are responsible for evaluating each vehicle's condition
                — including by independent pre-purchase inspection — before completing the sale, and accept
                full ownership risk upon delivery. We do not provide vehicle financing, loan origination, or
                lender referral services of any kind, and any independent funding required to complete a
                purchase is the sole responsibility of the buyer.
              </p>
            </TermsSubsection>

            <TermsSubsection title="Vehicle History Report Disclosures">
              <p className="text-gray-400 leading-relaxed">
                When available, we provide third-party vehicle history reports (e.g., Carfax, AutoCheck) as a
                courtesy to support informed buying decisions. These reports are produced by independent
                providers using data sourced from insurance companies, state DMVs, repair facilities, and
                other reporting entities. Ex$ell Car Sales LI does not author, control, or verify the
                underlying data and makes no representation that any history report is complete, current, or
                free of errors. Events that were never reported to a participating database — including
                unreported accidents, off-record repairs, or undisclosed prior use — may not appear on the
                report. Buyers are encouraged to review each history report carefully and to ask our team
                about any disclosed events prior to purchase.
              </p>
            </TermsSubsection>

            <TermsSubsection title="Professional Detailing Services">
              <p className="text-gray-400 leading-relaxed">
                Detailing services — whether performed on a vehicle being purchased from us or on a customer's
                own vehicle — are provided on a best-efforts basis using industry-standard products and
                techniques. Results may vary based on the vehicle's age, paint condition, prior care, interior
                materials, and the extent of pre-existing damage, staining, oxidation, or wear. We do not
                guarantee removal of every blemish, odor, scratch, swirl mark, or stain, and we are not
                responsible for cosmetic or mechanical issues that pre-existed the service. Specific service
                packages, pricing, turnaround times, and any limited service-specific guarantees will be
                confirmed in writing at the time of booking. Customers are responsible for removing personal
                belongings prior to service; Ex$ell Car Sales LI is not liable for items left in the vehicle.
              </p>
            </TermsSubsection>

            <TermsSubsection title="No Financial Services">
              <p className="text-gray-400 leading-relaxed">
                Ex$ell Car Sales LI is not a lender, broker, or financial institution and does not advertise,
                arrange, or refer customers to financing, loan, or credit products. Any references to
                financing on this Site, in customer communications, or in legacy materials should be
                disregarded. Buyers are solely responsible for arranging any independent funding through a
                lender of their own choosing prior to completing a purchase.
              </p>
            </TermsSubsection>
          </TermsSection>

          {/* Section 5 */}
          <TermsSection number="5" title="Limitation of Liability">
            <p className="text-gray-400 leading-relaxed mb-4">
              To the fullest extent permitted by applicable law, Ex$ell Car Sales LI, its owners, officers,
              employees, agents, and affiliates shall not be liable for any indirect, incidental, special,
              consequential, or punitive damages, including but not limited to:
            </p>
            <ul className="space-y-3 mb-5">
              {[
                'Loss of profits, revenue, data, or business opportunities.',
                'Vehicle breakdowns, mechanical failures, or defects discovered after the sale of an as-is vehicle.',
                'Any damages arising from your reliance on information provided on our website or by our staff.',
                'Damages resulting from unauthorized access to or alteration of your transmissions or data.',
                'Any actions, omissions, or decisions made by third-party warranty providers, history report providers, or independent service companies.',
                'Delays in vehicle delivery, title processing, or registration caused by third parties or government agencies.',
                'Inaccuracies in third-party vehicle history reports.',
                'Personal injury or property damage occurring during test drives, except where caused by our gross negligence.',
              ].map((item, i) => (
                <li key={i} className="flex items-start gap-3 text-gray-400">
                  <span className="mt-2 w-1.5 h-1.5 rounded-full bg-neon-orange flex-shrink-0" />
                  <span className="leading-relaxed">{item}</span>
                </li>
              ))}
            </ul>

            <TermsSubsection title="Maximum Liability">
              <p className="text-gray-400 leading-relaxed">
                In no event shall our total aggregate liability to you for all claims arising out of or relating
                to these Terms, our website, or any vehicle purchase exceed the total amount you paid to Ex$ell
                Car Sales LI for the specific vehicle or service giving rise to the claim.
              </p>
            </TermsSubsection>

            <TermsSubsection title="Assumption of Risk">
              <p className="text-gray-400 leading-relaxed">
                You acknowledge that purchasing a pre-owned vehicle involves inherent risks, including the
                possibility of undiscovered mechanical issues, prior damage, or other defects. By completing a
                purchase, you voluntarily assume these risks and agree that Ex$ell Car Sales LI shall not be
                held liable for any such issues unless they were knowingly concealed in violation of applicable
                law.
              </p>
            </TermsSubsection>
          </TermsSection>

          {/* Section 6 */}
          <TermsSection number="6" title="Dispute Resolution">
            <p className="text-gray-400 leading-relaxed mb-4">
              We are committed to resolving any disputes fairly and efficiently. In the event of a disagreement
              or claim arising out of or relating to these Terms, any vehicle purchase, or our services, the
              following dispute resolution procedures shall apply:
            </p>

            <TermsSubsection title="Informal Resolution">
              <p className="text-gray-400 leading-relaxed">
                Before initiating any formal dispute resolution process, you agree to first contact us directly
                to attempt to resolve the matter informally. You may reach us by phone at (631) 388-4426 or by
                email at info@exsellsalesli.com. We will make good-faith efforts to resolve your concern within
                thirty (30) business days of receiving your written notice of the dispute.
              </p>
            </TermsSubsection>

            <TermsSubsection title="Mediation">
              <p className="text-gray-400 leading-relaxed">
                If informal resolution is unsuccessful, either party may request non-binding mediation before a
                mutually agreed-upon mediator in Suffolk County, New York. The costs of mediation shall be shared
                equally between the parties unless otherwise agreed. Mediation must be attempted in good faith
                before either party may proceed to binding arbitration or litigation.
              </p>
            </TermsSubsection>

            <TermsSubsection title="Binding Arbitration">
              <p className="text-gray-400 leading-relaxed">
                If mediation fails to resolve the dispute, either party may elect to submit the dispute to
                binding arbitration administered by the American Arbitration Association ("AAA") under its
                Consumer Arbitration Rules. The arbitration shall take place in Suffolk County, New York. The
                arbitrator's decision shall be final and binding and may be entered as a judgment in any court
                of competent jurisdiction. Each party shall bear its own costs and attorney's fees unless the
                arbitrator determines otherwise.
              </p>
            </TermsSubsection>

            <TermsSubsection title="Class Action Waiver">
              <p className="text-gray-400 leading-relaxed">
                You agree that any dispute resolution proceedings will be conducted only on an individual basis
                and not in a class, consolidated, or representative action. You waive any right to participate
                in a class action lawsuit or class-wide arbitration against Ex$ell Car Sales LI.
              </p>
            </TermsSubsection>

            <TermsSubsection title="Governing Law">
              <p className="text-gray-400 leading-relaxed">
                These Terms and any disputes arising hereunder shall be governed by and construed in accordance
                with the laws of the State of New York, without regard to its conflict of law provisions. For
                any matters not subject to arbitration, you consent to the exclusive jurisdiction of the state
                and federal courts located in Suffolk County, New York.
              </p>
            </TermsSubsection>

            <TermsSubsection title="Statute of Limitations">
              <p className="text-gray-400 leading-relaxed">
                Any claim or cause of action arising out of or relating to these Terms or your use of our
                services must be filed within one (1) year after the cause of action accrues. Failure to file
                within this period shall constitute a permanent waiver of such claim.
              </p>
            </TermsSubsection>
          </TermsSection>

          {/* Section 7 */}
          <TermsSection number="7" title="Website Usage Terms">
            <p className="text-gray-400 leading-relaxed mb-4">
              The following terms govern your use of the Ex$ell Car Sales LI website:
            </p>

            <TermsSubsection title="Intellectual Property">
              <p className="text-gray-400 leading-relaxed">
                All content on this website — including but not limited to text, graphics, logos, images,
                photographs, vehicle descriptions, software, and design elements — is the property of Ex$ell
                Car Sales LI or its content suppliers and is protected by United States and international
                copyright, trademark, and other intellectual property laws. You may not reproduce, distribute,
                modify, create derivative works from, publicly display, or otherwise use any content from this
                website without our prior written consent.
              </p>
            </TermsSubsection>

            <TermsSubsection title="Accuracy of Information">
              <p className="text-gray-400 leading-relaxed">
                While we strive to ensure that all information on our website is accurate and up to date, we
                make no warranties or representations regarding the accuracy, completeness, or reliability of
                any content, including vehicle descriptions, pricing, specifications, photographs, mileage, or
                availability. Errors may occur, and information may change without notice. Always verify vehicle
                details directly with our sales team before making a purchase decision.
              </p>
            </TermsSubsection>

            <TermsSubsection title="Prohibited Uses">
              <p className="text-gray-400 leading-relaxed mb-3">
                You agree not to use our website for any unlawful purpose or in any way that could damage,
                disable, overburden, or impair our servers or network. Prohibited activities include but are
                not limited to:
              </p>
              <ul className="space-y-3">
                {[
                  'Scraping, crawling, or using automated tools to extract data or content from our website without written permission.',
                  'Attempting to gain unauthorized access to our systems, user accounts, or computer networks.',
                  'Transmitting any viruses, malware, worms, or other malicious code.',
                  'Using the website to harass, abuse, or harm another person or entity.',
                  'Impersonating any person or entity or misrepresenting your affiliation with any person or entity.',
                  'Interfering with or disrupting the integrity or performance of the website.',
                  'Posting or transmitting any false, misleading, or fraudulent information.',
                  'Using our website for any commercial purpose without our express written consent.',
                ].map((item, i) => (
                  <li key={i} className="flex items-start gap-3 text-gray-400">
                    <span className="mt-2 w-1.5 h-1.5 rounded-full bg-neon-pink flex-shrink-0" />
                    <span className="leading-relaxed">{item}</span>
                  </li>
                ))}
              </ul>
            </TermsSubsection>

            <TermsSubsection title="User-Submitted Content">
              <p className="text-gray-400 leading-relaxed">
                By submitting any content to our website — including reviews, comments, inquiries, or
                photographs — you grant Ex$ell Car Sales LI a non-exclusive, royalty-free, perpetual,
                irrevocable, and fully sublicensable right to use, reproduce, modify, adapt, publish, translate,
                create derivative works from, distribute, and display such content in any media. You represent
                and warrant that you own or control all rights to the content you submit and that such content
                does not violate any third party's rights.
              </p>
            </TermsSubsection>

            <TermsSubsection title="Third-Party Links">
              <p className="text-gray-400 leading-relaxed">
                Our website may contain links to third-party websites, services, or resources. These links are
                provided for your convenience only and do not imply endorsement or affiliation. We have no
                control over the content, privacy policies, or practices of any third-party websites and assume
                no responsibility or liability for them. Your use of third-party websites is at your own risk.
              </p>
            </TermsSubsection>

            <TermsSubsection title="Account Security">
              <p className="text-gray-400 leading-relaxed">
                If you create an account on our website, you are responsible for maintaining the confidentiality
                of your login credentials and for all activities that occur under your account. You agree to
                notify us immediately of any unauthorized use of your account or any other breach of security.
                We are not liable for any loss or damage arising from your failure to protect your account
                information.
              </p>
            </TermsSubsection>
          </TermsSection>

          {/* Section 8 */}
          <TermsSection number="8" title="Test Drive Policy">
            <p className="text-gray-400 leading-relaxed mb-4">
              Test drives are available by appointment and are subject to the following conditions:
            </p>
            <ul className="space-y-3">
              {[
                'You must possess a valid, unexpired driver\'s license issued by a U.S. state or territory.',
                'You must provide proof of valid auto insurance that covers the operation of non-owned vehicles.',
                'A copy of your driver\'s license will be retained on file for security purposes.',
                'Test drives are conducted at the sole discretion of Ex$ell Car Sales LI and may be denied for any reason.',
                'You agree to operate the vehicle in a safe, lawful manner and are responsible for any traffic violations, fines, or damages incurred during the test drive.',
                'An Ex$ell Car Sales LI representative may accompany you during the test drive.',
                'Test drive routes and duration are determined at our discretion.',
              ].map((item, i) => (
                <li key={i} className="flex items-start gap-3 text-gray-400">
                  <span className="mt-2 w-1.5 h-1.5 rounded-full bg-neon-cyan flex-shrink-0" />
                  <span className="leading-relaxed">{item}</span>
                </li>
              ))}
            </ul>
          </TermsSection>

          {/* Section 9 */}
          <TermsSection number="9" title="Trade-In Policy">
            <p className="text-gray-400 leading-relaxed mb-4">
              We may accept vehicle trade-ins at our sole discretion, subject to the following:
            </p>

            <TermsSubsection title="Valuation">
              <p className="text-gray-400 leading-relaxed">
                Trade-in values are determined based on our assessment of the vehicle's condition, mileage,
                market demand, and other relevant factors. Any trade-in value offered is valid only at the time
                of the offer and may change based on a physical inspection of the vehicle. Online or phone
                estimates are preliminary and non-binding.
              </p>
            </TermsSubsection>

            <TermsSubsection title="Title & Lien Requirements">
              <p className="text-gray-400 leading-relaxed">
                You must provide a clear title to any trade-in vehicle. If there is an outstanding lien on the
                vehicle, you are responsible for providing a payoff amount and facilitating the lien release.
                Trade-in transactions may be delayed until lien satisfaction is confirmed.
              </p>
            </TermsSubsection>

            <TermsSubsection title="Disclosure Obligations">
              <p className="text-gray-400 leading-relaxed">
                You represent and warrant that all information provided about your trade-in vehicle — including
                its condition, accident history, mechanical issues, and title status — is truthful and accurate.
                Failure to disclose material defects or title issues may void the trade-in agreement and result
                in legal action.
              </p>
            </TermsSubsection>
          </TermsSection>

          {/* Section 10 */}
          <TermsSection number="10" title="Indemnification">
            <p className="text-gray-400 leading-relaxed">
              You agree to indemnify, defend, and hold harmless Ex$ell Car Sales LI, its owners, officers,
              directors, employees, agents, and affiliates from and against any and all claims, damages,
              obligations, losses, liabilities, costs, or debt, and expenses (including but not limited to
              attorney's fees) arising from: (a) your use of and access to the website; (b) your violation of
              any term of these Terms; (c) your violation of any third-party right, including without limitation
              any copyright, property, or privacy right; (d) any claim that your submitted content caused damage
              to a third party; or (e) any vehicle purchase, history report use, detailing service, or other
              transaction with us, including disputes with third-party warranty providers, history report
              providers, or independent service companies. This indemnification obligation will survive the
              termination of these Terms
              and your use of our website.
            </p>
          </TermsSection>

          {/* Section 11 */}
          <TermsSection number="11" title="Disclaimer of Warranties">
            <div className="bg-white/[0.02] border border-white/10 rounded-xl p-5 mb-5">
              <p className="text-gray-300 leading-relaxed">
                THE WEBSITE AND ALL CONTENT, MATERIALS, INFORMATION, AND SERVICES PROVIDED ON OR THROUGH THE
                WEBSITE ARE PROVIDED ON AN <strong className="text-white">"AS IS"</strong> AND{' '}
                <strong className="text-white">"AS AVAILABLE"</strong> BASIS WITHOUT WARRANTIES OF ANY KIND,
                EITHER EXPRESS OR IMPLIED. TO THE FULLEST EXTENT PERMISSIBLE UNDER APPLICABLE LAW, EX$ELL CAR
                SALES LI DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED
                WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE, AND NON-INFRINGEMENT.
              </p>
            </div>
            <p className="text-gray-400 leading-relaxed">
              We do not warrant that the website will be uninterrupted, error-free, secure, or free of viruses
              or other harmful components. We do not warrant the accuracy or completeness of any information,
              text, graphics, links, or other items contained on the website. We make no warranties about the
              suitability, reliability, availability, timeliness, or accuracy of the website for any purpose.
            </p>
          </TermsSection>

          {/* Section 12 */}
          <TermsSection number="12" title="Severability">
            <p className="text-gray-400 leading-relaxed">
              If any provision of these Terms is found to be invalid, illegal, or unenforceable by a court of
              competent jurisdiction, such invalidity, illegality, or unenforceability shall not affect any other
              provision of these Terms, which shall remain in full force and effect. The invalid or unenforceable
              provision shall be modified to the minimum extent necessary to make it valid, legal, and
              enforceable while preserving its original intent.
            </p>
          </TermsSection>

          {/* Section 13 */}
          <TermsSection number="13" title="Entire Agreement">
            <p className="text-gray-400 leading-relaxed">
              These Terms, together with our{' '}
              <Link to="/privacy-policy" className="text-neon-cyan hover:text-neon-pink transition-colors underline underline-offset-2">
                Privacy Policy
              </Link>{' '}
              and any separate Vehicle Purchase Agreement executed at the time of sale, constitute the entire
              agreement between you and Ex$ell Car Sales LI regarding your use of the website and our services.
              These Terms supersede all prior or contemporaneous communications, proposals, and agreements,
              whether electronic, oral, or written, between you and Ex$ell Car Sales LI with respect to the
              website. A printed version of these Terms and of any notice given in electronic form shall be
              admissible in judicial or administrative proceedings based upon or relating to these Terms to the
              same extent and subject to the same conditions as other business documents and records originally
              generated and maintained in printed form.
            </p>
          </TermsSection>

          {/* Section 14 */}
          <TermsSection number="14" title="Changes to These Terms">
            <p className="text-gray-400 leading-relaxed">
              We reserve the right to update, change, or replace any part of these Terms of Service at our sole
              discretion by posting updates and/or changes to our website. It is your responsibility to check
              this page periodically for changes. Your continued use of or access to the website following the
              posting of any changes constitutes acceptance of those changes. We will indicate the date of the
              most recent revision at the top of this page.
            </p>
          </TermsSection>

          {/* Section 15 - Contact */}
          <TermsSection number="15" title="Contact Us">
            <p className="text-gray-400 leading-relaxed mb-6">
              If you have any questions about these Terms of Service, please contact us:
            </p>

            <div className="bg-white/[0.02] border border-white/10 rounded-xl p-6 space-y-4">
              <h4 className="text-white font-bold text-lg gradient-text-neon">
                Ex$ell Car Sales LI
              </h4>
              <div className="space-y-3">
                <a
                  href="mailto:info@exsellsalesli.com"
                  className="flex items-center gap-3 text-gray-400 hover:text-neon-cyan transition-colors group"
                >
                  <Mail className="w-4 h-4 text-neon-cyan group-hover:scale-110 transition-transform" />
                  <span>info@exsellsalesli.com</span>
                </a>
                <a
                  href="tel:6313884426"
                  className="flex items-center gap-3 text-gray-400 hover:text-neon-green transition-colors group"
                >
                  <Phone className="w-4 h-4 text-neon-green group-hover:scale-110 transition-transform" />
                  <span>(631) 388-4426</span>
                </a>
                <div className="flex items-center gap-3 text-gray-400">
                  <MapPin className="w-4 h-4 text-neon-orange" />
                  <span>Long Island, New York</span>
                </div>
              </div>

              <div className="pt-4 border-t border-white/5">
                <a
                  href="https://exsellsalesli.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-neon-pink hover:text-neon-orange transition-colors text-sm font-medium"
                >
                  www.exsellsalesli.com
                </a>
              </div>
            </div>
          </TermsSection>

        </div>
      </section>

      {/* Bottom CTA */}
      <section className="max-w-4xl mx-auto px-4 pb-16">
        <div className="h-px bg-gradient-to-r from-transparent via-white/10 to-transparent mb-8" />
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-gray-500 text-sm">
            These terms were last updated on {LAST_UPDATED}.
          </p>
          <div className="flex items-center gap-3">
            <Link
              to="/privacy-policy"
              className="inline-flex items-center gap-2 px-5 py-2.5 border border-white/10 text-gray-400 hover:text-neon-cyan hover:border-neon-cyan/30 font-bold text-sm rounded-lg transition-all"
            >
              Privacy Policy
            </Link>
            <button
              onClick={() => navigate('/')}
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-neon-pink to-neon-orange text-white font-bold text-sm rounded-lg hover:opacity-90 transition-opacity"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Home
            </button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

/* ─── Sub-components ─── */

interface TermsSectionProps {
  number: string;
  title: string;
  children: React.ReactNode;
}

const TermsSection: React.FC<TermsSectionProps> = ({ number, title, children }) => (
  <div>
    <div className="flex items-baseline gap-3 mb-4">
      <span className="text-neon-cyan font-mono text-sm font-bold opacity-60">{number.padStart(2, '0')}</span>
      <h2 className="text-xl md:text-2xl font-bold text-white">{title}</h2>
    </div>
    <div className="pl-0 md:pl-10">{children}</div>
  </div>
);

interface TermsSubsectionProps {
  title: string;
  children: React.ReactNode;
}

const TermsSubsection: React.FC<TermsSubsectionProps> = ({ title, children }) => (
  <div className="mt-5">
    <h3 className="text-white font-semibold mb-2 flex items-center gap-2">
      <span className="w-6 h-px bg-gradient-to-r from-neon-cyan to-transparent" />
      {title}
    </h3>
    {children}
  </div>
);

export default TermsOfService;
