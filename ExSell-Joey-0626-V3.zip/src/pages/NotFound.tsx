import { useLocation } from "react-router-dom";
import { useEffect } from "react";
import { Home, Phone } from "lucide-react";

const LOGO_URL = 'https://d64gsuwffb70l.cloudfront.net/6917af11eb66b8b0c2b0bc86_1774223659449_0339845b.jpg';

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname
    );
  }, [location.pathname]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-black px-4">
      <div className="text-center space-y-8 animate-slide-in">
        {/* Dominant logo */}
        <div className="relative inline-block mx-auto">
          <div className="absolute -inset-6 bg-gradient-to-br from-neon-pink/25 via-neon-orange/20 to-neon-cyan/25 rounded-2xl blur-2xl opacity-80" />
          <div className="absolute -inset-1.5 rounded-xl bg-gradient-to-br from-neon-pink via-neon-orange to-neon-cyan p-[2px]">
            <div className="w-full h-full rounded-xl bg-black" />
          </div>
          <img
            src={LOGO_URL}
            alt="Ex$ell Car Sales"
            className="relative h-32 md:h-40 w-auto mx-auto rounded-xl shadow-xl shadow-neon-pink/15 z-10"
          />
        </div>
        <h1 className="text-7xl font-display font-bold gradient-text-neon">404</h1>
        <p className="text-xl text-gray-400">
          Looks like this page took a wrong turn!
        </p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <a
            href="/"
            className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-neon-pink to-neon-orange text-white font-bold rounded-xl hover:opacity-90 transition-opacity"
          >
            <Home className="w-5 h-5" />
            Back to Home
          </a>
          <a
            href="tel:6313884426"
            className="inline-flex items-center gap-2 px-6 py-3 border-2 border-neon-cyan/50 text-neon-cyan font-bold rounded-xl hover:bg-neon-cyan/10 transition-colors"
          >
            <Phone className="w-5 h-5" />
            Call Us
          </a>
        </div>
      </div>
    </div>
  );
};

export default NotFound;
