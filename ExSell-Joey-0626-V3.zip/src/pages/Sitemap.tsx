import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import {
  Globe, ExternalLink, FileText, Car, Loader2, AlertCircle, MapPin,
  Star, MessageSquare, ChevronRight, Image as ImageIcon, Layers,
} from 'lucide-react';
import GoogleReviewBadge from '@/components/dealership/GoogleReviewBadge';
import { fetchVehicles, type Vehicle } from '@/data/vehicles';

interface SitemapImage {
  loc: string;
  title?: string;
  caption?: string;
}

interface SitemapUrl {
  loc: string;
  lastmod: string;
  changefreq: string;
  priority: string;
  images: SitemapImage[];
}

// Ensure /reviews is always represented in the sitemap view with priority 0.8
// and a weekly changefreq. Defensive augmentation in case the edge function
// ever returns a weaker entry.
const REVIEWS_SITEMAP_ENTRY = {
  path: '/reviews',
  priority: '0.8',
  changefreq: 'weekly',
};

export default function Sitemap() {
  const [urls, setUrls] = useState<SitemapUrl[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [generatedAt, setGeneratedAt] = useState('');

  // Vehicle data powers the HTML sitemap grouped by body type. We fetch in
  // parallel with the XML so the live DB data and the XML stay consistent.
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [vehiclesLoading, setVehiclesLoading] = useState(true);

  useEffect(() => {
    document.title = 'Sitemap | Ex$ell Car Sales LI';
    fetchSitemap();
    fetchVehicles()
      .then((v) => setVehicles(v))
      .catch(() => setVehicles([]))
      .finally(() => setVehiclesLoading(false));
  }, []);

  async function fetchSitemap() {
    try {
      const siteUrl = window.location.origin;
      const { data, error: fnError } = await supabase.functions.invoke('generate-sitemap', {
        body: {},
        headers: { origin: siteUrl },
      });

      if (fnError) throw fnError;

      const xmlStr = typeof data === 'string' ? data : '';
      if (!xmlStr) throw new Error('Empty response');

      const parser = new DOMParser();
      const doc = parser.parseFromString(xmlStr, 'application/xml');
      const urlElements = doc.querySelectorAll('url');
      const parsed: SitemapUrl[] = [];

      urlElements.forEach((el) => {
        // Parse nested <image:image> blocks. getElementsByTagNameNS with the
        // image sitemap namespace is the robust way across browsers; getElementsByTagName
        // with the local name also works in most DOMParser implementations.
        const imageElements = Array.from(el.getElementsByTagNameNS('*', 'image')).filter(
          (n) => n.nodeType === 1 && (n as Element).tagName.toLowerCase().endsWith('image')
        );
        const images: SitemapImage[] = imageElements
          .map((imgEl) => {
            const loc =
              imgEl.getElementsByTagNameNS('*', 'loc')[0]?.textContent?.trim() ||
              imgEl.querySelector('loc')?.textContent?.trim() ||
              '';
            const title =
              imgEl.getElementsByTagNameNS('*', 'title')[0]?.textContent?.trim() ||
              imgEl.querySelector('title')?.textContent?.trim() ||
              '';
            const caption =
              imgEl.getElementsByTagNameNS('*', 'caption')[0]?.textContent?.trim() ||
              imgEl.querySelector('caption')?.textContent?.trim() ||
              '';
            return loc ? { loc, title, caption } : null;
          })
          .filter((x): x is SitemapImage => !!x);

        parsed.push({
          loc: el.querySelector('loc')?.textContent || '',
          lastmod: el.querySelector('lastmod')?.textContent || '',
          changefreq: el.querySelector('changefreq')?.textContent || '',
          priority: el.querySelector('priority')?.textContent || '',
          images,
        });
      });

      // Defensive augmentation of /reviews entry.
      const reviewsIdx = parsed.findIndex((u) => {
        try {
          return new URL(u.loc).pathname.replace(/\/$/, '') === REVIEWS_SITEMAP_ENTRY.path;
        } catch {
          return u.loc.endsWith(REVIEWS_SITEMAP_ENTRY.path);
        }
      });
      const today = new Date().toISOString().slice(0, 10);
      const reviewsLoc = `${siteUrl}${REVIEWS_SITEMAP_ENTRY.path}`;
      if (reviewsIdx === -1) {
        parsed.push({
          loc: reviewsLoc,
          lastmod: today,
          changefreq: REVIEWS_SITEMAP_ENTRY.changefreq,
          priority: REVIEWS_SITEMAP_ENTRY.priority,
          images: [],
        });
      } else {
        const current = parsed[reviewsIdx];
        if (parseFloat(current.priority || '0') < parseFloat(REVIEWS_SITEMAP_ENTRY.priority)) {
          current.priority = REVIEWS_SITEMAP_ENTRY.priority;
        }
        if (!current.changefreq) {
          current.changefreq = REVIEWS_SITEMAP_ENTRY.changefreq;
        }
      }

      setUrls(parsed);

      const tsMatch = xmlStr.match(/Last generated: ([^\s]+)/);
      if (tsMatch) setGeneratedAt(tsMatch[1]);
    } catch (e: any) {
      console.error('Sitemap fetch error:', e);
      setError(e.message || 'Failed to load sitemap');
    } finally {
      setLoading(false);
    }
  }

  const staticUrls = urls.filter((u) => !u.loc.includes('/inventory/'));
  const vehicleUrls = urls.filter((u) => u.loc.includes('/inventory/'));

  // Group live vehicles by body type for the human-readable HTML sitemap.
  const vehiclesByBodyType = useMemo(() => {
    const groups = new Map<string, Vehicle[]>();
    for (const v of vehicles) {
      if (v.status !== 'available') continue;
      const key = v.bodyType || 'Other';
      const arr = groups.get(key) || [];
      arr.push(v);
      groups.set(key, arr);
    }
    // Sort groups alphabetically, and vehicles within each group by year desc.
    return Array.from(groups.entries())
      .map(([bodyType, list]) => ({
        bodyType,
        vehicles: list.sort((a, b) => b.year - a.year || a.make.localeCompare(b.make)),
      }))
      .sort((a, b) => a.bodyType.localeCompare(b.bodyType));
  }, [vehicles]);

  const totalAvailable = vehiclesByBodyType.reduce((sum, g) => sum + g.vehicles.length, 0);

  const priorityColor = (p: string) => {
    const n = parseFloat(p);
    if (n >= 0.8) return 'text-green-400 bg-green-400/10 border-green-400/20';
    if (n >= 0.5) return 'text-yellow-400 bg-yellow-400/10 border-yellow-400/20';
    return 'text-zinc-400 bg-zinc-400/10 border-zinc-400/20';
  };

  const freqColor = (f: string) => {
    if (f === 'daily') return 'text-cyan-400';
    if (f === 'weekly') return 'text-blue-400';
    if (f === 'monthly') return 'text-purple-400';
    return 'text-zinc-500';
  };

  // Body-type accent palette to visually distinguish each group.
  const bodyTypeAccent: Record<string, string> = {
    SUV: 'from-orange-500/10 border-orange-400/20 text-orange-300',
    Sedan: 'from-cyan-500/10 border-cyan-400/20 text-cyan-300',
    Coupe: 'from-pink-500/10 border-pink-400/20 text-pink-300',
    Minivan: 'from-purple-500/10 border-purple-400/20 text-purple-300',
    Truck: 'from-yellow-500/10 border-yellow-400/20 text-yellow-300',
    Hatchback: 'from-emerald-500/10 border-emerald-400/20 text-emerald-300',
  };
  const accentFor = (bt: string) =>
    bodyTypeAccent[bt] || 'from-zinc-500/10 border-zinc-400/20 text-zinc-300';

  return (
    <div className="min-h-screen bg-gradient-to-b from-zinc-950 via-zinc-900 to-zinc-950 text-white">
      {/* Header */}
      <div className="border-b border-zinc-800 bg-zinc-950/80 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-5xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link to="/" className="text-sm text-zinc-400 hover:text-white transition-colors flex items-center gap-2">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
            Back to Site
          </Link>
          <div className="flex items-center gap-2 text-zinc-500 text-xs">
            <Globe className="w-3.5 h-3.5" />
            XML + HTML Sitemap
          </div>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 py-10">
        {/* Title */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-3">
            <div className="p-2.5 rounded-xl bg-gradient-to-br from-cyan-500/20 to-blue-500/20 border border-cyan-500/20">
              <MapPin className="w-6 h-6 text-cyan-400" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">Sitemap</h1>
              <p className="text-zinc-500 text-sm">Ex$ell Car Sales LI — All indexed pages + every live vehicle detail page</p>
            </div>
          </div>
          {generatedAt && (
            <p className="text-xs text-zinc-600 mt-2">XML last generated: {new Date(generatedAt).toLocaleString()}</p>
          )}
        </div>

        {/* Featured page card: /reviews with live Google rating badge */}
        <Link
          to="/reviews"
          className="mb-8 group block p-5 rounded-2xl bg-gradient-to-br from-orange-500/10 via-yellow-500/5 to-transparent border border-orange-500/20 hover:border-orange-400/40 transition-all"
        >
          <div className="flex flex-col md:flex-row items-start md:items-center gap-4">
            <div className="p-3 rounded-xl bg-gradient-to-br from-orange-500/20 to-yellow-500/10 border border-orange-500/20 flex-shrink-0">
              <MessageSquare className="w-6 h-6 text-orange-400" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap mb-1">
                <h3 className="text-lg font-bold text-white group-hover:text-orange-200 transition-colors">
                  Customer Reviews
                </h3>
                <span className="text-xs px-2 py-0.5 rounded-full border border-green-400/30 bg-green-400/10 text-green-400 font-mono">
                  priority 0.8
                </span>
                <span className="text-xs px-2 py-0.5 rounded-full border border-blue-400/30 bg-blue-400/10 text-blue-400 font-mono">
                  weekly
                </span>
              </div>
              <p className="text-sm text-zinc-400 mb-2">
                Live customer reviews pulled from Google Business Profile — rich-result eligible with AggregateRating structured data.
              </p>
              <div className="flex items-center gap-3 flex-wrap">
                <GoogleReviewBadge variant="compact" showSkeleton />
                <span className="text-xs text-zinc-500 font-mono truncate">
                  {window.location.origin}/reviews
                </span>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-orange-400 group-hover:translate-x-1 transition-transform flex-shrink-0 hidden md:block" />
          </div>
        </Link>

        {loading && (
          <div className="flex items-center justify-center py-20 gap-3 text-zinc-400">
            <Loader2 className="w-5 h-5 animate-spin" />
            Loading sitemap...
          </div>
        )}

        {error && (
          <div className="flex items-center gap-3 p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400">
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
            <p className="text-sm">{error}</p>
          </div>
        )}

        {!loading && !error && (
          <>
            {/* Summary */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
              <div className="p-4 rounded-xl bg-zinc-800/50 border border-zinc-700/50 text-center">
                <p className="text-2xl font-bold text-white">{urls.length}</p>
                <p className="text-xs text-zinc-500 mt-1">Total URLs</p>
              </div>
              <div className="p-4 rounded-xl bg-zinc-800/50 border border-zinc-700/50 text-center">
                <p className="text-2xl font-bold text-cyan-400">{staticUrls.length}</p>
                <p className="text-xs text-zinc-500 mt-1">Static Pages</p>
              </div>
              <div className="p-4 rounded-xl bg-zinc-800/50 border border-zinc-700/50 text-center">
                <p className="text-2xl font-bold text-orange-400">{vehicleUrls.length}</p>
                <p className="text-xs text-zinc-500 mt-1">Vehicle Pages</p>
              </div>
              <div className="p-4 rounded-xl bg-zinc-800/50 border border-zinc-700/50 text-center">
                <p className="text-2xl font-bold text-pink-400">
                  {vehicleUrls.reduce((sum, u) => sum + u.images.length, 0)}
                </p>
                <p className="text-xs text-zinc-500 mt-1">Sitemap Images</p>
              </div>
            </div>

            {/* ─── HTML Sitemap: Vehicles grouped by body type ─── */}
            {totalAvailable > 0 && (
              <section className="mb-10">
                <div className="flex items-center gap-2 mb-1">
                  <Layers className="w-4 h-4 text-orange-400" />
                  <h2 className="text-lg font-semibold">Inventory by Body Type</h2>
                  <span className="text-xs text-zinc-500 ml-1">
                    ({totalAvailable} available vehicle{totalAvailable !== 1 ? 's' : ''})
                  </span>
                </div>
                <p className="text-xs text-zinc-500 mb-5">
                  Human-readable HTML sitemap. Each entry links to the vehicle's detail page (/inventory/:id)
                  which carries schema.org <code className="text-zinc-400">Car/Product</code> structured data
                  for rich vehicle search results.
                </p>
                <div className="space-y-4">
                  {vehiclesLoading ? (
                    <div className="flex items-center justify-center py-10 gap-3 text-zinc-500 text-sm">
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Loading inventory…
                    </div>
                  ) : (
                    vehiclesByBodyType.map((group) => (
                      <details
                        key={group.bodyType}
                        open
                        className={`group rounded-xl border bg-gradient-to-br ${accentFor(group.bodyType)} to-transparent`}
                      >
                        <summary className="cursor-pointer list-none flex items-center justify-between gap-3 p-4">
                          <div className="flex items-center gap-3">
                            <div className="p-2 rounded-lg bg-black/30">
                              <Car className="w-4 h-4" />
                            </div>
                            <div>
                              <h3 className={`font-semibold ${accentFor(group.bodyType).split(' ').pop()}`}>
                                {group.bodyType}
                              </h3>
                              <p className="text-xs text-zinc-500">
                                {group.vehicles.length} vehicle{group.vehicles.length !== 1 ? 's' : ''}
                              </p>
                            </div>
                          </div>
                          <ChevronRight className="w-4 h-4 text-zinc-500 transition-transform group-open:rotate-90" />
                        </summary>
                        <ul className="border-t border-white/5 divide-y divide-white/5">
                          {group.vehicles.map((v) => (
                            <li key={v.id}>
                              <Link
                                to={`/inventory/${v.id}`}
                                className="flex items-center gap-3 px-4 py-2.5 hover:bg-white/[0.03] transition-colors group/item"
                              >
                                <span className="text-xs text-zinc-600 font-mono w-10 flex-shrink-0">
                                  #{v.id}
                                </span>
                                <span className="text-sm text-zinc-200 group-hover/item:text-white truncate flex-1">
                                  <span className="text-zinc-500">{v.year}</span>{' '}
                                  <span className="font-semibold">{v.make} {v.model}</span>
                                  {v.trim && <span className="text-zinc-500"> {v.trim}</span>}
                                </span>
                                <span className="text-xs text-zinc-500 hidden sm:inline">
                                  {(v.mileage / 1000).toFixed(0)}K mi
                                </span>
                                <span className="text-xs font-semibold text-orange-400 min-w-[70px] text-right">
                                  {v.price > 0 ? `$${v.price.toLocaleString()}` : 'Call'}
                                </span>
                                <ExternalLink className="w-3 h-3 text-zinc-600 group-hover/item:text-zinc-300 flex-shrink-0" />
                              </Link>
                            </li>
                          ))}
                        </ul>
                      </details>
                    ))
                  )}
                </div>
              </section>
            )}

            {/* ─── XML: Static Pages ─── */}
            <div className="mb-8">
              <div className="flex items-center gap-2 mb-4">
                <FileText className="w-4 h-4 text-cyan-400" />
                <h2 className="text-lg font-semibold">Static Pages</h2>
                <span className="text-xs text-zinc-500 ml-1">({staticUrls.length})</span>
              </div>
              <div className="space-y-2">
                {staticUrls.map((u, i) => {
                  const isReviews = (() => {
                    try {
                      return new URL(u.loc).pathname.replace(/\/$/, '') === '/reviews';
                    } catch {
                      return u.loc.endsWith('/reviews');
                    }
                  })();
                  return (
                    <div
                      key={i}
                      className={`flex items-center justify-between p-3 rounded-lg border transition-colors group ${
                        isReviews
                          ? 'bg-orange-500/5 border-orange-400/20 hover:border-orange-400/40'
                          : 'bg-zinc-800/40 border-zinc-700/30 hover:border-zinc-600/50'
                      }`}
                    >
                      <div className="flex items-center gap-3 min-w-0 flex-1">
                        {isReviews ? (
                          <Star className="w-4 h-4 text-orange-400 flex-shrink-0" />
                        ) : (
                          <Globe className="w-4 h-4 text-zinc-500 flex-shrink-0" />
                        )}
                        <a href={u.loc} target="_blank" rel="noopener noreferrer" className="text-sm text-zinc-300 group-hover:text-white truncate transition-colors">
                          {u.loc}
                        </a>
                        <ExternalLink className="w-3 h-3 text-zinc-600 opacity-0 group-hover:opacity-100 flex-shrink-0 transition-opacity" />
                      </div>
                      <div className="flex items-center gap-3 flex-shrink-0 ml-4">
                        <span className={`text-xs ${freqColor(u.changefreq)}`}>{u.changefreq}</span>
                        <span className={`text-xs px-2 py-0.5 rounded-full border ${priorityColor(u.priority)}`}>{u.priority}</span>
                        <span className="text-xs text-zinc-600">{u.lastmod}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* ─── XML: Vehicle Pages ─── */}
            {vehicleUrls.length > 0 && (
              <div>
                <div className="flex items-center gap-2 mb-4">
                  <Car className="w-4 h-4 text-orange-400" />
                  <h2 className="text-lg font-semibold">Vehicle Detail Pages (XML)</h2>
                  <span className="text-xs text-zinc-500 ml-1">({vehicleUrls.length})</span>
                </div>
                <div className="space-y-2">
                  {vehicleUrls.map((u, i) => (
                    <div key={i} className="p-3 rounded-lg bg-zinc-800/40 border border-zinc-700/30 hover:border-zinc-600/50 transition-colors group">
                      <div className="flex items-center justify-between gap-3">
                        <div className="flex items-center gap-3 min-w-0 flex-1">
                          <Car className="w-4 h-4 text-zinc-500 flex-shrink-0" />
                          <a href={u.loc} target="_blank" rel="noopener noreferrer" className="text-sm text-zinc-300 group-hover:text-white truncate transition-colors">
                            {u.loc}
                          </a>
                          <ExternalLink className="w-3 h-3 text-zinc-600 opacity-0 group-hover:opacity-100 flex-shrink-0 transition-opacity" />
                        </div>
                        <div className="flex items-center gap-3 flex-shrink-0 ml-4">
                          {u.images.length > 0 && (
                            <span className="flex items-center gap-1 text-xs text-pink-400" title={`${u.images.length} image:image entries`}>
                              <ImageIcon className="w-3 h-3" />
                              {u.images.length}
                            </span>
                          )}
                          <span className={`text-xs ${freqColor(u.changefreq)}`}>{u.changefreq}</span>
                          <span className={`text-xs px-2 py-0.5 rounded-full border ${priorityColor(u.priority)}`}>{u.priority}</span>
                          <span className="text-xs text-zinc-600">{u.lastmod}</span>
                        </div>
                      </div>
                      {/* Preview first image thumbnail if present */}
                      {u.images.length > 0 && (
                        <div className="mt-2 flex gap-2 overflow-x-auto scrollbar-thin">
                          {u.images.slice(0, 6).map((img, j) => (
                            <img
                              key={j}
                              src={img.loc}
                              alt={img.title || 'Vehicle image'}
                              loading="lazy"
                              className="w-14 h-14 object-cover rounded-md border border-white/5 flex-shrink-0"
                            />
                          ))}
                          {u.images.length > 6 && (
                            <div className="w-14 h-14 flex items-center justify-center rounded-md border border-white/5 bg-zinc-800 text-xs text-zinc-400 flex-shrink-0">
                              +{u.images.length - 6}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
