import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Navbar from '@/components/dealership/Navbar';
import Footer from '@/components/dealership/Footer';
import { Shield, ArrowLeft, Mail, Phone, MapPin } from 'lucide-react';
import { usePageSEO } from '@/hooks/usePageSEO';


const LAST_UPDATED = 'March 23, 2026';

const PrivacyPolicy: React.FC = () => {
  usePageSEO('privacy');
  const navigate = useNavigate();


  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });
  }, []);

  return (
    <div className="min-h-screen bg-black text-white">
      <Navbar />

      {/* Hero Banner */}
      <section className="relative overflow-hidden pt-8 pb-16">
        {/* Background effects */}
        <div className="absolute inset-0 bg-gradient-to-b from-neon-pink/5 via-transparent to-transparent" />
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-neon-pink/5 rounded-full blur-[120px]" />
        <div className="absolute top-0 right-1/4 w-96 h-96 bg-neon-cyan/5 rounded-full blur-[120px]" />

        <div className="relative max-w-4xl mx-auto px-4">
          {/* Back button */}
          <button
            onClick={() => navigate('/')}
            className="inline-flex items-center gap-2 text-gray-400 hover:text-neon-cyan transition-colors mb-8 group"
          >
            <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
            <span className="text-sm font-medium">Back to Home</span>
          </button>

          {/* Title */}
          <div className="flex items-center gap-4 mb-6">
            <div className="p-3 bg-gradient-to-br from-neon-pink/20 to-neon-orange/20 border border-neon-pink/20 rounded-xl">
              <Shield className="w-8 h-8 text-neon-pink" />
            </div>
            <div>
              <h1 className="text-3xl md:text-4xl lg:text-5xl font-black gradient-text-neon">
                Privacy Policy
              </h1>
              <p className="text-gray-500 text-sm mt-1">
                Last Updated: {LAST_UPDATED}
              </p>
            </div>
          </div>

          <p className="text-gray-400 text-lg leading-relaxed max-w-3xl">
            Ex$ell Car Sales LI ("we," "us," or "our") is committed to protecting your privacy. 
            This Privacy Policy explains how we collect, use, disclose, and safeguard your information 
            when you visit our website, use our services, or interact with us.
          </p>
        </div>
      </section>

      {/* Divider */}
      <div className="max-w-4xl mx-auto px-4">
        <div className="h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
      </div>

      {/* Policy Content */}
      <section className="max-w-4xl mx-auto px-4 py-12">
        <div className="space-y-12">

          {/* Section 1 */}
          <PolicySection number="1" title="Information We Collect">
            <p className="text-gray-400 leading-relaxed mb-4">
              We may collect information about you in a variety of ways. The information we may collect via the website includes:
            </p>

            <PolicySubsection title="Personal Data">
              <p className="text-gray-400 leading-relaxed">
                Personally identifiable information, such as your name, shipping address, email address, 
                telephone number, and demographic information (such as your age, gender, hometown, and interests) 
                that you voluntarily give to us when you register with the website or when you choose to participate 
                in various activities related to the website, such as online chat and message boards. You are under 
                no obligation to provide us with personal information of any kind; however, your refusal to do so 
                may prevent you from using certain features of the website.
              </p>
            </PolicySubsection>

            <PolicySubsection title="Derivative Data">
              <p className="text-gray-400 leading-relaxed">
                Information our servers automatically collect when you access the website, such as your IP address, 
                your browser type, your operating system, your access times, and the pages you have viewed directly 
                before and after accessing the website. If you are using our mobile application, this information 
                may also include your device name and type, your operating system, your phone number, your country, 
                your likes and replies to a post, and other interactions with the application and other users via 
                server log files, as well as any other information you choose to provide.
              </p>
            </PolicySubsection>

            <PolicySubsection title="Financial Data">
              <p className="text-gray-400 leading-relaxed">
                Financial information, such as data related to your payment method (e.g., valid credit card number, 
                card brand, expiration date) that we may collect when you purchase, order, return, exchange, or 
                request information about our services from the website. We store only very limited, if any, 
                financial information that we collect. Otherwise, all financial information is stored by our 
                payment processor and you are encouraged to review their privacy policy and contact them directly 
                for responses to your questions.
              </p>
            </PolicySubsection>

            <PolicySubsection title="Data From Social Networks">
              <p className="text-gray-400 leading-relaxed">
                User information from social networking sites, such as Facebook, Instagram, and Twitter, including 
                your name, your social network username, location, gender, birth date, email address, profile 
                picture, and public data for contacts, if you connect your account to such social networks.
              </p>
            </PolicySubsection>

            <PolicySubsection title="Vehicle Inquiry Data">
              <p className="text-gray-400 leading-relaxed">
                When you submit a vehicle inquiry, schedule a test drive, request lender referral information, or 
                use our trade-in valuation tools, we collect the information you provide including but not limited 
                to: vehicle preferences, budget range, trade-in vehicle details, driver's license information, 
                and other data necessary to process your requests.
              </p>
            </PolicySubsection>


            <PolicySubsection title="Mobile Device Data">
              <p className="text-gray-400 leading-relaxed">
                Device information, such as your mobile device ID, model, and manufacturer, and information about 
                the location of your device, if you access the website from a mobile device.
              </p>
            </PolicySubsection>
          </PolicySection>

          {/* Section 2 */}
          <PolicySection number="2" title="Use of Your Information">
            <p className="text-gray-400 leading-relaxed mb-4">
              Having accurate information about you permits us to provide you with a smooth, efficient, and 
              customized experience. Specifically, we may use information collected about you via the website to:
            </p>
            <ul className="space-y-3">
              {[
                'Assist law enforcement and respond to subpoenas.',
                'Compile anonymous statistical data and analysis for use internally or with third parties.',
                'Create and manage your account.',
                'Deliver targeted advertising, coupons, newsletters, and other information regarding promotions and the website to you.',
                'Email you regarding your account or order.',
                'Enable user-to-user communications.',
                'Fulfill and manage purchases, orders, payments, and other transactions related to the website.',
                'Generate a personal profile about you to make future visits to the website more personalized.',
                'Increase the efficiency and operation of the website.',
                'Monitor and analyze usage and trends to improve your experience with the website.',
                'Notify you of updates to the website.',
                'Offer new products, services, mobile applications, and/or recommendations to you.',
                'Perform other business activities as needed.',
                'Prevent fraudulent transactions, monitor against theft, and protect against criminal activity.',
                'Process payments and refunds.',
                'Request feedback and contact you about your use of the website.',
                'Resolve disputes and troubleshoot problems.',
                'Respond to product and customer service requests.',
                'Send you a newsletter.',
                'Refer you to trusted lending partners upon request.',

                'Schedule and manage test drive appointments.',
                'Provide vehicle history reports and condition assessments.',
                'Facilitate vehicle trade-in evaluations.',
              ].map((item, i) => (
                <li key={i} className="flex items-start gap-3 text-gray-400">
                  <span className="mt-2 w-1.5 h-1.5 rounded-full bg-neon-pink flex-shrink-0" />
                  <span className="leading-relaxed">{item}</span>
                </li>
              ))}
            </ul>
          </PolicySection>

          {/* Section 3 */}
          <PolicySection number="3" title="Disclosure of Your Information">
            <p className="text-gray-400 leading-relaxed mb-4">
              We may share information we have collected about you in certain situations. Your information may 
              be disclosed as follows:
            </p>

            <PolicySubsection title="By Law or to Protect Rights">
              <p className="text-gray-400 leading-relaxed">
                If we believe the release of information about you is necessary to respond to legal process, to 
                investigate or remedy potential violations of our policies, or to protect the rights, property, 
                and safety of others, we may share your information as permitted or required by any applicable 
                law, rule, or regulation. This includes exchanging information with other entities for fraud 
                protection and credit risk reduction.
              </p>
            </PolicySubsection>

            <PolicySubsection title="Third-Party Service Providers">
              <p className="text-gray-400 leading-relaxed">
                We may share your information with third parties that perform services for us or on our behalf, 
                including payment processing, data analysis, email delivery, hosting services, customer service, 
                marketing assistance, vehicle history report providers, credit bureaus, lending institutions, 
                and insurance providers.
              </p>
            </PolicySubsection>

            <PolicySubsection title="Marketing Communications">
              <p className="text-gray-400 leading-relaxed">
                With your consent, or with an opportunity for you to withdraw consent, we may share your 
                information with third parties for marketing purposes, as permitted by law.
              </p>
            </PolicySubsection>

            <PolicySubsection title="Interactions with Other Users">
              <p className="text-gray-400 leading-relaxed">
                If you interact with other users of the website, those users may see your name, profile photo, 
                and descriptions of your activity, including sending invitations to other users, chatting with 
                other users, liking posts, and following blogs.
              </p>
            </PolicySubsection>

            <PolicySubsection title="Online Postings">
              <p className="text-gray-400 leading-relaxed">
                When you post comments, contributions, or other content to the website, your posts may be viewed 
                by all users and may be publicly distributed outside the website in perpetuity.
              </p>
            </PolicySubsection>

            <PolicySubsection title="Business Partners">
              <p className="text-gray-400 leading-relaxed">
                We may share your information with our business partners to offer you certain products, services, 
                or promotions. This includes but is not limited to lending partners we refer you to, extended warranty 
                providers, vehicle service contract companies, and automotive insurance providers.
              </p>

            </PolicySubsection>

            <PolicySubsection title="Sale or Bankruptcy">
              <p className="text-gray-400 leading-relaxed">
                If we reorganize or sell all or a portion of our assets, undergo a merger, or are acquired by 
                another entity, we may transfer your information to the successor entity. If we go out of 
                business or enter bankruptcy, your information would be an asset transferred or acquired by a 
                third party. You acknowledge that such transfers may occur and that the transferee may decline 
                to honor commitments we made in this Privacy Policy.
              </p>
            </PolicySubsection>
          </PolicySection>

          {/* Section 4 */}
          <PolicySection number="4" title="Tracking Technologies">
            <PolicySubsection title="Cookies and Web Beacons">
              <p className="text-gray-400 leading-relaxed">
                We may use cookies, web beacons, tracking pixels, and other tracking technologies on the website 
                to help customize the website and improve your experience. When you access the website, your 
                personal information is not collected through the use of tracking technology. Most browsers are 
                set to accept cookies by default. You can remove or reject cookies, but be aware that such action 
                could affect the availability and functionality of the website. You may not decline web beacons. 
                However, they can be rendered ineffective by declining all cookies or by modifying your web 
                browser's settings to notify you each time a cookie is tendered, permitting you to accept or 
                decline cookies on an individual basis.
              </p>
            </PolicySubsection>

            <PolicySubsection title="Internet-Based Advertising">
              <p className="text-gray-400 leading-relaxed">
                Additionally, we may use third-party software to serve ads on the website, implement email 
                marketing campaigns, and manage other interactive marketing initiatives. This third-party 
                software may use cookies or similar tracking technology to help manage and optimize your online 
                experience with us. For more information about opting-out of interest-based ads, visit the 
                Network Advertising Initiative Opt-Out Tool or Digital Advertising Alliance Opt-Out Tool.
              </p>
            </PolicySubsection>

            <PolicySubsection title="Website Analytics">
              <p className="text-gray-400 leading-relaxed">
                We may also partner with selected third-party vendors, such as Google Analytics, to allow 
                tracking technologies and remarketing services on the website through the use of first-party 
                cookies and third-party cookies, to, among other things, analyze and track users' use of the 
                website, determine the popularity of certain content, and better understand online activity. 
                By accessing the website, you consent to the collection and use of your information by these 
                third-party vendors. You are encouraged to review their privacy policy and contact them directly 
                for responses to your questions. We do not transfer personal information to these third-party 
                vendors. However, if you do not want any information to be collected and used by tracking 
                technologies, you can visit the third-party vendor or the Network Advertising Initiative 
                Opt-Out Tool or Digital Advertising Alliance Opt-Out Tool.
              </p>
            </PolicySubsection>
          </PolicySection>

          {/* Section 5 */}
          <PolicySection number="5" title="Third-Party Websites">
            <p className="text-gray-400 leading-relaxed">
              The website may contain links to third-party websites and applications of interest, including 
              advertisements and external services, that are not affiliated with us. Once you have used these 
              links to leave the website, any information you provide to these third parties is not covered by 
              this Privacy Policy, and we cannot guarantee the safety and privacy of your information. Before 
              visiting and providing any information to any third-party websites, you should inform yourself of 
              the privacy policies and practices (if any) of the third party responsible for that website, and 
              should take those steps necessary to, in your discretion, protect the privacy of your information. 
              We are not responsible for the content or privacy and security practices and policies of any third 
              parties, including other sites, services, or applications that may be linked to or from the website.
            </p>
          </PolicySection>

          {/* Section 6 */}
          <PolicySection number="6" title="Security of Your Information">
            <p className="text-gray-400 leading-relaxed">
              We use administrative, technical, and physical security measures to help protect your personal 
              information. While we have taken reasonable steps to secure the personal information you provide 
              to us, please be aware that despite our efforts, no security measures are perfect or impenetrable, 
              and no method of data transmission can be guaranteed against any interception or other type of 
              misuse. Any information disclosed online is vulnerable to interception and misuse by unauthorized 
              parties. Therefore, we cannot guarantee complete security if you provide personal information.
            </p>
          </PolicySection>

          {/* Section 7 */}
          <PolicySection number="7" title="Policy for Children">
            <p className="text-gray-400 leading-relaxed">
              We do not knowingly solicit information from or market to children under the age of 13. If we 
              learn that we have collected personal information from a child under age 13 without verification 
              of parental consent, we will delete that information as quickly as possible. If you become aware 
              of any data we have collected from children under age 13, please contact us using the contact 
              information provided below.
            </p>
          </PolicySection>

          {/* Section 8 */}
          <PolicySection number="8" title="Controls for Do-Not-Track Features">
            <p className="text-gray-400 leading-relaxed">
              Most web browsers and some mobile operating systems include a Do-Not-Track ("DNT") feature or 
              setting you can activate to signal your privacy preference not to have data about your online 
              browsing activities monitored and collected. No uniform technology standard for recognizing and 
              implementing DNT signals has been finalized. As such, we do not currently respond to DNT browser 
              signals or any other mechanism that automatically communicates your choice not to be tracked online. 
              If a standard for online tracking is adopted that we must follow in the future, we will inform you 
              about that practice in a revised version of this Privacy Policy.
            </p>
          </PolicySection>

          {/* Section 9 */}
          <PolicySection number="9" title="Options Regarding Your Information">
            <p className="text-gray-400 leading-relaxed mb-4">
              You may at any time review or change the information in your account or terminate your account by:
            </p>
            <ul className="space-y-3 mb-4">
              {[
                'Logging into your account settings and updating your account.',
                'Contacting us using the contact information provided below.',
                'Emailing us at info@exsellsalesli.com with your request.',
              ].map((item, i) => (
                <li key={i} className="flex items-start gap-3 text-gray-400">
                  <span className="mt-2 w-1.5 h-1.5 rounded-full bg-neon-cyan flex-shrink-0" />
                  <span className="leading-relaxed">{item}</span>
                </li>
              ))}
            </ul>
            <p className="text-gray-400 leading-relaxed">
              Upon your request to terminate your account, we will deactivate or delete your account and 
              information from our active databases. However, some information may be retained in our files 
              to prevent fraud, troubleshoot problems, assist with any investigations, enforce our Terms of 
              Use, and/or comply with legal requirements.
            </p>

            <PolicySubsection title="Emails and Communications">
              <p className="text-gray-400 leading-relaxed">
                If you no longer wish to receive correspondence, emails, or other communications from us, 
                you may opt-out by contacting us using the contact information provided below, or by using 
                the unsubscribe link found at the bottom of any email we send. If you no longer wish to 
                receive correspondence, emails, or other communications from third parties, you are responsible 
                for contacting the third party directly.
              </p>
            </PolicySubsection>
          </PolicySection>

          {/* Section 10 */}
          <PolicySection number="10" title="California Privacy Rights">
            <p className="text-gray-400 leading-relaxed">
              California Civil Code Section 1798.83, also known as the "Shine The Light" law, permits our users 
              who are California residents to request and obtain from us, once a year and free of charge, 
              information about categories of personal information (if any) we disclosed to third parties for 
              direct marketing purposes and the names and addresses of all third parties with which we shared 
              personal information in the immediately preceding calendar year. If you are a California resident 
              and would like to make such a request, please submit your request in writing to us using the 
              contact information provided below.
            </p>
            <p className="text-gray-400 leading-relaxed mt-4">
              If you are under 18 years of age, reside in California, and have a registered account with the 
              website, you have the right to request removal of unwanted data that you publicly post on the 
              website. To request removal of such data, please contact us using the contact information provided 
              below, and include the email address associated with your account and a statement that you reside 
              in California. We will make sure the data is not publicly displayed on the website, but please be 
              aware that the data may not be completely or comprehensively removed from our systems.
            </p>
          </PolicySection>

          {/* Section 11 - CCPA */}
          <PolicySection number="11" title="CCPA Privacy Rights (Do Not Sell My Personal Information)">
            <p className="text-gray-400 leading-relaxed mb-4">
              Under the CCPA, among other rights, California consumers have the right to:
            </p>
            <ul className="space-y-3 mb-4">
              {[
                'Request that a business that collects a consumer\'s personal data disclose the categories and specific pieces of personal data that a business has collected about consumers.',
                'Request that a business delete any personal data about the consumer that a business has collected.',
                'Request that a business that sells a consumer\'s personal data, not sell the consumer\'s personal data.',
              ].map((item, i) => (
                <li key={i} className="flex items-start gap-3 text-gray-400">
                  <span className="mt-2 w-1.5 h-1.5 rounded-full bg-neon-orange flex-shrink-0" />
                  <span className="leading-relaxed">{item}</span>
                </li>
              ))}
            </ul>
            <p className="text-gray-400 leading-relaxed">
              If you make a request, we have one month to respond to you. If you would like to exercise any 
              of these rights, please contact us. We do not sell personal information. However, the Service 
              Providers we partner with (for example, our advertising partners) may use technology on the 
              Service that "sells" personal information as defined by the CCPA law.
            </p>
          </PolicySection>

          {/* Section 12 - GDPR */}
          <PolicySection number="12" title="GDPR Data Protection Rights">
            <p className="text-gray-400 leading-relaxed mb-4">
              We would like to make sure you are fully aware of all of your data protection rights. 
              Every user is entitled to the following:
            </p>
            <ul className="space-y-3 mb-4">
              {[
                { title: 'The right to access', desc: 'You have the right to request copies of your personal data.' },
                { title: 'The right to rectification', desc: 'You have the right to request that we correct any information you believe is inaccurate. You also have the right to request that we complete the information you believe is incomplete.' },
                { title: 'The right to erasure', desc: 'You have the right to request that we erase your personal data, under certain conditions.' },
                { title: 'The right to restrict processing', desc: 'You have the right to request that we restrict the processing of your personal data, under certain conditions.' },
                { title: 'The right to object to processing', desc: 'You have the right to object to our processing of your personal data, under certain conditions.' },
                { title: 'The right to data portability', desc: 'You have the right to request that we transfer the data that we have collected to another organization, or directly to you, under certain conditions.' },
              ].map((item, i) => (
                <li key={i} className="flex items-start gap-3 text-gray-400">
                  <span className="mt-2 w-1.5 h-1.5 rounded-full bg-neon-green flex-shrink-0" />
                  <span className="leading-relaxed">
                    <strong className="text-white">{item.title}:</strong> {item.desc}
                  </span>
                </li>
              ))}
            </ul>
            <p className="text-gray-400 leading-relaxed">
              If you make a request, we have one month to respond to you. If you would like to exercise any 
              of these rights, please contact us.
            </p>
          </PolicySection>

          {/* Section 13 */}
          <PolicySection number="13" title="Vehicle-Specific Privacy Practices">
            <p className="text-gray-400 leading-relaxed mb-4">
              As an automotive dealership, we collect and process certain vehicle-specific information:
            </p>
            <ul className="space-y-3">
              {[
                'Vehicle Identification Numbers (VINs) for inventory management and vehicle history reports.',
                'Trade-in vehicle information including make, model, year, mileage, and condition.',
                'Driver\'s license information for test drive authorization and identity verification.',
                'Insurance information for vehicle delivery and registration purposes.',
                'Contact information shared with lending partners when you request a lender referral.',
                'Vehicle service records when applicable to pre-owned vehicle assessments.',
              ].map((item, i) => (
                <li key={i} className="flex items-start gap-3 text-gray-400">
                  <span className="mt-2 w-1.5 h-1.5 rounded-full bg-neon-purple flex-shrink-0" />
                  <span className="leading-relaxed">{item}</span>
                </li>
              ))}
            </ul>
            <p className="text-gray-400 leading-relaxed mt-4">
              When you request a lender referral, your contact information may be shared with our trusted 
              lending partners so they can reach out to you directly. We do not process financing applications 
              ourselves. We comply with all applicable federal and state regulations regarding 
              the handling of personal information.
            </p>

          </PolicySection>

          {/* Section 14 */}
          <PolicySection number="14" title="Changes to This Privacy Policy">
            <p className="text-gray-400 leading-relaxed">
              We may update this Privacy Policy from time to time in order to reflect, for example, changes to 
              our practices or for other operational, legal, or regulatory reasons. We will notify you of any 
              changes by posting the new Privacy Policy on this page. You are advised to review this Privacy 
              Policy periodically for any changes. Changes to this Privacy Policy are effective when they are 
              posted on this page.
            </p>
          </PolicySection>

          {/* Section 15 - Contact */}
          <PolicySection number="15" title="Contact Us">
            <p className="text-gray-400 leading-relaxed mb-6">
              If you have questions or comments about this Privacy Policy, please contact us at:
            </p>

            <div className="bg-white/[0.02] border border-white/10 rounded-xl p-6 space-y-4">
              <h4 className="text-white font-bold text-lg gradient-text-neon">
                Ex$ell Car Sales LI
              </h4>
              <div className="space-y-3">
                <a
                  href="mailto:info@exsellsalesli.com"
                  className="flex items-center gap-3 text-gray-400 hover:text-neon-cyan transition-colors group"
                >
                  <Mail className="w-4 h-4 text-neon-cyan group-hover:scale-110 transition-transform" />
                  <span>info@exsellsalesli.com</span>
                </a>
                <a
                  href="tel:6313884426"
                  className="flex items-center gap-3 text-gray-400 hover:text-neon-green transition-colors group"
                >
                  <Phone className="w-4 h-4 text-neon-green group-hover:scale-110 transition-transform" />
                  <span>(631) 388-4426</span>
                </a>
                <div className="flex items-center gap-3 text-gray-400">
                  <MapPin className="w-4 h-4 text-neon-orange" />
                  <span>Long Island, New York</span>
                </div>
              </div>

              <div className="pt-4 border-t border-white/5">
                <a
                  href="https://exsellsalesli.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-neon-pink hover:text-neon-orange transition-colors text-sm font-medium"
                >
                  www.exsellsalesli.com
                </a>
              </div>
            </div>
          </PolicySection>

        </div>
      </section>

      {/* Bottom CTA */}
      <section className="max-w-4xl mx-auto px-4 pb-16">
        <div className="h-px bg-gradient-to-r from-transparent via-white/10 to-transparent mb-8" />
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-gray-500 text-sm">
            This privacy policy was last updated on {LAST_UPDATED}.
          </p>
          <button
            onClick={() => navigate('/')}
            className="inline-flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-neon-pink to-neon-orange text-white font-bold text-sm rounded-lg hover:opacity-90 transition-opacity"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Home
          </button>
        </div>
      </section>

      <Footer />
    </div>
  );
};

/* ─── Sub-components ─── */

interface PolicySectionProps {
  number: string;
  title: string;
  children: React.ReactNode;
}

const PolicySection: React.FC<PolicySectionProps> = ({ number, title, children }) => (
  <div>
    <div className="flex items-baseline gap-3 mb-4">
      <span className="text-neon-pink font-mono text-sm font-bold opacity-60">{number.padStart(2, '0')}</span>
      <h2 className="text-xl md:text-2xl font-bold text-white">{title}</h2>
    </div>
    <div className="pl-0 md:pl-10">{children}</div>
  </div>
);

interface PolicySubsectionProps {
  title: string;
  children: React.ReactNode;
}

const PolicySubsection: React.FC<PolicySubsectionProps> = ({ title, children }) => (
  <div className="mt-5">
    <h3 className="text-white font-semibold mb-2 flex items-center gap-2">
      <span className="w-6 h-px bg-gradient-to-r from-neon-cyan to-transparent" />
      {title}
    </h3>
    {children}
  </div>
);

export default PrivacyPolicy;
