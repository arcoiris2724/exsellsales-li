import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import {
  ArrowLeft, Phone, Calendar, Heart, Share2, Printer,
  ChevronRight, Loader2, AlertCircle, Car, Check,
  MapPin, Clock, Shield, Award, Star, Scale, Video, Camera
} from 'lucide-react';
import { Vehicle, fetchVehicleById, fetchVehicles } from '@/data/vehicles';
import { useCompare } from '@/contexts/CompareContext';
import Navbar from '@/components/dealership/Navbar';
import Footer from '@/components/dealership/Footer';
import ImageGallery from '@/components/dealership/ImageGallery';
import VehicleSpecs from '@/components/dealership/VehicleSpecs';
import TestDriveModal from '@/components/dealership/TestDriveModal';
import ComparisonTray from '@/components/dealership/ComparisonTray';
import VideoWalkthrough from '@/components/dealership/VideoWalkthrough';
import RequestMoreInfoForm from '@/components/dealership/RequestMoreInfoForm';
import { useVehicleJsonLd } from '@/hooks/useVehicleJsonLd';
import { usePageSEO } from '@/hooks/usePageSEO';

const VehicleDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { addToCompare, removeFromCompare, isInCompare, canAddMore } = useCompare();
  const [vehicle, setVehicle] = useState<Vehicle | null>(null);
  const [relatedVehicles, setRelatedVehicles] = useState<Vehicle[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [isFavorite, setIsFavorite] = useState(false);
  const [showTestDrive, setShowTestDrive] = useState(false);
  const [activeTab, setActiveTab] = useState<'specs' | 'features' | 'video'>('specs');
  const [shareTooltip, setShareTooltip] = useState(false);

  // Inject schema.org Car/Product JSON-LD + canonical <link> into <head>
  useVehicleJsonLd(vehicle);

  // Vehicle-specific Open Graph / Twitter Card meta tags for social shares.
  // Uses the VDP hero image + a human-readable title & description built from
  // the live vehicle data. Falls back to default SEO values until the vehicle
  // has loaded.
  const vdpTitle = vehicle
    ? `${vehicle.year} ${vehicle.make} ${vehicle.model}${vehicle.trim ? ' ' + vehicle.trim : ''} | Ex$ell Car Sales LI`
    : undefined;
  const vdpDescription = vehicle
    ? (vehicle.description?.trim() ||
        `${vehicle.year} ${vehicle.make} ${vehicle.model}${vehicle.trim ? ' ' + vehicle.trim : ''} — ${
          vehicle.mileage ? `${vehicle.mileage.toLocaleString()} mi, ` : ''
        }${vehicle.exteriorColor || ''}${vehicle.exteriorColor ? ' exterior, ' : ''}${
          vehicle.price > 0 ? `priced at $${vehicle.price.toLocaleString()}` : 'call for price'
        }. Available at Ex$ell Sales LLC in Holbrook, NY.`)
    : undefined;
  const vdpOgImage = vehicle
    ? (vehicle.image || vehicle.images?.[0] || undefined)
    : undefined;
  usePageSEO('homepage', vehicle
    ? {
        title: vdpTitle,
        metaDescription: vdpDescription,
        ogTitle: vdpTitle,
        ogDescription: vdpDescription,
        ogImage: vdpOgImage,
        ogType: 'product',
      }
    : undefined);


  useEffect(() => {
    window.scrollTo(0, 0);
  }, [id]);

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      setLoading(true);
      setError(false);
      try {
        const vehicleId = Number(id);
        if (isNaN(vehicleId)) {
          setError(true);
          setLoading(false);
          return;
        }
        const data = await fetchVehicleById(vehicleId);
        if (cancelled) return;
        if (!data) {
          setError(true);
        } else {
          setVehicle(data);
          const favs = JSON.parse(localStorage.getItem('exsell-favorites') || '[]');
          setIsFavorite(favs.includes(data.id));
        }
      } catch {
        if (!cancelled) setError(true);
      } finally {
        if (!cancelled) setLoading(false);
      }
    };
    load();
    return () => { cancelled = true; };
  }, [id]);

  useEffect(() => {
    if (!vehicle) return;
    let cancelled = false;
    const loadRelated = async () => {
      try {
        const all = await fetchVehicles();
        if (cancelled) return;
        const related = all
          .filter((v) => v.id !== vehicle.id && v.status === 'available')
          .filter((v) =>
            v.bodyType === vehicle.bodyType ||
            v.make === vehicle.make ||
            Math.abs(v.price - vehicle.price) < 10000
          )
          .slice(0, 4);
        setRelatedVehicles(related);
      } catch {}
    };
    loadRelated();
    return () => { cancelled = true; };
  }, [vehicle]);

  const toggleFavorite = useCallback(() => {
    if (!vehicle) return;
    const favs: number[] = JSON.parse(localStorage.getItem('exsell-favorites') || '[]');
    const newFavs = isFavorite ? favs.filter((f) => f !== vehicle.id) : [...favs, vehicle.id];
    localStorage.setItem('exsell-favorites', JSON.stringify(newFavs));
    setIsFavorite(!isFavorite);
  }, [vehicle, isFavorite]);

  const handleCompareToggle = useCallback(() => {
    if (!vehicle) return;
    if (isInCompare(vehicle.id)) {
      removeFromCompare(vehicle.id);
    } else {
      addToCompare(vehicle);
    }
  }, [vehicle, isInCompare, addToCompare, removeFromCompare]);

  const handleShare = useCallback(() => {
    if (navigator.share) {
      navigator.share({
        title: vehicle ? `${vehicle.year} ${vehicle.make} ${vehicle.model}` : 'Vehicle',
        url: window.location.href,
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(window.location.href);
      setShareTooltip(true);
      setTimeout(() => setShareTooltip(false), 2000);
    }
  }, [vehicle]);

  const handlePrint = useCallback(() => {
    window.print();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-black text-white">
        <Navbar />
        <div className="flex flex-col items-center justify-center py-40">
          <Loader2 className="w-12 h-12 text-neon-pink animate-spin mb-4" />
          <p className="text-gray-400 text-lg">Loading vehicle details...</p>
        </div>
        <Footer />
      </div>
    );
  }

  if (error || !vehicle) {
    return (
      <div className="min-h-screen bg-black text-white">
        <Navbar />
        <div className="flex flex-col items-center justify-center py-40 px-4">
          <div className="w-16 h-16 bg-red-500/10 rounded-full flex items-center justify-center mb-4">
            <AlertCircle className="w-8 h-8 text-red-400" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-2">Vehicle Not Found</h2>
          <p className="text-gray-400 mb-6 text-center max-w-md">
            The vehicle you're looking for may have been sold or is no longer available.
          </p>
          <div className="flex gap-3">
            <button
              onClick={() => navigate('/')}
              className="px-6 py-3 bg-gradient-to-r from-neon-pink to-neon-orange text-white font-bold rounded-xl hover:opacity-90 transition-opacity"
            >
              Browse Inventory
            </button>
            <a
              href="tel:6313884426"
              className="px-6 py-3 border border-neon-cyan/40 text-neon-cyan font-bold rounded-xl hover:bg-neon-cyan/10 transition-colors"
            >
              Call Us
            </a>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  const allImages = vehicle.images.length > 0 ? vehicle.images : [vehicle.image];
  const vehicleTitle = `${vehicle.year} ${vehicle.make} ${vehicle.model}`;
  const inCompare = isInCompare(vehicle.id);
  const hasVideo = !!vehicle.videoUrl;

  // Build tabs list dynamically
  const tabs: { key: typeof activeTab; label: string; icon?: React.ReactNode }[] = [
    { key: 'specs', label: 'Specifications' },
    { key: 'features', label: 'Features' },
  ];
  if (hasVideo) {
    tabs.push({ key: 'video', label: 'Video Tour', icon: <Video className="w-4 h-4 text-neon-pink" /> });
  }

  return (
    <div className="min-h-screen bg-black text-white">
      <Navbar />

      {/* Breadcrumb */}
      <div className="bg-[#050505] border-b border-white/5">
        <div className="max-w-7xl mx-auto px-4 py-3">
          <div className="flex items-center gap-2 text-sm">
            <Link to="/" className="text-gray-500 hover:text-neon-cyan transition-colors">
              Home
            </Link>
            <ChevronRight className="w-3.5 h-3.5 text-gray-600" />
            <button
              onClick={() => {
                navigate('/');
                setTimeout(() => {
                  document.getElementById('inventory')?.scrollIntoView({ behavior: 'smooth' });
                }, 100);
              }}
              className="text-gray-500 hover:text-neon-cyan transition-colors"
            >
              Inventory
            </button>
            <ChevronRight className="w-3.5 h-3.5 text-gray-600" />
            <span className="text-white font-medium truncate">{vehicleTitle}</span>
          </div>
        </div>
      </div>

      {/* Back button bar */}
      <div className="bg-[#080808]">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <button
            onClick={() => navigate(-1)}
            className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors group"
          >
            <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
            <span className="text-sm font-medium">Back</span>
          </button>
          <div className="flex items-center gap-2">
            {/* Media counts */}
            <div className="hidden sm:flex items-center gap-3 mr-3 text-xs text-gray-500">
              <span className="flex items-center gap-1">
                <Camera className="w-3.5 h-3.5" />
                {allImages.length} photos
              </span>
              {hasVideo && (
                <span className="flex items-center gap-1 text-neon-pink">
                  <Video className="w-3.5 h-3.5" />
                  Video
                </span>
              )}
            </div>

            {/* Compare button */}
            <button
              onClick={handleCompareToggle}
              disabled={!inCompare && !canAddMore}
              className={`p-2 rounded-lg border transition-all flex items-center gap-1.5 ${
                inCompare
                  ? 'bg-neon-cyan/10 border-neon-cyan/40 text-neon-cyan'
                  : canAddMore
                  ? 'border-white/10 text-gray-400 hover:text-neon-cyan hover:border-neon-cyan/30'
                  : 'border-white/10 text-gray-600 cursor-not-allowed'
              }`}
              title={inCompare ? 'Remove from comparison' : canAddMore ? 'Add to comparison' : 'Comparison full (max 3)'}
            >
              <Scale className="w-4 h-4" />
              <span className="text-xs font-semibold hidden sm:inline">
                {inCompare ? 'Comparing' : 'Compare'}
              </span>
            </button>

            <button
              onClick={toggleFavorite}
              className={`p-2 rounded-lg border transition-all ${
                isFavorite
                  ? 'bg-neon-pink/10 border-neon-pink/40 text-neon-pink'
                  : 'border-white/10 text-gray-400 hover:text-neon-pink hover:border-neon-pink/30'
              }`}
              title={isFavorite ? 'Remove from favorites' : 'Add to favorites'}
            >
              <Heart className={`w-4 h-4 ${isFavorite ? 'fill-current' : ''}`} />
            </button>
            <div className="relative">
              <button
                onClick={handleShare}
                className="p-2 rounded-lg border border-white/10 text-gray-400 hover:text-neon-cyan hover:border-neon-cyan/30 transition-all"
                title="Share"
              >
                <Share2 className="w-4 h-4" />
              </button>
              {shareTooltip && (
                <div className="absolute -bottom-8 left-1/2 -translate-x-1/2 px-2 py-1 bg-neon-green/20 text-neon-green text-xs rounded whitespace-nowrap">
                  Link copied!
                </div>
              )}
            </div>
            <button
              onClick={handlePrint}
              className="p-2 rounded-lg border border-white/10 text-gray-400 hover:text-white hover:border-white/30 transition-all"
              title="Print"
            >
              <Printer className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
          {/* Left column - Image gallery (3 cols) */}
          <div className="lg:col-span-3">
            <ImageGallery images={allImages} alt={vehicleTitle} videoUrl={vehicle.videoUrl} />

            {/* Quick video CTA below gallery if video exists */}
            {hasVideo && (
              <button
                onClick={() => setActiveTab('video')}
                className="mt-4 w-full flex items-center justify-center gap-3 py-3.5 bg-gradient-to-r from-neon-pink/10 via-neon-orange/10 to-neon-pink/10 border border-neon-pink/20 rounded-xl hover:border-neon-pink/40 transition-all group"
              >
                <div className="w-10 h-10 bg-gradient-to-br from-neon-pink to-neon-orange rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Video className="w-5 h-5 text-white" />
                </div>
                <div className="text-left">
                  <div className="text-white font-bold text-sm">Watch Video Walkthrough</div>
                  <div className="text-gray-500 text-xs">Full interior & exterior video tour</div>
                </div>
                <ChevronRight className="w-4 h-4 text-gray-500 group-hover:text-neon-pink group-hover:translate-x-1 transition-all ml-auto" />
              </button>
            )}
          </div>

          {/* Right column - Key info & CTAs (2 cols) */}
          <div className="lg:col-span-2 space-y-6">
            {/* Status badge */}
            {vehicle.status === 'sold' ? (
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-red-500/10 border border-red-500/20 rounded-full">
                <div className="w-2 h-2 bg-red-500 rounded-full" />
                <span className="text-red-400 text-sm font-bold uppercase tracking-wider">Sold</span>
              </div>
            ) : vehicle.status === 'pending' ? (
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-yellow-500/10 border border-yellow-500/20 rounded-full">
                <div className="w-2 h-2 bg-yellow-500 rounded-full animate-pulse" />
                <span className="text-yellow-400 text-sm font-bold uppercase tracking-wider">Sale Pending</span>
              </div>
            ) : (
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-neon-green/10 border border-neon-green/20 rounded-full">
                <div className="w-2 h-2 bg-neon-green rounded-full" />
                <span className="text-neon-green text-sm font-bold uppercase tracking-wider">Available</span>
              </div>
            )}

            {/* Title */}
            <div>
              <h1 className="text-3xl md:text-4xl font-black text-white leading-tight">
                {vehicleTitle}
              </h1>
              {vehicle.trim && (
                <p className="text-lg text-gray-400 mt-1">{vehicle.trim}</p>
              )}
            </div>

            {/* Price */}
            <div className="p-5 bg-gradient-to-br from-neon-pink/5 via-neon-orange/5 to-transparent rounded-xl border border-neon-orange/20">
              <div className="text-4xl font-display font-bold text-neon-orange neon-text-orange">
                {vehicle.price > 0 ? `$${vehicle.price.toLocaleString()}` : 'Call for Price'}
              </div>
              <div className="text-sm text-gray-500 mt-1">
                {vehicle.price > 0 ? 'Call for details — we can refer you to trusted lenders' : 'Contact us for pricing information'}
              </div>
            </div>


            {/* Quick specs */}
            <div className="grid grid-cols-2 gap-3">
              {[
                { label: 'Mileage', value: `${(vehicle.mileage / 1000).toFixed(0)}K mi`, color: 'text-neon-pink' },
                { label: 'Transmission', value: vehicle.transmission, color: 'text-neon-cyan' },
                { label: 'Drivetrain', value: vehicle.drivetrain, color: 'text-neon-green' },
                { label: 'Fuel', value: vehicle.fuelType, color: 'text-neon-orange' },
                { label: 'Engine', value: vehicle.engine, color: 'text-neon-purple' },
                { label: 'Body', value: vehicle.bodyType, color: 'text-neon-yellow' },
              ].map((spec) => (
                <div key={spec.label} className="p-3 bg-white/[0.02] rounded-xl border border-white/5">
                  <div className={`text-xs ${spec.color} font-medium mb-0.5`}>{spec.label}</div>
                  <div className="text-sm text-white font-semibold truncate">{spec.value}</div>
                </div>
              ))}
            </div>

            {/* Media summary */}
            <div className="flex gap-3">
              <div className="flex-1 p-3 bg-white/[0.02] rounded-xl border border-white/5 flex items-center gap-2">
                <Camera className="w-4 h-4 text-neon-cyan" />
                <div>
                  <div className="text-xs text-gray-500">Photos</div>
                  <div className="text-sm text-white font-semibold">{allImages.length} images</div>
                </div>
              </div>
              {hasVideo && (
                <button
                  onClick={() => setActiveTab('video')}
                  className="flex-1 p-3 bg-neon-pink/5 rounded-xl border border-neon-pink/20 flex items-center gap-2 hover:bg-neon-pink/10 transition-colors group"
                >
                  <Video className="w-4 h-4 text-neon-pink" />
                  <div className="text-left">
                    <div className="text-xs text-neon-pink/70">Video Tour</div>
                    <div className="text-sm text-white font-semibold group-hover:text-neon-pink transition-colors">Watch Now</div>
                  </div>
                </button>
              )}
            </div>

            {/* Colors */}
            <div className="flex gap-4">
              <div className="flex-1 p-3 bg-white/[0.02] rounded-xl border border-white/5">
                <div className="text-xs text-gray-500 mb-0.5">Exterior</div>
                <div className="text-sm text-white font-medium">{vehicle.exteriorColor}</div>
              </div>
              <div className="flex-1 p-3 bg-white/[0.02] rounded-xl border border-white/5">
                <div className="text-xs text-gray-500 mb-0.5">Interior</div>
                <div className="text-sm text-white font-medium">{vehicle.interiorColor}</div>
              </div>
            </div>

            {/* CTA Buttons */}
            {vehicle.status === 'available' && (
              <div className="space-y-3">
                <a
                  href="tel:6313884426"
                  className="w-full flex items-center justify-center gap-2 py-4 bg-gradient-to-r from-neon-pink to-neon-orange text-white font-bold text-lg rounded-xl hover:opacity-90 transition-opacity neon-pulse"
                >
                  <Phone className="w-5 h-5" />
                  Call About This Vehicle
                </a>
                <button
                  onClick={() => setShowTestDrive(true)}
                  className="w-full flex items-center justify-center gap-2 py-4 border-2 border-neon-cyan/50 text-neon-cyan font-bold text-lg rounded-xl hover:bg-neon-cyan/10 transition-colors"
                >
                  <Calendar className="w-5 h-5" />
                  Schedule Test Drive
                </button>
                {/* Compare button */}
                <button
                  onClick={handleCompareToggle}
                  disabled={!inCompare && !canAddMore}
                  className={`w-full flex items-center justify-center gap-2 py-3.5 rounded-xl font-bold transition-all ${
                    inCompare
                      ? 'bg-neon-cyan/10 border-2 border-neon-cyan/50 text-neon-cyan'
                      : canAddMore
                      ? 'border-2 border-white/10 text-gray-300 hover:border-neon-cyan/30 hover:text-neon-cyan hover:bg-neon-cyan/5'
                      : 'border-2 border-white/5 text-gray-600 cursor-not-allowed'
                  }`}
                >
                  <Scale className="w-5 h-5" />
                  {inCompare ? 'Remove from Comparison' : canAddMore ? 'Add to Compare' : 'Comparison Full (3/3)'}
                </button>
              </div>
            )}

            {/* Trust badges */}
            <div className="grid grid-cols-3 gap-2">
              {[
                { icon: Shield, label: 'Vehicle History Report', color: 'text-neon-green' },
                { icon: Award, label: 'Quality Inspected', color: 'text-neon-cyan' },
                { icon: Star, label: '5-Star Rated Dealer', color: 'text-neon-orange' },
              ].map((badge) => (
                <div key={badge.label} className="flex flex-col items-center text-center p-3 bg-white/[0.02] rounded-xl border border-white/5">
                  <badge.icon className={`w-5 h-5 ${badge.color} mb-1.5`} />
                  <span className="text-[10px] text-gray-400 leading-tight">{badge.label}</span>
                </div>
              ))}
            </div>

            {/* Dealer info */}
            <div className="p-4 bg-white/[0.02] rounded-xl border border-white/5">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 bg-gradient-to-br from-neon-pink to-neon-orange rounded-lg flex items-center justify-center">
                  <Car className="w-5 h-5 text-white" />
                </div>
                <div>
                  <div className="text-white font-bold text-sm">Ex$ell Car Sales LI</div>
                  <div className="text-gray-500 text-xs">Licensed Dealer</div>
                </div>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2 text-gray-400">
                  <MapPin className="w-3.5 h-3.5 text-neon-orange" />
                  <span>Long Island, NY</span>
                </div>
                <div className="flex items-center gap-2 text-gray-400">
                  <Clock className="w-3.5 h-3.5 text-neon-cyan" />
                  <span>Mon-Fri: 7AM-5PM | Sat: 7AM-2PM | Sun: Closed</span>

                </div>
                <div className="flex items-center gap-2 text-gray-400">
                  <Phone className="w-3.5 h-3.5 text-neon-green" />
                  <a href="tel:6313884426" className="hover:text-neon-green transition-colors">(631) 388-4426</a>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* Description */}
        {vehicle.description && (
          <div className="mt-10 p-6 bg-white/[0.02] rounded-xl border border-white/5">
            <h3 className="text-xl font-bold text-white mb-3">About This Vehicle</h3>
            <p className="text-gray-400 leading-relaxed text-base">{vehicle.description}</p>
          </div>
        )}

        {/* Inline lead-capture form — only shown for vehicles the dealer can still sell */}
        {vehicle.status === 'available' && <RequestMoreInfoForm vehicle={vehicle} />}


        {/* Tabs: Specs / Features / Video */}
        <div className="mt-10">
          <div className="flex gap-1 border-b border-white/5 mb-8 overflow-x-auto scrollbar-thin">
            {tabs.map((tab) => (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key)}
                className={`px-5 py-3 text-sm font-bold transition-all relative whitespace-nowrap flex items-center gap-2 ${
                  activeTab === tab.key
                    ? 'text-white'
                    : 'text-gray-500 hover:text-gray-300'
                }`}
              >
                {tab.icon}
                {tab.label}
                {activeTab === tab.key && (
                  <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-neon-pink to-neon-orange" />
                )}
              </button>
            ))}
          </div>

          <div className="animate-fade-in">
            {activeTab === 'specs' && <VehicleSpecs vehicle={vehicle} />}

            {activeTab === 'features' && (
              <div className="space-y-6">
                <h3 className="text-xl font-bold text-white flex items-center gap-2">
                  <Check className="w-5 h-5 text-neon-green" />
                  Features & Equipment
                </h3>
                {vehicle.features.length > 0 ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                    {vehicle.features.map((feature, i) => (
                      <div
                        key={i}
                        className="flex items-center gap-3 p-3 bg-white/[0.02] rounded-xl border border-white/5 hover:border-neon-green/20 transition-colors"
                      >
                        <div className="w-6 h-6 bg-neon-green/10 rounded-full flex items-center justify-center flex-shrink-0">
                          <Check className="w-3.5 h-3.5 text-neon-green" />
                        </div>
                        <span className="text-sm text-gray-300">{feature}</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-500">Contact us for a full list of features and equipment.</p>
                )}
              </div>
            )}

            {activeTab === 'video' && hasVideo && (
              <VideoWalkthrough
                videoUrl={vehicle.videoUrl}
                vehicleTitle={vehicleTitle}
                posterImage={allImages[0]}
              />
            )}
          </div>
        </div>

        {/* Related Vehicles */}
        {relatedVehicles.length > 0 && (
          <div className="mt-16">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-bold text-white">
                Similar <span className="gradient-text-neon">Vehicles</span>
              </h3>
              <button
                onClick={() => {
                  navigate('/');
                  setTimeout(() => {
                    document.getElementById('inventory')?.scrollIntoView({ behavior: 'smooth' });
                  }, 100);
                }}
                className="text-sm text-neon-cyan hover:text-neon-cyan/80 font-medium transition-colors flex items-center gap-1"
              >
                View All Inventory
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {relatedVehicles.map((rv) => {
                const rvInCompare = isInCompare(rv.id);
                return (
                  <div
                    key={rv.id}
                    className={`group bg-[#0a0a0a] rounded-xl border transition-all overflow-hidden ${
                      rvInCompare
                        ? 'border-neon-cyan/30 shadow-md shadow-neon-cyan/5'
                        : 'border-white/5 hover:border-neon-pink/30'
                    }`}
                  >
                    <Link to={`/inventory/${rv.id}`} className="block">
                      <div className="relative aspect-[16/10] overflow-hidden">
                        <img
                          src={rv.image || (rv.images.length > 0 ? rv.images[0] : '/placeholder.svg')}
                          alt={`${rv.year} ${rv.make} ${rv.model}`}
                          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                        <div className="absolute bottom-2 right-2 px-2.5 py-1 bg-black/70 backdrop-blur-sm rounded-lg">
                          <span className="text-neon-orange font-bold text-sm">
                            {rv.price > 0 ? `$${rv.price.toLocaleString()}` : 'Call'}
                          </span>
                        </div>
                        {rvInCompare && (
                          <div className="absolute top-2 left-2 px-2 py-0.5 bg-neon-cyan/90 text-black text-[10px] font-bold rounded-full uppercase tracking-wider flex items-center gap-1">
                            <Scale className="w-2.5 h-2.5" />
                            Comparing
                          </div>
                        )}
                        {rv.videoUrl && (
                          <div className="absolute top-2 right-2 px-1.5 py-0.5 bg-neon-pink/90 text-white text-[9px] font-bold rounded-full flex items-center gap-0.5">
                            <Video className="w-2.5 h-2.5" />
                          </div>
                        )}
                      </div>

                    </Link>
                    <div className="p-3">
                      <Link to={`/inventory/${rv.id}`}>
                        <h4 className="text-white font-bold text-sm group-hover:text-neon-cyan transition-colors truncate">
                          {rv.year} {rv.make} {rv.model}
                        </h4>
                        <div className="flex items-center gap-2 mt-1 text-xs text-gray-500">
                          <span>{(rv.mileage / 1000).toFixed(0)}K mi</span>
                          <span className="w-1 h-1 bg-gray-600 rounded-full" />
                          <span>{rv.transmission}</span>
                          {rv.images.length > 5 && (
                            <>
                              <span className="w-1 h-1 bg-gray-600 rounded-full" />
                              <span className="flex items-center gap-0.5">
                                <Camera className="w-3 h-3" />
                                {rv.images.length}
                              </span>
                            </>
                          )}
                        </div>
                      </Link>
                      <button
                        onClick={() => {
                          if (rvInCompare) {
                            removeFromCompare(rv.id);
                          } else {
                            addToCompare(rv);
                          }
                        }}
                        disabled={!rvInCompare && !canAddMore}
                        className={`mt-2 w-full py-1.5 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1 ${
                          rvInCompare
                            ? 'bg-neon-cyan/10 border border-neon-cyan/30 text-neon-cyan'
                            : canAddMore
                            ? 'border border-white/10 text-gray-400 hover:text-neon-cyan hover:border-neon-cyan/30'
                            : 'border border-white/5 text-gray-600 cursor-not-allowed'
                        }`}
                      >
                        <Scale className="w-3 h-3" />
                        {rvInCompare ? 'Comparing' : 'Compare'}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Bottom CTA bar */}
        {vehicle.status === 'available' && (
          <div className="mt-16 p-6 md:p-8 bg-gradient-to-r from-neon-pink/5 via-neon-orange/5 to-neon-cyan/5 rounded-2xl border border-white/5">
            <div className="flex flex-col md:flex-row items-center justify-between gap-6">
              <div>
                <h3 className="text-2xl font-bold text-white mb-1">
                  Interested in this {vehicle.year} {vehicle.make} {vehicle.model}?
                </h3>
                <p className="text-gray-400">
                  Contact us today to schedule a test drive or get more information.
                </p>
              </div>
              <div className="flex gap-3 flex-shrink-0">
                <a
                  href="tel:6313884426"
                  className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-neon-pink to-neon-orange text-white font-bold rounded-xl hover:opacity-90 transition-opacity"
                >
                  <Phone className="w-4 h-4" />
                  Call Now
                </a>
                <button
                  onClick={() => setShowTestDrive(true)}
                  className="flex items-center gap-2 px-6 py-3 border-2 border-neon-cyan/50 text-neon-cyan font-bold rounded-xl hover:bg-neon-cyan/10 transition-colors"
                >
                  <Calendar className="w-4 h-4" />
                  Test Drive
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      <Footer />
      <ComparisonTray />

      {/* Test Drive Modal */}
      {showTestDrive && (
        <TestDriveModal
          vehicle={vehicle}
          onClose={() => setShowTestDrive(false)}
        />
      )}
    </div>
  );
};

export default VehicleDetail;
