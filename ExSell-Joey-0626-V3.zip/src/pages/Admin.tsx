import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';

import {
  Car, Plus, Search, Edit2, Trash2, Eye, EyeOff, DollarSign,
  BarChart3, Package, CheckCircle, Clock, XCircle, Loader2,
  ArrowLeft, LogOut, RefreshCw, ChevronDown, AlertTriangle,
  TrendingUp, Hash, Mail, Lock, Shield, User, KeyRound, Settings,
  Database, Sparkles, X, PenTool, Globe, Calendar, Inbox, Trophy,
  Camera, FileText
} from 'lucide-react';




import {
  Vehicle, fetchVehicles, createVehicle, updateVehicle, deleteVehicle, isUsingFallbackData
} from '@/data/vehicles';
import { seedDemoVehicles } from '@/data/seedVehicles';
import VehicleFormModal from '@/components/admin/VehicleFormModal';
import CraigslistImportModal from '@/components/admin/CraigslistImportModal';
import AIPricingPanel from '@/components/admin/AIPricingPanel';
import AIDescriptionPanel from '@/components/admin/AIDescriptionPanel';
import MarkAsSoldDialog from '@/components/admin/MarkAsSoldDialog';


import TestDriveBookingsPanel from '@/components/admin/TestDriveBookingsPanel';
import LeadsPanel from '@/components/admin/LeadsPanel';
import LeadFunnelChart from '@/components/admin/LeadFunnelChart';
import BulkImageUploadPanel from '@/components/admin/BulkImageUploadPanel';
import ContentManagerPanel from '@/components/admin/ContentManagerPanel';



import { toast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabase';

interface AdminUser {
  id: number;
  email: string;
  display_name: string;
  role: string;
  last_login?: string;
  login_count?: number;
}

const TOKEN_KEY = 'exsell_admin_token';

const Admin: React.FC = () => {
  const navigate = useNavigate();
  
  // Auth state
  const [authenticated, setAuthenticated] = useState(false);
  const [authLoading, setAuthLoading] = useState(true);
  const [adminUser, setAdminUser] = useState<AdminUser | null>(null);
  const [authToken, setAuthToken] = useState<string | null>(null);
  
  // Login form
  const [loginMode, setLoginMode] = useState<'login' | 'setup'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loginError, setLoginError] = useState('');
  const [loginLoading, setLoginLoading] = useState(false);
  
  // Settings modal
  const [showSettings, setShowSettings] = useState(false);
  const [currentPw, setCurrentPw] = useState('');
  const [newPw, setNewPw] = useState('');
  const [confirmPw, setConfirmPw] = useState('');
  const [pwLoading, setPwLoading] = useState(false);

  // Vehicle state
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [loading, setLoading] = useState(true);
  const [usingFallback, setUsingFallback] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [sortField, setSortField] = useState<string>('created_at');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');
  const [showForm, setShowForm] = useState(false);
  const [editingVehicle, setEditingVehicle] = useState<Vehicle | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<number | null>(null);
  const [actionLoading, setActionLoading] = useState<number | null>(null);
  const [seedLoading, setSeedLoading] = useState(false);
  const [pricingVehicle, setPricingVehicle] = useState<Vehicle | null>(null);
  const [descriptionVehicle, setDescriptionVehicle] = useState<Vehicle | null>(null);

  const [showCraigslistImport, setShowCraigslistImport] = useState(false);
  const [craigslistImportStatus, setCraigslistImportStatus] = useState<'available' | 'sold'>('available');
  const [importedVehicleData, setImportedVehicleData] = useState<Partial<Vehicle> | null>(null);

  // Mark as Sold dialog state
  const [markAsSoldVehicle, setMarkAsSoldVehicle] = useState<Vehicle | null>(null);

  // Active tab state — includes 'leads' and 'analytics'
  const [activeTab, setActiveTab] = useState<'inventory' | 'bookings' | 'leads' | 'analytics' | 'photos' | 'content'>('inventory');

  // Deep-link tab support: /admin?tab=leads (or analytics, bookings, …) auto-selects
  // the right tab on mount. This is what the lead-notify email CTA points at.
  const adminLocation = useLocation();
  useEffect(() => {
    const params = new URLSearchParams(adminLocation.search);
    const tab = params.get('tab');
    if (tab && ['inventory', 'bookings', 'leads', 'analytics', 'photos', 'content'].includes(tab)) {
      setActiveTab(tab as typeof activeTab);
    }
  }, [adminLocation.search]);






  // Verify existing session on mount
  useEffect(() => {
    const savedToken = localStorage.getItem(TOKEN_KEY);
    if (savedToken) {
      supabase.functions.invoke('admin-auth', {
        body: { action: 'verify', token: savedToken },
      }).then(({ data }) => {
        if (data?.valid && data?.user) {
          setAdminUser(data.user);
          setAuthToken(savedToken);
          setAuthenticated(true);
        } else {
          localStorage.removeItem(TOKEN_KEY);
        }
      }).catch(() => {
        localStorage.removeItem(TOKEN_KEY);
      }).finally(() => setAuthLoading(false));
    } else {
      setAuthLoading(false);
    }
  }, []);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    setLoginLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('admin-auth', {
        body: { action: 'login', email: email.trim(), password },
      });
      // Extract response - edge function always returns 200, so data should have the response
      const response = data || {};
      
      // Handle actual network/invocation errors
      if (error && !data) {
        // Try to extract message from error context
        let errorMsg = 'Connection error. Please try again.';
        try {
          if (error.context && typeof error.context.json === 'function') {
            const errBody = await error.context.json();
            errorMsg = errBody?.error || errorMsg;
          } else if (error.message) {
            errorMsg = error.message;
          }
        } catch {}
        setLoginError(errorMsg);
        return;
      }
      
      if (response.error) {
        setLoginError(response.error);
      } else if (response.success && response.token) {
        localStorage.setItem(TOKEN_KEY, response.token);
        setAuthToken(response.token);
        setAdminUser(response.user);
        setAuthenticated(true);
        toast({ title: 'Welcome back!', description: `Logged in as ${response.user.display_name}` });
      } else {
        setLoginError('Login failed. Please try again.');
      }
    } catch (err: any) {
      setLoginError(err.message || 'Connection error. Please try again.');
    } finally {
      setLoginLoading(false);
    }
  };

  const handleSetup = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    if (password.length < 6) { setLoginError('Password must be at least 6 characters'); return; }
    setLoginLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('admin-auth', {
        body: { action: 'setup', email: email.trim(), password, display_name: displayName.trim() || 'Admin' },
      });
      // Extract response - edge function always returns 200
      const response = data || {};
      
      // Handle actual network/invocation errors
      if (error && !data) {
        let errorMsg = 'Connection error. Please try again.';
        try {
          if (error.context && typeof error.context.json === 'function') {
            const errBody = await error.context.json();
            errorMsg = errBody?.error || errorMsg;
          } else if (error.message) {
            errorMsg = error.message;
          }
        } catch {}
        setLoginError(errorMsg);
        return;
      }
      
      if (response.error) {
        setLoginError(response.error);
        if (response.error.includes('already exists')) setLoginMode('login');
      } else if (response.success) {
        toast({ title: 'Account Created!', description: 'You can now log in with your credentials.' });
        setLoginMode('login');
        setLoginError('');
      } else {
        setLoginError('Setup failed. Please try again.');
      }
    } catch (err: any) {
      setLoginError(err.message || 'Setup failed. Please try again.');
    } finally {
      setLoginLoading(false);
    }
  };


  const handleLogout = async () => {
    if (authToken) {
      try {
        await supabase.functions.invoke('admin-auth', {
          body: { action: 'logout', token: authToken },
        });
      } catch {}
    }
    localStorage.removeItem(TOKEN_KEY);
    setAuthenticated(false);
    setAdminUser(null);
    setAuthToken(null);
    toast({ title: 'Logged out', description: 'You have been securely logged out.' });
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPw !== confirmPw) { toast({ title: 'Error', description: 'Passwords do not match', variant: 'destructive' }); return; }
    if (newPw.length < 6) { toast({ title: 'Error', description: 'Password must be at least 6 characters', variant: 'destructive' }); return; }
    setPwLoading(true);
    try {
      const { data } = await supabase.functions.invoke('admin-auth', {
        body: { action: 'change_password', token: authToken, current_password: currentPw, new_password: newPw },
      });
      if (data?.error) {
        toast({ title: 'Error', description: data.error, variant: 'destructive' });
      } else if (data?.success) {
        toast({ title: 'Password Changed', description: 'Your password has been updated successfully.' });
        setShowSettings(false);
        setCurrentPw(''); setNewPw(''); setConfirmPw('');
      }
    } catch { toast({ title: 'Error', description: 'Failed to change password', variant: 'destructive' }); }
    finally { setPwLoading(false); }
  };

  const loadVehicles = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchVehicles();
      setVehicles(data);
      setUsingFallback(isUsingFallbackData());
    }
    catch (err) { console.error('Failed to load vehicles:', err); }
    finally { setLoading(false); }
  }, []);
  useEffect(() => { if (authenticated) loadVehicles(); }, [authenticated, loadVehicles]);

  // Poll for vehicle changes every 15 seconds instead of using Realtime WebSocket
  // (Realtime disabled due to binary decode compatibility issues)
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);
  useEffect(() => {
    if (!authenticated) return;
    pollRef.current = setInterval(() => {
      fetchVehicles().then((data) => {
        setVehicles(data);
      }).catch(() => {
        // Silently ignore polling errors
      });
    }, 15000);

    return () => {
      if (pollRef.current) {
        clearInterval(pollRef.current);
      }
    };
  }, [authenticated]);




  const handleAddVehicle = async (data: Partial<Vehicle>) => {
    await createVehicle(data);
    toast({ title: 'Vehicle Added', description: `${data.year} ${data.make} ${data.model} has been added to inventory.` });
    setShowForm(false);
    loadVehicles();
  };

  const handleEditVehicle = async (data: Partial<Vehicle>) => {
    if (!editingVehicle) return;
    await updateVehicle(editingVehicle.id, data);
    toast({ title: 'Vehicle Updated', description: `${data.year} ${data.make} ${data.model} has been updated.` });
    setEditingVehicle(null);
    loadVehicles();
  };

  const handleStatusChange = async (vehicle: Vehicle, newStatus: Vehicle['status']) => {
    // Intercept 'sold' status to show confirmation dialog
    if (newStatus === 'sold' && vehicle.status !== 'sold') {
      setMarkAsSoldVehicle(vehicle);
      return;
    }
    setActionLoading(vehicle.id);
    try {
      const updates: Partial<Vehicle> = { status: newStatus };
      // If changing away from sold, clear sold fields
      if (newStatus !== 'sold') {
        updates.soldDate = undefined;
        updates.soldPrice = undefined;
      }
      await updateVehicle(vehicle.id, updates);
      toast({ title: 'Status Updated', description: `${vehicle.year} ${vehicle.make} ${vehicle.model} marked as ${newStatus}.` });
      loadVehicles();
    } catch { toast({ title: 'Error', description: 'Failed to update status.', variant: 'destructive' }); }
    finally { setActionLoading(null); }
  };

  // Handle confirmed Mark as Sold from the dialog
  const handleConfirmMarkAsSold = async (soldPrice?: number) => {
    if (!markAsSoldVehicle) return;
    const vehicle = markAsSoldVehicle;
    setActionLoading(vehicle.id);
    try {
      const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
      const updates: Partial<Vehicle> = {
        status: 'sold',
        soldDate: today,
        soldPrice: soldPrice,
      };
      await updateVehicle(vehicle.id, updates);
      toast({
        title: 'Vehicle Sold!',
        description: `${vehicle.year} ${vehicle.make} ${vehicle.model} has been moved to the Sold List.${soldPrice ? ` Sale price: $${soldPrice.toLocaleString()}` : ''}`,
      });
      setMarkAsSoldVehicle(null);
      loadVehicles();
    } catch {
      toast({ title: 'Error', description: 'Failed to mark vehicle as sold.', variant: 'destructive' });
    } finally {
      setActionLoading(null);
    }
  };


  const handleDelete = async (id: number) => {
    setActionLoading(id);
    try {
      await deleteVehicle(id);
      toast({ title: 'Vehicle Deleted', description: 'Vehicle has been removed from inventory.' });
      setDeleteConfirm(null);
      loadVehicles();
    } catch { toast({ title: 'Error', description: 'Failed to delete vehicle.', variant: 'destructive' }); }
    finally { setActionLoading(null); }
  };

  const handleQuickPriceEdit = async (vehicle: Vehicle) => {
    const newPrice = prompt(`Enter new price for ${vehicle.year} ${vehicle.make} ${vehicle.model}:`, String(vehicle.price));
    if (newPrice === null) return;
    const parsed = parseFloat(newPrice);
    if (isNaN(parsed) || parsed <= 0) { toast({ title: 'Invalid Price', description: 'Please enter a valid price.', variant: 'destructive' }); return; }
    setActionLoading(vehicle.id);
    try {
      await updateVehicle(vehicle.id, { price: parsed });
      toast({ title: 'Price Updated', description: `Price updated to $${parsed.toLocaleString()}.` });
      loadVehicles();
    } catch { toast({ title: 'Error', description: 'Failed to update price.', variant: 'destructive' }); }
    finally { setActionLoading(null); }
  };

  const handleSeedDemo = async () => {
    if (vehicles.length > 0) {
      toast({ title: 'Cannot Seed', description: 'Database already has vehicles. Delete existing vehicles first.', variant: 'destructive' });
      return;
    }
    setSeedLoading(true);
    try {
      const result = await seedDemoVehicles();
      if (result.success) {
        toast({ title: 'Demo Data Loaded!', description: `Successfully added ${result.count} demo vehicles to the database.` });
        loadVehicles();
      } else {
        toast({ title: 'Seed Failed', description: result.error || 'Unknown error', variant: 'destructive' });
      }
    } catch (err: any) {
      toast({ title: 'Seed Error', description: err.message || 'Failed to seed demo data', variant: 'destructive' });
    } finally {
      setSeedLoading(false);
    }
  };


  const filteredVehicles = vehicles
    .filter(v => {
      if (statusFilter !== 'all' && v.status !== statusFilter) return false;
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        const str = `${v.year} ${v.make} ${v.model} ${v.trim} ${v.vin}`.toLowerCase();
        if (!str.includes(q)) return false;
      }
      return true;
    })
    .sort((a, b) => {
      let aVal: any, bVal: any;
      switch (sortField) {
        case 'price': aVal = a.price; bVal = b.price; break;
        case 'year': aVal = a.year; bVal = b.year; break;
        case 'mileage': aVal = a.mileage; bVal = b.mileage; break;
        case 'make': aVal = a.make; bVal = b.make; break;
        default: aVal = a.id; bVal = b.id;
      }
      if (typeof aVal === 'string') return sortDir === 'asc' ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
      return sortDir === 'asc' ? aVal - bVal : bVal - aVal;
    });

  const stats = {
    total: vehicles.length,
    available: vehicles.filter(v => v.status === 'available').length,
    pending: vehicles.filter(v => v.status === 'pending').length,
    sold: vehicles.filter(v => v.status === 'sold').length,
    totalValue: vehicles.filter(v => v.status === 'available').reduce((sum, v) => sum + v.price, 0),
    avgPrice: vehicles.filter(v => v.status === 'available').length > 0
      ? vehicles.filter(v => v.status === 'available').reduce((sum, v) => sum + v.price, 0) / vehicles.filter(v => v.status === 'available').length
      : 0,
  };

  // ── AUTH LOADING ──
  if (authLoading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-10 h-10 text-neon-pink animate-spin mx-auto mb-4" />
          <p className="text-gray-400 text-sm">Verifying session...</p>
        </div>
      </div>
    );
  }

  // ── LOGIN / SETUP SCREEN ──
  if (!authenticated) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center px-4">
        {/* Background effects */}
        <div className="fixed inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-neon-pink/5 rounded-full blur-3xl" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-neon-cyan/5 rounded-full blur-3xl" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-neon-orange/3 rounded-full blur-3xl" />
        </div>

        <div className="w-full max-w-md relative z-10">
          {/* Logo & Header */}
          <div className="text-center mb-8">
            <div className="relative inline-block mb-4">
              <div className="absolute -inset-3 bg-gradient-to-br from-neon-pink/30 via-neon-orange/20 to-neon-cyan/30 rounded-3xl blur-xl" />
              <div className="relative w-20 h-20 bg-gradient-to-br from-neon-pink to-neon-orange rounded-2xl flex items-center justify-center shadow-2xl shadow-neon-pink/20">
                <Shield className="w-10 h-10 text-white" />
              </div>
            </div>
            <h1 className="text-3xl font-black text-white mb-1">
              {loginMode === 'setup' ? 'Create Admin Account' : 'Admin Login'}
            </h1>
            <p className="text-gray-500 text-sm">
              {loginMode === 'setup'
                ? 'Set up your first administrator account'
                : 'Sign in to manage your dealership inventory'}
            </p>
          </div>

          {/* Login Card */}
          <div className="bg-white/[0.03] backdrop-blur-xl border border-white/10 rounded-2xl p-8 shadow-2xl">
            <form onSubmit={loginMode === 'setup' ? handleSetup : handleLogin} className="space-y-5">
              {loginMode === 'setup' && (
                <div>
                  <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">
                    Display Name
                  </label>
                  <div className="relative">
                    <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-gray-500" />
                    <input
                      type="text"
                      value={displayName}
                      onChange={(e) => setDisplayName(e.target.value)}
                      placeholder="Your name"
                      className="w-full pl-11 pr-4 py-3.5 bg-white/[0.03] border border-white/10 rounded-xl text-white placeholder-gray-600 focus:border-neon-cyan focus:outline-none focus:ring-1 focus:ring-neon-cyan/30 transition-all"
                    />
                  </div>
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-gray-500" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => { setEmail(e.target.value); setLoginError(''); }}
                    placeholder="admin@exsell.com"
                    required
                    autoFocus
                    className="w-full pl-11 pr-4 py-3.5 bg-white/[0.03] border border-white/10 rounded-xl text-white placeholder-gray-600 focus:border-neon-cyan focus:outline-none focus:ring-1 focus:ring-neon-cyan/30 transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">
                  Password
                </label>
                <div className="relative">
                  <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-gray-500" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => { setPassword(e.target.value); setLoginError(''); }}
                    placeholder={loginMode === 'setup' ? 'Min 6 characters' : 'Enter password'}
                    required
                    minLength={loginMode === 'setup' ? 6 : 1}
                    className="w-full pl-11 pr-12 py-3.5 bg-white/[0.03] border border-white/10 rounded-xl text-white placeholder-gray-600 focus:border-neon-cyan focus:outline-none focus:ring-1 focus:ring-neon-cyan/30 transition-all"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300 transition-colors"
                  >
                    {showPassword ? <EyeOff className="w-4.5 h-4.5" /> : <Eye className="w-4.5 h-4.5" />}
                  </button>
                </div>
              </div>

              {loginError && (
                <div className="flex items-center gap-2 px-4 py-3 bg-red-500/10 border border-red-500/20 rounded-xl">
                  <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0" />
                  <p className="text-red-400 text-sm">{loginError}</p>
                </div>
              )}

              <button
                type="submit"
                disabled={loginLoading}
                className="w-full py-3.5 bg-gradient-to-r from-neon-pink to-neon-orange text-white font-bold rounded-xl hover:opacity-90 transition-all disabled:opacity-50 flex items-center justify-center gap-2 shadow-lg shadow-neon-pink/20"
              >
                {loginLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    {loginMode === 'setup' ? 'Creating Account...' : 'Signing In...'}
                  </>
                ) : (
                  <>
                    {loginMode === 'setup' ? (
                      <><KeyRound className="w-4 h-4" /> Create Account</>
                    ) : (
                      <><Shield className="w-4 h-4" /> Sign In</>
                    )}
                  </>
                )}
              </button>
            </form>

            {/* Toggle login/setup */}
            <div className="mt-6 pt-5 border-t border-white/5 text-center">
              {loginMode === 'login' ? (
                <p className="text-gray-500 text-sm">
                  First time?{' '}
                  <button
                    onClick={() => { setLoginMode('setup'); setLoginError(''); }}
                    className="text-neon-cyan hover:text-neon-cyan/80 font-semibold transition-colors"
                  >
                    Create Admin Account
                  </button>
                </p>
              ) : (
                <p className="text-gray-500 text-sm">
                  Already have an account?{' '}
                  <button
                    onClick={() => { setLoginMode('login'); setLoginError(''); }}
                    className="text-neon-cyan hover:text-neon-cyan/80 font-semibold transition-colors"
                  >
                    Sign In
                  </button>
                </p>
              )}
            </div>
          </div>

          {/* Back to website */}
          <button
            onClick={() => navigate('/')}
            className="w-full mt-4 py-3 text-gray-600 hover:text-white transition-colors text-sm flex items-center justify-center gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Website
          </button>

          {/* Security badge */}
          <div className="mt-6 flex items-center justify-center gap-2 text-gray-700 text-xs">
            <Lock className="w-3 h-3" />
            <span>256-bit encrypted connection</span>
          </div>
        </div>
      </div>
    );
  }

  // ── ADMIN DASHBOARD ──
  return (
    <div className="min-h-screen bg-[#0a0a0a]">
      {/* Admin Header */}
      <header className="sticky top-0 z-50 bg-black/90 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button onClick={() => navigate('/')} className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors">
              <ArrowLeft className="w-4 h-4" />
              <span className="hidden sm:inline text-sm">Back to Site</span>
            </button>
            <div className="h-6 w-px bg-white/10" />
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-br from-neon-pink to-neon-orange rounded-lg flex items-center justify-center">
                <Car className="w-4 h-4 text-white" />
              </div>
              <div>
                <h1 className="text-white font-bold text-sm leading-tight">EX$ELL Admin</h1>
                <p className="text-gray-500 text-[11px]">
                  {adminUser ? `${adminUser.display_name} (${adminUser.role})` : 'Inventory Management'}
                </p>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={loadVehicles} disabled={loading} className="p-2 text-gray-400 hover:text-white transition-colors" title="Refresh">
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
            {/* Import dropdown with Available / Sold options */}
            <div className="relative group">
              <button
                onClick={() => { setCraigslistImportStatus('available'); setShowCraigslistImport(true); }}
                className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-500 to-blue-500 text-white font-semibold rounded-lg text-sm hover:opacity-90 transition-opacity shadow-lg shadow-purple-500/20"
                title="Import from Craigslist"
              >
                <Globe className="w-4 h-4" />
                <span className="hidden md:inline">Import from CL</span>
                <span className="md:hidden">Import</span>
                <ChevronDown className="w-3 h-3 opacity-60" />
              </button>
              <div className="absolute right-0 top-full mt-1 hidden group-hover:block z-50">
                <div className="bg-[#1a1a1a] border border-white/10 rounded-lg shadow-xl overflow-hidden min-w-[200px] py-1">
                  <button
                    onClick={() => { setCraigslistImportStatus('available'); setShowCraigslistImport(true); }}
                    className="w-full px-4 py-2.5 text-left text-sm text-gray-300 hover:bg-white/5 hover:text-white transition-colors flex items-center gap-2"
                  >
                    <CheckCircle className="w-4 h-4 text-neon-green" />
                    Import as Available
                  </button>
                  <button
                    onClick={() => { setCraigslistImportStatus('sold'); setShowCraigslistImport(true); }}
                    className="w-full px-4 py-2.5 text-left text-sm text-gray-300 hover:bg-white/5 hover:text-white transition-colors flex items-center gap-2"
                  >
                    <Trophy className="w-4 h-4 text-red-400" />
                    Import as Sold
                    <span className="ml-auto text-[10px] text-gray-500 bg-white/5 px-1.5 py-0.5 rounded">to sold list</span>
                  </button>
                </div>
              </div>
            </div>
            <button
              onClick={() => setShowForm(true)}
              className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-neon-pink to-neon-orange text-white font-semibold rounded-lg text-sm hover:opacity-90 transition-opacity"
            >
              <Plus className="w-4 h-4" />
              <span className="hidden sm:inline">Add Vehicle</span>
            </button>

            <button onClick={() => setShowSettings(true)} className="p-2 text-gray-400 hover:text-neon-cyan transition-colors" title="Settings">
              <Settings className="w-4 h-4" />
            </button>
            <button onClick={handleLogout} className="p-2 text-gray-400 hover:text-red-400 transition-colors" title="Logout">
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>


      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
        {/* Tab Navigation */}
        <div className="flex items-center gap-1 bg-white/[0.02] border border-white/5 rounded-xl p-1 overflow-x-auto">
          <button
            onClick={() => setActiveTab('inventory')}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm font-semibold transition-all whitespace-nowrap ${
              activeTab === 'inventory'
                ? 'bg-gradient-to-r from-neon-pink/20 to-neon-orange/20 text-white border border-neon-pink/30'
                : 'text-gray-500 hover:text-gray-300 hover:bg-white/[0.03]'
            }`}
          >
            <Car className="w-4 h-4" />
            Inventory
            <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${activeTab === 'inventory' ? 'bg-neon-pink/20 text-neon-pink' : 'bg-white/5 text-gray-500'}`}>
              {vehicles.length}
            </span>
          </button>
          <button
            onClick={() => setActiveTab('bookings')}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm font-semibold transition-all whitespace-nowrap ${
              activeTab === 'bookings'
                ? 'bg-gradient-to-r from-neon-cyan/20 to-neon-green/20 text-white border border-neon-cyan/30'
                : 'text-gray-500 hover:text-gray-300 hover:bg-white/[0.03]'
            }`}
          >
            <Calendar className="w-4 h-4" />
            Test Drive Bookings
          </button>
          <button
            onClick={() => setActiveTab('leads')}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm font-semibold transition-all whitespace-nowrap ${
              activeTab === 'leads'
                ? 'bg-gradient-to-r from-neon-orange/20 to-amber-500/20 text-white border border-neon-orange/30'
                : 'text-gray-500 hover:text-gray-300 hover:bg-white/[0.03]'
            }`}
          >

            <Inbox className="w-4 h-4" />
            Leads
          </button>
          <button
            onClick={() => setActiveTab('analytics')}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm font-semibold transition-all whitespace-nowrap ${
              activeTab === 'analytics'
                ? 'bg-gradient-to-r from-neon-cyan/20 to-neon-pink/20 text-white border border-neon-cyan/30'
                : 'text-gray-500 hover:text-gray-300 hover:bg-white/[0.03]'
            }`}
            title="Lead funnel analytics & response-time KPIs"
          >
            <TrendingUp className="w-4 h-4" />
            Analytics
            <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${activeTab === 'analytics' ? 'bg-neon-cyan/20 text-neon-cyan' : 'bg-white/5 text-gray-500'}`}>
              Funnel
            </span>
          </button>

          <button
            onClick={() => setActiveTab('photos')}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm font-semibold transition-all whitespace-nowrap ${
              activeTab === 'photos'
                ? 'bg-gradient-to-r from-purple-500/20 to-pink-500/20 text-white border border-purple-500/30'
                : 'text-gray-500 hover:text-gray-300 hover:bg-white/[0.03]'
            }`}
          >
            <Camera className="w-4 h-4" />
            Photos
            <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${activeTab === 'photos' ? 'bg-purple-500/20 text-purple-300' : 'bg-white/5 text-gray-500'}`}>
              {vehicles.reduce((sum, v) => sum + (v.images?.length || 0), 0)}
            </span>
          </button>
          <button
            onClick={() => setActiveTab('content')}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm font-semibold transition-all whitespace-nowrap ${
              activeTab === 'content'
                ? 'bg-gradient-to-r from-teal-500/20 to-emerald-500/20 text-white border border-teal-500/30'
                : 'text-gray-500 hover:text-gray-300 hover:bg-white/[0.03]'
            }`}
          >
            <FileText className="w-4 h-4" />
            Content
            <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${activeTab === 'content' ? 'bg-teal-500/20 text-teal-300' : 'bg-white/5 text-gray-500'}`}>
              CMS
            </span>
          </button>
        </div>


        {/* Tab Content */}
        {activeTab === 'inventory' ? (
          <>
            {/* Fallback Data Warning Banner */}
            {usingFallback && vehicles.length > 0 && (
              <div className="p-4 bg-gradient-to-r from-amber-500/10 to-red-500/10 border border-amber-500/30 rounded-xl">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <h4 className="text-amber-300 font-bold text-sm mb-1">Read-only Demo Data — Edits Won't Save</h4>
                    <p className="text-amber-200/80 text-xs leading-relaxed">
                      The database is unreachable, so you're viewing <strong>local fallback data</strong>. Any edits, price changes, status updates, or deletes <strong>will fail</strong> because these vehicles don't exist in your database yet.
                    </p>
                    <div className="flex flex-wrap gap-2 mt-3">
                      <button
                        onClick={loadVehicles}
                        className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-500/20 border border-amber-500/40 text-amber-200 text-xs font-semibold rounded-lg hover:bg-amber-500/30 transition-colors"
                      >
                        <RefreshCw className="w-3 h-3" /> Retry Database Connection
                      </button>
                      <button
                        onClick={handleSeedDemo}
                        disabled={seedLoading}
                        className="flex items-center gap-1.5 px-3 py-1.5 bg-purple-500/20 border border-purple-500/40 text-purple-200 text-xs font-semibold rounded-lg hover:bg-purple-500/30 transition-colors disabled:opacity-50"
                      >
                        <Database className="w-3 h-3" /> Seed These Vehicles Into DB
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Stats Cards */}
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
              <StatCard icon={Package} label="Total" value={stats.total} color="text-white" bg="bg-white/5" />
              <StatCard icon={CheckCircle} label="Available" value={stats.available} color="text-neon-green" bg="bg-neon-green/5" />
              <StatCard icon={Clock} label="Pending" value={stats.pending} color="text-neon-orange" bg="bg-neon-orange/5" />
              <StatCard icon={XCircle} label="Sold" value={stats.sold} color="text-red-400" bg="bg-red-400/5" />
              <StatCard icon={DollarSign} label="Inventory Value" value={`$${(stats.totalValue / 1000).toFixed(0)}K`} color="text-neon-cyan" bg="bg-neon-cyan/5" />
              <StatCard icon={TrendingUp} label="Avg Price" value={`$${(stats.avgPrice / 1000).toFixed(1)}K`} color="text-neon-pink" bg="bg-neon-pink/5" />
            </div>


            {/* Toolbar */}
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                <input
                  type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search vehicles..."
                  className="w-full pl-10 pr-4 py-2.5 bg-white/[0.03] border border-white/10 rounded-lg text-white text-sm placeholder-gray-500 focus:border-neon-cyan focus:outline-none"
                />
              </div>
              <div className="flex gap-2">
                <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}
                  className="px-3 py-2.5 bg-white/[0.03] border border-white/10 rounded-lg text-white text-sm focus:border-neon-cyan focus:outline-none">
                  <option value="all">All Status</option>
                  <option value="available">Available</option>
                  <option value="pending">Pending</option>
                  <option value="sold">Sold</option>
                </select>
                <select
                  value={`${sortField}-${sortDir}`}
                  onChange={(e) => { const [field, dir] = e.target.value.split('-'); setSortField(field); setSortDir(dir as 'asc' | 'desc'); }}
                  className="px-3 py-2.5 bg-white/[0.03] border border-white/10 rounded-lg text-white text-sm focus:border-neon-cyan focus:outline-none">
                  <option value="created_at-desc">Newest First</option>
                  <option value="created_at-asc">Oldest First</option>
                  <option value="price-desc">Price: High to Low</option>
                  <option value="price-asc">Price: Low to High</option>
                  <option value="year-desc">Year: Newest</option>
                  <option value="make-asc">Make: A-Z</option>
                </select>
              </div>
            </div>

            {/* Vehicle List */}
            {loading ? (
              <div className="flex items-center justify-center py-20">
                <Loader2 className="w-8 h-8 text-neon-pink animate-spin" />
              </div>
            ) : filteredVehicles.length === 0 ? (
              <div className="text-center py-20">
                <Car className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-white mb-2">No vehicles found</h3>
                <p className="text-gray-400 text-sm mb-6">
                  {searchQuery || statusFilter !== 'all' ? 'Try adjusting your filters' : 'Add your first vehicle to get started'}
                </p>
                {!searchQuery && statusFilter === 'all' && (
                  <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
                    <button onClick={() => setShowForm(true)}
                      className="px-6 py-2.5 bg-gradient-to-r from-neon-pink to-neon-orange text-white font-semibold rounded-lg text-sm hover:opacity-90 transition-opacity flex items-center gap-2">
                      <Plus className="w-4 h-4" />
                      Add First Vehicle
                    </button>
                    <span className="text-gray-600 text-xs">or</span>
                    <button
                      onClick={handleSeedDemo}
                      disabled={seedLoading}
                      className="px-6 py-2.5 bg-gradient-to-r from-purple-600 to-blue-600 text-white font-semibold rounded-lg text-sm hover:opacity-90 transition-opacity flex items-center gap-2 disabled:opacity-50 shadow-lg shadow-purple-500/20"
                    >
                      {seedLoading ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" />
                          Seeding 12 Vehicles...
                        </>
                      ) : (
                        <>
                          <Database className="w-4 h-4" />
                          Seed 12 Demo Vehicles
                        </>
                      )}
                    </button>
                  </div>
                )}
                {!searchQuery && statusFilter === 'all' && !seedLoading && (
                  <p className="text-gray-600 text-xs mt-4 max-w-md mx-auto">
                    Seed demo data inserts 12 realistic vehicle listings (BMW, Mercedes, Toyota, Tesla, etc.) into the database with full specs, descriptions, and images.
                  </p>
                )}
              </div>
            ) : (
              <div className="space-y-3">
                {filteredVehicles.map((vehicle) => (
                  <VehicleRow
                    key={vehicle.id} vehicle={vehicle}
                    isLoading={actionLoading === vehicle.id}
                    deleteConfirm={deleteConfirm === vehicle.id}
                    onEdit={() => setEditingVehicle(vehicle)}
                    onStatusChange={(status) => handleStatusChange(vehicle, status)}
                    onQuickPrice={() => handleQuickPriceEdit(vehicle)}
                    onAIPrice={() => setPricingVehicle(vehicle)}
                    onAIDescription={() => setDescriptionVehicle(vehicle)}
                    onDeleteRequest={() => setDeleteConfirm(vehicle.id)}
                    onDeleteConfirm={() => handleDelete(vehicle.id)}
                    onDeleteCancel={() => setDeleteConfirm(null)}
                  />
                ))}
              </div>
            )}

            <div className="text-center py-4 text-gray-600 text-xs">
              {filteredVehicles.length} of {vehicles.length} vehicles shown
            </div>
          </>
        ) : activeTab === 'bookings' ? (
          <TestDriveBookingsPanel />
        ) : activeTab === 'photos' ? (
          <BulkImageUploadPanel vehicles={vehicles} onVehiclesUpdated={loadVehicles} />
        ) : activeTab === 'content' ? (
          <ContentManagerPanel />
        ) : activeTab === 'leads' ? (
          <LeadsPanel />
        ) : activeTab === 'analytics' ? (
          <LeadFunnelChart />
        ) : null}


      </main>


      {/* Settings Modal */}
      {showSettings && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/70 backdrop-blur-sm p-4" onClick={() => setShowSettings(false)}>
          <div className="bg-[#111] border border-white/10 rounded-2xl w-full max-w-md p-6 space-y-6" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between">
              <h2 className="text-white font-bold text-lg flex items-center gap-2"><Settings className="w-5 h-5 text-neon-cyan" /> Account Settings</h2>
              <button onClick={() => setShowSettings(false)} className="text-gray-500 hover:text-white"><XCircle className="w-5 h-5" /></button>
            </div>
            
            {adminUser && (
              <div className="bg-white/[0.03] border border-white/5 rounded-xl p-4 space-y-2">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-neon-pink to-neon-orange rounded-full flex items-center justify-center text-white font-bold">
                    {adminUser.display_name.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <p className="text-white font-semibold text-sm">{adminUser.display_name}</p>
                    <p className="text-gray-500 text-xs">{adminUser.email}</p>
                  </div>
                </div>
                <div className="flex gap-4 text-xs text-gray-500 pt-2 border-t border-white/5">
                  <span>Role: <span className="text-neon-cyan">{adminUser.role}</span></span>
                  <span>Logins: <span className="text-white">{adminUser.login_count || 0}</span></span>
                </div>
              </div>
            )}

            <form onSubmit={handleChangePassword} className="space-y-4">
              <h3 className="text-white font-semibold text-sm flex items-center gap-2"><KeyRound className="w-4 h-4 text-neon-orange" /> Change Password</h3>
              <input type="password" value={currentPw} onChange={e => setCurrentPw(e.target.value)} placeholder="Current password" required
                className="w-full px-4 py-3 bg-white/[0.03] border border-white/10 rounded-xl text-white text-sm placeholder-gray-600 focus:border-neon-cyan focus:outline-none" />
              <input type="password" value={newPw} onChange={e => setNewPw(e.target.value)} placeholder="New password (min 6 chars)" required minLength={6}
                className="w-full px-4 py-3 bg-white/[0.03] border border-white/10 rounded-xl text-white text-sm placeholder-gray-600 focus:border-neon-cyan focus:outline-none" />
              <input type="password" value={confirmPw} onChange={e => setConfirmPw(e.target.value)} placeholder="Confirm new password" required
                className="w-full px-4 py-3 bg-white/[0.03] border border-white/10 rounded-xl text-white text-sm placeholder-gray-600 focus:border-neon-cyan focus:outline-none" />
              <button type="submit" disabled={pwLoading}
                className="w-full py-3 bg-gradient-to-r from-neon-cyan to-neon-green text-black font-bold rounded-xl hover:opacity-90 transition-opacity disabled:opacity-50 flex items-center justify-center gap-2 text-sm">
                {pwLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <KeyRound className="w-4 h-4" />}
                Update Password
              </button>
            </form>
          </div>
        </div>
      )}

      {/* AI Pricing Modal */}
      {pricingVehicle && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/70 backdrop-blur-sm p-4" onClick={() => setPricingVehicle(null)}>
          <div className="w-full max-w-lg max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <AIPricingPanel
              vehicle={pricingVehicle}
              currentPrice={pricingVehicle.price}
              onApplyPrice={async (price) => {
                try {
                  await updateVehicle(pricingVehicle.id, { price });
                  toast({ title: 'Price Updated', description: `${pricingVehicle.year} ${pricingVehicle.make} ${pricingVehicle.model} price set to $${price.toLocaleString()}.` });
                  loadVehicles();
                } catch {
                  toast({ title: 'Error', description: 'Failed to update price.', variant: 'destructive' });
                }
              }}
            />
            <button
              onClick={() => setPricingVehicle(null)}
              className="w-full mt-3 py-2.5 text-gray-500 hover:text-white text-sm font-medium transition-colors flex items-center justify-center gap-2"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* AI Description Modal */}

      {descriptionVehicle && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/70 backdrop-blur-sm p-4" onClick={() => setDescriptionVehicle(null)}>
          <div className="w-full max-w-lg max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <AIDescriptionPanel
              vehicle={descriptionVehicle}
              currentDescription={descriptionVehicle.description || ''}
              onApplyDescription={async (desc) => {
                try {
                  await updateVehicle(descriptionVehicle.id, { description: desc });
                  toast({ title: 'Description Updated', description: `${descriptionVehicle.year} ${descriptionVehicle.make} ${descriptionVehicle.model} description has been updated.` });
                  loadVehicles();
                } catch {
                  toast({ title: 'Error', description: 'Failed to update description.', variant: 'destructive' });
                }
              }}
            />
            <button
              onClick={() => setDescriptionVehicle(null)}
              className="w-full mt-3 py-2.5 text-gray-500 hover:text-white text-sm font-medium transition-colors flex items-center justify-center gap-2"
            >
              <X className="w-4 h-4" />
              Close
            </button>
          </div>
        </div>
      )}

      {/* Craigslist Import Modal */}
      {showCraigslistImport && (
        <CraigslistImportModal
          onImportComplete={(data) => {
            setShowCraigslistImport(false);
            setImportedVehicleData(data);
            setShowForm(true);
            toast({ title: 'Import Complete', description: `${data.year || ''} ${data.make || ''} ${data.model || ''} data ready - review and save below.` });
          }}
          onClose={() => setShowCraigslistImport(false)}
        />
      )}

      {/* Add/Edit Modal - with optional imported data */}
      {showForm && (
        <VehicleFormModal
          initialData={importedVehicleData}
          onSave={async (data) => { await handleAddVehicle(data); setImportedVehicleData(null); }}
          onClose={() => { setShowForm(false); setImportedVehicleData(null); }}
        />
      )}
      {editingVehicle && <VehicleFormModal vehicle={editingVehicle} onSave={handleEditVehicle} onClose={() => setEditingVehicle(null)} />}

      {/* Mark as Sold Confirmation Dialog */}
      {markAsSoldVehicle && (
        <MarkAsSoldDialog
          vehicle={markAsSoldVehicle}
          onConfirm={handleConfirmMarkAsSold}
          onCancel={() => setMarkAsSoldVehicle(null)}
        />
      )}
    </div>
  );

};



const StatCard: React.FC<{ icon: React.ElementType; label: string; value: string | number; color: string; bg: string }> = ({ icon: Icon, label, value, color, bg }) => (
  <div className={`${bg} border border-white/5 rounded-xl p-4`}>
    <div className="flex items-center gap-2 mb-2">
      <Icon className={`w-4 h-4 ${color}`} />
      <span className="text-gray-500 text-xs font-medium">{label}</span>
    </div>
    <div className={`text-xl font-bold ${color}`}>{value}</div>
  </div>
);

const VehicleRow: React.FC<{
  vehicle: Vehicle; isLoading: boolean; deleteConfirm: boolean;
  onEdit: () => void; onStatusChange: (status: Vehicle['status']) => void;
  onQuickPrice: () => void; onAIPrice: () => void; onAIDescription: () => void;
  onDeleteRequest: () => void; onDeleteConfirm: () => void; onDeleteCancel: () => void;
}> = ({ vehicle, isLoading, deleteConfirm, onEdit, onStatusChange, onQuickPrice, onAIPrice, onAIDescription, onDeleteRequest, onDeleteConfirm, onDeleteCancel }) => {
  const [showStatusMenu, setShowStatusMenu] = useState(false);
  const statusConfig = {
    available: { label: 'Available', color: 'text-neon-green', bg: 'bg-neon-green/10', border: 'border-neon-green/30' },
    pending: { label: 'Pending', color: 'text-neon-orange', bg: 'bg-neon-orange/10', border: 'border-neon-orange/30' },
    sold: { label: 'Sold', color: 'text-red-400', bg: 'bg-red-400/10', border: 'border-red-400/30' },
  };
  const sc = statusConfig[vehicle.status];

  return (
    <div className={`bg-white/[0.02] border rounded-xl overflow-hidden transition-all ${deleteConfirm ? 'border-red-500/40' : 'border-white/5 hover:border-neon-cyan/30 hover:bg-white/[0.04]'}`}>
      <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 p-4">
        {/* Clickable image to edit */}
        <button
          onClick={onEdit}
          className="w-full sm:w-28 h-20 rounded-lg overflow-hidden flex-shrink-0 bg-gray-900 group relative"
          title="Click to edit full vehicle details"
        >
          {vehicle.image ? (
            <img src={vehicle.image} alt={`${vehicle.make} ${vehicle.model}`} className="w-full h-full object-cover group-hover:opacity-70 transition-opacity" />
          ) : (
            <div className="w-full h-full flex items-center justify-center"><Car className="w-8 h-8 text-gray-700" /></div>
          )}
          <div className="absolute inset-0 bg-neon-cyan/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
            <Edit2 className="w-5 h-5 text-white drop-shadow-lg" />
          </div>
        </button>
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <button onClick={onEdit} className="text-left group/title" title="Click to edit full vehicle details">
              <h3 className="text-white font-semibold text-sm leading-tight group-hover/title:text-neon-cyan transition-colors">
                {vehicle.year} {vehicle.make} {vehicle.model}
              </h3>
              <p className="text-gray-500 text-xs mt-0.5">{vehicle.trim} {vehicle.exteriorColor && `| ${vehicle.exteriorColor}`}</p>
            </button>
            <div className="text-right flex-shrink-0">
              <button onClick={onQuickPrice} className="text-neon-orange font-bold text-sm hover:underline" title="Click to edit price">
                ${vehicle.price.toLocaleString()}
              </button>
              <p className="text-gray-600 text-[11px]">{vehicle.mileage.toLocaleString()} mi</p>
            </div>
          </div>
          <div className="flex items-center gap-3 mt-2 flex-wrap">
            <div className="relative">
              <button onClick={() => setShowStatusMenu(!showStatusMenu)}
                className={`flex items-center gap-1.5 px-2.5 py-1 ${sc.bg} ${sc.border} border rounded-full text-xs font-medium ${sc.color} hover:opacity-80 transition-opacity`}
                title="Click to change status">
                {sc.label}<ChevronDown className="w-3 h-3" />
              </button>
              {showStatusMenu && (
                <>
                  <div className="fixed inset-0 z-10" onClick={() => setShowStatusMenu(false)} />
                  <div className="absolute top-full left-0 mt-1 z-20 bg-[#1a1a1a] border border-white/10 rounded-lg shadow-xl overflow-hidden min-w-[140px]">
                    {(Object.keys(statusConfig) as Vehicle['status'][]).map((status) => {
                      const cfg = statusConfig[status];
                      return (
                        <button key={status} onClick={() => { setShowStatusMenu(false); if (status !== vehicle.status) onStatusChange(status); }}
                          className={`w-full px-3 py-2 text-left text-xs font-medium hover:bg-white/5 transition-colors flex items-center gap-2 ${status === vehicle.status ? cfg.color : 'text-gray-400'}`}>
                          {status === vehicle.status && <CheckCircle className="w-3 h-3" />}{cfg.label}
                        </button>
                      );
                    })}
                  </div>
                </>
              )}
            </div>
            <span className="text-gray-600 text-[11px]">{vehicle.bodyType}</span>
            <span className="text-gray-600 text-[11px]">{vehicle.drivetrain}</span>
            {vehicle.vin && <span className="text-gray-600 text-[11px] font-mono">{vehicle.vin}</span>}
            <div className="flex items-center gap-1 ml-auto">
              {isLoading ? (
                <Loader2 className="w-4 h-4 text-gray-400 animate-spin" />
              ) : deleteConfirm ? (
                <div className="flex items-center gap-2">
                  <span className="text-red-400 text-xs font-medium">Delete this vehicle?</span>
                  <button onClick={onDeleteConfirm} className="px-3 py-1 bg-red-500 text-white text-xs font-semibold rounded-lg hover:bg-red-600 transition-colors">Yes, Delete</button>
                  <button onClick={onDeleteCancel} className="px-3 py-1 border border-white/10 text-gray-400 text-xs rounded-lg hover:text-white transition-colors">Cancel</button>
                </div>
              ) : (
                <>
                  <button onClick={onAIPrice} className="p-2 text-gray-500 hover:text-indigo-400 transition-colors" title="AI Price Advisor">
                    <Sparkles className="w-4 h-4" />
                  </button>
                  <button onClick={onAIDescription} className="p-2 text-gray-500 hover:text-teal-400 transition-colors" title="AI Description Writer">
                    <PenTool className="w-4 h-4" />
                  </button>
                  {/* Prominent Edit button with label */}
                  <button
                    onClick={onEdit}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-neon-cyan/10 border border-neon-cyan/30 text-neon-cyan hover:bg-neon-cyan/20 rounded-lg text-xs font-semibold transition-colors"
                    title="Edit full vehicle details"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Edit</span>
                  </button>
                  <button onClick={onDeleteRequest} className="p-2 text-gray-500 hover:text-red-400 transition-colors" title="Delete vehicle"><Trash2 className="w-4 h-4" /></button>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Admin;

