import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Navbar from '@/components/dealership/Navbar';
import Footer from '@/components/dealership/Footer';
import { ArrowLeft, Target, Heart, Shield, Award, Handshake, Star, Car, TrendingUp, Phone, Mail, ChevronRight, Sparkles, Eye, Clock, Building2, Gem, ThumbsUp, Wrench } from 'lucide-react';
import { useSiteContent } from '@/hooks/useSiteContent';
import { usePageSEO } from '@/hooks/usePageSEO';


// Icon name to component mapping for CMS-driven content
const ICON_MAP: Record<string, React.ElementType> = {
  Shield, Heart, Award, Handshake, Gem, TrendingUp, Star, Building2, Clock, Sparkles, Eye, Car, Target, ThumbsUp, Wrench
};
const getIcon = (name: string): React.ElementType => ICON_MAP[name] || Star;

const HERO_IMAGE = 'https://d64gsuwffb70l.cloudfront.net/69c07f5eedda49fd18b3c790_1774304920400_26d52777.jpg';

// Default fallback data (used when DB has no content yet)
const DEFAULT_HERO_SUBTITLE = "More than a dealership — we're a Long Island family dedicated to helping you find the perfect vehicle with honesty, transparency, and a personal touch you won't find anywhere else.";
const DEFAULT_HERO_STATS = [
  { value: '14+', label: 'Years in Business' },
  { value: '1,500+', label: 'Vehicles Sold' },
  { value: '5.0', label: 'Star Rating' },
  { value: '98%', label: 'Customer Satisfaction' },
];
const DEFAULT_STORY_PARAGRAPHS = [
  "Ex$ell Car Sales LI was born in 2012 from a simple frustration: buying a used car shouldn't feel like navigating a minefield. Founder Joey Farino III, a lifelong car enthusiast and Long Island native, had seen too many friends and family members burned by shady dealers, hidden fees, and vehicles that weren't what they seemed.",
  "Starting with just eight carefully selected vehicles on a modest lot in Suffolk County, Joey set out to prove that a pre-owned dealership could be built on radical transparency. Every vehicle came with a full history report. Every price was clearly posted with no hidden add-ons. Every customer was treated like family.",
  "Word spread quickly. Neighbors told neighbors. Families came back for their second and third vehicles. What started as one man's mission became a team of passionate automotive professionals who share the same belief: you deserve better than the typical car-buying experience.",
  "Today, Ex$ell Car Sales LI is one of Long Island's most trusted names in pre-owned vehicles, with over 1,500 happy customers and a 5-star reputation that we work hard to earn every single day."
];
const DEFAULT_MISSION = "To redefine the pre-owned vehicle experience on Long Island by combining exceptional quality, radical transparency, and genuine care for every customer who walks through our doors.";
const DEFAULT_VISION = "To be the dealership that Long Island families recommend without hesitation — where every vehicle is a source of pride, every transaction is built on trust, and every customer becomes part of the Ex$ell family.";

const TEAM_MEMBERS = [{
  name: 'Joey Farino III',
  role: 'Founder & Owner',
  image: 'https://d64gsuwffb70l.cloudfront.net/69c07f5eedda49fd18b3c790_1774304803267_ffdd50d5.png',
  bio: 'With over 20 years in the automotive industry, Joey founded Ex$ell Car Sales LI with a simple vision: make buying a quality pre-owned vehicle an honest, stress-free experience. His passion for cars and people drives everything we do.',
  color: 'neon-pink'

}, {
  name: 'Sophia Reyes',
  role: 'Sales Manager',
  image: 'https://d64gsuwffb70l.cloudfront.net/69c07f5eedda49fd18b3c790_1774304821249_778d451a.jpg',
  bio: "Sophia's encyclopedic knowledge of every vehicle on the lot and her genuine desire to match customers with the perfect car have made her an invaluable part of the team. She's been with Ex$ell since 2018.",
  color: 'neon-cyan'
}, {
  name: 'David Chen',
  role: 'Buyer Concierge',
  image: 'https://d64gsuwffb70l.cloudfront.net/69c07f5eedda49fd18b3c790_1774304842393_d378fa18.png',
  bio: 'David walks buyers through every step of the purchase — vehicle history, paperwork, and pickup logistics — so the transaction is smooth and stress-free from first visit to keys in hand.',
  color: 'neon-green'
}, {

  name: 'Carlos Rivera',
  role: 'Lead Technician',
  image: 'https://d64gsuwffb70l.cloudfront.net/69c07f5eedda49fd18b3c790_1774304858352_d5e5637b.jpg',
  bio: 'ASE-certified with 12 years of experience, Carlos leads our multi-point inspection process. Every vehicle that earns the Ex$ell seal of approval passes through his meticulous hands first.',
  color: 'neon-orange'
}, {
  name: 'Aisha Johnson',
  role: 'Customer Experience Lead',
  image: 'https://d64gsuwffb70l.cloudfront.net/69c07f5eedda49fd18b3c790_1774304879648_c14f0906.png',
  bio: "Aisha ensures every customer interaction — from the first phone call to post-purchase follow-up — is exceptional. She's the reason our reviews consistently mention how welcomed and valued customers feel.",
  color: 'neon-purple'
}, {
  name: 'Jake Morrison',
  role: 'Detailing Specialist',
  image: 'https://d64gsuwffb70l.cloudfront.net/69c07f5eedda49fd18b3c790_1774304898157_8a2920f4.jpg',
  bio: "Jake's obsession with perfection means every vehicle that leaves our lot looks showroom-ready. His detailing work has become a signature part of the Ex$ell experience that customers rave about.",
  color: 'neon-cyan'
}];
const CORE_VALUES = [{
  icon: Shield,
  title: 'Transparency',
  description: 'No hidden fees, no bait-and-switch tactics. We provide full vehicle history reports, honest condition assessments, and upfront pricing on every vehicle.',
  color: 'from-neon-cyan to-blue-500',
  dotColor: 'bg-neon-cyan'
}, {
  icon: Heart,
  title: 'Customer First',
  description: "Your needs drive our business. We listen, we advise, and we never pressure. If a vehicle isn't right for you, we'll be the first to say so.",
  color: 'from-neon-pink to-rose-500',
  dotColor: 'bg-neon-pink'
}, {
  icon: Award,
  title: 'Quality Assurance',
  description: 'Every vehicle undergoes a rigorous multi-point inspection. We only put our name on cars we would confidently recommend to our own families.',
  color: 'from-neon-orange to-amber-500',
  dotColor: 'bg-neon-orange'
}, {
  icon: Handshake,
  title: 'Community Roots',
  description: "We're not a faceless corporation — we're your Long Island neighbors. We sponsor local events, support area charities, and believe in giving back to the community that supports us.",
  color: 'from-neon-green to-emerald-500',
  dotColor: 'bg-neon-green'
}, {
  icon: Gem,
  title: 'Integrity',
  description: 'We treat every customer the way we would want to be treated. Honest dealings, fair pricing, and standing behind every vehicle we sell.',
  color: 'from-neon-purple to-violet-500',
  dotColor: 'bg-neon-purple'
}, {
  icon: TrendingUp,
  title: 'Continuous Improvement',
  description: 'We constantly invest in our team, our technology, and our processes to deliver an ever-better car-buying experience.',
  color: 'from-yellow-400 to-orange-500',
  dotColor: 'bg-yellow-400'
}];
const MILESTONE_COLORS: Record<string, {
  border: string;
  text: string;
  bg: string;
  borderBadge: string;
}> = {
  'neon-pink': {
    border: 'border-pink-500/50',
    text: 'text-neon-pink',
    bg: 'bg-neon-pink/10',
    borderBadge: 'border-neon-pink/20'
  },
  'neon-orange': {
    border: 'border-orange-500/50',
    text: 'text-neon-orange',
    bg: 'bg-neon-orange/10',
    borderBadge: 'border-neon-orange/20'
  },
  'neon-cyan': {
    border: 'border-cyan-400/50',
    text: 'text-neon-cyan',
    bg: 'bg-neon-cyan/10',
    borderBadge: 'border-neon-cyan/20'
  },
  'neon-green': {
    border: 'border-green-400/50',
    text: 'text-neon-green',
    bg: 'bg-neon-green/10',
    borderBadge: 'border-neon-green/20'
  },
  'neon-purple': {
    border: 'border-purple-500/50',
    text: 'text-purple-400',
    bg: 'bg-purple-500/10',
    borderBadge: 'border-purple-500/20'
  }
};
const MILESTONES = [{
  year: '2012',
  title: 'The Beginning',
  description: 'Joey Farino III opens Ex$ell Car Sales LI from a modest lot in Suffolk County with just 8 vehicles and a dream of redefining the pre-owned car experience on Long Island.',

  icon: Building2,
  color: 'neon-pink'
}, {
  year: '2014',
  title: 'First 100 Sales',
  description: 'Within two years, word-of-mouth referrals and a commitment to honesty propel Ex$ell past its first 100 vehicle sales — a milestone that proved the community valued a different kind of dealership.',
  icon: Car,
  color: 'neon-orange'
}, {
  year: '2016',
  title: 'Expanded Showroom',
  description: 'Growing demand leads to a major facility upgrade with a larger showroom, dedicated detailing bay, and a full-service inspection center.',
  icon: TrendingUp,
  color: 'neon-cyan'
}, {
  year: '2018',
  title: 'Detailing Bay Expansion',
  description: 'Ex$ell adds a dedicated in-house detailing bay so every vehicle leaves the lot showroom-clean — a signature part of the customer experience.',
  icon: Sparkles,
  color: 'neon-green'
}, {
  year: '2020',

  title: 'Digital Transformation',
  description: 'Launching a full online inventory experience with virtual walkarounds, online inquiries, and contactless delivery options to serve customers safely during the pandemic.',
  icon: Sparkles,
  color: 'neon-purple'
}, {
  year: '2022',
  title: '1,000+ Happy Customers',
  description: 'A decade of dedication culminates in surpassing 1,000 vehicles sold — each one representing a family that trusted Ex$ell with one of life\'s biggest purchases.',
  icon: Star,
  color: 'neon-pink'
}, {
  year: '2024',
  title: '5-Star Reputation',
  description: 'Ex$ell earns a consistent 5-star rating across Google, Facebook, and DealerRater, cementing its reputation as Long Island\'s most trusted pre-owned dealership.',
  icon: Award,
  color: 'neon-orange'
}, {
  year: '2026',
  title: 'The Future',
  description: 'Investing in AI-powered vehicle matching, expanded delivery radius, and an even larger inventory to continue serving Long Island families for decades to come.',
  icon: Eye,
  color: 'neon-cyan'
}];
const About: React.FC = () => {
  const navigate = useNavigate();
  const [visibleSections, setVisibleSections] = useState<Set<string>>(new Set());
  const { content: siteContent } = useSiteContent();
  usePageSEO('about');


  // ─── Derive dynamic content from DB (with hardcoded fallbacks) ───
  const heroSubtitle = siteContent.about_hero?.subtitle || DEFAULT_HERO_SUBTITLE;
  const heroStats = siteContent.about_hero?.stats || DEFAULT_HERO_STATS;
  const storyParagraphs = siteContent.about_story?.paragraphs || DEFAULT_STORY_PARAGRAPHS;
  const missionText = siteContent.about_mission?.mission || DEFAULT_MISSION;
  const visionText = siteContent.about_mission?.vision || DEFAULT_VISION;

  // Core values from DB (convert icon string to component)
  const dynamicCoreValues = siteContent.about_core_values
    ? (siteContent.about_core_values as any[]).map((v: any) => ({
        icon: getIcon(v.icon),
        title: v.title,
        description: v.description,
        color: v.color || 'from-neon-cyan to-blue-500',
        dotColor: v.color?.includes('pink') ? 'bg-neon-pink' : v.color?.includes('cyan') ? 'bg-neon-cyan' : v.color?.includes('green') ? 'bg-neon-green' : v.color?.includes('orange') ? 'bg-neon-orange' : v.color?.includes('purple') ? 'bg-neon-purple' : 'bg-yellow-400',
      }))
    : CORE_VALUES;

  // Milestones from DB
  const dynamicMilestones = siteContent.about_milestones
    ? (siteContent.about_milestones as any[]).map((m: any) => ({
        year: m.year,
        title: m.title,
        description: m.description,
        icon: getIcon(m.icon),
        color: m.color || 'neon-pink',
      }))
    : MILESTONES;

  // Team from DB
  const dynamicTeam = siteContent.about_team || TEAM_MEMBERS;

  useEffect(() => {
    window.scrollTo({
      top: 0,
      behavior: 'instant' as ScrollBehavior
    });
  }, []);
  useEffect(() => {
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          setVisibleSections(prev => new Set(prev).add(entry.target.id));
        }
      });
    }, {
      threshold: 0.1,
      rootMargin: '0px 0px -50px 0px'
    });
    const sections = document.querySelectorAll('[data-animate]');
    sections.forEach(s => observer.observe(s));
    return () => observer.disconnect();
  }, []);
  const isVisible = (id: string) => visibleSections.has(id);

  return <div className="min-h-screen bg-black text-white">
      <Navbar />

      {/* ═══════════════════ HERO SECTION ═══════════════════ */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0">
          <img src={HERO_IMAGE} alt="Ex$ell Car Sales Showroom" className="w-full h-full object-cover opacity-30" />
          <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/80 to-black" />
          <div className="absolute inset-0 bg-gradient-to-r from-neon-pink/5 via-transparent to-neon-cyan/5" />
        </div>
        <div className="absolute top-20 left-1/4 w-[500px] h-[500px] bg-neon-pink/8 rounded-full blur-[150px]" />
        <div className="absolute top-20 right-1/4 w-[500px] h-[500px] bg-neon-cyan/8 rounded-full blur-[150px]" />

        <div className="relative max-w-7xl mx-auto px-4 pt-12 pb-20 md:pt-16 md:pb-28">
          <button onClick={() => navigate('/')} className="inline-flex items-center gap-2 text-gray-400 hover:text-neon-cyan transition-colors mb-10 group">
            <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
            <span className="text-sm font-medium">Back to Home</span>
          </button>
          <div className="max-w-3xl">
            <div className="flex items-center gap-3 mb-4">
              <div className="h-px w-12 bg-gradient-to-r from-neon-pink to-neon-orange" />
              <span className="text-neon-pink font-semibold text-sm uppercase tracking-widest">Our Story</span>
            </div>
            <h1 className="text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-black leading-[1.1] mb-6">
              <span className="gradient-text-neon">About</span>{' '}
              <span className="text-white">Ex$ell</span><br />
              <span className="text-white">Car Sales LI</span>
            </h1>
            <p className="text-gray-400 text-lg md:text-xl leading-relaxed max-w-2xl">
              {heroSubtitle}
            </p>
            <div className="flex flex-wrap gap-6 md:gap-10 mt-10">
              {heroStats.map((stat: any) => <div key={stat.label} className="text-center">
                <div className="text-2xl md:text-3xl font-black gradient-text-neon">{stat.value}</div>
                <div className="text-gray-500 text-xs md:text-sm font-medium mt-1">{stat.label}</div>
              </div>)}
            </div>
          </div>
        </div>
      </section>

      {/* ═══════════════════ OUR STORY ═══════════════════ */}
      <section className="relative py-20 md:py-28">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-neon-pink/[0.02] to-transparent" />
        <div id="story-section" data-animate className={`relative max-w-7xl mx-auto px-4 transition-all duration-700 ${isVisible('story-section') ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2.5 bg-gradient-to-br from-neon-pink/20 to-neon-orange/20 border border-neon-pink/20 rounded-xl">
                  <Clock className="w-5 h-5 text-neon-pink" />
                </div>
                <span className="text-neon-pink font-semibold text-sm uppercase tracking-widest">Our History</span>
              </div>
              <h2 className="text-3xl md:text-4xl font-black text-white mb-6" data-mixed-content="true">
                Built on Trust,{' '}<span className="gradient-text-neon">Driven by Passion</span>
              </h2>
              <div className="space-y-5 text-gray-400 leading-relaxed">
                {storyParagraphs.map((p: string, i: number) => <p key={i}>{p}</p>)}
              </div>
            </div>

            <div className="relative">
              <div className="absolute -inset-4 bg-gradient-to-br from-neon-pink/10 via-neon-orange/5 to-neon-cyan/10 rounded-3xl blur-2xl" />
              <div className="relative bg-white/[0.03] border border-white/10 rounded-2xl p-8 md:p-10 backdrop-blur-sm">
                <div className="flex items-center gap-3 mb-6">
                  <div className="p-3 bg-gradient-to-br from-neon-cyan/20 to-blue-500/20 border border-neon-cyan/20 rounded-xl">
                    <Target className="w-6 h-6 text-neon-cyan" />
                  </div>
                  <h3 className="text-2xl font-black text-white">Our Mission</h3>
                </div>
                <blockquote className="text-lg md:text-xl text-gray-300 leading-relaxed italic border-l-2 border-neon-pink/50 pl-6 mb-6">
                  "{missionText}"
                </blockquote>
                <div className="h-px bg-gradient-to-r from-neon-pink/30 via-neon-orange/30 to-transparent mb-6" />
                <div className="space-y-4">
                  <h4 className="text-white font-bold text-sm uppercase tracking-wider">Our Vision</h4>
                  <p className="text-gray-400 leading-relaxed">{visionText}</p>
                </div>
                <div className="absolute top-0 right-0 w-20 h-20 border-t-2 border-r-2 border-neon-pink/20 rounded-tr-2xl" />
                <div className="absolute bottom-0 left-0 w-20 h-20 border-b-2 border-l-2 border-neon-cyan/20 rounded-bl-2xl" />
              </div>
            </div>
          </div>
        </div>
      </section>



      {/* ═══════════════════ CORE VALUES ═══════════════════ */}
      <section className="relative py-20 md:py-28">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-neon-cyan/[0.02] to-transparent" />
        <div className="absolute top-1/2 left-0 w-[600px] h-[600px] bg-neon-cyan/5 rounded-full blur-[200px] -translate-y-1/2" />

        <div className="relative max-w-7xl mx-auto px-4">
          <div id="values-header" data-animate className={`text-center mb-14 transition-all duration-700 ${isVisible('values-header') ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
            <div className="flex items-center justify-center gap-3 mb-4">
              <div className="h-px w-12 bg-gradient-to-r from-transparent to-neon-cyan" />
              <span className="text-neon-cyan font-semibold text-sm uppercase tracking-widest">
                What We Stand For
              </span>
              <div className="h-px w-12 bg-gradient-to-l from-transparent to-neon-cyan" />
            </div>
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-black text-white">
              Our Core <span className="gradient-text-neon">Values</span>
            </h2>
            <p className="text-gray-500 mt-4 max-w-2xl mx-auto text-lg">
              These aren't just words on a wall — they're the principles that
              guide every decision we make and every interaction we have.
            </p>
          </div>

          <div id="values-grid" data-animate className={`grid sm:grid-cols-2 lg:grid-cols-3 gap-6 transition-all duration-700 delay-200 ${isVisible('values-grid') ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
            {CORE_VALUES.map((value, i) => {
            const Icon = value.icon;
            return <div key={value.title} className="group relative bg-white/[0.02] border border-white/5 rounded-2xl p-7 hover:border-white/15 transition-all duration-500 hover:-translate-y-1" style={{
              animationDelay: `${i * 100}ms`
            }}>
                  {/* Hover glow */}
                  <div className={`absolute inset-0 bg-gradient-to-br ${value.color} opacity-0 group-hover:opacity-[0.03] rounded-2xl transition-opacity duration-500`} />

                  <div className="relative">
                    <div className={`inline-flex p-3 bg-gradient-to-br ${value.color} bg-opacity-20 rounded-xl mb-5`} style={{
                  background: 'rgba(255,255,255,0.03)'
                }}>
                      <Icon className="w-6 h-6 text-white/80" />
                    </div>
                    <div className="flex items-center gap-2 mb-3">
                      <span className={`w-2 h-2 rounded-full ${value.dotColor}`} />
                      <h3 className="text-lg font-bold text-white">
                        {value.title}
                      </h3>
                    </div>
                    <p className="text-gray-500 leading-relaxed text-sm">
                      {value.description}
                    </p>
                  </div>
                </div>;
          })}
          </div>
        </div>
      </section>

      {/* ═══════════════════ TIMELINE ═══════════════════ */}
      <section className="relative py-20 md:py-28 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-neon-orange/[0.02] to-transparent" />
        <div className="absolute top-1/3 right-0 w-[500px] h-[500px] bg-neon-orange/5 rounded-full blur-[200px]" />

        <div className="relative max-w-5xl mx-auto px-4">
          <div id="timeline-header" data-animate className={`text-center mb-16 transition-all duration-700 ${isVisible('timeline-header') ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
            <div className="flex items-center justify-center gap-3 mb-4">
              <div className="h-px w-12 bg-gradient-to-r from-transparent to-neon-orange" />
              <span className="text-neon-orange font-semibold text-sm uppercase tracking-widest">
                Our Journey
              </span>
              <div className="h-px w-12 bg-gradient-to-l from-transparent to-neon-orange" />
            </div>
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-black text-white" data-mixed-content="true">
              Milestones &{' '}
              <span className="gradient-text-neon">Achievements</span>
            </h2>
            <p className="text-gray-500 mt-4 max-w-2xl mx-auto text-lg">
              From a small lot with big dreams to Long Island's most trusted
              pre-owned dealership — here's how we got here.
            </p>
          </div>

          {/* Timeline */}
          <div id="timeline-items" data-animate className={`relative transition-all duration-700 delay-200 ${isVisible('timeline-items') ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
            {/* Center line */}
            <div className="absolute left-6 md:left-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-neon-pink/40 via-neon-orange/40 to-neon-cyan/40" />

            <div className="space-y-12">
              {MILESTONES.map((milestone, i) => {
              const Icon = milestone.icon;
              const isLeft = i % 2 === 0;
              const mc = MILESTONE_COLORS[milestone.color] || MILESTONE_COLORS['neon-pink'];
              return <div key={milestone.year} className={`relative flex items-start gap-6 md:gap-0 ${isLeft ? 'md:flex-row' : 'md:flex-row-reverse'}`}>
                    {/* Dot on the line */}
                    <div className="absolute left-6 md:left-1/2 -translate-x-1/2 z-10">
                      <div className={`w-12 h-12 rounded-full bg-black border-2 ${mc.border} flex items-center justify-center`}>
                        <Icon className={`w-5 h-5 ${mc.text}`} />
                      </div>
                    </div>

                    {/* Content */}
                    <div className={`ml-16 md:ml-0 md:w-[calc(50%-2rem)] ${isLeft ? 'md:pr-8 md:text-right' : 'md:pl-8 md:text-left'}`}>
                      <div className={`inline-block px-3 py-1 rounded-full text-xs font-bold tracking-wider mb-3 ${mc.bg} ${mc.text} border ${mc.borderBadge}`}>
                        {milestone.year}
                      </div>
                      <h3 className="text-xl font-bold text-white mb-2">
                        {milestone.title}
                      </h3>
                      <p className="text-gray-500 leading-relaxed text-sm">
                        {milestone.description}
                      </p>
                    </div>

                    {/* Spacer for opposite side */}
                    <div className="hidden md:block md:w-[calc(50%-2rem)]" />
                  </div>;
            })}
            </div>
          </div>
        </div>
      </section>


      {/* ═══════════════════ TEAM SECTION ═══════════════════ */}
      <section className="relative py-20 md:py-28">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-neon-pink/[0.02] to-transparent" />
        <div className="absolute bottom-0 left-1/3 w-[600px] h-[600px] bg-neon-pink/5 rounded-full blur-[200px]" />

        <div className="relative max-w-7xl mx-auto px-4">
          <div id="team-header" data-animate className={`text-center mb-14 transition-all duration-700 ${isVisible('team-header') ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
            <div className="flex items-center justify-center gap-3 mb-4">
              <div className="h-px w-12 bg-gradient-to-r from-transparent to-neon-pink" />
              <span className="text-neon-pink font-semibold text-sm uppercase tracking-widest">
                The People Behind the Brand
              </span>
              <div className="h-px w-12 bg-gradient-to-l from-transparent to-neon-pink" />
            </div>
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-black text-white">
              Meet Our <span className="gradient-text-neon">Team</span>
            </h2>
            <p className="text-gray-500 mt-4 max-w-2xl mx-auto text-lg">
              Every member of the Ex$ell family is here because they genuinely
              love cars and love helping people. Get to know the faces behind
              your next vehicle purchase.
            </p>
          </div>

          <div id="team-grid" data-animate className={`grid sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8 transition-all duration-700 delay-200 ${isVisible('team-grid') ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
            {TEAM_MEMBERS.map((member, i) => <TeamCard key={member.name} member={member} index={i} />)}
          </div>
        </div>
      </section>

      {/* ═══════════════════ CTA SECTION ═══════════════════ */}
      <section className="relative py-20 md:py-28 overflow-hidden">
        {/* Background effects */}
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-neon-pink/[0.04] to-transparent" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-neon-pink/5 rounded-full blur-[200px]" />

        <div id="cta-section" data-animate className={`relative max-w-4xl mx-auto px-4 transition-all duration-700 ${isVisible('cta-section') ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <div className="relative bg-white/[0.03] border border-white/10 rounded-3xl p-8 md:p-14 text-center backdrop-blur-sm overflow-hidden">
            {/* Decorative gradient border glow */}
            <div className="absolute -top-px left-0 right-0 h-px bg-gradient-to-r from-transparent via-neon-pink/60 to-transparent" />
            <div className="absolute -bottom-px left-0 right-0 h-px bg-gradient-to-r from-transparent via-neon-cyan/60 to-transparent" />
            <div className="absolute top-0 -left-px w-px h-full bg-gradient-to-b from-transparent via-neon-pink/30 to-transparent" />
            <div className="absolute top-0 -right-px w-px h-full bg-gradient-to-b from-transparent via-neon-cyan/30 to-transparent" />

            {/* Corner accents */}
            <div className="absolute top-4 left-4 w-8 h-8 border-t border-l border-neon-pink/30 rounded-tl-lg" />
            <div className="absolute top-4 right-4 w-8 h-8 border-t border-r border-neon-cyan/30 rounded-tr-lg" />
            <div className="absolute bottom-4 left-4 w-8 h-8 border-b border-l border-neon-cyan/30 rounded-bl-lg" />
            <div className="absolute bottom-4 right-4 w-8 h-8 border-b border-r border-neon-pink/30 rounded-br-lg" />

            <div className="relative">
              <div className="inline-flex p-4 bg-gradient-to-br from-neon-pink/20 to-neon-orange/20 border border-neon-pink/20 rounded-2xl mb-6">
                <Car className="w-8 h-8 text-neon-pink" />
              </div>

              <h2 className="text-3xl md:text-4xl lg:text-5xl font-black text-white mb-4" data-mixed-content="true">
                Ready to Find Your{' '}
                <span className="gradient-text-neon">Perfect Ride?</span>
              </h2>
              <p className="text-gray-400 text-lg max-w-2xl mx-auto mb-10 leading-relaxed">
                Browse our hand-picked inventory of quality pre-owned vehicles,
                or reach out to our team directly. We're here to help you every
                step of the way — no pressure, just honest advice.
              </p>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <button onClick={() => {
                navigate('/');
                setTimeout(() => {
                  const el = document.getElementById('inventory');
                  if (el) el.scrollIntoView({
                    behavior: 'smooth'
                  });
                }, 200);
              }} className="inline-flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-neon-pink to-neon-orange text-white font-bold rounded-xl hover:opacity-90 transition-opacity neon-pulse text-base">
                  <Car className="w-5 h-5" />
                  Browse Inventory
                  <ChevronRight className="w-4 h-4" />
                </button>

                <button onClick={() => {
                navigate('/');
                setTimeout(() => {
                  const el = document.getElementById('contact');
                  if (el) el.scrollIntoView({
                    behavior: 'smooth'
                  });
                }, 200);
              }} className="inline-flex items-center gap-2 px-8 py-4 border border-neon-cyan/50 text-neon-cyan font-bold rounded-xl hover:bg-neon-cyan/10 transition-colors text-base">
                  <Mail className="w-5 h-5" />
                  Contact the Team
                </button>

                <a href="tel:6313884426" className="inline-flex items-center gap-2 px-8 py-4 border border-neon-green/50 text-neon-green font-bold rounded-xl hover:bg-neon-green/10 transition-colors text-base">
                  <Phone className="w-5 h-5" />
                  Call Now
                </a>
              </div>

              {/* Trust badges */}
              <div className="flex flex-wrap items-center justify-center gap-6 mt-10 pt-8 border-t border-white/5">
                {[{
                icon: Shield,
                label: 'Full Vehicle History'
              }, {
                icon: ThumbsUp,
                label: 'No-Pressure Sales'
              }, {
                icon: Wrench,
                label: 'Multi-Point Inspection'
              }, {
                icon: Award,
                label: '5-Star Rated'
              }].map(badge => {
                const Icon = badge.icon;
                return <div key={badge.label} className="flex items-center gap-2 text-gray-500 text-sm">
                      <Icon className="w-4 h-4 text-neon-pink/60" />
                      <span>{badge.label}</span>
                    </div>;
              })}
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>;
};

/* ─── Team Card Sub-component ─── */

interface TeamCardProps {
  member: (typeof TEAM_MEMBERS)[number];
  index: number;
}
const TeamCard: React.FC<TeamCardProps> = ({
  member,
  index
}) => {
  const [hovered, setHovered] = useState(false);
  const colorMap: Record<string, {
    border: string;
    glow: string;
    text: string;
  }> = {
    'neon-pink': {
      border: 'border-neon-pink/30',
      glow: 'bg-neon-pink/10',
      text: 'text-neon-pink'
    },
    'neon-cyan': {
      border: 'border-neon-cyan/30',
      glow: 'bg-neon-cyan/10',
      text: 'text-neon-cyan'
    },
    'neon-green': {
      border: 'border-neon-green/30',
      glow: 'bg-neon-green/10',
      text: 'text-neon-green'
    },
    'neon-orange': {
      border: 'border-neon-orange/30',
      glow: 'bg-neon-orange/10',
      text: 'text-neon-orange'
    },
    'neon-purple': {
      border: 'border-purple-500/30',
      glow: 'bg-purple-500/10',
      text: 'text-purple-400'
    }
  };
  const colors = colorMap[member.color] || colorMap['neon-pink'];
  return <div className={`group relative bg-white/[0.02] border border-white/5 rounded-2xl overflow-hidden hover:border-white/15 transition-all duration-500 hover:-translate-y-1`} onMouseEnter={() => setHovered(true)} onMouseLeave={() => setHovered(false)}>
      {/* Image */}
      <div className="relative aspect-[4/5] overflow-hidden"><img src={member.image} alt={member.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />{/* Gradient overlay */}<div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-transparent" />{/* Name overlay at bottom of image */}<div className="absolute bottom-0 left-0 right-0 p-6">
          <h3 className="text-xl font-bold text-white mb-1">{member.name}</h3>
          <div className="flex items-center gap-2">
            <span className={`w-2 h-2 rounded-full ${colors.glow.replace('/10', '/80')}`} style={{
            backgroundColor: member.color === 'neon-pink' ? 'rgb(255, 44, 108)' : member.color === 'neon-cyan' ? 'rgb(0, 245, 255)' : member.color === 'neon-green' ? 'rgb(57, 255, 20)' : member.color === 'neon-orange' ? 'rgb(255, 165, 0)' : 'rgb(168, 85, 247)'
          }} />
            <span className={`text-sm font-semibold ${colors.text}`}>
              {member.role}
            </span>
          </div>
        </div></div>


      {/* Bio */}
      <div className="p-6 pt-4">
        <p className="text-gray-500 text-sm leading-relaxed">{member.bio}</p>
      </div>

      {/* Bottom accent line */}
      <div className={`h-0.5 bg-gradient-to-r from-transparent ${member.color === 'neon-pink' ? 'via-neon-pink/50' : member.color === 'neon-cyan' ? 'via-neon-cyan/50' : member.color === 'neon-green' ? 'via-neon-green/50' : member.color === 'neon-orange' ? 'via-neon-orange/50' : 'via-purple-500/50'} to-transparent transition-opacity duration-500 ${hovered ? 'opacity-100' : 'opacity-0'}`} />
    </div>;
};
export default About;