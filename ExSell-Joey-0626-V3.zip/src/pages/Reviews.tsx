import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Navbar from '@/components/dealership/Navbar';
import Footer from '@/components/dealership/Footer';
import GoogleReviewsLive from '@/components/dealership/GoogleReviewsLive';
import {
  Star,
  ArrowLeft,
  MessageSquare,
  Award,
  Car,
  ExternalLink,
  MapPin,
  Heart,
  PenSquare,
  Share2,
} from 'lucide-react';
import { usePageSEO } from '@/hooks/usePageSEO';
import { useReviewsJsonLd } from '@/hooks/useReviewsJsonLd';

import { useSiteContent } from '@/hooks/useSiteContent';
import { usePlaceConfig } from '@/hooks/usePlaceConfig';
import {
  GOOGLE_BUSINESS_URL,
  FACEBOOK_PAGE_URL,
  FACEBOOK_REVIEWS_URL,
} from '@/lib/googlePlace';

const Reviews: React.FC = () => {
  usePageSEO('reviews');
  useReviewsJsonLd({ pagePath: '/reviews' });
  const navigate = useNavigate();
  const { content } = useSiteContent();
  const address = content?.contact?.address || 'Long Island, NY';

  // Live Google Place ID configuration (admin-editable in /admin → Content)
  const {
    placeId,
    isPlaceholder: isPlaceholderPlaceId,
    writeReviewUrl,
    mapsEmbedUrl,
  } = usePlaceConfig();


  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });
  }, []);

  // Use the Place ID embed when configured; otherwise fall back to query embed
  const mapEmbedSrc = mapsEmbedUrl;




  const handleShare = async () => {
    const shareData = {
      title: 'Ex$ell Car Sales LI Reviews',
      text: 'Check out the reviews for Ex$ell Car Sales LI on Google!',
      url: GOOGLE_BUSINESS_URL,
    };
    if (navigator.share) {
      try {
        await navigator.share(shareData);
      } catch {
        /* user cancelled */
      }
    } else {
      navigator.clipboard?.writeText(GOOGLE_BUSINESS_URL);
    }
  };

  return (
    <div className="min-h-screen bg-black text-white">
      <Navbar />

      {/* ─── Hero Banner ─── */}
      <section className="relative overflow-hidden pt-8 pb-16">
        <div className="absolute inset-0 bg-gradient-to-b from-neon-orange/5 via-transparent to-transparent" />
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-neon-orange/5 rounded-full blur-[120px]" />
        <div className="absolute top-0 right-1/4 w-96 h-96 bg-neon-cyan/5 rounded-full blur-[120px]" />

        <div className="relative max-w-6xl mx-auto px-4">
          <button
            onClick={() => navigate('/')}
            className="inline-flex items-center gap-2 text-gray-400 hover:text-neon-cyan transition-colors mb-8 group"
          >
            <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
            <span className="text-sm font-medium">Back to Home</span>
          </button>

          <div className="flex items-center gap-4 mb-6">
            <div className="p-3 bg-gradient-to-br from-neon-orange/20 to-neon-pink/20 border border-neon-orange/20 rounded-xl">
              <MessageSquare className="w-8 h-8 text-neon-orange" />
            </div>
            <div>
              <h1 className="text-3xl md:text-4xl lg:text-5xl font-black gradient-text-neon">
                Customer Reviews
              </h1>
              <p className="text-gray-500 text-sm mt-1">
                Read real reviews on Google &amp; Facebook
              </p>
            </div>
          </div>

          <p className="text-gray-400 text-lg leading-relaxed max-w-3xl">
            We let our customers do the talking. All of our reviews live on Google and
            Facebook — verified, unfiltered, and straight from the people who've shopped
            with us at Ex$ell Car Sales LI.
          </p>
        </div>
      </section>

      {/* ─── Live Google Reviews (rating + count + 5 most recent snippets) ─── */}
      <section className="max-w-6xl mx-auto px-4 -mt-4">
        <GoogleReviewsLive
          placeId={placeId}
          businessUrl={GOOGLE_BUSINESS_URL}
          disabled={isPlaceholderPlaceId}
        />
      </section>


      {/* ─── Primary Review Platform CTAs ─── */}
      <section className="max-w-6xl mx-auto px-4 pb-16">

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Google Card */}
          <div className="relative overflow-hidden bg-gradient-to-br from-white/[0.04] to-white/[0.02] border border-white/10 rounded-2xl p-8 hover:border-neon-orange/30 transition-colors group">
            <div className="absolute top-0 right-0 w-64 h-64 bg-neon-orange/5 rounded-full blur-[80px]" />
            <div className="relative">
              <div className="flex items-center gap-4 mb-5">
                <div className="w-14 h-14 bg-white rounded-xl flex items-center justify-center flex-shrink-0">
                  <svg className="w-8 h-8" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                    />
                  </svg>
                </div>
                <div>
                  <h2 className="text-2xl font-black text-white">Google Reviews</h2>
                  <div className="flex items-center gap-2 mt-1">
                    <div className="flex">
                      {[1, 2, 3, 4, 5].map((s) => (
                        <Star key={s} className="w-4 h-4 fill-neon-orange text-neon-orange" />
                      ))}
                    </div>
                    <span className="text-gray-400 text-sm">Trusted by thousands</span>
                  </div>
                </div>
              </div>
              <p className="text-gray-400 leading-relaxed mb-6">
                See what real customers are saying on our Google Business Profile —
                ratings, photos, and detailed feedback from verified buyers.
              </p>
              <a
                href={GOOGLE_BUSINESS_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 w-full sm:w-auto justify-center px-6 py-3.5 bg-gradient-to-r from-neon-pink to-neon-orange text-white font-bold rounded-lg shadow-lg shadow-neon-orange/20 hover:opacity-90 transition-opacity"
              >
                Read our reviews on Google
                <ExternalLink className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Facebook Card */}
          <div className="relative overflow-hidden bg-gradient-to-br from-white/[0.04] to-white/[0.02] border border-white/10 rounded-2xl p-8 hover:border-neon-cyan/30 transition-colors group">
            <div className="absolute top-0 right-0 w-64 h-64 bg-neon-cyan/5 rounded-full blur-[80px]" />
            <div className="relative">
              <div className="flex items-center gap-4 mb-5">
                <div className="w-14 h-14 bg-[#1877F2] rounded-xl flex items-center justify-center flex-shrink-0">
                  <svg className="w-8 h-8 text-white" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                  </svg>
                </div>
                <div>
                  <h2 className="text-2xl font-black text-white">Facebook Reviews</h2>
                  <div className="flex items-center gap-2 mt-1">
                    <Heart className="w-4 h-4 text-neon-pink fill-neon-pink" />
                    <span className="text-gray-400 text-sm">Join our community</span>
                  </div>
                </div>
              </div>
              <p className="text-gray-400 leading-relaxed mb-6">
                Connect with us on Facebook to read recommendations from neighbors
                across Long Island and see updates on our latest inventory.
              </p>
              <a
                href={FACEBOOK_REVIEWS_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 w-full sm:w-auto justify-center px-6 py-3.5 border border-neon-cyan/50 text-neon-cyan font-bold rounded-lg hover:bg-neon-cyan/10 transition-colors"
              >
                Review us on Facebook
                <ExternalLink className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* ─── Divider ─── */}
      <div className="max-w-6xl mx-auto px-4">
        <div className="h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
      </div>

      {/* ─── Embedded Google Map ─── */}
      <section className="max-w-6xl mx-auto px-4 py-16">
        <div className="text-center mb-8">
          <div className="inline-flex p-3 bg-gradient-to-br from-neon-cyan/20 to-neon-green/20 border border-neon-cyan/20 rounded-xl mb-4">
            <MapPin className="w-7 h-7 text-neon-cyan" />
          </div>
          <h2 className="text-2xl md:text-4xl font-black text-white mb-3">
            Find Us On <span className="gradient-text-neon">Google Maps</span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Click the map to view our location, reviews, photos, and directions on Google.
          </p>
        </div>

        <div className="relative bg-white/[0.02] border border-white/10 rounded-2xl overflow-hidden">
          <div className="relative w-full" style={{ paddingBottom: '50%' }}>
            <iframe
              title="Ex$ell Car Sales LI on Google Maps"
              src={mapEmbedSrc}
              className="absolute inset-0 w-full h-full border-0"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              allowFullScreen
            />
          </div>

          {/* Overlay info bar */}
          <div className="p-5 border-t border-white/10 bg-black/40 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-neon-orange/10 rounded-lg">
                <MapPin className="w-5 h-5 text-neon-orange" />
              </div>
              <div>
                <div className="text-white font-bold">Ex$ell Car Sales LI</div>
                <div className="text-gray-500 text-sm">{address}</div>
              </div>
            </div>
            <a
              href={GOOGLE_BUSINESS_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-white/[0.05] border border-white/10 text-white text-sm font-semibold rounded-lg hover:bg-white/10 transition-colors"
            >
              View Reviews &amp; Rating on Google
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>
      </section>

      {/* ─── Divider ─── */}
      <div className="max-w-6xl mx-auto px-4">
        <div className="h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
      </div>

      {/* ─── Leave a Review CTA ─── */}
      <section className="max-w-6xl mx-auto px-4 py-16">
        <div className="relative overflow-hidden bg-white/[0.02] border border-white/5 rounded-2xl p-8 md:p-12">
          <div className="absolute top-0 right-0 w-80 h-80 bg-neon-orange/5 rounded-full blur-[100px]" />
          <div className="absolute bottom-0 left-0 w-80 h-80 bg-neon-cyan/5 rounded-full blur-[100px]" />

          <div className="relative text-center max-w-2xl mx-auto mb-10">
            <div className="inline-flex p-3 bg-gradient-to-br from-neon-orange/20 to-neon-pink/20 border border-neon-orange/20 rounded-xl mb-6">
              <PenSquare className="w-8 h-8 text-neon-orange" />
            </div>
            <h2 className="text-2xl md:text-4xl font-black text-white mb-4">
              Recently Bought a Car From <span className="gradient-text-neon">Ex$ell</span>?
            </h2>
            <p className="text-gray-400 text-lg leading-relaxed">
              Your review helps other Long Island car buyers find their perfect ride —
              and it means the world to our family business. It only takes a minute!
            </p>
          </div>

          {/* Review Action Cards */}
          <div className="relative grid grid-cols-1 md:grid-cols-2 gap-5 max-w-3xl mx-auto">
            <a
              href={writeReviewUrl}

              target="_blank"
              rel="noopener noreferrer"
              className="group p-6 bg-black/40 border border-white/10 rounded-xl hover:border-neon-orange/40 transition-colors"
            >
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center">
                  <svg className="w-6 h-6" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                    />
                  </svg>
                </div>
                <h3 className="text-white font-bold">Leave a Google Review</h3>
              </div>
              <p className="text-gray-400 text-sm mb-4 leading-relaxed">
                Rate your experience and help us reach more happy customers on Google.
              </p>
              <span className="inline-flex items-center gap-2 text-neon-orange text-sm font-semibold group-hover:gap-3 transition-all">
                Write a Review
                <ExternalLink className="w-3.5 h-3.5" />
              </span>
            </a>

            <a
              href={FACEBOOK_PAGE_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="group p-6 bg-black/40 border border-white/10 rounded-xl hover:border-neon-cyan/40 transition-colors"
            >
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 bg-[#1877F2] rounded-lg flex items-center justify-center">
                  <svg className="w-6 h-6 text-white" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                  </svg>
                </div>
                <h3 className="text-white font-bold">Recommend on Facebook</h3>
              </div>
              <p className="text-gray-400 text-sm mb-4 leading-relaxed">
                Share your experience with friends &amp; family in our Facebook community.
              </p>
              <span className="inline-flex items-center gap-2 text-neon-cyan text-sm font-semibold group-hover:gap-3 transition-all">
                Recommend Us
                <ExternalLink className="w-3.5 h-3.5" />
              </span>
            </a>
          </div>

          {/* Share button */}
          <div className="relative text-center mt-8">
            <button
              onClick={handleShare}
              className="inline-flex items-center gap-2 px-5 py-2.5 text-gray-400 text-sm font-medium hover:text-white transition-colors"
            >
              <Share2 className="w-4 h-4" />
              Share our reviews page with a friend
            </button>
          </div>
        </div>
      </section>

      {/* ─── Bottom CTA ─── */}
      <section className="max-w-6xl mx-auto px-4 pb-16">
        <div className="h-px bg-gradient-to-r from-transparent via-white/10 to-transparent mb-8" />
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-gray-500 text-sm">
            <Award className="w-4 h-4 text-neon-green" />
            <span>Family-owned &amp; trusted across Long Island</span>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate('/')}
              className="inline-flex items-center gap-2 px-5 py-2.5 border border-white/10 text-gray-300 font-bold text-sm rounded-lg hover:text-white hover:border-white/20 transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Home
            </button>
            <button
              onClick={() => {
                navigate('/');
                setTimeout(() => {
                  const el = document.getElementById('inventory');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }, 200);
              }}
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-neon-pink to-neon-orange text-white font-bold text-sm rounded-lg hover:opacity-90 transition-opacity"
            >
              <Car className="w-4 h-4" />
              Browse Inventory
            </button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Reviews;
