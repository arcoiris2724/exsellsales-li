// Vehicle templates for quick add - pre-filled specs for common makes/models
// Admin picks a template, then only needs to fill in: year, price, mileage, color, VIN, photos

export interface VehicleTemplate {
  id: string;
  make: string;
  model: string;
  trim: string;
  engine: string;
  transmission: string;
  drivetrain: string;
  fuelType: string;
  bodyType: string;
  features: string[];
  category: TemplateCategory;
  popular?: boolean;
}

export type TemplateCategory = 'SUV' | 'Sedan' | 'Truck' | 'Coupe' | 'Van' | 'Hatchback' | 'Convertible' | 'Wagon' | 'Minivan' | 'Sports';

export const VEHICLE_TEMPLATES: VehicleTemplate[] = [
  // ═══════════════════════════════════════════════
  // JEEP
  // ═══════════════════════════════════════════════
  {
    id: 'jeep-compass-latitude',
    make: 'Jeep', model: 'Compass', trim: 'Latitude',
    engine: '2.4L I4', transmission: 'Automatic', drivetrain: 'FWD', fuelType: 'Gasoline', bodyType: 'SUV',
    features: ['Bluetooth', 'Backup Camera', 'Alloy Wheels', 'Keyless Entry', 'Cruise Control', 'Power Windows'],
    category: 'SUV', popular: true,
  },
  {
    id: 'jeep-cherokee-limited',
    make: 'Jeep', model: 'Cherokee', trim: 'Limited',
    engine: '3.2L V6', transmission: 'Automatic', drivetrain: 'FWD', fuelType: 'Gasoline', bodyType: 'SUV',
    features: ['Leather Seats', 'Navigation', 'Heated Seats', 'Backup Camera', 'Remote Start', 'Sunroof'],
    category: 'SUV', popular: true,
  },
  {
    id: 'jeep-grand-cherokee-limited',
    make: 'Jeep', model: 'Grand Cherokee', trim: 'Limited',
    engine: '5.7L HEMI V8', transmission: 'Automatic', drivetrain: '4WD', fuelType: 'Gasoline', bodyType: 'SUV',
    features: ['Leather Seats', 'Navigation', 'Sunroof', 'Heated Seats', 'Tow Package', 'HEMI V8', 'Backup Camera'],
    category: 'SUV', popular: true,
  },
  {
    id: 'jeep-grand-cherokee-laredo',
    make: 'Jeep', model: 'Grand Cherokee', trim: 'Laredo',
    engine: '3.6L V6', transmission: 'Automatic', drivetrain: '4WD', fuelType: 'Gasoline', bodyType: 'SUV',
    features: ['Bluetooth', 'Backup Camera', 'Alloy Wheels', 'Cruise Control', 'Power Windows'],
    category: 'SUV',
  },
  {
    id: 'jeep-wrangler-sport',
    make: 'Jeep', model: 'Wrangler', trim: 'Sport',
    engine: '3.6L V6', transmission: 'Automatic', drivetrain: '4WD', fuelType: 'Gasoline', bodyType: 'SUV',
    features: ['4WD', 'Removable Top', 'Bluetooth', 'Tow Hooks', 'Skid Plates'],
    category: 'SUV',
  },
  {
    id: 'jeep-patriot-latitude',
    make: 'Jeep', model: 'Patriot', trim: 'Latitude',
    engine: '2.4L I4', transmission: 'Automatic', drivetrain: 'FWD', fuelType: 'Gasoline', bodyType: 'SUV',
    features: ['Bluetooth', 'Heated Seats', 'Alloy Wheels', 'Cruise Control', 'Satellite Radio'],
    category: 'SUV',
  },

  // ═══════════════════════════════════════════════
  // TOYOTA
  // ═══════════════════════════════════════════════
  {
    id: 'toyota-camry-le',
    make: 'Toyota', model: 'Camry', trim: 'LE',
    engine: '2.5L I4', transmission: 'Automatic', drivetrain: 'FWD', fuelType: 'Gasoline', bodyType: 'Sedan',
    features: ['Bluetooth', 'Backup Camera', 'Cruise Control', 'Power Windows', 'Air Conditioning', 'Keyless Entry'],
    category: 'Sedan', popular: true,
  },
  {
    id: 'toyota-camry-se',
    make: 'Toyota', model: 'Camry', trim: 'SE',
    engine: '2.5L I4', transmission: 'Automatic', drivetrain: 'FWD', fuelType: 'Gasoline', bodyType: 'Sedan',
    features: ['Bluetooth', 'Backup Camera', 'Sport Suspension', 'Alloy Wheels', 'Cruise Control', 'Paddle Shifters'],
    category: 'Sedan',
  },
  {
    id: 'toyota-corolla-le',
    make: 'Toyota', model: 'Corolla', trim: 'LE',
    engine: '1.8L I4', transmission: 'CVT', drivetrain: 'FWD', fuelType: 'Gasoline', bodyType: 'Sedan',
    features: ['Bluetooth', 'Backup Camera', 'Lane Departure Warning', 'Cruise Control', 'Power Windows'],
    category: 'Sedan', popular: true,
  },
  {
    id: 'toyota-rav4-le',
    make: 'Toyota', model: 'RAV4', trim: 'LE',
    engine: '2.5L I4', transmission: 'Automatic', drivetrain: 'FWD', fuelType: 'Gasoline', bodyType: 'SUV',
    features: ['Bluetooth', 'Backup Camera', 'Lane Departure Warning', 'Cruise Control', 'Apple CarPlay'],
    category: 'SUV', popular: true,
  },
  {
    id: 'toyota-highlander-le',
    make: 'Toyota', model: 'Highlander', trim: 'LE',
    engine: '3.5L V6', transmission: 'Automatic', drivetrain: 'FWD', fuelType: 'Gasoline', bodyType: 'SUV',
    features: ['Third Row', 'Bluetooth', 'Backup Camera', 'Cruise Control', 'Power Windows', 'Air Conditioning'],
    category: 'SUV',
  },
  {
    id: 'toyota-tacoma-sr5',
    make: 'Toyota', model: 'Tacoma', trim: 'SR5',
    engine: '3.5L V6', transmission: 'Automatic', drivetrain: '4WD', fuelType: 'Gasoline', bodyType: 'Truck',
    features: ['4WD', 'Bluetooth', 'Backup Camera', 'Tow Package', 'Bed Liner', 'Cruise Control'],
    category: 'Truck',
  },
  {
    id: 'toyota-4runner-sr5',
    make: 'Toyota', model: '4Runner', trim: 'SR5',
    engine: '4.0L V6', transmission: 'Automatic', drivetrain: '4WD', fuelType: 'Gasoline', bodyType: 'SUV',
    features: ['4WD', 'Bluetooth', 'Backup Camera', 'Tow Package', 'Roof Rack', 'Running Boards'],
    category: 'SUV',
  },
  {
    id: 'toyota-solara-se',
    make: 'Toyota', model: 'Solara', trim: 'SE',
    engine: '2.4L I4', transmission: 'Automatic', drivetrain: 'FWD', fuelType: 'Gasoline', bodyType: 'Coupe',
    features: ['Power Windows', 'Power Locks', 'Cruise Control', 'CD Player', 'Alloy Wheels'],
    category: 'Coupe',
  },

  // ═══════════════════════════════════════════════
  // HONDA
  // ═══════════════════════════════════════════════
  {
    id: 'honda-civic-lx',
    make: 'Honda', model: 'Civic', trim: 'LX',
    engine: '2.0L I4', transmission: 'CVT', drivetrain: 'FWD', fuelType: 'Gasoline', bodyType: 'Sedan',
    features: ['Bluetooth', 'Backup Camera', 'Lane Keeping Assist', 'Cruise Control', 'Apple CarPlay'],
    category: 'Sedan', popular: true,
  },
  {
    id: 'honda-accord-lx',
    make: 'Honda', model: 'Accord', trim: 'LX',
    engine: '1.5L Turbo I4', transmission: 'CVT', drivetrain: 'FWD', fuelType: 'Gasoline', bodyType: 'Sedan',
    features: ['Bluetooth', 'Backup Camera', 'Honda Sensing', 'Cruise Control', 'Apple CarPlay', 'Android Auto'],
    category: 'Sedan', popular: true,
  },
  {
    id: 'honda-crv-lx',
    make: 'Honda', model: 'CR-V', trim: 'LX',
    engine: '2.4L I4', transmission: 'CVT', drivetrain: 'FWD', fuelType: 'Gasoline', bodyType: 'SUV',
    features: ['Backup Camera', 'Bluetooth', 'Cruise Control', 'Power Windows', 'Air Conditioning'],
    category: 'SUV', popular: true,
  },
  {
    id: 'honda-crv-ex',
    make: 'Honda', model: 'CR-V', trim: 'EX',
    engine: '1.5L Turbo I4', transmission: 'CVT', drivetrain: 'AWD', fuelType: 'Gasoline', bodyType: 'SUV',
    features: ['Sunroof', 'Bluetooth', 'Backup Camera', 'Honda Sensing', 'Apple CarPlay', 'Heated Seats'],
    category: 'SUV',
  },
  {
    id: 'honda-element-ex',
    make: 'Honda', model: 'Element', trim: 'EX',
    engine: '2.4L I4', transmission: 'Automatic', drivetrain: 'AWD', fuelType: 'Gasoline', bodyType: 'SUV',
    features: ['AWD', 'Sunroof', 'Alloy Wheels', 'Cruise Control', 'Power Windows'],
    category: 'SUV',
  },
  {
    id: 'honda-odyssey-lx',
    make: 'Honda', model: 'Odyssey', trim: 'LX',
    engine: '3.5L V6', transmission: 'Automatic', drivetrain: 'FWD', fuelType: 'Gasoline', bodyType: 'Minivan',
    features: ['Power Sliding Doors', 'Third Row', 'Cruise Control', 'Air Conditioning', 'Bluetooth'],
    category: 'Minivan',
  },
  {
    id: 'honda-pilot-ex',
    make: 'Honda', model: 'Pilot', trim: 'EX',
    engine: '3.5L V6', transmission: 'Automatic', drivetrain: 'FWD', fuelType: 'Gasoline', bodyType: 'SUV',
    features: ['Third Row', 'Bluetooth', 'Backup Camera', 'Honda Sensing', 'Sunroof', 'Apple CarPlay'],
    category: 'SUV',
  },

  // ═══════════════════════════════════════════════
  // NISSAN
  // ═══════════════════════════════════════════════
  {
    id: 'nissan-rogue-s',
    make: 'Nissan', model: 'Rogue', trim: 'S',
    engine: '2.5L I4', transmission: 'CVT', drivetrain: 'FWD', fuelType: 'Gasoline', bodyType: 'SUV',
    features: ['Bluetooth', 'Backup Camera', 'Cruise Control', 'Power Windows', 'Keyless Entry'],
    category: 'SUV', popular: true,
  },
  {
    id: 'nissan-altima-s',
    make: 'Nissan', model: 'Altima', trim: '2.5 S',
    engine: '2.5L I4', transmission: 'CVT', drivetrain: 'FWD', fuelType: 'Gasoline', bodyType: 'Sedan',
    features: ['Bluetooth', 'Backup Camera', 'Cruise Control', 'Power Windows', 'Keyless Entry'],
    category: 'Sedan',
  },
  {
    id: 'nissan-pathfinder-sv',
    make: 'Nissan', model: 'Pathfinder', trim: 'SV',
    engine: '3.5L V6', transmission: 'CVT', drivetrain: 'FWD', fuelType: 'Gasoline', bodyType: 'SUV',
    features: ['Third Row', 'Bluetooth', 'Backup Camera', 'Cruise Control', 'Alloy Wheels'],
    category: 'SUV',
  },

  // ═══════════════════════════════════════════════
  // GMC
  // ═══════════════════════════════════════════════
  {
    id: 'gmc-yukon-denali',
    make: 'GMC', model: 'Yukon', trim: 'Denali',
    engine: '6.2L V8', transmission: 'Automatic', drivetrain: '4WD', fuelType: 'Gasoline', bodyType: 'SUV',
    features: ['Navigation', 'Leather Seats', 'Sunroof', 'Heated/Cooled Seats', 'Bose Audio', 'Third Row', 'DVD Entertainment', 'Power Liftgate'],
    category: 'SUV', popular: true,
  },
  {
    id: 'gmc-yukon-slt',
    make: 'GMC', model: 'Yukon', trim: 'SLT',
    engine: '5.3L V8', transmission: 'Automatic', drivetrain: '4WD', fuelType: 'Gasoline', bodyType: 'SUV',
    features: ['Leather Seats', 'Heated Seats', 'Bose Audio', 'Third Row', 'Running Boards', 'Tow Package'],
    category: 'SUV',
  },
  {
    id: 'gmc-sierra-sle',
    make: 'GMC', model: 'Sierra 1500', trim: 'SLE',
    engine: '5.3L V8', transmission: 'Automatic', drivetrain: '4WD', fuelType: 'Gasoline', bodyType: 'Truck',
    features: ['4WD', 'Bluetooth', 'Backup Camera', 'Tow Package', 'Bed Liner', 'Running Boards'],
    category: 'Truck',
  },

  // ═══════════════════════════════════════════════
  // MERCEDES-BENZ
  // ═══════════════════════════════════════════════
  {
    id: 'mercedes-gl450-4matic',
    make: 'Mercedes-Benz', model: 'GL450', trim: '4MATIC',
    engine: '4.6L V8 Bi-Turbo', transmission: 'Automatic', drivetrain: 'AWD', fuelType: 'Gasoline', bodyType: 'SUV',
    features: ['Navigation', 'Leather Seats', 'Sunroof', 'Heated Seats', 'Third Row', 'Backup Camera', 'Bluetooth', 'Premium Sound'],
    category: 'SUV', popular: true,
  },
  {
    id: 'mercedes-c300-4matic',
    make: 'Mercedes-Benz', model: 'C300', trim: '4MATIC',
    engine: '2.0L Turbo I4', transmission: 'Automatic', drivetrain: 'AWD', fuelType: 'Gasoline', bodyType: 'Sedan',
    features: ['Navigation', 'Leather Seats', 'Sunroof', 'Heated Seats', 'Bluetooth', 'Backup Camera', 'Premium Sound'],
    category: 'Sedan',
  },
  {
    id: 'mercedes-e350',
    make: 'Mercedes-Benz', model: 'E350', trim: 'Luxury',
    engine: '3.5L V6', transmission: 'Automatic', drivetrain: 'RWD', fuelType: 'Gasoline', bodyType: 'Sedan',
    features: ['Navigation', 'Leather Seats', 'Sunroof', 'Heated Seats', 'Premium Sound', 'Parking Sensors'],
    category: 'Sedan',
  },
  {
    id: 'mercedes-gle350',
    make: 'Mercedes-Benz', model: 'GLE350', trim: '4MATIC',
    engine: '2.0L Turbo I4', transmission: 'Automatic', drivetrain: 'AWD', fuelType: 'Gasoline', bodyType: 'SUV',
    features: ['Navigation', 'Leather Seats', 'Panoramic Sunroof', 'Heated Seats', 'Backup Camera', 'Blind Spot Monitor'],
    category: 'SUV',
  },

  // ═══════════════════════════════════════════════
  // BMW
  // ═══════════════════════════════════════════════
  {
    id: 'bmw-3series-330i',
    make: 'BMW', model: '3 Series', trim: '330i',
    engine: '2.0L Turbo I4', transmission: 'Automatic', drivetrain: 'RWD', fuelType: 'Gasoline', bodyType: 'Sedan',
    features: ['Navigation', 'Leather Seats', 'Sunroof', 'Bluetooth', 'Backup Camera', 'Sport Mode'],
    category: 'Sedan',
  },
  {
    id: 'bmw-x5-xdrive35i',
    make: 'BMW', model: 'X5', trim: 'xDrive35i',
    engine: '3.0L Turbo I6', transmission: 'Automatic', drivetrain: 'AWD', fuelType: 'Gasoline', bodyType: 'SUV',
    features: ['Navigation', 'Leather Seats', 'Panoramic Sunroof', 'Heated Seats', 'Third Row', 'Backup Camera'],
    category: 'SUV',
  },
  {
    id: 'bmw-x3-sdrive30i',
    make: 'BMW', model: 'X3', trim: 'sDrive30i',
    engine: '2.0L Turbo I4', transmission: 'Automatic', drivetrain: 'RWD', fuelType: 'Gasoline', bodyType: 'SUV',
    features: ['Navigation', 'Leather Seats', 'Sunroof', 'Bluetooth', 'Backup Camera', 'Apple CarPlay'],
    category: 'SUV',
  },

  // ═══════════════════════════════════════════════
  // FORD
  // ═══════════════════════════════════════════════
  {
    id: 'ford-f150-xlt',
    make: 'Ford', model: 'F-150', trim: 'XLT',
    engine: '3.5L V6 EcoBoost', transmission: 'Automatic', drivetrain: '4WD', fuelType: 'Gasoline', bodyType: 'Truck',
    features: ['4WD', 'Bluetooth', 'Backup Camera', 'Tow Package', 'Bed Liner', 'Running Boards', 'SYNC'],
    category: 'Truck', popular: true,
  },
  {
    id: 'ford-escape-se',
    make: 'Ford', model: 'Escape', trim: 'SE',
    engine: '1.5L EcoBoost I4', transmission: 'Automatic', drivetrain: 'FWD', fuelType: 'Gasoline', bodyType: 'SUV',
    features: ['Bluetooth', 'Backup Camera', 'SYNC 3', 'Cruise Control', 'Apple CarPlay'],
    category: 'SUV',
  },
  {
    id: 'ford-explorer-xlt',
    make: 'Ford', model: 'Explorer', trim: 'XLT',
    engine: '3.5L V6', transmission: 'Automatic', drivetrain: 'FWD', fuelType: 'Gasoline', bodyType: 'SUV',
    features: ['Third Row', 'Bluetooth', 'Backup Camera', 'SYNC', 'Cruise Control', 'Alloy Wheels'],
    category: 'SUV',
  },
  {
    id: 'ford-freestar-se',
    make: 'Ford', model: 'Freestar', trim: 'SE',
    engine: '3.9L V6', transmission: 'Automatic', drivetrain: 'FWD', fuelType: 'Gasoline', bodyType: 'Minivan',
    features: ['Third Row', 'Rear Air Conditioning', 'Power Windows', 'Power Locks', 'Cruise Control'],
    category: 'Minivan',
  },

  // ═══════════════════════════════════════════════
  // CHEVROLET
  // ═══════════════════════════════════════════════
  {
    id: 'chevy-silverado-lt',
    make: 'Chevrolet', model: 'Silverado 1500', trim: 'LT',
    engine: '5.3L V8', transmission: 'Automatic', drivetrain: '4WD', fuelType: 'Gasoline', bodyType: 'Truck',
    features: ['4WD', 'Bluetooth', 'Backup Camera', 'Tow Package', 'OnStar', 'Bed Liner'],
    category: 'Truck', popular: true,
  },
  {
    id: 'chevy-equinox-lt',
    make: 'Chevrolet', model: 'Equinox', trim: 'LT',
    engine: '1.5L Turbo I4', transmission: 'Automatic', drivetrain: 'FWD', fuelType: 'Gasoline', bodyType: 'SUV',
    features: ['Bluetooth', 'Backup Camera', 'Apple CarPlay', 'Cruise Control', 'Heated Seats'],
    category: 'SUV',
  },
  {
    id: 'chevy-tahoe-lt',
    make: 'Chevrolet', model: 'Tahoe', trim: 'LT',
    engine: '5.3L V8', transmission: 'Automatic', drivetrain: '4WD', fuelType: 'Gasoline', bodyType: 'SUV',
    features: ['Leather Seats', 'Third Row', 'Bose Audio', 'Backup Camera', 'Tow Package', 'Running Boards'],
    category: 'SUV',
  },

  // ═══════════════════════════════════════════════
  // KIA / HYUNDAI
  // ═══════════════════════════════════════════════
  {
    id: 'kia-sorento-lx',
    make: 'Kia', model: 'Sorento', trim: 'LX',
    engine: '2.4L I4', transmission: 'Automatic', drivetrain: 'FWD', fuelType: 'Gasoline', bodyType: 'SUV',
    features: ['Bluetooth', 'Backup Camera', 'Alloy Wheels', 'Cruise Control', 'Satellite Radio'],
    category: 'SUV',
  },
  {
    id: 'kia-sportage-lx',
    make: 'Kia', model: 'Sportage', trim: 'LX',
    engine: '2.4L I4', transmission: 'Automatic', drivetrain: 'FWD', fuelType: 'Gasoline', bodyType: 'SUV',
    features: ['Bluetooth', 'Backup Camera', 'Cruise Control', 'Power Windows', 'Air Conditioning'],
    category: 'SUV',
  },
  {
    id: 'hyundai-tucson-se',
    make: 'Hyundai', model: 'Tucson', trim: 'SE',
    engine: '2.0L I4', transmission: 'Automatic', drivetrain: 'FWD', fuelType: 'Gasoline', bodyType: 'SUV',
    features: ['Bluetooth', 'Backup Camera', 'Cruise Control', 'Power Windows', 'Apple CarPlay'],
    category: 'SUV',
  },
  {
    id: 'hyundai-santa-fe-se',
    make: 'Hyundai', model: 'Santa Fe', trim: 'SE',
    engine: '2.4L I4', transmission: 'Automatic', drivetrain: 'FWD', fuelType: 'Gasoline', bodyType: 'SUV',
    features: ['Bluetooth', 'Backup Camera', 'Cruise Control', 'Apple CarPlay', 'Blind Spot Monitor'],
    category: 'SUV',
  },

  // ═══════════════════════════════════════════════
  // CHRYSLER / DODGE
  // ═══════════════════════════════════════════════
  {
    id: 'chrysler-pt-cruiser-touring',
    make: 'Chrysler', model: 'PT Cruiser', trim: 'Touring',
    engine: '2.4L I4', transmission: 'Automatic', drivetrain: 'FWD', fuelType: 'Gasoline', bodyType: 'SUV',
    features: ['Air Conditioning', 'Power Windows', 'Power Locks', 'CD Player', 'Cruise Control'],
    category: 'SUV',
  },
  {
    id: 'chrysler-300-touring',
    make: 'Chrysler', model: '300', trim: 'Touring',
    engine: '3.6L V6', transmission: 'Automatic', drivetrain: 'RWD', fuelType: 'Gasoline', bodyType: 'Sedan',
    features: ['Bluetooth', 'Backup Camera', 'Leather Seats', 'Heated Seats', 'Alloy Wheels'],
    category: 'Sedan',
  },
  {
    id: 'dodge-durango-sxt',
    make: 'Dodge', model: 'Durango', trim: 'SXT',
    engine: '3.6L V6', transmission: 'Automatic', drivetrain: 'RWD', fuelType: 'Gasoline', bodyType: 'SUV',
    features: ['Third Row', 'Bluetooth', 'Backup Camera', 'Uconnect', 'Cruise Control', 'Alloy Wheels'],
    category: 'SUV',
  },
  {
    id: 'dodge-charger-sxt',
    make: 'Dodge', model: 'Charger', trim: 'SXT',
    engine: '3.6L V6', transmission: 'Automatic', drivetrain: 'RWD', fuelType: 'Gasoline', bodyType: 'Sedan',
    features: ['Bluetooth', 'Backup Camera', 'Uconnect', 'Alloy Wheels', 'Sport Mode'],
    category: 'Sedan',
  },

  // ═══════════════════════════════════════════════
  // MASERATI / LUXURY
  // ═══════════════════════════════════════════════
  {
    id: 'maserati-quattroporte-s',
    make: 'Maserati', model: 'Quattroporte', trim: 'S',
    engine: '4.7L V8', transmission: 'Automatic', drivetrain: 'RWD', fuelType: 'Gasoline', bodyType: 'Sedan',
    features: ['Leather Seats', 'Navigation', 'Premium Sound', 'Sunroof', 'Heated Seats', 'Parking Sensors'],
    category: 'Sedan',
  },
  {
    id: 'maserati-ghibli-s',
    make: 'Maserati', model: 'Ghibli', trim: 'S Q4',
    engine: '3.0L V6 Twin-Turbo', transmission: 'Automatic', drivetrain: 'AWD', fuelType: 'Gasoline', bodyType: 'Sedan',
    features: ['Leather Seats', 'Navigation', 'Premium Sound', 'Sunroof', 'Heated Seats', 'Backup Camera'],
    category: 'Sedan',
  },

  // ═══════════════════════════════════════════════
  // SUBARU
  // ═══════════════════════════════════════════════
  {
    id: 'subaru-outback-premium',
    make: 'Subaru', model: 'Outback', trim: 'Premium',
    engine: '2.5L Boxer I4', transmission: 'CVT', drivetrain: 'AWD', fuelType: 'Gasoline', bodyType: 'Wagon',
    features: ['AWD', 'EyeSight', 'Bluetooth', 'Backup Camera', 'Heated Seats', 'Apple CarPlay'],
    category: 'Wagon',
  },
  {
    id: 'subaru-forester-premium',
    make: 'Subaru', model: 'Forester', trim: 'Premium',
    engine: '2.5L Boxer I4', transmission: 'CVT', drivetrain: 'AWD', fuelType: 'Gasoline', bodyType: 'SUV',
    features: ['AWD', 'EyeSight', 'Bluetooth', 'Backup Camera', 'Heated Seats', 'Panoramic Sunroof'],
    category: 'SUV',
  },

  // ═══════════════════════════════════════════════
  // SMART / SCION / OTHER
  // ═══════════════════════════════════════════════
  {
    id: 'smart-fortwo-passion',
    make: 'Smart', model: 'Fortwo', trim: 'Passion',
    engine: '1.0L I3', transmission: 'Automatic', drivetrain: 'RWD', fuelType: 'Gasoline', bodyType: 'Coupe',
    features: ['Panoramic Roof', 'Heated Seats', 'Bluetooth', 'Air Conditioning', 'Power Windows'],
    category: 'Coupe',
  },
  {
    id: 'scion-xb-base',
    make: 'Scion', model: 'xB', trim: 'Base',
    engine: '1.5L I4', transmission: 'Automatic', drivetrain: 'FWD', fuelType: 'Gasoline', bodyType: 'Hatchback',
    features: ['Air Conditioning', 'Power Windows', 'Power Locks', 'CD Player', 'Pioneer Audio'],
    category: 'Hatchback',
  },

  // ═══════════════════════════════════════════════
  // LEXUS
  // ═══════════════════════════════════════════════
  {
    id: 'lexus-rx350',
    make: 'Lexus', model: 'RX 350', trim: 'Base',
    engine: '3.5L V6', transmission: 'Automatic', drivetrain: 'FWD', fuelType: 'Gasoline', bodyType: 'SUV',
    features: ['Leather Seats', 'Navigation', 'Sunroof', 'Heated Seats', 'Backup Camera', 'Premium Sound'],
    category: 'SUV',
  },
  {
    id: 'lexus-es350',
    make: 'Lexus', model: 'ES 350', trim: 'Base',
    engine: '3.5L V6', transmission: 'Automatic', drivetrain: 'FWD', fuelType: 'Gasoline', bodyType: 'Sedan',
    features: ['Leather Seats', 'Navigation', 'Sunroof', 'Heated Seats', 'Backup Camera', 'Premium Sound'],
    category: 'Sedan',
  },

  // ═══════════════════════════════════════════════
  // ACURA / INFINITI
  // ═══════════════════════════════════════════════
  {
    id: 'acura-mdx-base',
    make: 'Acura', model: 'MDX', trim: 'Base',
    engine: '3.5L V6', transmission: 'Automatic', drivetrain: 'FWD', fuelType: 'Gasoline', bodyType: 'SUV',
    features: ['Third Row', 'Leather Seats', 'Sunroof', 'Bluetooth', 'Backup Camera', 'Heated Seats'],
    category: 'SUV',
  },
  {
    id: 'infiniti-qx60-base',
    make: 'Infiniti', model: 'QX60', trim: 'Base',
    engine: '3.5L V6', transmission: 'CVT', drivetrain: 'FWD', fuelType: 'Gasoline', bodyType: 'SUV',
    features: ['Third Row', 'Leather Seats', 'Navigation', 'Sunroof', 'Heated Seats', 'Backup Camera'],
    category: 'SUV',
  },

  // ═══════════════════════════════════════════════
  // VOLKSWAGEN
  // ═══════════════════════════════════════════════
  {
    id: 'vw-jetta-se',
    make: 'Volkswagen', model: 'Jetta', trim: 'SE',
    engine: '1.4L Turbo I4', transmission: 'Automatic', drivetrain: 'FWD', fuelType: 'Gasoline', bodyType: 'Sedan',
    features: ['Bluetooth', 'Backup Camera', 'Apple CarPlay', 'Heated Seats', 'Cruise Control'],
    category: 'Sedan',
  },
  {
    id: 'vw-tiguan-se',
    make: 'Volkswagen', model: 'Tiguan', trim: 'SE',
    engine: '2.0L Turbo I4', transmission: 'Automatic', drivetrain: 'FWD', fuelType: 'Gasoline', bodyType: 'SUV',
    features: ['Bluetooth', 'Backup Camera', 'Apple CarPlay', 'Panoramic Sunroof', 'Heated Seats'],
    category: 'SUV',
  },
];

// Get unique categories from templates
export function getTemplateCategories(): TemplateCategory[] {
  const cats = new Set(VEHICLE_TEMPLATES.map(t => t.category));
  return Array.from(cats).sort() as TemplateCategory[];
}

// Get unique makes from templates
export function getTemplateMakes(): string[] {
  const makes = new Set(VEHICLE_TEMPLATES.map(t => t.make));
  return Array.from(makes).sort();
}

// Get popular templates
export function getPopularTemplates(): VehicleTemplate[] {
  return VEHICLE_TEMPLATES.filter(t => t.popular);
}

// Search templates
export function searchTemplates(query: string, category?: TemplateCategory): VehicleTemplate[] {
  let results = VEHICLE_TEMPLATES;
  
  if (category) {
    results = results.filter(t => t.category === category);
  }
  
  if (query) {
    const q = query.toLowerCase();
    results = results.filter(t =>
      `${t.make} ${t.model} ${t.trim} ${t.engine} ${t.bodyType}`.toLowerCase().includes(q)
    );
  }
  
  return results;
}
