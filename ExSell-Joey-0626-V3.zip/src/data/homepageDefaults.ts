// ─── Homepage CMS Types & Defaults ───
// These match the current hardcoded values in the homepage components.

export interface HeroSectionContent {
  badgeText: string;
  headlineLines: string[];
  subtitle: string;
  ctaPrimary: string;
  ctaSecondary: string;
  trustBadges: { icon: string; text: string }[];
  stats: { value: string; label: string; color: string }[];
}

export interface ServiceItem {
  icon: string;
  title: string;
  description: string;
  color: string;
  bgColor: string;
  borderColor: string;
}

export interface ServicesSectionContent {
  title: string;
  titleHighlight: string;
  subtitle: string;
  services: ServiceItem[];
  ctaPhone: string;
  ctaPhoneDisplay: string;
}

export interface WhyChooseUsReason {
  icon: string;
  title: string;
  description: string;
  color: string;
}

export interface WhyChooseUsStat {
  value: string;
  label: string;
  color: string;
}

export interface WhyChooseUsContent {
  title: string;
  titleHighlight: string;
  description: string;
  reasons: WhyChooseUsReason[];
  stats: WhyChooseUsStat[];
}

export interface TestimonialItem {
  name: string;
  location: string;
  rating: number;
  text: string;
  vehicle: string;
}

export interface TestimonialsSectionContent {
  title: string;
  titleHighlight: string;
  subtitle: string;
  overallRating: string;
  reviewCount: string;
  testimonials: TestimonialItem[];
}

export interface ContactSectionContent {
  title: string;
  titleHighlight: string;
  subtitle: string;
  phone: string;
  phoneDisplay: string;
  phoneLabel: string;
  email: string;
  emailLabel: string;
  address: string;
  addressLabel: string;
  hoursWeekday: string;
  hoursSunday: string;
  facebookUrl: string;
  instagramUrl: string;
}
export interface FooterQuickLink {
  label: string;
  type: 'scroll' | 'route';
  target: string;
}

export interface FooterContent {
  tagline: string;
  services: string[];
  quickLinks: FooterQuickLink[];
  copyrightName: string;
  websiteUrl: string;
  locationText: string;
}

// ─── SEO & Meta Tags Types ───

export interface SEOPageMeta {
  title: string;
  metaDescription: string;
  ogTitle: string;
  ogDescription: string;
  ogImage: string;
}

export interface SEOContent {
  homepage: SEOPageMeta;
  about: SEOPageMeta;
  reviews: SEOPageMeta;
  sold: SEOPageMeta;
  privacy: SEOPageMeta;
  terms: SEOPageMeta;
}

export type SEOPageKey = keyof SEOContent;

// ─── Analytics / Tracking Types ───

export interface AnalyticsConfig {
  enabled: boolean;
  ga4MeasurementId: string;
  gtmContainerId: string;
  respectCookieConsent: boolean;
}

// ─── Announcement Banner Type ───

export interface AnnouncementBannerContent {
  enabled: boolean;
  message: string;
  /** Optional inline call-to-action link shown after the message. */
  ctaLabel: string;
  ctaType: 'none' | 'scroll' | 'route' | 'external' | 'phone';
  ctaTarget: string;
  /** Color theme — controls the gradient/background of the bar. */
  theme: 'pink' | 'orange' | 'cyan' | 'green' | 'purple';
  /** Allow visitors to close the banner (remembered for the session). */
  dismissible: boolean;
  /** Scroll the message across like a marquee/ticker. */
  marquee: boolean;
}

// ─── Default Values ───


export const DEFAULT_HERO_SECTION: HeroSectionContent = {
  badgeText: "Long Island's Premier Used Car Dealer",
  headlineLines: ['Drive Your', 'Dream Car', 'Today'],
  subtitle: 'Hand-picked pre-owned vehicles backed by full history reports and showroom-ready detailing. Transparent pricing, no hidden fees, and a customer-first approach that sets us apart.',
  ctaPrimary: 'Browse Inventory',
  ctaSecondary: 'Contact Us',
  trustBadges: [
    { icon: 'Shield', text: 'Vehicle History Reports' },
    { icon: 'Award', text: 'Quality Inspected' },
    { icon: 'Handshake', text: 'No Hidden Fees' },
  ],
  stats: [
    { value: '500+', label: 'Cars Sold', color: 'text-neon-pink' },
    { value: '4.9', label: 'Star Rating', color: 'text-neon-orange' },
    { value: '100%', label: 'Transparent Pricing', color: 'text-neon-green' },
    { value: '10+', label: 'Years Experience', color: 'text-neon-cyan' },
  ],
};

export const DEFAULT_SERVICES_SECTION: ServicesSectionContent = {
  title: 'What We',
  titleHighlight: 'Offer',
  subtitle: 'Three things we do exceptionally well: quality pre-owned inventory, full vehicle history transparency, and professional detailing that makes every car shine.',
  services: [
    { icon: 'Car', title: 'Quality Pre-Owned Vehicles', description: 'Every vehicle in our inventory is hand-selected and thoroughly inspected to meet our high standards.', color: 'text-neon-pink', bgColor: 'bg-neon-pink/10', borderColor: 'border-neon-pink/20' },
    { icon: 'Shield', title: 'Vehicle History Reports', description: 'Full transparency with detailed vehicle history reports available for every car on our lot.', color: 'text-neon-green', bgColor: 'bg-neon-green/10', borderColor: 'border-neon-green/20' },
    { icon: 'Wrench', title: 'Professional Detailing', description: 'Every vehicle is professionally detailed before delivery. We also offer detailing services for your current ride.', color: 'text-neon-orange', bgColor: 'bg-neon-orange/10', borderColor: 'border-neon-orange/20' },
  ],


  ctaPhone: '6313884426',
  ctaPhoneDisplay: '(631) 388-4426',
};

export const DEFAULT_WHY_CHOOSE_US: WhyChooseUsContent = {
  title: 'Why Choose',
  titleHighlight: 'Ex$ell?',
  description: "At Ex$ell Car Sales, we believe buying a car should be exciting — not stressful. We're a family-owned dealership on Long Island committed to honest deals, quality vehicles, and an experience that keeps you coming back.",
  reasons: [
    { icon: 'TrendingDown', title: 'Below Market Pricing', description: 'We price our vehicles competitively so you get the best deal without the haggling.', color: 'text-neon-green' },
    { icon: 'ShieldCheck', title: 'No Hidden Fees', description: 'The price you see is the price you pay. Complete transparency, always.', color: 'text-neon-cyan' },
    { icon: 'Clock', title: 'Quick & Easy Process', description: 'From browsing to driving off the lot — we make the car buying experience fast and stress-free.', color: 'text-neon-orange' },
    { icon: 'Users', title: 'Family-Owned Business', description: 'We treat every customer like family. Your satisfaction is our reputation.', color: 'text-neon-pink' },
    { icon: 'Sparkles', title: 'Showroom-Ready Cars', description: 'Every vehicle is professionally detailed and inspected before it hits our lot.', color: 'text-neon-purple' },
    { icon: 'FileCheck', title: 'Full History Transparency', description: 'Every vehicle comes with a detailed history report so you know exactly what you’re buying — no surprises.', color: 'text-neon-yellow' },
  ],
  stats: [
    { value: '500+', label: 'Happy Customers', color: 'text-neon-pink' },
    { value: '4.9', label: 'Star Rating', color: 'text-neon-orange' },
    { value: '10+', label: 'Years Experience', color: 'text-neon-green' },
  ],
};

export const DEFAULT_TESTIMONIALS: TestimonialsSectionContent = {
  title: 'What Our',
  titleHighlight: 'Customers',
  subtitle: "Don't just take our word for it — hear from real customers who found their perfect ride at Ex$ell.",
  overallRating: '4.9',
  reviewCount: '200+',
  testimonials: [
    { name: 'Mike R.', location: 'Babylon, NY', rating: 5, text: "Best car buying experience I've ever had. No pressure, fair price, and the car was in perfect condition. The team at Ex$ell made everything so easy. Highly recommend!", vehicle: '2021 BMW 330i' },
    { name: 'Sarah T.', location: 'Islip, NY', rating: 5, text: 'I was nervous about buying a used car, but Ex$ell put all my fears to rest. They showed me the full vehicle history, let me take my time, and made the whole process stress-free. Love my new ride!', vehicle: '2022 Toyota Camry' },
    { name: 'James L.', location: 'Huntington, NY', rating: 5, text: "These guys are the real deal. Honest, straightforward, and they stand behind their cars. I've bought two vehicles from them now and both have been fantastic. Family-owned and it shows.", vehicle: '2020 Audi Q5' },
    { name: 'Maria G.', location: 'Bay Shore, NY', rating: 5, text: 'As a first-time buyer with limited credit, I was turned away by other dealers. Ex$ell worked with me and got me into a beautiful car with affordable payments. Forever grateful!', vehicle: '2023 Honda Civic' },
    { name: 'David K.', location: 'Smithtown, NY', rating: 5, text: 'The detailing on my car was showroom quality. They went above and beyond to make sure everything was perfect before I drove off the lot. Top-notch service from start to finish.', vehicle: '2022 Dodge Charger' },
    { name: 'Lisa P.', location: 'Brentwood, NY', rating: 5, text: 'Found my dream SUV at Ex$ell! The price was thousands below what other dealers were asking for similar vehicles. The whole process took less than 2 hours. Amazing!', vehicle: '2021 Lexus RX 350' },
  ],
};

export const DEFAULT_CONTACT: ContactSectionContent = {
  title: 'Get In',
  titleHighlight: 'Touch',
  subtitle: "Ready to find your next ride? Have questions? Reach out — we're here to help.",
  phone: '6313884426',
  phoneDisplay: '(631) 388-4426',
  phoneLabel: 'Call or text anytime',
  email: 'info@exsellsalesli.com',
  emailLabel: 'Email us anytime',
  address: 'Long Island, NY',
  addressLabel: 'Serving all of Long Island',
  hoursWeekday: 'Mon-Fri: 7AM - 5PM | Sat: 7AM - 2PM',
  hoursSunday: 'Sun: Closed',

  facebookUrl: 'https://www.facebook.com/ExSellSales',
  instagramUrl: 'https://instagram.com',
};

export const DEFAULT_FOOTER: FooterContent = {
  tagline: "Long Island's trusted source for quality pre-owned vehicles. Family-owned, customer-focused, and committed to getting you behind the wheel.",
  services: [
    'Pre-Owned Vehicles',
    'Vehicle Trade-Ins',
    'Car Detailing',
    'Vehicle History Reports',
    'Test Drives',
  ],

  quickLinks: [
    { label: 'Home', type: 'scroll', target: 'hero' },
    { label: 'Inventory', type: 'scroll', target: 'inventory' },
    { label: 'Services', type: 'scroll', target: 'services' },
    { label: 'Why Choose Us', type: 'scroll', target: 'why-us' },
    { label: 'Contact Us', type: 'scroll', target: 'contact' },
    { label: 'Sold Vehicles', type: 'route', target: '/sold' },
    { label: 'Customer Reviews', type: 'route', target: '/reviews' },
    { label: 'About Us', type: 'route', target: '/about' },
    { label: 'Privacy Policy', type: 'route', target: '/privacy-policy' },
    { label: 'Terms of Service', type: 'route', target: '/terms-of-service' },
  ],
  copyrightName: 'Ex$ell Car Sales LI',
  websiteUrl: 'exsellsalesli.com',
  locationText: 'Long Island, New York',
};

/**
 * Default social-share image used across all pages when no per-page or CMS
 * override is set. Hosted on the CDN at 1200×630 (the recommended OG size).
 */
export const DEFAULT_OG_IMAGE =
  "https://d64gsuwffb70l.cloudfront.net/69c07f5eedda49fd18b3c790_1780425504780_301c8b68.png";

export const DEFAULT_SEO: SEOContent = {
  homepage: {
    title: "Ex$ell Car Sales LI | Quality Pre-Owned Vehicles on Long Island",
    metaDescription: "Long Island's premier used car dealer. Browse quality pre-owned vehicles at unbeatable prices. Transparent pricing, no hidden fees, and a customer-first approach. Serving all of Long Island, NY.",
    ogTitle: "Ex$ell Car Sales LI | Drive Your Dream Car Today",
    ogDescription: "Quality pre-owned vehicles at unbeatable prices on Long Island. 500+ cars sold, 4.9-star rating, 100% transparent pricing. Browse our inventory today!",
    ogImage: DEFAULT_OG_IMAGE,
  },
  about: {
    title: "About Us | Ex$ell Car Sales LI — Our Story & Team",
    metaDescription: "Learn about Ex$ell Car Sales LI — a family-owned Long Island dealership founded in 2012. Meet our team, discover our mission, and see why 1,500+ customers trust us with their vehicle purchases.",
    ogTitle: "About Ex$ell Car Sales LI — Family-Owned, Customer-Focused",
    ogDescription: "More than a dealership — we're a Long Island family dedicated to honest deals, quality vehicles, and an experience that keeps you coming back. 14+ years serving Long Island.",
    ogImage: DEFAULT_OG_IMAGE,
  },
  reviews: {
    title: "Customer Reviews | Ex$ell Car Sales LI — 4.9 Star Rating",
    metaDescription: "Read verified customer reviews for Ex$ell Car Sales LI. 4.9-star rating from 200+ real customers. See why Long Island families trust us for quality pre-owned vehicles.",
    ogTitle: "Customer Reviews — Ex$ell Car Sales LI | 4.9 Stars",
    ogDescription: "Don't just take our word for it — hear from real customers who found their perfect ride at Ex$ell Car Sales LI. 200+ verified reviews, 4.9-star average.",
    ogImage: DEFAULT_OG_IMAGE,
  },
  sold: {
    title: "Sold Vehicles | Ex$ell Car Sales LI — Previously Sold Inventory",
    metaDescription: "Browse previously sold vehicles at Ex$ell Car Sales LI. See the quality rides that have found happy homes. Looking for something similar? Contact us today!",
    ogTitle: "Sold Vehicles — Ex$ell Car Sales LI",
    ogDescription: "Check out the vehicles we've successfully matched with happy owners. Proof of the quality rides that move through our lot on Long Island.",
    ogImage: DEFAULT_OG_IMAGE,
  },
  privacy: {
    title: "Privacy Policy | Ex$ell Car Sales LI",
    metaDescription: "Read the privacy policy for Ex$ell Car Sales LI. Learn how we collect, use, and protect your personal information when you visit our website or use our services.",
    ogTitle: "Privacy Policy — Ex$ell Car Sales LI",
    ogDescription: "Ex$ell Car Sales LI is committed to protecting your privacy. Read our full privacy policy to understand how we handle your information.",
    ogImage: DEFAULT_OG_IMAGE,
  },
  terms: {
    title: "Terms of Service | Ex$ell Car Sales LI",
    metaDescription: "Read the terms of service for Ex$ell Car Sales LI. Understand the terms governing vehicle purchases, website usage, test drives, trade-ins, and more.",
    ogTitle: "Terms of Service — Ex$ell Car Sales LI",
    ogDescription: "Terms of Service for Ex$ell Car Sales LI. Covering as-is pre-owned vehicle purchases, vehicle history report disclosures, professional detailing services, dispute resolution, and website usage.",
    ogImage: DEFAULT_OG_IMAGE,
  },
};

export const DEFAULT_ANALYTICS: AnalyticsConfig = {
  enabled: false,
  ga4MeasurementId: '',
  gtmContainerId: '',
  respectCookieConsent: true,
};

export const DEFAULT_ANNOUNCEMENT_BANNER: AnnouncementBannerContent = {
  enabled: false,
  message: 'Spring Sale Now On — Save up to $2,000 on select pre-owned vehicles!',
  ctaLabel: 'Browse Inventory',
  ctaType: 'scroll',
  ctaTarget: 'inventory',
  theme: 'pink',
  dismissible: true,
  marquee: false,
};


export const SEO_PAGE_LABELS: Record<SEOPageKey, string> = {
  homepage: 'Homepage',
  about: 'About Us',
  reviews: 'Customer Reviews',
  sold: 'Sold Vehicles',
  privacy: 'Privacy Policy',
  terms: 'Terms of Service',
};

// Section keys for database storage
export const HOMEPAGE_SECTIONS = {
  hero: 'homepage_hero',
  services: 'homepage_services',
  whyChooseUs: 'homepage_why_choose_us',
  testimonials: 'homepage_testimonials',
  contact: 'homepage_contact',
  footer: 'homepage_footer',
  seo: 'seo_meta_tags',
  analytics: 'analytics_config',
  announcement: 'announcement_banner',
} as const;

