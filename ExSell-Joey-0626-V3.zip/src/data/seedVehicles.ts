import { supabase } from '@/lib/supabase';

export interface SeedVehicle {
  year: number;
  make: string;
  model: string;
  trim: string;
  price: number;
  mileage: number;
  exterior_color: string;
  interior_color: string;
  transmission: string;
  drivetrain: string;
  fuel_type: string;
  engine: string;
  body_type: string;
  vin: string;
  image: string;
  images: string[];
  features: string[];
  status: 'available' | 'sold' | 'pending';
  description: string;
  video_url: string;
}

const SEED_VEHICLES: SeedVehicle[] = [
  // ═══════════════════════════════════════════════
  // CURRENT AVAILABLE INVENTORY
  // ═══════════════════════════════════════════════
  {
    year: 2016, make: 'Jeep', model: 'Compass MK49', trim: 'Latitude', price: 11950, mileage: 45031,
    exterior_color: 'Blue', interior_color: 'Black', transmission: 'Automatic', drivetrain: 'FWD',
    fuel_type: 'Gasoline', engine: '2.4L I4', body_type: 'SUV', vin: '1C4NJDEB8GD709573',
    image: '',
    images: [],
    features: ['Bluetooth', 'Backup Camera', 'Alloy Wheels', 'Keyless Entry', 'Cruise Control'],
    status: 'available',
    description: 'Excellent condition 2016 Jeep Compass MK49 Latitude in Blue with only 45K miles. Well-maintained and ready to drive.',
    video_url: '',
  },
  {
    year: 2016, make: 'Jeep', model: 'Cherokee KL', trim: 'Limited', price: 0, mileage: 86809,
    exterior_color: 'Grey', interior_color: 'Black Leather', transmission: 'Automatic', drivetrain: 'FWD',
    fuel_type: 'Gasoline', engine: '3.2L V6', body_type: 'SUV', vin: '1C4PJMDS6GW334006',
    image: '',
    images: [],
    features: ['Leather Seats', 'Navigation', 'Heated Seats', 'Backup Camera', 'Remote Start', 'Sunroof'],
    status: 'available',
    description: 'Like New condition 2016 Jeep Cherokee KL Limited in Grey. Loaded with premium features including leather, navigation, and heated seats. Call for pricing.',
    video_url: '',
  },
  {
    year: 2013, make: 'Mercedes-Benz', model: 'GL450', trim: '4MATIC', price: 16995, mileage: 60465,
    exterior_color: 'Black', interior_color: 'Black Leather', transmission: 'Automatic', drivetrain: 'AWD',
    fuel_type: 'Gasoline', engine: '4.6L V8 Bi-Turbo', body_type: 'SUV', vin: '4JGDF7CE1DA105142',
    image: '',
    images: [],
    features: ['Navigation', 'Leather Seats', 'Sunroof', 'Heated Seats', 'Third Row', 'Backup Camera', 'Bluetooth', 'Premium Sound'],
    status: 'available',
    description: 'Like New condition 2013 Mercedes-Benz GL450 4MATIC in Black. Luxury full-size SUV with only 60K miles. Bi-Turbo V8 power with all-wheel drive.',
    video_url: '',
  },
  {
    year: 2006, make: 'Toyota', model: 'Camry', trim: 'LE', price: 7950, mileage: 83692,
    exterior_color: 'Silver', interior_color: 'Gray', transmission: 'Automatic', drivetrain: 'FWD',
    fuel_type: 'Gasoline', engine: '2.4L I4', body_type: 'Sedan', vin: '4T1BE32KX6U111470',
    image: '',
    images: [],
    features: ['Power Windows', 'Power Locks', 'Cruise Control', 'CD Player', 'Air Conditioning'],
    status: 'available',
    description: 'Excellent condition 2006 Toyota Camry. Legendary Toyota reliability with 83K miles. Perfect daily driver.',
    video_url: '',
  },
  {
    year: 2013, make: 'Nissan', model: 'Rogue', trim: 'S', price: 7950, mileage: 98884,
    exterior_color: 'Black', interior_color: 'Black', transmission: 'CVT', drivetrain: 'FWD',
    fuel_type: 'Gasoline', engine: '2.5L I4', body_type: 'SUV', vin: 'JN8AS5MV6DW110477',
    image: '',
    images: [],
    features: ['Bluetooth', 'Backup Camera', 'Cruise Control', 'Power Windows', 'Keyless Entry'],
    status: 'available',
    description: 'Excellent condition 2013 Nissan Rogue in Black. Spacious and fuel-efficient compact SUV.',
    video_url: '',
  },
  {
    year: 2005, make: 'Chrysler', model: 'PT Cruiser', trim: 'Touring', price: 5900, mileage: 68496,
    exterior_color: 'Blue', interior_color: 'Gray', transmission: 'Automatic', drivetrain: 'FWD',
    fuel_type: 'Gasoline', engine: '2.4L I4', body_type: 'SUV', vin: '3C4FY58B95T620040',
    image: '',
    images: [],
    features: ['Air Conditioning', 'Power Windows', 'Power Locks', 'CD Player', 'Cruise Control'],
    status: 'available',
    description: 'Like New condition 2005 Chrysler PT Cruiser Touring in Blue with only 68K miles. Unique retro styling with modern reliability.',
    video_url: '',
  },

  // ═══════════════════════════════════════════════
  // SOLD VEHICLES
  // ═══════════════════════════════════════════════
  {
    year: 2015, make: 'GMC', model: 'Yukon', trim: 'Denali', price: 17950, mileage: 85400,
    exterior_color: 'White', interior_color: 'Cocoa/Shale Leather', transmission: 'Automatic', drivetrain: '4WD',
    fuel_type: 'Gasoline', engine: '6.2L V8', body_type: 'SUV', vin: '1GKS2EEF2CR279727',
    image: '',
    images: [],
    features: ['Navigation', 'Leather Seats', 'Sunroof', 'Heated/Cooled Seats', 'Bose Audio', 'Third Row', 'DVD Entertainment', 'Power Liftgate'],
    status: 'sold',
    description: '2015 GMC Yukon Denali in White. Full-size luxury SUV with powerful 6.2L V8.',
    video_url: '',
  },
  {
    year: 2011, make: 'GMC', model: 'Yukon', trim: 'SLT 4x4', price: 16500, mileage: 67834,
    exterior_color: 'Silver', interior_color: 'Ebony Leather', transmission: 'Automatic', drivetrain: '4WD',
    fuel_type: 'Gasoline', engine: '5.3L V8', body_type: 'SUV', vin: '1GKS2CE03BR369547',
    image: '',
    images: [],
    features: ['Leather Seats', 'Heated Seats', 'Bose Audio', 'Third Row', 'Running Boards', 'Tow Package'],
    status: 'sold',
    description: '2011 GMC Yukon SLT 4x4 in Silver. Reliable full-size SUV.',
    video_url: '',
  },
  {
    year: 2009, make: 'Maserati', model: 'Quattroporte', trim: 'S', price: 16500, mileage: 59927,
    exterior_color: 'Grey', interior_color: 'Tan Leather', transmission: 'Automatic', drivetrain: 'RWD',
    fuel_type: 'Gasoline', engine: '4.7L V8', body_type: 'Sedan', vin: 'ZAMJK39A990043630',
    image: '',
    images: [],
    features: ['Leather Seats', 'Navigation', 'Premium Sound', 'Sunroof', 'Heated Seats', 'Parking Sensors'],
    status: 'sold',
    description: '2009 Maserati Quattroporte S in Grey. Italian luxury sedan with 4.7L V8.',
    video_url: '',
  },
  {
    year: 2003, make: 'Honda', model: 'Element', trim: 'EX', price: 13500, mileage: 79773,
    exterior_color: 'Orange', interior_color: 'Black', transmission: 'Automatic', drivetrain: 'AWD',
    fuel_type: 'Gasoline', engine: '2.4L I4', body_type: 'SUV', vin: '5J6YH28553L006087',
    image: '',
    images: [],
    features: ['AWD', 'Sunroof', 'Alloy Wheels', 'Cruise Control', 'Power Windows'],
    status: 'sold',
    description: '2003 Honda Element EX in Orange. Versatile and fun AWD crossover.',
    video_url: '',
  },
  {
    year: 2014, make: 'Honda', model: 'CR-V', trim: 'LX', price: 12600, mileage: 99348,
    exterior_color: 'Black', interior_color: 'Gray', transmission: 'Automatic', drivetrain: 'FWD',
    fuel_type: 'Gasoline', engine: '2.4L I4', body_type: 'SUV', vin: '2HKRM4H31EH689770',
    image: '',
    images: [],
    features: ['Backup Camera', 'Bluetooth', 'Cruise Control', 'Power Windows', 'Air Conditioning'],
    status: 'sold',
    description: '2014 Honda CR-V LX in Black. Reliable compact SUV.',
    video_url: '',
  },
  {
    year: 2015, make: 'Kia', model: 'Sorento', trim: 'LX', price: 11995, mileage: 47766,
    exterior_color: 'Grey', interior_color: 'Black', transmission: 'Automatic', drivetrain: 'FWD',
    fuel_type: 'Gasoline', engine: '2.4L I4', body_type: 'SUV', vin: '5XYKTCA6XFG569266',
    image: '',
    images: [],
    features: ['Bluetooth', 'Backup Camera', 'Alloy Wheels', 'Cruise Control', 'Satellite Radio'],
    status: 'sold',
    description: '2015 Kia Sorento LX in Grey. Low mileage midsize SUV.',
    video_url: '',
  },
  {
    year: 2009, make: 'Honda', model: 'CR-V', trim: 'LX', price: 10995, mileage: 52236,
    exterior_color: 'Silver', interior_color: 'Gray', transmission: 'Automatic', drivetrain: 'FWD',
    fuel_type: 'Gasoline', engine: '2.4L I4', body_type: 'SUV', vin: '5J6RE48329L051228',
    image: '',
    images: [],
    features: ['Power Windows', 'Power Locks', 'Air Conditioning', 'CD Player', 'Cruise Control'],
    status: 'sold',
    description: '2009 Honda CR-V LX. Low mileage Honda reliability.',
    video_url: '',
  },
  {
    year: 2010, make: 'Jeep', model: 'Grand Cherokee', trim: 'Limited', price: 11900, mileage: 68840,
    exterior_color: 'Black', interior_color: 'Black Leather', transmission: 'Automatic', drivetrain: '4WD',
    fuel_type: 'Gasoline', engine: '5.7L HEMI V8', body_type: 'SUV', vin: '1J4RR5GT9AC124689',
    image: '',
    images: [],
    features: ['Leather Seats', 'Navigation', 'Sunroof', 'Heated Seats', 'Tow Package', 'HEMI V8'],
    status: 'sold',
    description: '2010 Jeep Grand Cherokee Limited in Black with HEMI V8.',
    video_url: '',
  },
  {
    year: 2006, make: 'Scion', model: 'xB', trim: 'Base', price: 9700, mileage: 75833,
    exterior_color: 'Maroon', interior_color: 'Dark Charcoal', transmission: 'Automatic', drivetrain: 'FWD',
    fuel_type: 'Gasoline', engine: '1.5L I4', body_type: 'SUV', vin: 'JTLKT324464036670',
    image: '',
    images: [],
    features: ['Air Conditioning', 'Power Windows', 'Power Locks', 'CD Player', 'Pioneer Audio'],
    status: 'sold',
    description: '2006 Scion xB in Maroon. Fun and fuel-efficient box car.',
    video_url: '',
  },
  {
    year: 2004, make: 'Toyota', model: 'Solara', trim: 'SE', price: 10500, mileage: 25326,
    exterior_color: 'Silver', interior_color: 'Charcoal', transmission: 'Automatic', drivetrain: 'FWD',
    fuel_type: 'Gasoline', engine: '2.4L I4', body_type: 'Coupe', vin: '4T1CE38PX4U94868',
    image: '',
    images: [],
    features: ['Power Windows', 'Power Locks', 'Cruise Control', 'CD Player', 'Alloy Wheels'],
    status: 'sold',
    description: '2004 Toyota Solara SE in Silver with extremely low 25K miles. Rare find.',
    video_url: '',
  },
  {
    year: 2011, make: 'Jeep', model: 'Patriot', trim: 'Latitude', price: 8500, mileage: 69718,
    exterior_color: 'Blue', interior_color: 'Dark Slate Gray', transmission: 'Automatic', drivetrain: 'FWD',
    fuel_type: 'Gasoline', engine: '2.4L I4', body_type: 'SUV', vin: '1J4NF1GB1BD187840',
    image: '',
    images: [],
    features: ['Bluetooth', 'Heated Seats', 'Alloy Wheels', 'Cruise Control', 'Satellite Radio'],
    status: 'sold',
    description: '2011 Jeep Patriot Latitude in Blue. Compact SUV with Jeep capability.',
    video_url: '',
  },
  {
    year: 2006, make: 'Honda', model: 'Odyssey', trim: 'LX', price: 7995, mileage: 74881,
    exterior_color: 'Silver', interior_color: 'Gray', transmission: 'Automatic', drivetrain: 'FWD',
    fuel_type: 'Gasoline', engine: '3.5L V6', body_type: 'Minivan', vin: '5FNRL38266B108445',
    image: '',
    images: [],
    features: ['Power Sliding Doors', 'Third Row', 'Cruise Control', 'CD Player', 'Air Conditioning'],
    status: 'sold',
    description: '2006 Honda Odyssey LX in Silver. Reliable family minivan with V6 power.',
    video_url: '',
  },
  {
    year: 2013, make: 'Smart', model: 'Fortwo', trim: 'Passion', price: 6900, mileage: 60365,
    exterior_color: 'White', interior_color: 'Black', transmission: 'Automatic', drivetrain: 'RWD',
    fuel_type: 'Gasoline', engine: '1.0L I3', body_type: 'Coupe', vin: 'WMEEJ3BA9DK685024',
    image: '',
    images: [],
    features: ['Panoramic Roof', 'Heated Seats', 'Bluetooth', 'Air Conditioning', 'Power Windows'],
    status: 'sold',
    description: '2013 Smart Fortwo Passion in White. Ultimate city car with great fuel economy.',
    video_url: '',
  },
  {
    year: 2004, make: 'Ford', model: 'Freestar', trim: 'SE', price: 6999, mileage: 65443,
    exterior_color: 'Silver', interior_color: 'Flint Gray', transmission: 'Automatic', drivetrain: 'FWD',
    fuel_type: 'Gasoline', engine: '3.9L V6', body_type: 'Minivan', vin: '2FMZA516X4BA07560',
    image: '',
    images: [],
    features: ['Third Row', 'Rear Air Conditioning', 'Power Windows', 'Power Locks', 'Cruise Control'],
    status: 'sold',
    description: '2004 Ford Freestar SE in Silver. Spacious family minivan.',
    video_url: '',
  },

];

export async function seedDemoVehicles(): Promise<{ success: boolean; count: number; error?: string }> {
  try {
    // Check if vehicles already exist
    const { count, error: countError } = await supabase
      .from('vehicles')
      .select('*', { count: 'exact', head: true });

    if (countError) {
      return { success: false, count: 0, error: countError.message };
    }

    if (count && count > 0) {
      return { success: false, count: 0, error: `Database already has ${count} vehicles. Clear existing data first or add vehicles manually.` };
    }

    // Insert all seed vehicles
    const { data, error: insertError } = await supabase
      .from('vehicles')
      .insert(SEED_VEHICLES)
      .select();

    if (insertError) {
      return { success: false, count: 0, error: insertError.message };
    }

    return { success: true, count: data?.length || 0 };
  } catch (err: any) {
    return { success: false, count: 0, error: err.message || 'Unknown error during seeding' };
  }
}

export default SEED_VEHICLES;
