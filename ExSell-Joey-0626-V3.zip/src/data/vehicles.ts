import { supabase } from '@/lib/supabase';

export interface Vehicle {
  id: number;
  year: number;
  make: string;
  model: string;
  trim: string;
  price: number;
  mileage: number;
  exteriorColor: string;
  interiorColor: string;
  transmission: string;
  drivetrain: string;
  fuelType: string;
  engine: string;
  bodyType: string;
  vin: string;
  image: string;
  images: string[];
  features: string[];
  status: 'available' | 'sold' | 'pending';
  description: string;
  videoUrl: string;
  soldDate?: string;
  soldPrice?: number;
  created_at?: string;
  updated_at?: string;
}

// Map DB row (snake_case) to Vehicle interface (camelCase)
export function mapDbVehicle(row: any): Vehicle {
  return {
    id: row.id,
    year: row.year,
    make: row.make,
    model: row.model,
    trim: row.trim || '',
    price: Number(row.price),
    mileage: row.mileage || 0,
    exteriorColor: row.exterior_color || '',
    interiorColor: row.interior_color || '',
    transmission: row.transmission || 'Automatic',
    drivetrain: row.drivetrain || 'FWD',
    fuelType: row.fuel_type || 'Gasoline',
    engine: row.engine || '',
    bodyType: row.body_type || 'Sedan',
    vin: row.vin || '',
    image: row.image || '',
    images: row.images || [],
    features: row.features || [],
    status: row.status || 'available',
    description: row.description || '',
    videoUrl: row.video_url || '',
    soldDate: row.sold_date || undefined,
    soldPrice: row.sold_price ? Number(row.sold_price) : undefined,
    created_at: row.created_at,
    updated_at: row.updated_at,
  };
}



// Map Vehicle interface (camelCase) back to DB row (snake_case)
export function mapVehicleToDb(vehicle: Partial<Vehicle>): Record<string, any> {
  const dbRow: Record<string, any> = {};
  if (vehicle.year !== undefined) dbRow.year = vehicle.year;
  if (vehicle.make !== undefined) dbRow.make = vehicle.make;
  if (vehicle.model !== undefined) dbRow.model = vehicle.model;
  if (vehicle.trim !== undefined) dbRow.trim = vehicle.trim;
  if (vehicle.price !== undefined) dbRow.price = vehicle.price;
  if (vehicle.mileage !== undefined) dbRow.mileage = vehicle.mileage;
  if (vehicle.exteriorColor !== undefined) dbRow.exterior_color = vehicle.exteriorColor;
  if (vehicle.interiorColor !== undefined) dbRow.interior_color = vehicle.interiorColor;
  if (vehicle.transmission !== undefined) dbRow.transmission = vehicle.transmission;
  if (vehicle.drivetrain !== undefined) dbRow.drivetrain = vehicle.drivetrain;
  if (vehicle.fuelType !== undefined) dbRow.fuel_type = vehicle.fuelType;
  if (vehicle.engine !== undefined) dbRow.engine = vehicle.engine;
  if (vehicle.bodyType !== undefined) dbRow.body_type = vehicle.bodyType;
  if (vehicle.vin !== undefined) dbRow.vin = vehicle.vin;
  if (vehicle.image !== undefined) dbRow.image = vehicle.image;
  if (vehicle.images !== undefined) dbRow.images = vehicle.images;
  if (vehicle.features !== undefined) dbRow.features = vehicle.features;
  if (vehicle.status !== undefined) dbRow.status = vehicle.status;
  if (vehicle.description !== undefined) dbRow.description = vehicle.description;
  if (vehicle.videoUrl !== undefined) dbRow.video_url = vehicle.videoUrl;
  if (vehicle.soldDate !== undefined) dbRow.sold_date = vehicle.soldDate;
  if (vehicle.soldPrice !== undefined) dbRow.sold_price = vehicle.soldPrice;
  return dbRow;
}




// Fallback vehicle data in case database is unreachable
const FALLBACK_VEHICLES: Vehicle[] = [
  // ═══════════════════════════════════════════════
  // CURRENT AVAILABLE INVENTORY
  // ═══════════════════════════════════════════════
  {
    id: 13, year: 2016, make: "Jeep", model: "Compass MK49", trim: "Latitude", price: 11950, mileage: 45031,
    exteriorColor: "Blue", interiorColor: "Black", transmission: "Automatic", drivetrain: "FWD",
    fuelType: "Gasoline", engine: "2.4L I4", bodyType: "SUV", vin: "1C4NJDEB8GD709573",
    image: "",
    images: [],
    features: ["Bluetooth", "Backup Camera", "Alloy Wheels", "Keyless Entry", "Cruise Control"],
    status: "available",
    description: "Excellent condition 2016 Jeep Compass MK49 Latitude in Blue with only 45K miles. Well-maintained and ready to drive.",
    videoUrl: ""
  },
  {
    id: 14, year: 2016, make: "Jeep", model: "Cherokee KL", trim: "Limited", price: 0, mileage: 86809,
    exteriorColor: "Grey", interiorColor: "Black Leather", transmission: "Automatic", drivetrain: "FWD",
    fuelType: "Gasoline", engine: "3.2L V6", bodyType: "SUV", vin: "1C4PJMDS6GW334006",
    image: "",
    images: [],
    features: ["Leather Seats", "Navigation", "Heated Seats", "Backup Camera", "Remote Start", "Sunroof"],
    status: "available",
    description: "Like New condition 2016 Jeep Cherokee KL Limited in Grey. Loaded with premium features including leather, navigation, and heated seats. Call for pricing.",
    videoUrl: ""
  },
  {
    id: 15, year: 2013, make: "Mercedes-Benz", model: "GL450", trim: "4MATIC", price: 16995, mileage: 60465,
    exteriorColor: "Black", interiorColor: "Black Leather", transmission: "Automatic", drivetrain: "AWD",
    fuelType: "Gasoline", engine: "4.6L V8 Bi-Turbo", bodyType: "SUV", vin: "4JGDF7CE1DA105142",
    image: "",
    images: [],
    features: ["Navigation", "Leather Seats", "Sunroof", "Heated Seats", "Third Row", "Backup Camera", "Bluetooth", "Premium Sound"],
    status: "available",
    description: "Like New condition 2013 Mercedes-Benz GL450 4MATIC in Black. Luxury full-size SUV with only 60K miles. Bi-Turbo V8 power with all-wheel drive.",
    videoUrl: ""
  },
  {
    id: 16, year: 2006, make: "Toyota", model: "Camry", trim: "LE", price: 7950, mileage: 83692,
    exteriorColor: "Silver", interiorColor: "Gray", transmission: "Automatic", drivetrain: "FWD",
    fuelType: "Gasoline", engine: "2.4L I4", bodyType: "Sedan", vin: "4T1BE32KX6U111470",
    image: "",
    images: [],
    features: ["Power Windows", "Power Locks", "Cruise Control", "CD Player", "Air Conditioning"],
    status: "available",
    description: "Excellent condition 2006 Toyota Camry. Legendary Toyota reliability with 83K miles. Perfect daily driver.",
    videoUrl: ""
  },
  {
    id: 17, year: 2013, make: "Nissan", model: "Rogue", trim: "S", price: 7950, mileage: 98884,
    exteriorColor: "Black", interiorColor: "Black", transmission: "CVT", drivetrain: "FWD",
    fuelType: "Gasoline", engine: "2.5L I4", bodyType: "SUV", vin: "JN8AS5MV6DW110477",
    image: "",
    images: [],
    features: ["Bluetooth", "Backup Camera", "Cruise Control", "Power Windows", "Keyless Entry"],
    status: "available",
    description: "Excellent condition 2013 Nissan Rogue in Black. Spacious and fuel-efficient compact SUV.",
    videoUrl: ""
  },
  {
    id: 18, year: 2005, make: "Chrysler", model: "PT Cruiser", trim: "Touring", price: 5900, mileage: 68496,
    exteriorColor: "Blue", interiorColor: "Gray", transmission: "Automatic", drivetrain: "FWD",
    fuelType: "Gasoline", engine: "2.4L I4", bodyType: "SUV", vin: "3C4FY58B95T620040",
    image: "",
    images: [],
    features: ["Air Conditioning", "Power Windows", "Power Locks", "CD Player", "Cruise Control"],
    status: "available",
    description: "Like New condition 2005 Chrysler PT Cruiser Touring in Blue with only 68K miles. Unique retro styling with modern reliability.",
    videoUrl: ""
  },

  // ═══════════════════════════════════════════════
  // SOLD VEHICLES
  // ═══════════════════════════════════════════════
  {
    id: 19, year: 2015, make: "GMC", model: "Yukon", trim: "Denali", price: 17950, mileage: 85400,
    exteriorColor: "White", interiorColor: "Cocoa/Shale Leather", transmission: "Automatic", drivetrain: "4WD",
    fuelType: "Gasoline", engine: "6.2L V8", bodyType: "SUV", vin: "1GKS2EEF2CR279727",
    image: "",
    images: [],
    features: ["Navigation", "Leather Seats", "Sunroof", "Heated/Cooled Seats", "Bose Audio", "Third Row", "DVD Entertainment", "Power Liftgate"],
    status: "sold", description: "2015 GMC Yukon Denali in White. Full-size luxury SUV with powerful 6.2L V8.", videoUrl: ""
  },
  {
    id: 20, year: 2011, make: "GMC", model: "Yukon", trim: "SLT 4x4", price: 16500, mileage: 67834,
    exteriorColor: "Silver", interiorColor: "Ebony Leather", transmission: "Automatic", drivetrain: "4WD",
    fuelType: "Gasoline", engine: "5.3L V8", bodyType: "SUV", vin: "1GKS2CE03BR369547",
    image: "",
    images: [],
    features: ["Leather Seats", "Heated Seats", "Bose Audio", "Third Row", "Running Boards", "Tow Package"],
    status: "sold", description: "2011 GMC Yukon SLT 4x4 in Silver. Reliable full-size SUV.", videoUrl: ""
  },
  {
    id: 21, year: 2009, make: "Maserati", model: "Quattroporte", trim: "S", price: 16500, mileage: 59927,
    exteriorColor: "Grey", interiorColor: "Tan Leather", transmission: "Automatic", drivetrain: "RWD",
    fuelType: "Gasoline", engine: "4.7L V8", bodyType: "Sedan", vin: "ZAMJK39A990043630",
    image: "",
    images: [],
    features: ["Leather Seats", "Navigation", "Premium Sound", "Sunroof", "Heated Seats", "Parking Sensors"],
    status: "sold", description: "2009 Maserati Quattroporte S in Grey. Italian luxury sedan with 4.7L V8.", videoUrl: ""
  },
  {
    id: 22, year: 2003, make: "Honda", model: "Element", trim: "EX", price: 13500, mileage: 79773,
    exteriorColor: "Orange", interiorColor: "Black", transmission: "Automatic", drivetrain: "AWD",
    fuelType: "Gasoline", engine: "2.4L I4", bodyType: "SUV", vin: "5J6YH28553L006087",
    image: "",
    images: [],
    features: ["AWD", "Sunroof", "Alloy Wheels", "Cruise Control", "Power Windows"],
    status: "sold", description: "2003 Honda Element EX in Orange. Versatile and fun AWD crossover.", videoUrl: ""
  },
  {
    id: 23, year: 2014, make: "Honda", model: "CR-V", trim: "LX", price: 12600, mileage: 99348,
    exteriorColor: "Black", interiorColor: "Gray", transmission: "Automatic", drivetrain: "FWD",
    fuelType: "Gasoline", engine: "2.4L I4", bodyType: "SUV", vin: "2HKRM4H31EH689770",
    image: "",
    images: [],
    features: ["Backup Camera", "Bluetooth", "Cruise Control", "Power Windows", "Air Conditioning"],
    status: "sold", description: "2014 Honda CR-V LX in Black. Reliable compact SUV.", videoUrl: ""
  },
  {
    id: 24, year: 2015, make: "Kia", model: "Sorento", trim: "LX", price: 11995, mileage: 47766,
    exteriorColor: "Grey", interiorColor: "Black", transmission: "Automatic", drivetrain: "FWD",
    fuelType: "Gasoline", engine: "2.4L I4", bodyType: "SUV", vin: "5XYKTCA6XFG569266",
    image: "",
    images: [],
    features: ["Bluetooth", "Backup Camera", "Alloy Wheels", "Cruise Control", "Satellite Radio"],
    status: "sold", description: "2015 Kia Sorento LX in Grey. Low mileage midsize SUV.", videoUrl: ""
  },
  {
    id: 25, year: 2009, make: "Honda", model: "CR-V", trim: "LX", price: 10995, mileage: 52236,
    exteriorColor: "Silver", interiorColor: "Gray", transmission: "Automatic", drivetrain: "FWD",
    fuelType: "Gasoline", engine: "2.4L I4", bodyType: "SUV", vin: "5J6RE48329L051228",
    image: "",
    images: [],
    features: ["Power Windows", "Power Locks", "Air Conditioning", "CD Player", "Cruise Control"],
    status: "sold", description: "2009 Honda CR-V LX. Low mileage Honda reliability.", videoUrl: ""
  },
  {
    id: 26, year: 2010, make: "Jeep", model: "Grand Cherokee", trim: "Limited", price: 11900, mileage: 68840,
    exteriorColor: "Black", interiorColor: "Black Leather", transmission: "Automatic", drivetrain: "4WD",
    fuelType: "Gasoline", engine: "5.7L HEMI V8", bodyType: "SUV", vin: "1J4RR5GT9AC124689",
    image: "",
    images: [],
    features: ["Leather Seats", "Navigation", "Sunroof", "Heated Seats", "Tow Package", "HEMI V8"],
    status: "sold", description: "2010 Jeep Grand Cherokee Limited in Black with HEMI V8.", videoUrl: ""
  },
  {
    id: 27, year: 2006, make: "Scion", model: "xB", trim: "Base", price: 9700, mileage: 75833,
    exteriorColor: "Maroon", interiorColor: "Dark Charcoal", transmission: "Automatic", drivetrain: "FWD",
    fuelType: "Gasoline", engine: "1.5L I4", bodyType: "SUV", vin: "JTLKT324464036670",
    image: "",
    images: [],
    features: ["Air Conditioning", "Power Windows", "Power Locks", "CD Player", "Pioneer Audio"],
    status: "sold", description: "2006 Scion xB in Maroon. Fun and fuel-efficient box car.", videoUrl: ""
  },
  {
    id: 28, year: 2004, make: "Toyota", model: "Solara", trim: "SE", price: 10500, mileage: 25326,
    exteriorColor: "Silver", interiorColor: "Charcoal", transmission: "Automatic", drivetrain: "FWD",
    fuelType: "Gasoline", engine: "2.4L I4", bodyType: "Coupe", vin: "4T1CE38PX4U94868",
    image: "",
    images: [],
    features: ["Power Windows", "Power Locks", "Cruise Control", "CD Player", "Alloy Wheels"],
    status: "sold", description: "2004 Toyota Solara SE in Silver with extremely low 25K miles. Rare find.", videoUrl: ""
  },
  {
    id: 29, year: 2011, make: "Jeep", model: "Patriot", trim: "Latitude", price: 8500, mileage: 69718,
    exteriorColor: "Blue", interiorColor: "Dark Slate Gray", transmission: "Automatic", drivetrain: "FWD",
    fuelType: "Gasoline", engine: "2.4L I4", bodyType: "SUV", vin: "1J4NF1GB1BD187840",
    image: "",
    images: [],
    features: ["Bluetooth", "Heated Seats", "Alloy Wheels", "Cruise Control", "Satellite Radio"],
    status: "sold", description: "2011 Jeep Patriot Latitude in Blue. Compact SUV with Jeep capability.", videoUrl: ""
  },
  {
    id: 30, year: 2006, make: "Honda", model: "Odyssey", trim: "LX", price: 7995, mileage: 74881,
    exteriorColor: "Silver", interiorColor: "Gray", transmission: "Automatic", drivetrain: "FWD",
    fuelType: "Gasoline", engine: "3.5L V6", bodyType: "Minivan", vin: "5FNRL38266B108445",
    image: "",
    images: [],
    features: ["Power Sliding Doors", "Third Row", "Cruise Control", "CD Player", "Air Conditioning"],
    status: "sold", description: "2006 Honda Odyssey LX in Silver. Reliable family minivan with V6 power.", videoUrl: ""
  },
  {
    id: 31, year: 2013, make: "Smart", model: "Fortwo", trim: "Passion", price: 6900, mileage: 60365,
    exteriorColor: "White", interiorColor: "Black", transmission: "Automatic", drivetrain: "RWD",
    fuelType: "Gasoline", engine: "1.0L I3", bodyType: "Coupe", vin: "WMEEJ3BA9DK685024",
    image: "",
    images: [],
    features: ["Panoramic Roof", "Heated Seats", "Bluetooth", "Air Conditioning", "Power Windows"],
    status: "sold", description: "2013 Smart Fortwo Passion in White. Ultimate city car with great fuel economy.", videoUrl: ""
  },
  {
    id: 32, year: 2004, make: "Ford", model: "Freestar", trim: "SE", price: 6999, mileage: 65443,
    exteriorColor: "Silver", interiorColor: "Flint Gray", transmission: "Automatic", drivetrain: "FWD",
    fuelType: "Gasoline", engine: "3.9L V6", bodyType: "Minivan", vin: "2FMZA516X4BA07560",
    image: "",
    images: [],
    features: ["Third Row", "Rear Air Conditioning", "Power Windows", "Power Locks", "Cruise Control"],
    status: "sold", description: "2004 Ford Freestar SE in Silver. Spacious family minivan.", videoUrl: ""
  },
];




// Track whether we're using fallback data
let _usingFallback = false;
export function isUsingFallbackData(): boolean {
  return _usingFallback;
}

// Helper: query with retry (tries twice)
async function queryWithRetry<T>(
  queryFn: (signal: AbortSignal) => Promise<{ data: T | null; error: any }>,
  timeoutMs = 8000
): Promise<{ data: T | null; error: any }> {
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), timeoutMs);
      const result = await queryFn(controller.signal);
      clearTimeout(timeout);
      if (!result.error) return result;
      // If first attempt failed with a non-abort error, retry once
      if (attempt === 0) {
        console.warn(`DB query attempt ${attempt + 1} failed, retrying...`, result.error.message);
        await new Promise(r => setTimeout(r, 500));
        continue;
      }
      return result;
    } catch (e: any) {
      if (attempt === 0) {
        console.warn(`DB query attempt ${attempt + 1} threw, retrying...`, e.message);
        await new Promise(r => setTimeout(r, 500));
        continue;
      }
      return { data: null, error: e };
    }
  }
  return { data: null, error: new Error('All retry attempts failed') };
}

// Fetch all vehicles from database with retry and fallback
export async function fetchVehicles(): Promise<Vehicle[]> {
  try {
    const { data, error } = await queryWithRetry<any[]>(
      (signal) => supabase
        .from('vehicles')
        .select('*')
        .order('created_at', { ascending: false })
        .abortSignal(signal)
    );

    if (error || !data) {
      console.warn('DB query failed after retries, using local inventory data');
      _usingFallback = true;
      return FALLBACK_VEHICLES;
    }

    _usingFallback = false;
    return data.map(mapDbVehicle);
  } catch (e) {
    console.info('Using local inventory data');
    _usingFallback = true;
    return FALLBACK_VEHICLES;
  }
}

// Fetch only sold vehicles from database
export async function fetchSoldVehicles(): Promise<Vehicle[]> {
  try {
    const { data, error } = await queryWithRetry<any[]>(
      (signal) => supabase
        .from('vehicles')
        .select('*')
        .eq('status', 'sold')
        .order('sold_date', { ascending: false, nullsFirst: false })
        .order('updated_at', { ascending: false })
        .abortSignal(signal)
    );

    if (error || !data) {
      console.warn('DB query failed after retries, using local sold data');
      _usingFallback = true;
      return FALLBACK_VEHICLES.filter(v => v.status === 'sold');
    }

    _usingFallback = false;
    return data.map(mapDbVehicle);
  } catch (e) {
    console.info('Using local sold data');
    _usingFallback = true;
    return FALLBACK_VEHICLES.filter(v => v.status === 'sold');
  }
}





// Fetch a single vehicle by ID
export async function fetchVehicleById(id: number): Promise<Vehicle | null> {
  const { data, error } = await supabase
    .from('vehicles')
    .select('*')
    .eq('id', id)
    .single();

  if (error) {
    console.error('Error fetching vehicle:', error);
    // Try fallback
    const fallback = FALLBACK_VEHICLES.find(v => v.id === id);
    return fallback || null;
  }

  return data ? mapDbVehicle(data) : null;
}

// Create a new vehicle
export async function createVehicle(vehicle: Partial<Vehicle>): Promise<Vehicle | null> {
  const dbRow = mapVehicleToDb(vehicle);
  const { data, error } = await supabase
    .from('vehicles')
    .insert(dbRow)
    .select()
    .single();

  if (error) {
    console.error('Error creating vehicle:', error);
    throw error;
  }

  return data ? mapDbVehicle(data) : null;
}

// Update an existing vehicle
export async function updateVehicle(id: number, updates: Partial<Vehicle>): Promise<Vehicle | null> {
  const dbRow = mapVehicleToDb(updates);
  dbRow.updated_at = new Date().toISOString();

  const { data, error } = await supabase
    .from('vehicles')
    .update(dbRow)
    .eq('id', id)
    .select()
    .single();

  if (error) {
    console.error('Error updating vehicle:', error);
    throw error;
  }

  return data ? mapDbVehicle(data) : null;
}

// Delete a vehicle
export async function deleteVehicle(id: number): Promise<boolean> {
  const { error } = await supabase
    .from('vehicles')
    .delete()
    .eq('id', id);

  if (error) {
    console.error('Error deleting vehicle:', error);
    throw error;
  }

  return true;
}

// Upload a vehicle image to storage
export async function uploadVehicleImage(file: File): Promise<string> {
  const fileExt = file.name.split('.').pop();
  const fileName = `${Date.now()}-${Math.random().toString(36).substring(2)}.${fileExt}`;
  const filePath = `vehicles/${fileName}`;

  const { error } = await supabase.storage
    .from('vehicle-images')
    .upload(filePath, file, {
      cacheControl: '3600',
      upsert: false,
    });

  if (error) {
    console.error('Error uploading image:', error);
    throw error;
  }

  const { data: urlData } = supabase.storage
    .from('vehicle-images')
    .getPublicUrl(filePath);

  return urlData.publicUrl;
}


// Upload an image from a URL to Supabase storage (frontend-side)
export async function uploadImageFromUrl(imageUrl: string): Promise<string> {
  // Fetch the image
  const response = await fetch(imageUrl);
  if (!response.ok) {
    throw new Error(`Failed to fetch image: ${response.status}`);
  }
  
  const blob = await response.blob();
  
  // Determine file extension from content type or URL
  const contentType = blob.type || 'image/jpeg';
  const extMap: Record<string, string> = {
    'image/jpeg': 'jpg',
    'image/jpg': 'jpg',
    'image/png': 'png',
    'image/webp': 'webp',
    'image/gif': 'gif',
  };
  const ext = extMap[contentType] || 'jpg';
  
  const fileName = `${Date.now()}-${Math.random().toString(36).substring(2)}.${ext}`;
  const filePath = `vehicles/${fileName}`;

  const { error } = await supabase.storage
    .from('vehicle-images')
    .upload(filePath, blob, {
      cacheControl: '3600',
      upsert: false,
      contentType,
    });

  if (error) {
    throw new Error(`Storage upload failed: ${error.message}`);
  }

  const { data: urlData } = supabase.storage
    .from('vehicle-images')
    .getPublicUrl(filePath);

  return urlData.publicUrl;
}


// Clear all stock (Unsplash) photos from all vehicles in the database
export async function clearAllStockPhotos(): Promise<{ cleared: number }> {
  // First, fetch all vehicles
  const { data: allVehicles, error: fetchError } = await supabase
    .from('vehicles')
    .select('id, image, images');

  if (fetchError || !allVehicles) {
    throw new Error(fetchError?.message || 'Failed to fetch vehicles');
  }

  let clearedCount = 0;

  for (const vehicle of allVehicles) {
    const hasStockImage = vehicle.image && vehicle.image.includes('unsplash.com');
    const stockImages = (vehicle.images || []).filter((img: string) => img.includes('unsplash.com'));
    
    if (!hasStockImage && stockImages.length === 0) continue;

    // Filter out stock images, keep real ones
    const realImages = (vehicle.images || []).filter((img: string) => !img.includes('unsplash.com'));
    const newMainImage = hasStockImage ? (realImages[0] || '') : vehicle.image;

    const { error: updateError } = await supabase
      .from('vehicles')
      .update({
        image: newMainImage,
        images: realImages,
        updated_at: new Date().toISOString(),
      })
      .eq('id', vehicle.id);

    if (updateError) {
      console.error(`Failed to clear stock photos for vehicle ${vehicle.id}:`, updateError);
    } else {
      clearedCount++;
    }
  }

  return { cleared: clearedCount };
}


// Derive filter options from vehicles array
export function getBodyTypes(vehicles: Vehicle[]): string[] {
  const types = Array.from(new Set(vehicles.map(v => v.bodyType))).sort();
  return ['All', ...types];
}

export function getMakes(vehicles: Vehicle[]): string[] {
  const makesList = Array.from(new Set(vehicles.map(v => v.make))).sort();
  return ['All', ...makesList];
}

export const priceRanges = [
  { label: 'All Prices', min: 0, max: Infinity },
  { label: 'Under $8,000', min: 0, max: 8000 },
  { label: '$8,000 - $12,000', min: 8000, max: 12000 },
  { label: '$12,000 - $18,000', min: 12000, max: 18000 },
  { label: 'Over $18,000', min: 18000, max: Infinity },
];

// Keep a static fallback for body types used in filters
export const bodyTypes = ['All', 'Sedan', 'SUV', 'Coupe', 'Minivan'];
