import { useEffect, useRef } from 'react';
import { useLocation } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { DEFAULT_ANALYTICS, HOMEPAGE_SECTIONS } from '@/data/homepageDefaults';
import type { AnalyticsConfig } from '@/data/homepageDefaults';

// ─── Module-level cache ───
let cachedConfig: AnalyticsConfig | null = null;
let configPromise: Promise<AnalyticsConfig> | null = null;

const COOKIE_STORAGE_KEY = 'exsell-cookie-consent';

// ─── Helpers ───

function getCookieAnalyticsConsent(): boolean {
  try {
    const stored = localStorage.getItem(COOKIE_STORAGE_KEY);
    if (!stored) return false;
    const parsed = JSON.parse(stored);
    return parsed?.preferences?.analytics === true;
  } catch {
    return false;
  }
}

async function fetchAnalyticsConfig(): Promise<AnalyticsConfig> {
  try {
    const { data, error } = await supabase
      .from('site_content')
      .select('content')
      .eq('section', HOMEPAGE_SECTIONS.analytics)
      .single();
    if (error || !data) return DEFAULT_ANALYTICS;
    return data.content as AnalyticsConfig;
  } catch {
    return DEFAULT_ANALYTICS;
  }
}

function getOrFetchConfig(): Promise<AnalyticsConfig> {
  if (cachedConfig) return Promise.resolve(cachedConfig);
  if (!configPromise) {
    configPromise = fetchAnalyticsConfig().then((result) => {
      cachedConfig = result;
      return result;
    });
  }
  return configPromise;
}

/** Call from admin panel after saving to force re-fetch */
export function invalidateAnalyticsCache() {
  cachedConfig = null;
  configPromise = null;
}

// ─── Script injection helpers ───

function injectGA4(measurementId: string) {
  // Prevent duplicate injection
  if (document.getElementById('ga4-gtag-script')) return;

  // gtag.js loader
  const script = document.createElement('script');
  script.id = 'ga4-gtag-script';
  script.async = true;
  script.src = `https://www.googletagmanager.com/gtag/js?id=${measurementId}`;
  document.head.appendChild(script);

  // gtag inline config
  const inline = document.createElement('script');
  inline.id = 'ga4-gtag-inline';
  inline.textContent = `
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', '${measurementId}', { send_page_view: false });
  `;
  document.head.appendChild(inline);
}

function injectGTM(containerId: string) {
  // Prevent duplicate injection
  if (document.getElementById('gtm-script')) return;

  // GTM head script
  const script = document.createElement('script');
  script.id = 'gtm-script';
  script.textContent = `
    (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
    new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
    j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
    'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
    })(window,document,'script','dataLayer','${containerId}');
  `;
  document.head.appendChild(script);

  // GTM noscript iframe (appended to body)
  if (!document.getElementById('gtm-noscript')) {
    const noscript = document.createElement('noscript');
    noscript.id = 'gtm-noscript';
    const iframe = document.createElement('iframe');
    iframe.src = `https://www.googletagmanager.com/ns.html?id=${containerId}`;
    iframe.height = '0';
    iframe.width = '0';
    iframe.style.display = 'none';
    iframe.style.visibility = 'hidden';
    noscript.appendChild(iframe);
    document.body.insertBefore(noscript, document.body.firstChild);
  }
}

function removeGA4() {
  document.getElementById('ga4-gtag-script')?.remove();
  document.getElementById('ga4-gtag-inline')?.remove();
}

function removeGTM() {
  document.getElementById('gtm-script')?.remove();
  document.getElementById('gtm-noscript')?.remove();
}

function sendGA4PageView(measurementId: string, path: string) {
  try {
    if (typeof (window as any).gtag === 'function') {
      (window as any).gtag('config', measurementId, {
        page_path: path,
      });
    }
  } catch {
    // silently fail
  }
}

function sendGTMPageView(path: string) {
  try {
    (window as any).dataLayer = (window as any).dataLayer || [];
    (window as any).dataLayer.push({
      event: 'page_view',
      page_path: path,
    });
  } catch {
    // silently fail
  }
}

// ─── Conversion / event tracking ───

/**
 * Logs a custom conversion event to both GA4 (gtag) and GTM (dataLayer).
 * Safe to call even if analytics scripts haven't been injected — it fails
 * silently. Use for CTA taps like 'call_click' / 'text_click'.
 *
 * @param eventName  e.g. 'call_click', 'text_click', 'callback_request'
 * @param params     extra params such as { source: 'mobile_bar' }
 */
export function trackConversion(
  eventName: string,
  params: Record<string, string | number | boolean> = {}
) {
  try {
    if (typeof (window as any).gtag === 'function') {
      (window as any).gtag('event', eventName, params);
    }
  } catch {
    // silently fail
  }
  try {
    (window as any).dataLayer = (window as any).dataLayer || [];
    (window as any).dataLayer.push({ event: eventName, ...params });
  } catch {
    // silently fail
  }
}

// ─── Main Hook ───

/**
 * Fetches analytics configuration from the database, respects cookie consent,
 * and dynamically injects GA4 / GTM tracking scripts into the document head.
 * Also sends virtual page views on route changes for SPA navigation.
 *
 * Call this once at the app root level (e.g. inside a component rendered in App.tsx).
 */
export function useAnalytics() {
  const location = useLocation();
  const configRef = useRef<AnalyticsConfig>(DEFAULT_ANALYTICS);
  const injectedRef = useRef(false);

  // Initial config fetch + script injection
  useEffect(() => {
    let cancelled = false;

    getOrFetchConfig().then((config) => {
      if (cancelled) return;
      configRef.current = config;

      if (!config.enabled) {
        // If disabled, clean up any previously injected scripts
        removeGA4();
        removeGTM();
        injectedRef.current = false;
        return;
      }

      // Check cookie consent if required
      if (config.respectCookieConsent && !getCookieAnalyticsConsent()) {
        // User hasn't consented to analytics cookies — don't inject
        removeGA4();
        removeGTM();
        injectedRef.current = false;
        return;
      }

      // Inject scripts
      if (config.ga4MeasurementId && /^G-[A-Z0-9]+$/i.test(config.ga4MeasurementId)) {
        injectGA4(config.ga4MeasurementId);
      }
      if (config.gtmContainerId && /^GTM-[A-Z0-9]+$/i.test(config.gtmContainerId)) {
        injectGTM(config.gtmContainerId);
      }
      injectedRef.current = true;
    });

    return () => {
      cancelled = true;
    };
  }, []);

  // Listen for cookie consent changes (user accepts/rejects after page load)
  useEffect(() => {
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key !== COOKIE_STORAGE_KEY) return;
      const config = configRef.current;
      if (!config.enabled || !config.respectCookieConsent) return;

      if (getCookieAnalyticsConsent()) {
        // User just consented — inject scripts
        if (config.ga4MeasurementId && /^G-[A-Z0-9]+$/i.test(config.ga4MeasurementId)) {
          injectGA4(config.ga4MeasurementId);
        }
        if (config.gtmContainerId && /^GTM-[A-Z0-9]+$/i.test(config.gtmContainerId)) {
          injectGTM(config.gtmContainerId);
        }
        injectedRef.current = true;
      } else {
        // User revoked consent — remove scripts
        removeGA4();
        removeGTM();
        injectedRef.current = false;
      }
    };

    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  // Send virtual page views on route change
  useEffect(() => {
    if (!injectedRef.current) return;
    const config = configRef.current;
    if (!config.enabled) return;

    const path = location.pathname + location.search;

    if (config.ga4MeasurementId) {
      sendGA4PageView(config.ga4MeasurementId, path);
    }
    if (config.gtmContainerId) {
      sendGTMPageView(path);
    }
  }, [location]);
}
