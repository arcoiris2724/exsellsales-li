import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { isPlaceholderPlaceId } from '@/lib/googlePlace';
import { usePlaceConfig } from './usePlaceConfig';

export interface LiveGoogleReview {
  rating: number | null;
  text: string;
  authorName: string;
  authorPhotoUri: string | null;
  authorUri: string | null;
  publishTime: string | null;
  relativeTime: string | null;
}

export interface LiveGoogleReviewsData {
  cached?: boolean;
  stale?: boolean;
  rating: number | null;
  userRatingCount: number | null;
  reviews: LiveGoogleReview[];
  fetchedAt?: string;
  warning?: string;
  error?: string;
}

interface UseGoogleReviewsOptions {
  /** Override the resolved Place ID (defaults to the live value from `usePlaceConfig`). */
  placeId?: string;
  /** If true, the query is disabled (e.g. caller knows the Place ID is a placeholder). */
  enabled?: boolean;
  /** Force a fresh fetch (bypasses the 24h server cache). */
  forceRefresh?: boolean;
}

/**
 * Fetches the cached Google reviews via the `google-reviews-fetch` edge function
 * and memoizes the result in React Query so the Places API isn't re-hit on every
 * render or route change.
 *
 * The Place ID is read live from `site_content` via `usePlaceConfig` so an
 * admin can update it from the CMS without a redeploy. Pass a `placeId` option
 * only when you need to override the live value (rare).
 *
 * The edge function caches responses server-side for 24h; we mirror that on
 * the client with a 24h staleTime and 7-day gcTime to keep the homepage badge
 * snappy across navigations.
 */
export function useGoogleReviews(options: UseGoogleReviewsOptions = {}) {
  const placeConfig = usePlaceConfig();
  const placeId = options.placeId ?? placeConfig.placeId;
  const placeholder = isPlaceholderPlaceId(placeId);
  const enabled = (options.enabled ?? true) && !placeholder && !placeConfig.loading;

  const query = useQuery<LiveGoogleReviewsData>({
    queryKey: ['google-reviews', placeId, options.forceRefresh ?? false],
    enabled,
    staleTime: 1000 * 60 * 60 * 24, // 24 hours
    gcTime: 1000 * 60 * 60 * 24 * 7, // 7 days
    refetchOnWindowFocus: false,
    retry: 1,
    queryFn: async () => {
      const { data, error } = await supabase.functions.invoke('google-reviews-fetch', {
        body: { placeId, forceRefresh: options.forceRefresh ?? false },
      });
      if (error) throw new Error(error.message || 'Failed to load Google reviews');
      if (data?.error) throw new Error(data.error);
      return data as LiveGoogleReviewsData;
    },
  });

  return {
    ...query,
    /** True when we intentionally skipped the fetch because no real Place ID is set. */
    placeholder,
    /** The Place ID actually being queried (live or override). */
    placeId,
    /** Convenience accessors (null-safe). */
    rating: query.data?.rating ?? null,
    userRatingCount: query.data?.userRatingCount ?? null,
    reviews: query.data?.reviews ?? [],
  };
}
