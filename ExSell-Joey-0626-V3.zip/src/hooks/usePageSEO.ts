import { useEffect, useState, useMemo } from 'react';
import { supabase } from '@/lib/supabase';
import { DEFAULT_SEO, HOMEPAGE_SECTIONS } from '@/data/homepageDefaults';
import type { SEOContent, SEOPageKey, SEOPageMeta } from '@/data/homepageDefaults';

// Cache the SEO data so we don't re-fetch on every page navigation
let cachedSEO: SEOContent | null = null;
let fetchPromise: Promise<SEOContent | null> | null = null;

async function fetchSEOData(): Promise<SEOContent | null> {
  try {
    const { data, error } = await supabase
      .from('site_content')
      .select('content')
      .eq('section', HOMEPAGE_SECTIONS.seo)
      .single();

    if (error || !data) return null;
    return data.content as SEOContent;
  } catch {
    return null;
  }
}

function getOrFetchSEO(): Promise<SEOContent | null> {
  if (cachedSEO) return Promise.resolve(cachedSEO);
  if (!fetchPromise) {
    fetchPromise = fetchSEOData().then((result) => {
      cachedSEO = result;
      return result;
    });
  }
  return fetchPromise;
}

// Allow cache invalidation (called after admin saves)
export function invalidateSEOCache() {
  cachedSEO = null;
  fetchPromise = null;
}

/**
 * Upsert a <meta> tag. Handles both `name="..."` (Twitter Card, description)
 * and `property="..."` (Open Graph) attribute styles.
 */
function setMetaTag(key: string, content: string, isProperty = false) {
  if (!content) return;
  const attr = isProperty ? 'property' : 'name';
  let el = document.querySelector(`meta[${attr}="${key}"]`) as HTMLMetaElement | null;
  if (!el) {
    el = document.createElement('meta');
    el.setAttribute(attr, key);
    document.head.appendChild(el);
  }
  el.setAttribute('content', content);
}

/**
 * Remove a <meta> tag if it exists. Used when switching between page types
 * (e.g. product VDP → generic homepage) so stale OG tags don't linger.
 */
function removeMetaTag(key: string, isProperty = false) {
  const attr = isProperty ? 'property' : 'name';
  const el = document.querySelector(`meta[${attr}="${key}"]`);
  if (el) el.parentElement?.removeChild(el);
}

/**
 * Inject (or update) a <link rel="canonical"> tag pointing at the current page.
 * We prefer the production origin when the hostname matches a known production
 * host so previews / localhost don't leak into canonical URLs.
 */
function setCanonicalLink(pathname: string, canonicalOverride?: string): string {
  if (typeof window === 'undefined') return '';

  let href = canonicalOverride;
  if (!href) {
    const host = window.location.hostname;
    const isPreview =
      host === 'localhost' ||
      host.startsWith('127.') ||
      host.endsWith('.local') ||
      host.includes('lovableproject') ||
      host.includes('databasepad') ||
      host.includes('famous.ai') ||
      host.includes('vercel.app') ||
      host.includes('netlify.app');
    const origin = isPreview ? 'https://exsellsalesli.com' : window.location.origin;
    href = new URL(pathname || '/', origin).href;
  }

  let link = document.querySelector('link[rel="canonical"]') as HTMLLinkElement | null;
  if (!link) {
    link = document.createElement('link');
    link.setAttribute('rel', 'canonical');
    document.head.appendChild(link);
  }
  link.setAttribute('href', href);
  return href;
}

/**
 * Optional per-call overrides for usePageSEO. Any field left undefined falls
 * back to the CMS value (or DEFAULT_SEO). Used by VehicleDetail.tsx to inject
 * per-vehicle OG/Twitter meta so social shares surface rich previews.
 */
export interface SEOOverrides {
  title?: string;
  metaDescription?: string;
  ogTitle?: string;
  ogDescription?: string;
  ogImage?: string;
  /** Defaults to `"website"`; VDPs pass `"product"`. */
  ogType?: string;
  /** Explicit canonical override (bypasses path-based derivation). */
  canonicalUrl?: string;
  /** Explicit og:url / twitter:url override. */
  url?: string;
  /** Twitter Card type. Defaults to `"summary_large_image"` when an og:image exists, else `"summary"`. */
  twitterCard?: 'summary' | 'summary_large_image' | 'app' | 'player';
  /** Site-wide Twitter @handle (optional). */
  twitterSite?: string;
}

/**
 * Custom hook that fetches SEO meta data from the database and injects it
 * into the document head (title, description, Open Graph, Twitter Card, and
 * a canonical <link>). Falls back to DEFAULT_SEO values.
 *
 * Overrides (2nd arg) let individual pages (e.g. Vehicle Detail Pages) override
 * individual fields with page-specific values — which is how we surface
 * per-vehicle hero images and titles in social shares without changing the
 * CMS-managed homepage SEO.
 *
 * Usage:
 *   usePageSEO('homepage')
 *   usePageSEO('homepage', { title: vdpTitle, ogImage: vehicle.image, ogType: 'product' })
 */
export function usePageSEO(pageKey: SEOPageKey, overrides?: SEOOverrides) {
  const [meta, setMeta] = useState<SEOPageMeta>(DEFAULT_SEO[pageKey]);

  // Stabilise override identity so the effect doesn't re-run every render
  // when the caller passes an inline object literal.
  const stableOverrides = useMemo(
    () => overrides,
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [
      overrides?.title,
      overrides?.metaDescription,
      overrides?.ogTitle,
      overrides?.ogDescription,
      overrides?.ogImage,
      overrides?.ogType,
      overrides?.canonicalUrl,
      overrides?.url,
      overrides?.twitterCard,
      overrides?.twitterSite,
    ]
  );

  useEffect(() => {
    let cancelled = false;

    getOrFetchSEO().then((seoData) => {
      if (cancelled) return;
      const baseMeta = seoData?.[pageKey] || DEFAULT_SEO[pageKey];

      // Merge: overrides win, then CMS, then defaults
      const merged: SEOPageMeta = {
        title: stableOverrides?.title || baseMeta.title,
        metaDescription: stableOverrides?.metaDescription || baseMeta.metaDescription,
        ogTitle: stableOverrides?.ogTitle || baseMeta.ogTitle || stableOverrides?.title || baseMeta.title,
        ogDescription:
          stableOverrides?.ogDescription ||
          baseMeta.ogDescription ||
          stableOverrides?.metaDescription ||
          baseMeta.metaDescription,
        ogImage: stableOverrides?.ogImage || baseMeta.ogImage || '',
      };
      setMeta(merged);

      // ─── <title> + description ───
      if (merged.title) document.title = merged.title;
      if (merged.metaDescription) setMetaTag('description', merged.metaDescription);

      // ─── Open Graph ───
      // og:site_name stays constant across the site.
      setMetaTag('og:site_name', 'Ex$ell Car Sales LI', true);
      if (merged.ogTitle) setMetaTag('og:title', merged.ogTitle, true);
      if (merged.ogDescription) setMetaTag('og:description', merged.ogDescription, true);

      const ogType = stableOverrides?.ogType || 'website';
      setMetaTag('og:type', ogType, true);

      // og:url — prefer explicit override, else canonical href
      const canonicalOverride =
        stableOverrides?.canonicalUrl ||
        (baseMeta as unknown as { canonicalUrl?: string }).canonicalUrl;
      const canonicalHref = setCanonicalLink(window.location.pathname, canonicalOverride);
      const ogUrl = stableOverrides?.url || canonicalHref || window.location.href;
      setMetaTag('og:url', ogUrl, true);

      // og:image (+ helpful optional dimensions fallback)
      if (merged.ogImage) {
        setMetaTag('og:image', merged.ogImage, true);
        setMetaTag('og:image:alt', merged.ogTitle || merged.title || 'Ex$ell Car Sales LI', true);
      } else {
        removeMetaTag('og:image', true);
        removeMetaTag('og:image:alt', true);
      }

      // ─── Twitter Card ───
      // Use summary_large_image whenever we have an og:image so shares render
      // the hero photo; fall back to plain "summary" for imageless pages.
      const twitterCard =
        stableOverrides?.twitterCard || (merged.ogImage ? 'summary_large_image' : 'summary');
      setMetaTag('twitter:card', twitterCard);
      if (merged.ogTitle) setMetaTag('twitter:title', merged.ogTitle);
      if (merged.ogDescription) setMetaTag('twitter:description', merged.ogDescription);
      if (merged.ogImage) {
        setMetaTag('twitter:image', merged.ogImage);
        setMetaTag('twitter:image:alt', merged.ogTitle || merged.title || 'Ex$ell Car Sales LI');
      } else {
        removeMetaTag('twitter:image');
        removeMetaTag('twitter:image:alt');
      }
      setMetaTag('twitter:url', ogUrl);
      if (stableOverrides?.twitterSite) {
        setMetaTag('twitter:site', stableOverrides.twitterSite);
      }
    });

    return () => {
      cancelled = true;
    };
  }, [pageKey, stableOverrides]);

  return meta;
}
