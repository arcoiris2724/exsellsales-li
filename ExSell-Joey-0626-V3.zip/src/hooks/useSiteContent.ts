import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';

export interface SiteContentMap {
  [section: string]: any;
}

/**
 * Hook to fetch all site_content rows and return them as a map.
 * Falls back to empty object if DB is unreachable.
 */
export function useSiteContent() {
  const [content, setContent] = useState<SiteContentMap>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchContent = useCallback(async () => {
    try {
      setLoading(true);
      const { data, error: fetchError } = await supabase
        .from('site_content')
        .select('section, content, updated_at');

      if (fetchError) {
        console.warn('Failed to fetch site content:', fetchError.message);
        setError(fetchError.message);
        return;
      }

      const map: SiteContentMap = {};
      if (data) {
        for (const row of data) {
          map[row.section] = row.content;
        }
      }
      setContent(map);
      setError(null);
    } catch (err: any) {
      console.warn('Site content fetch error:', err);
      setError(err.message || 'Unknown error');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchContent();
  }, [fetchContent]);

  return { content, loading, error, refetch: fetchContent };
}

/**
 * Save (upsert) a section's content into the database.
 *
 * NOTE: We intentionally do NOT rely on Postgres `ON CONFLICT` here because the
 * `site_content.section` column may not have a UNIQUE constraint in every
 * environment — which triggers the error:
 *   "there is no unique or exclusion constraint matching the ON CONFLICT specification"
 *
 * Instead we do a safe two-step: check if the row exists → UPDATE, else INSERT.
 * This works regardless of whether the unique constraint was ever migrated in.
 */
export async function saveSiteContent(section: string, content: any): Promise<{ success: boolean; error?: string }> {
  try {
    const nowIso = new Date().toISOString();

    // 1. Does a row for this section already exist?
    const { data: existing, error: selectError } = await supabase
      .from('site_content')
      .select('id')
      .eq('section', section)
      .limit(1)
      .maybeSingle();

    if (selectError) {
      return { success: false, error: selectError.message };
    }

    if (existing?.id) {
      // 2a. Row exists — UPDATE it by primary key (no ON CONFLICT needed).
      const { error: updateError } = await supabase
        .from('site_content')
        .update({ content, updated_at: nowIso })
        .eq('id', existing.id);

      if (updateError) {
        return { success: false, error: updateError.message };
      }
      return { success: true };
    }

    // 2b. No row — INSERT a fresh one.
    const { error: insertError } = await supabase
      .from('site_content')
      .insert({ section, content, updated_at: nowIso });

    if (insertError) {
      // Race-condition fallback: another client may have inserted in between.
      // Retry as update.
      const { data: retryRow } = await supabase
        .from('site_content')
        .select('id')
        .eq('section', section)
        .limit(1)
        .maybeSingle();

      if (retryRow?.id) {
        const { error: retryUpdateError } = await supabase
          .from('site_content')
          .update({ content, updated_at: nowIso })
          .eq('id', retryRow.id);
        if (retryUpdateError) {
          return { success: false, error: retryUpdateError.message };
        }
        return { success: true };
      }

      return { success: false, error: insertError.message };
    }

    return { success: true };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Unknown error' };
  }
}

/**
 * Fetch a single section's content.
 */
export async function fetchSectionContent(section: string): Promise<any | null> {
  try {
    const { data, error } = await supabase
      .from('site_content')
      .select('content')
      .eq('section', section)
      .limit(1)
      .maybeSingle();

    if (error || !data) return null;
    return data.content;
  } catch {
    return null;
  }
}
