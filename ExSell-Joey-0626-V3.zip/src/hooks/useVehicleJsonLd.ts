import { useEffect } from 'react';
import type { Vehicle } from '@/data/vehicles';
import { GOOGLE_BUSINESS_URL, FACEBOOK_PAGE_URL } from '@/lib/googlePlace';

/**
 * Injects schema.org Vehicle / Car / Product structured data into <head> for a
 * single vehicle detail page so Google can surface the listing as a rich
 * vehicle result (price, mileage, fuel type, seller, etc.).
 *
 * Spec references:
 *  - https://schema.org/Vehicle
 *  - https://schema.org/Car
 *  - https://developers.google.com/search/docs/appearance/structured-data/vehicle-listing
 *
 * Only emits markup when we have a complete, usable vehicle record.
 */

const SCRIPT_ID = 'exsell-vehicle-jsonld';

function absoluteUrl(path: string): string {
  if (typeof window === 'undefined') return path;
  try {
    return new URL(path, window.location.origin).href;
  } catch {
    return path;
  }
}

interface UseVehicleJsonLdOptions {
  /** Optional dealer/seller name override — defaults to ExSell Sales LLC. */
  sellerName?: string;
  /** Optional dealer phone for the Offer.seller (E.164 or display format). */
  sellerPhone?: string;
  /** Optional dealer street address (single-line). */
  sellerStreet?: string;
  /** Optional dealer city. */
  sellerCity?: string;
  /** Optional dealer region (state). */
  sellerRegion?: string;
  /** Optional dealer postal code. */
  sellerPostalCode?: string;
}


/**
 * Normalize common fuel-type strings to schema.org approved values where possible.
 * Falls through to the raw string for anything else.
 */
function normalizeFuelType(fuel: string): string {
  if (!fuel) return 'Gasoline';
  const f = fuel.toLowerCase();
  if (f.includes('electric')) return 'Electric';
  if (f.includes('hybrid') && f.includes('plug')) return 'Plug-in Hybrid';
  if (f.includes('hybrid')) return 'Hybrid';
  if (f.includes('diesel')) return 'Diesel';
  if (f.includes('flex')) return 'Flex Fuel';
  if (f.includes('gas')) return 'Gasoline';
  return fuel;
}

/**
 * Map our free-form transmission to schema.org vehicleTransmission values
 * (Automatic | Manual | SemiAutomatic).
 */
function normalizeTransmission(t: string): string {
  if (!t) return 'Automatic';
  const lower = t.toLowerCase();
  if (lower.includes('manual')) return 'Manual';
  if (lower.includes('cvt')) return 'Automatic';
  if (lower.includes('dct') || lower.includes('dual')) return 'SemiAutomatic';
  return 'Automatic';
}
export function useVehicleJsonLd(
  vehicle: Vehicle | null | undefined,
  options: UseVehicleJsonLdOptions = {}
) {
  useEffect(() => {
    const existing = document.getElementById(SCRIPT_ID);

    // Guard: remove stale markup if there's no vehicle to describe yet.
    if (!vehicle || !vehicle.id) {
      if (existing) existing.remove();
      return;
    }

    const sellerName = options.sellerName || 'ExSell Sales LLC';
    const sellerPhone = options.sellerPhone || '+1-631-388-4426';
    const sellerStreet = options.sellerStreet || '442 Tate St Suite A';
    const sellerCity = options.sellerCity || 'Holbrook';
    const sellerRegion = options.sellerRegion || 'NY';
    const sellerPostalCode = options.sellerPostalCode || '11741';


    const pageUrl = absoluteUrl(`/inventory/${vehicle.id}`);

    // Ensure a <link rel="canonical"> tag exists on this detail page pointing at
    // the canonical vehicle URL (so /inventory/123?utm=foo → /inventory/123).
    let canonical = document.querySelector('link[rel="canonical"]') as HTMLLinkElement | null;
    if (!canonical) {
      canonical = document.createElement('link');
      canonical.setAttribute('rel', 'canonical');
      document.head.appendChild(canonical);
    }
    canonical.setAttribute('href', pageUrl);

    const name = `${vehicle.year} ${vehicle.make} ${vehicle.model}${
      vehicle.trim ? ' ' + vehicle.trim : ''
    }`.trim();


    // Primary image — prefer the hero image, fall back to first gallery image
    const primaryImage =
      vehicle.image ||
      (vehicle.images && vehicle.images.length > 0 ? vehicle.images[0] : '');
    const images = [
      ...(primaryImage ? [primaryImage] : []),
      ...(vehicle.images || []).filter((i) => i && i !== primaryImage),
    ].map((src) => absoluteUrl(src));

    // Schema.org availability enum
    let availability = 'https://schema.org/InStock';
    if (vehicle.status === 'sold') availability = 'https://schema.org/SoldOut';
    else if (vehicle.status === 'pending') availability = 'https://schema.org/LimitedAvailability';

    const description =
      vehicle.description ||
      `${name} with ${vehicle.mileage?.toLocaleString() ?? '—'} miles, ${
        vehicle.exteriorColor || ''
      } exterior, available at ${sellerName}.`.trim();

    // Core Vehicle / Car entity. We use @type: ["Car","Product"] so the
    // same markup satisfies both vehicle-listing and product rich-results.
    const jsonLd: Record<string, unknown> = {
      '@context': 'https://schema.org/',
      '@type': ['Car', 'Product'],
      '@id': `${pageUrl}#vehicle`,
      name,
      url: pageUrl,
      description,
      ...(images.length > 0 ? { image: images } : {}),
      brand: {
        '@type': 'Brand',
        name: vehicle.make,
      },
      manufacturer: {
        '@type': 'Organization',
        name: vehicle.make,
      },
      model: vehicle.model,
      ...(vehicle.trim ? { vehicleConfiguration: vehicle.trim } : {}),
      modelDate: String(vehicle.year),
      productionDate: String(vehicle.year),
      vehicleModelDate: String(vehicle.year),
      ...(vehicle.vin ? { vehicleIdentificationNumber: vehicle.vin, sku: vehicle.vin } : { sku: String(vehicle.id) }),
      mileageFromOdometer: {
        '@type': 'QuantitativeValue',
        value: vehicle.mileage ?? 0,
        unitCode: 'SMI', // Statute miles
      },
      fuelType: normalizeFuelType(vehicle.fuelType),
      vehicleTransmission: normalizeTransmission(vehicle.transmission),
      ...(vehicle.drivetrain ? { driveWheelConfiguration: vehicle.drivetrain } : {}),
      ...(vehicle.engine
        ? {
            vehicleEngine: {
              '@type': 'EngineSpecification',
              name: vehicle.engine,
            },
          }
        : {}),
      bodyType: vehicle.bodyType,
      ...(vehicle.exteriorColor ? { color: vehicle.exteriorColor } : {}),
      ...(vehicle.interiorColor
        ? { vehicleInteriorColor: vehicle.interiorColor }
        : {}),
      itemCondition: 'https://schema.org/UsedCondition',
    };

    // Offer — only emit a price if it's a real value; Google rejects price:0
    const price = vehicle.status === 'sold' && vehicle.soldPrice ? vehicle.soldPrice : vehicle.price;
    if (price && price > 0) {
      jsonLd.offers = {
        '@type': 'Offer',
        url: pageUrl,
        priceCurrency: 'USD',
        price,
        availability,
        itemCondition: 'https://schema.org/UsedCondition',
        priceValidUntil: new Date(new Date().getFullYear() + 1, 11, 31)
          .toISOString()
          .slice(0, 10),
        seller: {
          '@type': 'AutoDealer',
          name: sellerName,
          telephone: sellerPhone,
          url: absoluteUrl('/'),
          address: {
            '@type': 'PostalAddress',
            streetAddress: sellerStreet,
            addressLocality: sellerCity,
            addressRegion: sellerRegion,
            postalCode: sellerPostalCode,
            addressCountry: 'US',
          },
          sameAs: [GOOGLE_BUSINESS_URL, FACEBOOK_PAGE_URL],
        },
      };

    } else {
      // Still attach the seller so Google knows who's offering it, just without price
      jsonLd.offers = {
        '@type': 'Offer',
        url: pageUrl,
        availability,
        priceSpecification: {
          '@type': 'PriceSpecification',
          priceCurrency: 'USD',
          price: 0,
          valueAddedTaxIncluded: false,
        },
        seller: {
          '@type': 'AutoDealer',
          name: sellerName,
          telephone: sellerPhone,
        },
      };
    }

    let script = existing as HTMLScriptElement | null;
    if (!script) {
      script = document.createElement('script');
      script.type = 'application/ld+json';
      script.id = SCRIPT_ID;
      document.head.appendChild(script);
    }
    script.textContent = JSON.stringify(jsonLd);

    return () => {
      // Clean up when leaving the detail page so markup doesn't persist onto other routes.
      const el = document.getElementById(SCRIPT_ID);
      if (el) el.remove();
    };
  }, [
    vehicle,
    options.sellerName,
    options.sellerPhone,
    options.sellerStreet,
    options.sellerCity,
    options.sellerRegion,
    options.sellerPostalCode,
  ]);

}
