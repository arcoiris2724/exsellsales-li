import { useEffect } from 'react';
import { useGoogleReviews } from './useGoogleReviews';
import { useSiteContent } from './useSiteContent';
import { GOOGLE_BUSINESS_URL, FACEBOOK_PAGE_URL } from '@/lib/googlePlace';

/**
 * Injects (or updates) a JSON-LD `<script>` tag in the document head describing
 * the business as an AutoDealer with schema.org AggregateRating + the top 5
 * most recent Review entities, all sourced from the live Google Places data
 * (via the `google-reviews-fetch` edge function, cached through `useGoogleReviews`).
 *
 * Goal: enable Google rich-results star ratings on /reviews and the homepage.
 *
 * Only emits structured data when we have a real rating (>0) and at least one
 * review — Google will reject aggregate markup without a usable rating count.
 */

const SCRIPT_ID = 'exsell-reviews-jsonld';

function absoluteUrl(path: string): string {
  if (typeof window === 'undefined') return path;
  try {
    return new URL(path, window.location.origin).href;
  } catch {
    return path;
  }
}

interface UseReviewsJsonLdOptions {
  /** Which page this markup is for — affects the `@id` / `url` of the main entity. */
  pagePath?: string;
  /** Optional override for the business display name. */
  businessName?: string;
}

export function useReviewsJsonLd(options: UseReviewsJsonLdOptions = {}) {
  const { rating, userRatingCount, reviews, placeholder } = useGoogleReviews();
  const { content } = useSiteContent();

  useEffect(() => {
    // Remove any stale script on every render cycle — we'll re-add below if valid.
    const existing = document.getElementById(SCRIPT_ID);

    // Guard: nothing to render if we don't have live data yet (or placeholder Place ID)
    if (
      placeholder ||
      !rating ||
      rating <= 0 ||
      !userRatingCount ||
      userRatingCount <= 0
    ) {
      if (existing) existing.remove();
      return;
    }

    const contact = content?.contact || {};
    const businessName =
      options.businessName ||
      contact.businessName ||
      'Ex$ell Car Sales LI';
    const phone = contact.phone || undefined;
    const address = contact.address || 'Long Island, NY';
    const email = contact.email || undefined;

    const pagePath = options.pagePath || (typeof window !== 'undefined' ? window.location.pathname : '/');
    const pageUrl = absoluteUrl(pagePath);

    // Format AggregateRating (Google requires bestRating + ratingCount/reviewCount)
    const aggregateRating = {
      '@type': 'AggregateRating',
      ratingValue: Number(rating.toFixed(1)),
      bestRating: 5,
      worstRating: 1,
      ratingCount: userRatingCount,
      reviewCount: userRatingCount,
    };

    // Top 5 most recent reviews (already sorted server-side, but sort defensively)
    const topReviews = [...(reviews || [])]
      .filter((r) => r && (r.text || r.authorName))
      .sort((a, b) => {
        const ta = a.publishTime ? new Date(a.publishTime).getTime() : 0;
        const tb = b.publishTime ? new Date(b.publishTime).getTime() : 0;
        return tb - ta;
      })
      .slice(0, 5)
      .map((r) => {
        const review: Record<string, unknown> = {
          '@type': 'Review',
          author: {
            '@type': 'Person',
            name: r.authorName || 'Verified Google Customer',
          },
          reviewRating: {
            '@type': 'Rating',
            ratingValue: r.rating ?? 5,
            bestRating: 5,
            worstRating: 1,
          },
          publisher: {
            '@type': 'Organization',
            name: 'Google',
          },
        };
        if (r.text) review.reviewBody = r.text;
        if (r.publishTime) review.datePublished = r.publishTime.slice(0, 10);
        return review;
      });

    const jsonLd: Record<string, unknown> = {
      '@context': 'https://schema.org',
      '@type': 'AutoDealer',
      '@id': `${pageUrl}#business`,
      name: businessName,
      url: pageUrl,
      image: absoluteUrl('/placeholder.svg'),
      address: {
        '@type': 'PostalAddress',
        streetAddress: address,
        addressRegion: 'NY',
        addressCountry: 'US',
      },
      sameAs: [GOOGLE_BUSINESS_URL, FACEBOOK_PAGE_URL],
      aggregateRating,
    };

    if (phone) jsonLd.telephone = phone;
    if (email) jsonLd.email = email;
    if (topReviews.length > 0) jsonLd.review = topReviews;

    // Inject (or update) the script tag
    let script = existing as HTMLScriptElement | null;
    if (!script) {
      script = document.createElement('script');
      script.type = 'application/ld+json';
      script.id = SCRIPT_ID;
      document.head.appendChild(script);
    }
    script.textContent = JSON.stringify(jsonLd);

    return () => {
      // Cleanup when the page unmounts so stale markup doesn't linger on other routes
      const el = document.getElementById(SCRIPT_ID);
      if (el) el.remove();
    };
  }, [
    rating,
    userRatingCount,
    reviews,
    placeholder,
    content,
    options.businessName,
    options.pagePath,
  ]);
}
