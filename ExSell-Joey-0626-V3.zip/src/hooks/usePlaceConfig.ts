import { useMemo } from 'react';
import { useSiteContent } from './useSiteContent';
import {
  GOOGLE_PLACE_ID as DEFAULT_PLACE_ID,
  GOOGLE_PLACE_SECTION,
  GOOGLE_MAPS_EMBED_FALLBACK,
  buildMapsEmbedUrl,
  buildWriteReviewUrl,
  isPlaceholderPlaceId,
  normalizePlaceId,
  type GooglePlaceConfig,
} from '@/lib/googlePlace';

export interface ResolvedPlaceConfig {
  /** Live Place ID from the database, or the hard-coded placeholder fallback. */
  placeId: string;
  /** True when no real Place ID has been configured yet (still the placeholder). */
  isPlaceholder: boolean;
  /** True while the site_content row is still loading from Supabase. */
  loading: boolean;
  /** "Write a review" URL pre-built for the resolved Place ID. */
  writeReviewUrl: string;
  /** Maps embed URL pre-built for the resolved Place ID, or a query fallback. */
  mapsEmbedUrl: string;
  /** True if this hook is using the query-based fallback embed (placeholder mode). */
  usingFallbackEmbed: boolean;
}

/**
 * Resolves the live Google Place ID from the `site_content` table (section
 * `google_place`) with a graceful fallback to the hard-coded placeholder in
 * `src/lib/googlePlace.ts`. Returned URLs are pre-built so callers can use
 * them directly.
 *
 * An admin updates the value via the CMS; every component that consumes this
 * hook (badge, /reviews page, JSON-LD, GoogleReviewsLive) will re-render with
 * the live ID — no redeploy needed.
 */
export function usePlaceConfig(): ResolvedPlaceConfig {
  const { content, loading } = useSiteContent();

  return useMemo(() => {
    const stored = content?.[GOOGLE_PLACE_SECTION] as GooglePlaceConfig | undefined;
    const rawId = normalizePlaceId(stored?.placeId);
    const placeId = rawId || DEFAULT_PLACE_ID;
    const placeholder = isPlaceholderPlaceId(placeId);

    return {
      placeId,
      isPlaceholder: placeholder,
      loading,
      writeReviewUrl: buildWriteReviewUrl(placeId),
      mapsEmbedUrl: placeholder ? GOOGLE_MAPS_EMBED_FALLBACK : buildMapsEmbedUrl(placeId),
      usingFallbackEmbed: placeholder,
    };
  }, [content, loading]);
}
